---
sidebar: auto
sidebarDepth: 2
---

# 魔方 Cube

> Copyright (c) 2019-present Lenovo China Services

- 全渠道接入客户  多样化沟通
公众号/小程序/Web/Wap/H5/IOS/Andriod/Hot line

- 智能化交付  高效流转  跨部门协作
在线、呼叫、客户等多场景实时创建工单 / 一键流转，方便跨部门协同

- 八大产品板块  全面提升服务品质
全渠道接入/智能路由/用户识别/诊断机器人/智能交付/工单管理/智能运营/智能全量质检

## Start

``` bash

# Clone project
git clone git@10.120.24.200:FE/cube.git

# Switching branch
git checkout develop

# Install dependencies
npm install

```

相关文档：
- 后台脚手架：[vue-element-admin](https://panjiachen.github.io/vue-element-admin-site/zh/)
- [腾讯云通信服务端集成](https://cloud.tencent.com/document/product/269/1518)
- [腾讯云通信客户端集成](https://cloud.tencent.com/document/product/269/1515)

## Vue 开发风格指南

> 参考： https://cn.vuejs.org/v2/style-guide/

### Git & JIRA

魔方项目和JIRA 做了集成，能够在提交记录里关联JIRA Issue

参考： https://confluence.atlassian.com/bitbucket/use-smart-commits-298979931.html

栗子：
```
JRA-123 JRA-234 JRA-345 #解决 #comment 这里写备注信息，将自动填写到JIRA备注里
```
 
Resolves issues JRA-123, JRA-234 and JRA-345.
 
Multiple issue keys must be separated by whitespace or commas.

### Cube permission
魔方项目权限需要中台配置，各新增页面如需配置权限，请发邮件给IT宜营


注意事项：
- 各页面route的name必须为英文且全局唯一
- 权限配置项邮件中，路径选项填写为新增页面的name值，非实际页面路径
- 本地环境中不进行权限验证，如涉及权限校验，请在/src/utils/index.js中修改如下代码
将process.env.ENV_CONFIG修改为当前环境


```javascript
export const isProd = process.env.ENV_CONFIG === 'prod'
```
 