---
home: true
heroImage: https://cube-resources.lenovo.com.cn/cube/Image/20197/casefile_sa9lajrvgbm.png
actionText: 快速开始
actionLink: /quick-start
features:
- title: 流程讲解
  details: 包含工作台的核心流程梳理，快速理解全局背景。
- title: 组件文档
  details: 为了快速迭代，我们为产品化内容开发了诸多可复用的组件。
- title: 约定文档
  details: 为了保证样式风格统一、交互和操作统一，我们都有约定和规范。
footer: Copyright © 2019-present DT XCube
---

::: tip
快速导航

[1. 魔方产品化API](http://cube.g.lenovo.com.cn/api-container/apidoc)
[2. vue-element-admin 文档](https://panjiachen.github.io/vue-element-admin-site/zh/)
:::

# 索引页

## 准备开发
- [快速开始](./quick-start.md)
- [Git 工作流](./CONTRIBUTING.md)

## 公共组件和能力
Vue 组件
- [右键菜单（ContextMenu）](./components/context-menu.md)
- [图片查看器（ImageViewer）](./components/image-viewer.md)
- [定制样式的时间选择器（ExtDatePicker）](./components/ext-date-picker.md)

Vuex module
- [API loading，防止重复点击利器](./components/api-loading.md)
- [Permission 菜单和按钮权限判断](./components/permission.md)

## 结构和内容约定

- [呼叫中心流程和说明](./call-center.md)
- [呼叫中心右侧功能区开发](./appointments/functional.md)

## 线上错误日志收集

- 待完善