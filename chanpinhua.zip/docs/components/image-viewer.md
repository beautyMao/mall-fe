# image viewer

> 图片查看器，基于viewerjs，提供图片的放大缩小旋转等常规操作

## 使用

## Slots

| 名称 | 说明  |
|------|------------------------|
| —— | 默认填充的插槽，点击将初始化并显示查看器  |

## Props

| 参数                    | 说明  | 类型 | 可选值 | 默认值 |
|-------------------------|-------|------|--------|--------|
| src | 大图路径  | String | -      | -      |
| srcs | 大图列表的路径  | Array | -      | -      |


## Methods

| 方法名                    | 说明  | 方法参数
|-------------------------|-------|------|
| showViewer | 初始化图片查看器并显示图片  | index, 默认显示第几张图，默认为0 |
| destroy | 销毁图片查看器  | 无 |
| fullscreenToggle | 图片查看器全屏  | 无 |
| imageViewClose | 关闭图片查看器  | 无 |

## 在模板中使用

```vue
<image-viewer :src="'https://cube-resources.lenovo.com.cn/cube/Image/20196/89715160165001121560238426309.jpeg'">
  <img src="https://cube-resources.lenovo.com.cn/cube/Image/20196/89715160165001121560238426309.jpeg">
</image-viewer>
```

## 使用方法触发
```vue
<template>
  <div>
    <button @click="show">显示图片</button>
    <image-viewer :src="imageSrc" ref="imageView"></image-viewer>
  </div>
</template>
<script>
export default {
  data() {
   return {
    imageSrc: 'https://cube-resources.lenovo.com.cn/cube/Image/20196/89715160165001121560238426309.jpeg'
   }
  },
  methods: {
   show() {
    this.$refs.imageView.showViewer()
   }
  }
}
</script>
```

## License

[MIT](http://opensource.org/licenses/MIT)

Copyright (c) XCube Lenovo
