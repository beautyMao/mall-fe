# Extension el-date-picker

> 定制样式的时间选择器，支持时间跨度设定

![样式示例](https://cube-resources.lenovo.com.cn/cube/Image/20197/2467781924751871562920962152.png)

## 使用

## Props

| 参数                    | 说明  | 类型 | 可选值 | 默认值 |
|-------------------------|-------|------|--------|--------|
| span | 时间跨度设置，文案描述7天内，span=6  | Number | -      | 0      |
| placehoder | 前缀提示文案  | String | -      | -      |

## Events

| 事件名                    | 说明  | 事件参数
|-------------------------|-------|------|
| range-error | 跨度超出设置  | span 跨度 |

## 在模板中使用

```vue
<el-form-item required>
  <ext-date-picker
    v-model="range"
    size="large"
    placehoder="创建日期"
    type="daterange"
    range-separator="至"
    start-placeholder="开始日期"
    end-placeholder="结束日期"
    format="yyyy 年 MM 月 dd 日"
    :span="6"
    @range-error="handleRangeError"
    value-format="yyyy-MM-dd"></ext-date-picker>
</el-form-item>
```

## License

[MIT](http://opensource.org/licenses/MIT)

Copyright (c) XCube Lenovo
