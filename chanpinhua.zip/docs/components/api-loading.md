---
sidebar: auto
sidebarDepth: 2
---

# Vuex api loading

> 拦截请求并与vuex loading 绑定，结合element ui 的v-loading director 方便快速的根据接口制作页面loading 效果，
> 以及防止用户重复点击

该功能已经集成到request，作为一个中间件来自动处理。

## 如何使用

在模板中使用

```vue
<template>
  <container v-loading="loading('knowledgeSearch')">
    ...
    <button :disabled="loading('/api/wb/notification/email')"></button>
  </container>
</template>
```

```javascript
export default {
  computed: {
    ...mapGetters('api', ['loading'])
  }
}
```

## 部分请求确定不用vuex loading

只需要增加config 参数，vuexLoading = false，可以禁用某个请求的vuex loading。

```javascript
import requestBase from '@/utils/request'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 网络延迟获取
export function getNetStatusPing() {
  return request({
    url: '/api/wb/netstatus/ping',
    method: 'get',
    vuexLoading: false
  })
}
```