---
sidebar: auto
sidebarDepth: 2
---

# Permission 权限判断

> 提供菜单和按钮权限判断能力，方便控制页面或者模块的加载。

## 如何使用

Permission 已经作为vuex store module，通过使用getter 方便获取：

```vue
<template>
  <container>
    <button :disabled="!buttonPermission('accountDelete')"></button>
  </container>
</template>
```

```javascript
export default {
  computed: {
    ...mapGetters([
      'buttonPermission'
    ])
  }
}
```
