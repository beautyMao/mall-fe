---
sidebar: auto
sidebarDepth: 2
---

## 呼叫中心开发文档

- 由于简化了部分 vuex state 的生成，部分变量命名方式直接使用的后端返回值。

腾讯云 IM 错误码文档： https://cloud.tencent.com/document/product/269/1671

### 腾讯 IM 事件监听注册

我们已经封装了 IM 的消息接收，能够同时处理用户消息和管理员通知

```javascript
txim.addEventListener(EVENT_TYPE.NOTIFY, message => {
  console.log('收到通知消息：', message)
})
txim.addEventListener(EVENT_TYPE.MSG, message => {
  console.log('收到的聊天消息：', message.text)
})
txim.addEventListener(EVENT_TYPE.LOGIN, message => {
  this.$message.success('IM 登录成功')
})
txim.addEventListener(EVENT_TYPE.RECONNECT, message => {
  this.$message.warning('IM 网络状态不好已断开，正在尝试重连')
})
txim.addEventListener(EVENT_TYPE.CONNECTRET, message => {
  this.$message.success('IM 已连接')
})
txim.addEventListener(EVENT_TYPE.KICKOFF, message => {
  this.$notify.error({
    title: 'IM 被踢出',
    message:
      'IM 已经离线，当前无法收到用户发来的消息，请确保账户没有被重复登录之后，刷新页面重新连接。',
    duration: 0
  })
})
```

### 腾讯 IM 自定义消息格式示例

普通文本消息

```json
{
  "MessageType": "CC.ChatMessage",
  "MessageBody": {
    "SessionID": "4qnemOZc-BP",
    "ChatRoute": "webchat",
    "ClientType": "user",
    "SendTime": "2019-05-22 00:54:31",
    "Body": {
      "Type": "Text",
      "Content": {
        "Text": "是，表情和文字/::(/::(",
        "Emotion": 2.5
      }
    }
  }
}
```

图片、语音、视频等媒体资源

```json
{
  "MessageType": "CC.ChatMessage",
  "MessageBody": {
    "SessionID": "4qnemOZc-BP",
    "ChatRoute": "webchat",
    "ClientType": "user",
    "SendTime": "2019-05-22 02:07:16",
    "SourceUrl": "https://cube-resources.lenovo.com.cn/cube/Image/20195/22048154088965571558462036955.png",
    "Body": {
      "Type": "Image",
      "Content": {
        "MediaUrl": "https://cube-resources.lenovo.com.cn/cube/Image/20195/22048154088965571558462036955.png"
      }
    }
  }
}
```

### 通知类消息

由服务端主动推送给工程师的消息：
- Timeout 会话超时服务端关闭会话
- CreateSession 新用户会话通知
- UserCloseSession 用户主动关闭了会话（webchat）
- Appraise 用户点评信息
- CheckStatus 跨天工程师的0点状态被置为离线的通知消息

```json
{
  "MessageType": "BC.Notification",
  "MessageBody": {
    "Body": {
      "Type": "CreateSession",
      "Content": {
        "Text": "创建会话通知"
      }
    }
  }
}
```

## 用户会话（Session）说明

### 结构

- 会话基本属性：id, cube_uid, customer_id, user_name, engineer_name
- 消息记录相关：caseList, messages, draft
- 会话状态：userActive, isVirtual
