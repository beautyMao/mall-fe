---
sidebar: auto
sidebarDepth: 2
---

# functional common

> 抽象出来的功能区父级组件

## 右侧功能区简介

一个tab page 组件专注做一件事情即可，不建议嵌套多个page

每个session 在tab page 里应该拥有独立的临时数据，使用vue 的mixin 方式来让新建的tab page 拥有这项能力。

需要为每个tab page 建立独立的文件夹，提供`index.vue` 入口文件，并且组件内提供了`meta` 属性。
我们会自动的加载相应的tab page 到功能区，具体的`meta` 属性内容如下：

```javascript
export default {
  // 用于标记
  meta: {
    title: 'Demo',
    icon: 'table',
    visible: true,
    name: 'demo'
  }
  // ...其他vue 内容
}
```

## 如何使用

### 基本用法

```javascript
import funcCommon from '../func-common'

const defaultData = {
  title: '默认的标题',
  name: '',
  sex: '1',
  birthday: ''
}

export default {
  // 用于标记
  meta: {
    title: 'Demo',
    icon: 'table',
    visible: true,
    name: 'demo'
  },
  mixins: [funcCommon],
  data() {
    return {
      // 这里不要再使用 'data' 这个key，因为已经在funcCommon 里使用了
      other: 'ok'
    }
  },
  methods: {
    // 每个新建立的session 可以从这里获得一份全新的初始化临时数据
    initPageData() {
      return { ...defaultData }
    }
  }
}
```

在不同session 间切换时，tab page 将自动选用对应的临时数据。

```html
<div class="func-panel">
  <h2>查询客户信息</h2>
  <h3>currentSessionId is: {{ currentSessionID }}</h3>

  <p>{{other}}</p>

  <form v-if="currentSessionID">
    <el-input v-model="pageData.title" placeholder="title" />
    <el-input v-model="pageData.name" placeholder="name" />
  </form>
  <p v-else>数据加载中</p>

</div>
```

### 空框下的数据

在组件初始化时，自动的为针对能够在空框下使用的组件，组件将在空框下始终使用一份数据。

### 计算属性在异步赋值时的问题

比如如下一段代码：

```javascript
export default {
  methods: {
    onPageDataInit(session) {
      getIRList(session.cube_uid).then(res => {
        // 这里存在异步设置属性
        this.pageData.IRData.list = this.$get(res, 'data.case_info', [])
      })
    },
    longAsyncAction() {
      bigTask().then((res) => {
        this.pageData.data = res.data
      })
    }
  }
}
```

有以下两个场景：
- 刷新页面，同时初始化多个session，onPageDataInit 被多次调用
- 一个耗时的异步动作，在得到响应时可能已经切换了session

在得到异步数据结果之后，很有可能切换了用户或者进入currentSession 发生了变化，导致这里的pageData 并非是当前session 的内容。
所以，我们需要获得一份当前session 下的pageData，并在之后的异步完成后正确的赋值。

修改的代码如下：
```javascript
export default {
  methods: {
    onPageDataInit(session, pageData) {
      getIRList(session.cube_uid).then(res => {
        pageData.IRData.list = this.$get(res, 'data.case_info', [])
      })
    },
    longAsyncAction() {
      // 获取当前session 下对应的数据副本
      const page = this.getPageData()
      bigTask().then((res) => {
        page.data = res.data
      })
    }
  }
}
```

## Methods

### 主动调用

子组件内可以主动调用的方法。

| 方法名                    | 说明  | 方法参数
|-------------------------|-------|------|
| getPageData | 为解决异步获取数据直接去修改pageData 可能错乱的问题  | id: session id，默认为当前会话 |
| resetPageData | 提供重置当前页面数据的方法  | avoidPageDataInit，不触发page data init 事件，默认false |
| gotoPage | 前往下一个tab page，当然也可以在组件内容使用emit('toggleTab')  | name: 下一个tab 名称；data: 携带的参数 |

### 被动调用

子组件内被动调用的方法，覆盖即可。

| 方法名                    | 说明  | 方法参数
|-------------------------|-------|------|
| initPageData | 子组件`必须`要覆盖并实现自己的初始化数据方法  | id: session id，默认为当前会话 |
| onPageDataInit | 当新的会话（包括刷新页面后获取的会话）出现时，通知父级根据session id 可以做初始化  | session, pageData |
| onDefaultPageDataInit | 当空框（默认会话）出现时，通知父级根据DEFAULT_KEY 可以做初始化  | 无 |
| setPageExtData | 接收上一个tab page 跳转时传递的参数  | data: 携带的参数 |