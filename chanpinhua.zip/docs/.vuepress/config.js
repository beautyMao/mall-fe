module.exports = {
  title: 'XCube',
  description: 'XCube workbench Document',
  head: [
    ['link', { rel: 'icon', href: '/logo.png' }]
  ],
  base: '/workbench/docs/',
  themeConfig: {
    repo: 'http://g.lenovo.com.cn/CUBE/workbench',
    // 默认为 false，设置为 true 来启用
    editLinks: true,
    // 自定义编辑链接的文本。默认是 "Edit this page"
    editLinkText: '在Gitlab上编辑此页',
    // 如果你的文档不在仓库的根目录下：
    docsDir: 'docs',
    lastUpdated: '最后更新时间',
    nav: [
      { text: 'Home', link: '/' },
      { text: 'Prds', link: 'http://g.lenovo.com.cn/CUBE/DOC' }
    ]
  }
}
