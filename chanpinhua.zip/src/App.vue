<template>
  <div id="app">
    <keep-alive exclude="login">
      <router-view />
    </keep-alive>
  </div>
</template>

<script>
  import { initEsLog } from './api/log'
  import { mapGetters } from 'vuex'

  export default {
    name: 'app',
    computed: mapGetters({
      user: 'user'
    }),
    mounted() {
      initEsLog()
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss">
  $scrollBase: #bdc3c7;
  $scrollBackground: #f5f5f5;
  body {
    // 280+400+480=1160px
    min-width: 1160px;
  }

  ::-webkit-scrollbar {
    width: 7px;
    height: 7px;
  }

  ::-webkit-scrollbar-button {
    width: 0px;
    height: 0px;
  }

  ::-webkit-scrollbar-thumb {
    background: $scrollBase;
    border: 0px none #ffffff;
    border-radius: 50px;
  }

  ::-webkit-scrollbar-thumb:hover {
    background: darken($scrollBase, 5%);
  }

  ::-webkit-scrollbar-thumb:active {
    background: darken($scrollBase, 10%);
  }

  ::-webkit-scrollbar-track {
    background: $scrollBackground;
    border: 0px none #ffffff;
    border-radius: 50px;
  }

  ::-webkit-scrollbar-track:hover {
    background: darken($scrollBackground, 5%);
  }

  ::-webkit-scrollbar-track:active {
    background: darken($scrollBackground, 10%);
  }

  ::-webkit-scrollbar-corner {
    background: transparent;
  }
</style>
