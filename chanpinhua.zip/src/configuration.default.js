export default {
  version: 'try-free-v1.0.0',
  im: { appid: '1400249005' },
  api: {
    base: '/api',
    cti: 'https://cube.lenovo.com.cn/cti',
    oss: 'https://cube-resources.lenovo.com.cn/',
    upload: '/api/wb/case/up',
    domain: 'imccdev.lenovo.com.cn'
  },
  permission: {
    // 网页插件
    // 定制化咨询界面
    // 多媒体沟通
    'webchat': { 'plugin': true, 'custom_page': true, 'media_message': true },
    // 多公众号对接
    'wechat': { 'official_accounts': true },
    'workbench': [],
    // 自定义点评推送
    'evaluation': { 'custom_push_config': true },
    // 短信推送 ok
    // 工单记录查询
    'engineer_helper': { 'send_short_message': true, 'order_log_search': true },
    // 客服标签管理 route
    // 客户标签管理 ok
    // 标签匹配规则 route
    'tag': { 'engineer_manager': true, 'customer_manager': true, 'matching_rule': true },
    'manager': { 'ccp_dashboard': true },
    'wisdom': {
      // 智能复合路由规则
      'route': true,
      // 智能情绪分析 ok
      'emotion': true,
      // 会话情绪监控及报表
      'emotion_report': true,
      // 智能推荐
      'recommend': true,
      // 自动优化排序
      'auto_sort': true,
      // 支持手动检索
      'manual_search': true,
      // 属地天气展示
      'weather': true,
      // 获取手机地理位置
      'phone_location': true
    },
    // 工单 ok
    'order': true
  }
}
