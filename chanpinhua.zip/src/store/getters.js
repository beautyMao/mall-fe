const getters = {
  sidebar: state => state.app.sidebar,
  size: state => state.app.size,
  device: state => state.app.device,
  user: state => state.user,
  token: state => state.user.token,
  avatar: state => state.user.allInfo.avatar,
  name: state => state.user.name,
  roles: state => state.user.roles,
  visitedViews: state => state.tagsView.visitedViews,
  cachedViews: state => state.tagsView.cachedViews,
  messageLogs: state => state.messageLog.logs,
  permissionRouters: state => state.permission.routers,
  addRouters: state => state.permission.addRouters,
  allInfo: state => state.user.allInfo, // 客服所有信息
  engineerCode: state => state.user.allInfo.code,
  sessionId: state => state.call.currentSessionID, // 获取当前会话用户
  currentStatus: state => state.user.currentStatus, // 获取当前登录用户的工作状态
  // 获取单个按钮权限
  buttonPermission: state => keyName => {
    if (process.env.VUE_APP_ENV_CONFIG === 'dev') {
      return true
    } else {
      return state.user.buttonPermission.findIndex(item => item.keyword === keyName) > -1
    }
  }
}
export default getters
