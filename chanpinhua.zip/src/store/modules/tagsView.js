import Vue from 'vue'

// 为了能够放到sessionStorage 里，简化router view 结构
const convertView = (routerView) => {
  return {
    title: routerView.meta.title || 'no-name',
    name: routerView.name.replace(/\B([A-Z])/g, '_$1').toLowerCase(),
    path: routerView.path,
    fullPath: routerView.fullPath,
    params: routerView.params,
    query: routerView.query,
    cache: !routerView.meta.noCache
  }
}

const tagsView = {
  namespaced: true,
  state: {
    visitedViews: [
      // {
      //   path: '/xxx',
      //   title: 'this is xxx',
      //   fullPath: '/xxx?a=1',
      //   name: 'xx'
      // }
    ],
    cachedViews: []
  },
  mutations: {
    INIT_ALL_VIEW: (state, views) => {
      state.visitedViews = views.map(view => {
        view.name = view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase()
        return view
      })
      state.cachedViews = views.filter(view => view.cache).map(view => view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase())
    },
    ADD_VISITED_VIEW: (state, view) => {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      if (state.visitedViews.some(v => v.path === view.path)) return
      state.visitedViews.push(convertView(view))
    },
    ADD_CACHED_VIEW: (state, view) => {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      if (state.cachedViews.includes(view.name)) return
      if (!view.meta.noCache) {
        state.cachedViews.push(view.name)
      }
    },

    DEL_VISITED_VIEW: (state, view) => {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      for (const [i, v] of state.visitedViews.entries()) {
        if (v.path === view.path) {
          state.visitedViews.splice(i, 1)
          break
        }
      }
    },
    DEL_CACHED_VIEW: (state, view) => {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      for (const i of state.cachedViews) {
        if (i === view.name) {
          const index = state.cachedViews.indexOf(i)
          state.cachedViews.splice(index, 1)
          break
        }
      }
    },

    DEL_OTHERS_VISITED_VIEWS: (state, view) => {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      for (const [i, v] of state.visitedViews.entries()) {
        if (v.path === view.path) {
          state.visitedViews = state.visitedViews.slice(i, i + 1)
          break
        }
      }
    },
    DEL_OTHERS_CACHED_VIEWS: (state, view) => {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      for (const i of state.cachedViews) {
        if (i === view.name) {
          const index = state.cachedViews.indexOf(i)
          state.cachedViews = state.cachedViews.slice(index, index + 1)
          break
        }
      }
    },

    DEL_ALL_VISITED_VIEWS: state => {
      state.visitedViews = []
    },
    DEL_ALL_CACHED_VIEWS: state => {
      state.cachedViews = []
    },
    // 这里的目的也就是更新full path
    UPDATE_VISITED_VIEW: (state, view) => {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      for (let i = 0; i < state.visitedViews.length; i++) {
        if (state.visitedViews[i].path === view.path) {
          Vue.set(state.visitedViews, i, convertView(view))
          break
        }
      }
    }
  },
  actions: {
    initAllViews({ commit }, views) {
      commit('INIT_ALL_VIEW', views)
    },
    addView({ dispatch }, view) {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      dispatch('addVisitedView', view)
      dispatch('addCachedView', view)
    },
    addVisitedView({ commit }, view) {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      commit('ADD_VISITED_VIEW', view)
    },
    addCachedView({ commit }, view) {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      commit('ADD_CACHED_VIEW', view)
    },

    delView({ dispatch, state }, view) {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      return new Promise(resolve => {
        dispatch('delVisitedView', view)
        dispatch('delCachedView', view)
        resolve({
          visitedViews: [...state.visitedViews],
          cachedViews: [...state.cachedViews]
        })
      })
    },
    delVisitedView({ commit, state }, view) {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      return new Promise(resolve => {
        commit('DEL_VISITED_VIEW', view)
        resolve([...state.visitedViews])
      })
    },
    delCachedView({ commit, state }, view) {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      return new Promise(resolve => {
        commit('DEL_CACHED_VIEW', view)
        resolve([...state.cachedViews])
      })
    },

    delOthersViews({ dispatch, state }, view) {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      return new Promise(resolve => {
        dispatch('delOthersVisitedViews', view)
        dispatch('delOthersCachedViews', view)
        resolve({
          visitedViews: [...state.visitedViews],
          cachedViews: [...state.cachedViews]
        })
      })
    },
    delOthersVisitedViews({ commit, state }, view) {
      console.log(view)
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      return new Promise(resolve => {
        commit('DEL_OTHERS_VISITED_VIEWS', view)
        resolve([...state.visitedViews])
      })
    },
    delOthersCachedViews({ commit, state }, view) {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      return new Promise(resolve => {
        commit('DEL_OTHERS_CACHED_VIEWS', view)
        resolve([...state.cachedViews])
      })
    },

    delAllViews({ dispatch, state }, view) {
      // view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      return new Promise(resolve => {
        dispatch('delAllVisitedViews', view)
        dispatch('delAllCachedViews', view)
        resolve({
          visitedViews: [...state.visitedViews],
          cachedViews: [...state.cachedViews]
        })
      })
    },
    delAllVisitedViews({ commit, state }) {
      return new Promise(resolve => {
        commit('DEL_ALL_VISITED_VIEWS')
        resolve([...state.visitedViews])
      })
    },
    delAllCachedViews({ commit, state }) {
      return new Promise(resolve => {
        commit('DEL_ALL_CACHED_VIEWS')
        resolve([...state.cachedViews])
      })
    },

    updateVisitedView({ commit }, view) {
      view = { ...view, name: view.name.replace(/\B([A-Z])/g, '_$1').toLowerCase() }
      commit('UPDATE_VISITED_VIEW', view)
    }
  },
  getters: {
    visitedViews: state => state.visitedViews,
    cachedViews: state => state.cachedViews
  }
}

export default tagsView
