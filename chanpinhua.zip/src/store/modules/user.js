// import Raven from 'raven-js'

import { getInfo, login } from '@/api/login'
import { engineerStatus, getEngStatus, getLoginPermission } from '@/api/public'
import { getToken, removeToken } from '@/utils/auth'
import { getLocalStorage } from '@/utils/local-storage'

const user = {
  state: {
    token: getToken(), // token
    roles: [], // 权限列表
    allInfo: {
      avatar: '',
      business_id: 1,
      chat_limit: 5,
      code: '',
      email: '',
      group_id: null,
      im_sign: '',
      last_login_time: '2019-09-04 09:22:57',
      name: '',
      phone: '',
      phone_state: 'offline',
      queue_limit: 5,
      status: 1,
      text_state: 'offline',
      phone_queues: [],
      text_queues: []
    },
    // 客服状态相关
    currentStatus: 'offline',
    permission: false,
    buttonPermission: []
  },

  mutations: {
    SET_TOKEN: (state, token) => {
      state.token = token
    },
    SET_ROLES: (state, roles) => {
      state.roles = roles
    },
    SET_ENGINEER_INFO: (state, allInfo) => {
      state.allInfo = Object.assign(state.allInfo, allInfo)
    },
    CHANGE_STATUS: (state, nextStatus) => {
      state.currentStatus = nextStatus
    },
    SET_PERMISSION: (state, permission) => {
      state.permission = permission
    },
    SET_PERMISSION_BUTTONS: (state, buttonPermission) => {
      state.buttonPermission = buttonPermission
    }
  },

  actions: {
    // 登录
    Login({ commit, state, dispatch }, userInfo) {
      return login(userInfo.username, userInfo.password, userInfo.captcha).then(response => {
        commit('SET_ENGINEER_INFO', {
          code: userInfo.username.trim()
        })
        dispatch('call/loginSoftphone')
        return response.data
      })
    },

    // 获取客服信息，在客服成功登陆之后，在router 守卫中调用
    GetInfo({ commit }) {
      return getInfo().then(response => {
        commit('SET_ENGINEER_INFO', { ...response.data })
        // 初始化本地存储
        const engineerCode = response.data.code
        engineerCode && getLocalStorage(engineerCode)

        return getLoginPermission()
        // Raven.setUserContext({
        //   id: data.code,
        //   username: data.name
        // })
        // return getLoginPermission()
      }).then(respone => {
        const data = respone.data.menu

        if (respone.data.button) {
          // button Permission
          const buttonPermission = respone.data.button
          if (buttonPermission) {
            commit('SET_PERMISSION_BUTTONS', buttonPermission)
          }
        }

        if (!respone.data.menu) {
          const permissionList = []
          commit('SET_PERMISSION', permissionList)
          return permissionList
        } else {
          // flatten data
          const flatten = function(data) {
            if (!data.childs.length) {
              return [data.keyword]
            } else {
              return [].concat(data.keyword).concat(...data.childs.map(flatten))
            }
          }
          const permissionList = [].concat(...data.map(flatten)).map(path => path)
          commit('SET_PERMISSION', permissionList)
          return permissionList
        }
      })
    },

    // 切换工作状态
    changeWorkStatus({ commit, state }, nextStatus) {
      return engineerStatus(state.allInfo.code, state.currentStatus, nextStatus).then(response => {
        commit('CHANGE_STATUS', nextStatus)
        return response
      })
    },

    // 登出
    LogOut({ commit, state }) {
      return new Promise((resolve, reject) => {
        commit('SET_TOKEN', '')
        sessionStorage.removeItem('tag-view:views')
        removeToken()
        resolve()
      })
    },

    // 前端 登出
    FedLogOut({ commit }) {
      return new Promise(resolve => {
        commit('SET_TOKEN', '')
        removeToken()
        resolve()
      })
    },

    // 初始化客服工作状态
    // todo 可以被getInfo 里的信息替代了
    initEngStatus({ commit }) {
      return getEngStatus().then(response => {
        const currentStatus = response.data.current_status || 'offline'
        commit('CHANGE_STATUS', currentStatus)
        return currentStatus
      })
    }
  }
}

export default user
