import get from 'lodash.get'
import { debounce } from '@/utils'
import { updateUserData } from '@/api/call-center/softphone'
import { CallType, FunctionPoint, MessageName } from '@/store/modules/call-center/voice/enum'

/**
 * 手机号如果带 90|9 自动去除
 * @param phoneLike
 * @return {*}
 */
export const removePhonePrefix = (phoneLike) => {
  if (/^(9|90|0)1[3456789]\d{9}$/.test(phoneLike)) {
    return phoneLike.replace(/^90|^0|^9/, '')
  } else if (phoneLike.length !== 7) {
    return phoneLike.replace(/^9/, '')
  }
  return phoneLike
}

// 考虑一下虚拟运营商
export const isMobile = (phoneLike) => {
  return /^1[3456789]\d{9}$/.test(phoneLike)
}

// 是否是内部号码
export const isInternalNumber = (phone) => {
  return /^805\d{4}$/.test(phone)
}

/**
 * 工程师或者用户主动触发的电话事件，而非程序触发的自动流程
 * 用于筛掉报工号、转满意度 等程序流程触发的各类事件
 * call.userData.functionPoint 属于随路数据，在接下来的事件中都会存在
 * 在store handle 里做的就是收到call.userData.functionPoint 之后立即updateUserData 将其移除
 * @param data
 * @return {boolean}
 */
export const isMankindOperation = ({ data }) => {
  const { call: { callType }, messageName } = data
  const operation = get(data, 'call.userData.ecloud_consult_operation')
  const operationNames = ['transfer', 'conference']

  // 在转接接入方，operation === 'transfer||conference' 可以放行
  // 这个时候要处理转接操作，创建会话
  if (callType === CallType.Consult && messageName === MessageName.EventRinging) {
    return operationNames.includes(operation)
  }

  const funcName = get(data, 'call.userData.functionPoint', '')

  // 在转满意度释放时、在完成转接释放时，可以放行，这里同时排除满意度路由点的release 事件
  if (messageName === MessageName.EventReleased) {
    if ([FunctionPoint.ToSatisfaction, FunctionPoint.Transfer].includes(funcName)) {
      return callType !== CallType.Consult
    }
  }

  // 在转接接入方，振铃可以放行
  if (funcName === FunctionPoint.Transfer && messageName === MessageName.EventRinging) {
    return true
  }

  // 首要判断依据，只要存在，就认为是自动流程触发
  const isAutoOperation = funcName !== ''
  if (isAutoOperation) {
    return false
  }

  // 转接前会hold 当前session，这个操作与先前主动hold 的唯一区别就是userData.ecloud_consult_operation = transfer
  // 这个hold 会在updateVoiceUserData 下给自动移除
  // 什么时候变成 conference？ 报工号使用的是Conference 模式
  if (operation && messageName === MessageName.EventHeld) {
    return !operationNames.includes(operation)
  }

  // 未命中以上任何一个，可以认为是工程师操作产生的事件，需要处理
  return true
}

/**
 * 对于连续触发的更新随路动作，集中在一起合并发送
 * @param connId
 * @param data
 */
export const updateVoiceUserData = (connId, data) => {
  userDataMap.set(connId, Object.assign(userDataMap.get(connId) || {}, data))
  debouncedUpdateUserData(connId, data)
}
const userDataMap = new Map()

const debouncedUpdateUserData = debounce((connId, data) => {
  userDataMap.forEach((data, connId) => {
    updateUserData(connId, data)
  })
  userDataMap.clear()
}, 500)
