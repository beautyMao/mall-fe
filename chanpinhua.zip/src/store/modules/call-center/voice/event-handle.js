/* eslint-disable */
import * as api from '@/api/call-center/softphone'
import {
  MessageType,
  CallState,
  AgentState
} from '@call/voice/enum'
import get from 'lodash.get'
import * as types from '@call/mutation-types'
import sessionHandle from '@/store/modules/call-center/voice/session-handle'
import * as vActions from './actions'
import { isInternalNumber, updateVoiceUserData } from '@call/voice/util'

let dialEventTrace = ''

const onCallStateDialing = ({ commit, state, rootGetters }, data) => { // 拨号中
  const { voice } = state
  const { call: { connId, callType } } = data

  if (callType === 'Consult') { // 咨询第三方
    api.attachUserData(voice.connId,{
      releaseEventTrace2: `dial`,
      connId: connId
    })
    commit(types.SET_VOICE_TRANSFERCONNID, connId)
    dialEventTrace = 1
    vActions.telStatusAll({ commit, state, rootGetters }, 22, 1) // 22
    vActions.telStatusAll({ commit, state, rootGetters }, 14, 2) // 14
  } else {
    commit(types.SET_VOICE_TRANSFERCONNID, '')
    vActions.telStatusAll({ commit, state, rootGetters }, 7, 3) // 7
    commit(types.SET_VOICE_CONNID, connId)
  }
}

const onCallStateEstablished = ({ commit, state, rootGetters }, data) => { // 通话中
  const { voice } = state
  const { call: { connId, callType }, messageName, thirdPartyRole } = data
  const ecloud_consult_operation = get(data, 'call.userData.ecloud_consult_operation')
  const releaseEventTrace2 = get(data, 'call.userData.releaseEventTrace2')
  const releaseEventTrace = get(data, 'call.userData.releaseEventTrace')
  const _Function = get(data, 'call.userData.Function')
  const functionPoint = get(data, 'call.userData.functionPoint')
  const ecloud_retriveType = get(data, 'call.userData.ecloud_retriveType')
  const otherDn = data.otherDn
  // const RTargetAgentSelected = get(data, 'call.userData.RTargetAgentSelected')
  dialEventTrace = ''
  if (callType === 'Consult') { // 是否 会议 或 转接
    if (voice.transferConnId === '') {
      if(releaseEventTrace2 === 'released'){
        vActions.telStatusAll({ commit, state, rootGetters }, 9, 4) // 9
        vActions.telStatusAll({ commit, state, rootGetters }, 23, 5) // 23
        updateVoiceUserData(voice.connId, {
          releaseEventTrace2: `released2`
        })
      }else if(releaseEventTrace2 === 'released2' && messageName === 'EventRetrieved'){
        vActions.telStatusAll({ commit, state, rootGetters }, 11, 6) // 11
      }else if(releaseEventTrace === 'released' && messageName === 'EventRetrieved'){
        vActions.telStatusAll({ commit, state, rootGetters }, 11, 7) // 11
      }else if(ecloud_consult_operation === 'transfer' || ecloud_consult_operation === 'conference'){
        vActions.telStatusAll({ commit, state, rootGetters }, 9, 8) // 9
        vActions.telStatusAll({ commit, state, rootGetters }, 23, 9) // 23
      }else if(ecloud_consult_operation === 'transfer_complete' || ecloud_consult_operation === 'conference_complete'){
        vActions.telStatusAll({ commit, state, rootGetters }, 9, 10) // 9
        vActions.telStatusAll({ commit, state, rootGetters }, 23, 11) // 23
      }else{
        vActions.telStatusAll({ commit, state, rootGetters }, 17, 12) // 17
      }
    } else {
      if (ecloud_consult_operation === 'transfer') {
        api.attachUserData(voice.connId, {
          releaseEventTrace: `establish`,
          connId: connId
        })
        vActions.telStatusAll({ commit, state, rootGetters }, 20, 13) // 20
      } else if(functionPoint === '997') { //报工号step2
        api.completeConference(voice.connId, voice.transferConnId)
      } else {
        api.attachUserData(voice.connId, {
          releaseEventTrace: 'establish',
          connId: connId
        })
        vActions.telStatusAll({ commit, state, rootGetters }, 18, 14) // 18
      }
    }
  } else { // 非 会议 或 转接
    if (messageName === 'EventPartyAdded') { // 发起会议方，会议接起
      commit(types.SET_VOICE_TRANSFERCONNID, '')
      if (_Function === '997') {
        vActions.telStatusAll({ commit, state, rootGetters }, 21, 15) // 21
      } else {
        updateVoiceUserData(voice.connId, {
          releaseEventTrace: '',
          releaseEventTrace2: '',
          connId: ''
        })
        vActions.telStatusAll({ commit, state, rootGetters }, 19, 16) // 19
      }
    } else if (messageName === 'EventPartyDeleted') {
      if (data.otherDn.length>7){
        vActions.telStatusAll({ commit, state, rootGetters }, 9, 17) // 9
        vActions.telStatusAll({ commit, state, rootGetters }, 23, 18) // 23
      } else if (_Function === '997'){
        updateVoiceUserData(voice.connId, {
          Function: '',
          transferTelQueue: ''
        })
        vActions.telStatusAll({ commit, state, rootGetters }, 9, 19) // 9
        commit(types.SET_VOICE_TRANSFERCONNID, '')
      } else {
        commit(types.SET_VOICE_TRANSFERCONNID, '')
        vActions.telStatusAll({ commit, state, rootGetters }, 24, 20) // 24
      }
    } else if (messageName === 'EventPartyChanged') { // 接受会议，会议接起
      if (thirdPartyRole === 'ConferencedBy') {
        vActions.telStatusAll({ commit, state, rootGetters }, 19, 21) // 19
      } else if (thirdPartyRole === 'TransferredBy') {
        updateVoiceUserData(voice.connId, {
          releaseEventTrace: '',
          releaseEventTrace2: '',
          connId: ''
        })
        commit(types.SET_VOICE_CONNID, connId)
        vActions.telStatusAll({ commit, state, rootGetters }, 9, 22) // 9
      }
      commit(types.SET_VOICE_CONNID, connId)
    } else if (messageName === 'EventEstablished' && thirdPartyRole === 'ConferencedBy') {
      vActions.telStatusAll({ commit, state, rootGetters }, 19, 23) // 19
    } else if (messageName === 'EventRetrieved'){
      if (ecloud_retriveType === 'retriveType') {
        vActions.telStatusAll({ commit, state, rootGetters }, 9, 24) // 9
      } else {
        if(_Function !== '997'){
          vActions.telStatusAll({ commit, state, rootGetters }, 11, 25) // 11
        }
      }
    } else {
      vActions.telStatusAll({ commit, state, rootGetters }, 9, 26) // 9
      // 非内部通话的呼入，才报工号
      if (callType === 'Inbound' && !isInternalNumber(otherDn)){
        api.reportNumber(voice.connId, rootGetters.engineerCode) //报工号step1
      }
    }
  }
}

// todo callState 没有应该没有这个状态
const onCallStateRetrieve = ({ commit, state, rootGetters }, data) => { // 接起 中
  vActions.telStatusAll({ commit, state, rootGetters }, 11, 27) // 11
}

// Held 中
const onCallStateHeld = ({ commit, state, rootGetters }, data) => {
  // data.call.userData.ecloud_consult_operation 的判断和util.isMankindOperation({ data }) 是等价的
  // ecloud_consult_operation 在满意度之后会被标记为完成
  // todo ecloud_consult_operation 可能在发起会议时产生hold 被误判
  if(dialEventTrace === '') {
    vActions.telStatusAll({ commit, state, rootGetters }, 10, 28) // 10
  } else {
    vActions.telStatusAll({ commit, state, rootGetters }, 22, 29) // 22
    dialEventTrace = ''
  }
}

const onCallStateReleased = ({ commit, state, rootGetters, dispatch }, data) => { // 干净的工作台 或 无转接 或 无会议
  const { voice } = state
  const { call: { connId, callType } } = data
  const operation = get(data, 'call.userData.ecloud_consult_operation')
  const releaseEventTrace2 = get(data, 'call.userData.releaseEventTrace2')
  const releaseEventTrace = get(data, 'call.userData.releaseEventTrace')
  const ReleasingParty = get(data, 'extensions.ReleasingParty')
  const es_satisfaction = get(data, 'call.userData.es_satisfaction')
  dialEventTrace = ''
  if (callType === 'Consult') { // 是否存在 转接 和 多方通话
    if (voice.transferConnId === '') {
      vActions.telStatusAll({ commit, state, rootGetters }, 13, 30) // 13
    } else {
      if (operation === 'transfer' || operation === 'conference') {
        if(releaseEventTrace === 'released'){
          vActions.telStatusAll({ commit, state, rootGetters }, 13, 31) // 13
        } else if(releaseEventTrace2 === 'released2'){
          vActions.telStatusAll({ commit, state, rootGetters }, 13, 32) // 13
        } else {
          // 咨询转接未被接起
          api.retrieveCall(voice.connId)
          // updateUserDataVoice(connId, prams);
          commit(types.SET_VOICE_TRANSFERCONNID, '')
          //接起
          vActions.telStatusAll({ commit, state, rootGetters }, 9, 33) // 9
        }
      } else if (es_satisfaction === '1') {
        commit(types.SET_VOICE_TRANSFERCONNID, '')
        vActions.telStatusAll({ commit, state, rootGetters }, 13, 34) // 13
      } else if (operation === 'conference_complete' || operation === 'transfer_complete') {
        updateVoiceUserData(voice.connId, {
          releaseEventTrace: '',
          releaseEventTrace2: ''
        })
        commit(types.SET_VOICE_TRANSFERCONNID, '')
        vActions.telStatusAll({ commit, state, rootGetters }, 13, 35) // 13
      } else if (get(data, 'call.userData.Function') === '999') {
        commit(types.SET_VOICE_TRANSFERCONNID, '')
        // 转接完成
        vActions.telStatusAll({ commit, state, rootGetters }, 13, 36) // 13
      } else if (get(data, 'call.userData.transferTelQueue') === '998') {
        commit(types.SET_VOICE_TRANSFERCONNID, '')
        // 转接完成
        vActions.telStatusAll({ commit, state, rootGetters }, 13, 36) // 13
      } else {
        api.retrieveCall(voice.connId) // 保持取回
        commit(types.SET_VOICE_TRANSFERCONNID, '')
        // 会议完成
        vActions.telStatusAll({ commit, state, rootGetters }, 9, 37) // 9
      }
    }
  } else {
    if (releaseEventTrace === 'establish' && ReleasingParty === '2 Remote') {
      const userDataConnId = data.call.userData.connId
      commit(types.SET_VOICE_CONNID, userDataConnId)
      commit(types.SET_VOICE_TRANSFERCONNID, '')
      updateVoiceUserData(userDataConnId, {
        releaseEventTrace: 'released'
      })
      vActions.telStatusAll({ commit, state, rootGetters }, 9, 38) // 9
      vActions.telStatusAll({ commit, state, rootGetters }, 23, 39) // 23
    } else if (ReleasingParty === '2 Remote' && callType === 'Outbound' && releaseEventTrace2 === 'dial') {
      const userDataConnId = data.call.userData.connId
      commit(types.SET_VOICE_CONNID, userDataConnId)
      commit(types.SET_VOICE_TRANSFERCONNID, '')
      vActions.telStatusAll({ commit, state, rootGetters }, 7, 40) // 7
      updateVoiceUserData(userDataConnId, { releaseEventTrace2: `released` })
    } else {
      vActions.telStatusAll({ commit, state, rootGetters }, 13, 41) // 13
    }
  }
}

const onCallStateRinging = ({ commit, state, rootGetters }, data) => { // 进线振铃
  const { call: { connId }, phoneNumber } = data
  commit('SET_VOICE_CALL_G_SANI', phoneNumber)
  vActions.telStatusAll({ commit, state, rootGetters }, 8, 42) // 8
  commit(types.SET_VOICE_CONNID, connId)
}

/**
 * onCallStateChangeMessage 拨打电话状态改变
 * @param commit
 * @param state
 * @param rootGetters
 * @param dispatch
 * @param data
 * @return
 */
const onCallStateChangeMessage = ({commit, state, rootGetters, dispatch }, { data }) => {
  const { call: { state: callState, callType, connId }, messageName } = data

  const mapAction = {
    [CallState.Dialing]: onCallStateDialing,
    [CallState.Established]: onCallStateEstablished,
    [CallState.Retrieve]: onCallStateRetrieve,
    [CallState.Held]: onCallStateHeld,
    [CallState.Released]: onCallStateReleased,
    [CallState.Ringing]: onCallStateRinging
  }
  const action = mapAction[callState]
  if (action) {
    action({ commit, state, rootGetters, dispatch }, data)
  }
}

/**
 * 坐席状态变更，被动更新魔方工程师状态
 * @param commit
 * @param state
 * @param rootGetters
 * @param dispatch
 * @param agentState
 * @param agentStateExt
 */
const onAgentStatusChanged = ({ commit, state, rootGetters, dispatch }, agentState, agentStateExt) => {
  // 坐席和按钮状态
  const telStatusMap = {
    [AgentState.LoggedOut]: 6,
    [AgentState.LoggedIn]: 2,
    [AgentState.NotReady]: 4,
    [AgentState.Ready]: (() => {
      return !rootGetters['call/showButtons'].hangUpStatus ? 3 : -1
    })(),
    // todo AgentState.AfterCallWork? 只有AgentStateExt（即displayName）才有这个值
    'AfterCallWork': 5
  }
  const nextTelState = telStatusMap[agentState]
  if (nextTelState > -1) {
    vActions.telStatusAll({ commit, state, rootGetters }, nextTelState, `43-${nextTelState}` )
  }
}

/**
 * 获得一个消息处理函数
 * 本函数体仅处理agent state 和 call state，其余交给子函数处理
 * @param commit
 * @param state
 * @param rootGetters
 * @param dispatch
 * @return {Function}
 */
export const stateChangeHandle = function(commit, state, rootGetters, dispatch) {
  return (message, type) => {
    switch (type) {
      case MessageType.DeviceStateChange: {
        const agentState = get(message, 'data.devices[0].userState.state')
        const agentStateExt = get(message, 'data.devices[0].userState.displayName')
        commit('SET_VOICE_AGENT_STATE', { agentState, agentStateExt })
        // 电话工作时间自增 与 刷新
        // 冗余了，自增后的结果除非在更多组件下公用，没有必要放到store 里，直接由组件内部去管理
        // getEngStatusTimeFn({ commit, state, rootGetters }, agentState)
        onAgentStatusChanged({ commit, state, rootGetters, dispatch }, agentState, agentStateExt)
        break
      }

      case MessageType.CallStateChange: {
        const callState = get(message, 'data.call.state')
        const callType = get(message, 'data.call.callType')
        const messageName = get(message, 'data.messageName')
        const thirdPartyRole = get(message, 'data.thirdPartyRole')
        const userData = get(message, 'data.call.userData')

        if (callState && callState !== state.voice.callState) {
          commit('SET_VOICE_CALL_STATE', callState)
        }
        if (callType && callType !== state.voice.callType) {
          commit('SET_VOICE_CALL_TYPE', callType)
        }
        if (messageName && messageName !== state.voice.messageName) {
          commit('SET_VOICE_MESSAGE_NAME', messageName)
        }
        if (thirdPartyRole !== state.voice.thirdPartyRole) {
          commit('SET_VOICE_THIRD_PARTY_ROLE', thirdPartyRole)
        }
        if (userData) commit('SET_VOICE_USERDATA', userData)
        // todo 存储全量数据？
        commit('SET_VOICE_MESSAGE_STATE', message.data)
        onCallStateChangeMessage({ commit, state, rootGetters, dispatch }, message)
        break
      }
    }

    // 拆分一下，逻辑清晰一些
    sessionHandle({ commit, state, rootGetters, dispatch, message, type })
  }
}
