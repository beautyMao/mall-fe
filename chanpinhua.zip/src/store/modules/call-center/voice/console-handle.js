/* eslint-disable */
import { CallState, EngineerStatus, MessageType } from '@call/voice/enum'
import * as util from './util'

let mankindOperationFlag = false
let currentEngineerStatus = EngineerStatus.Callin

/**
 * 新的事件处理器，尝试用新的方式去归纳整理会话相关逻辑
 * 这里只处理控制台按钮相关的状态
 * @param commit
 * @param state
 * @param rootGetters
 * @param dispatch
 * @param message
 * @param type
 */
export default ({ commit, state, rootGetters, dispatch, message, type }) => {
  // 恩，接下来都是处理CallStateChange 的内容了
  if (type !== MessageType.CallStateChange) {
    return
  }

  // 移除影响判断的随路数据
  // checkAndUpdateUserData(message)

  // 如果是自动流程产生的事件消息，跳过
  mankindOperationFlag = util.isMankindOperation({ data: message.data })
  if (!mankindOperationFlag) {
    return
  }

  const { call: { state: callState, callType }, messageName } = message.data

  const mapAction = {
    [CallState.Dialing]: onCallStateDialing,
    [CallState.Established]: onCallStateEstablished,
    [CallState.Retrieve]: onCallStateRetrieve,
    [CallState.Held]: onCallStateHeld,
    [CallState.Released]: onCallStateReleased,
    [CallState.Ringing]: onCallStateRinging
  }
  const action = mapAction[callState]
  if (action) {
    action({ commit, state, rootGetters, dispatch }, message.data)
  }
}

const onCallStateDialing = ({ commit, state, rootGetters, dispatch }, data) => {
  const { call: { transferConnId } } = data

}

const onCallStateEstablished = ({ commit, state, rootGetters, dispatch }, data) => {
  const { call: { transferConnId, callType }, messageName, thirdPartyRole } = data

}

// 据说这个状态出现在转接接起时 目前没有见到过
const onCallStateRetrieve = ({ commit, state, rootGetters, dispatch }, data) => {
}

const onCallStateHeld = ({ commit, state, rootGetters, dispatch }, data) => {
}

const onCallStateReleased = ({ commit, state, rootGetters, dispatch }, data) => {
  const { messageName } = data

}

const onCallStateRinging = ({ commit, state, rootGetters, dispatch }, data) => {
  const { call: { transferConnId, callType } } = data

}
