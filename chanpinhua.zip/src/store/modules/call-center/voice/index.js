/* eslint-disable */
import Vue from 'vue'
import {
  CallState,
  EngineerStatus,
  AgentState,
  DeviceState
} from '@call/voice/enum'
import { ClientType } from '@/store/modules/call-center/enum'
import * as actions from './actions'

// todo 后期规模如果扩大了，这里可以成为独立的vuex module
// 现在是作为store 中的call module
export default {
  state: {
    currentStatus: EngineerStatus.Offline,
    session: {
      id: '', // gensys phone id
      cubeId: '', // cube session id
      place: '', // 物理机位置
      placeip: '', // 坐席IP
      location: '' // 工程师所在区域
    },
    // 会议&多方通话&转接前协商，使用的临时session
    consultSession: {
      active: false,
      connId: '',
      transferConnId: '',
      otherDn: '',
      currentCallState: ''
    },
    g_sAni: '',
    phoneNumber: '',
    agentState: AgentState.LoggedOut,
    agentStateExt: AgentState.LoggedOut,
    deviceState: DeviceState.Inactive,
    message: {}, // event data, messageType = CallStateChange
    weather: {
      // currentCity: '北京'
    },
    callState: CallState.Released,
    workload: {
      callout_num: 0,
      callin_num: 0,
      hold_num: 0,
      call_avg_time: 0
    },
    service: [],
    firstQuestion: [],
    showButtons: {
      answer: false,
      holdStatus: false,
      dialStatus: false,
      hangUpStatus: false,
      pickUpStatus: false,
      transferStatus: false,
      completeTransferStatus: false,
      meetingStatus: false,
      completeMeetingStatus: false,
      satisfactionDegreeStatus: false
    },
    transferConnId: '',
    connId: '',
    callType: 'Outbound',
    messageName: '',
    thirdPartyRole: '',
    userData: '',
    region: ''
  },
  getters: {
    agentState: state => state.voice.agentState,
    agentStateExt: state => state.voice.agentStateExt,
    callState: state => state.voice.callState,
    deviceState: state => state.voice.deviceState,
    phoneNumber: state => state.voice.phoneNumber,
    callMessage: state => state.voice.message,
    workload: state => state.voice.workload,
    service: state => state.voice.service,
    firstQuestion: state => state.voice.firstQuestion,
    transferConnId: state => state.voice.transferConnId,
    connId: state => state.voice.connId,
    weather: state => state.voice.weather,
    showButtons: state => state.voice.showButtons,
    callType: state => state.voice.callType,
    messageName: state => state.voice.messageName,
    thirdPartyRole: state => state.voice.thirdPartyRole,
    voiceCubeId: state => state.voice.session.cubeId,
    voiceCubeSession: state => state.sessions[state.voice.session.cubeId],
    place: state => state.voice.session.place,
    sessionPhoneId: state => state.voice.session.id,
    consultSession: state => state.voice.consultSession,
    userData: state => state.voice.userData,
    region: state => state.voice.region,
    softPhoneStatus: state => state.voice.currentStatus,
    workStatus: state => state.voice.workStatus,
    g_sAni: state => state.voice.g_sAni
  },
  mutations: {
    SET_VOICE_AGENT_STATE: (state, { agentState, agentStateExt }) => {
      state.voice.agentState = agentState
      // 在这个里面能够容易区分出after call work （案面）等状态，agentState 是agentStateExt 的子集
      state.voice.agentStateExt = agentStateExt
    },
    SET_VOICE_CALL_STATE: (state, callState) => {
      state.voice.callState = callState
    },
    SET_VOICE_PHONE_NUMBER: (state, phoneNumber) => {
      state.voice.phoneNumber = phoneNumber
    },
    SET_VOICE_MESSAGE_STATE: (state, message) => { // 存储会话信息
      state.voice.message = message
    },
    SET_VOICE_WEATHER: (state, { session, weatherInfo }) => {
      state.sessions[session.id].weather = weatherInfo
    },
    SET_VOICE_WORKLOAD: (state, workload) => { // 存储服务量
      state.voice.workload = workload
    },
    SET_VOICE_REMIND: (state, { session, remind }) => { // 特殊提醒
      state.sessions[session.id].remind = remind
    },
    SET_VOICE_REGION: (state, { session, region }) => {
      state.voice.region = region
      state.sessions[session.id].region = region
    },
    SET_VOICE_SERVICE: (state, service) => { // 存储我的服务列表
      state.voice.service = service
    },
    SET_VOICE_FIRST_QUESTION: (state, firstQuestion) => { // 存储我的首问列表
      state.voice.firstQuestion = firstQuestion
    },
    SET_VOICE_TRANSFERCONNID: (state, transferConnId) => { // 存储 transferConnId
      state.voice.transferConnId = transferConnId
    },
    SET_VOICE_CONNID: (state, connId) => { // 存储 connId
      state.voice.connId = connId
    },
    SET_VOICE_USERDATA: (state, userData) => { // 存储 connId
      state.voice.userData = userData
    },
    SHOW_BUTTONS: (state, showButtons) => { // 存储 showButtons
      state.voice.showButtons = showButtons
    },
    SET_VOICE_CALL_TYPE: (state, callType) => {
      state.voice.callType = callType
    },
    SET_VOICE_MESSAGE_NAME: (state, messageName) => {
      state.voice.messageName = messageName
    },
    SET_VOICE_THIRD_PARTY_ROLE: (state, thirdPartyRole) => {
      state.voice.thirdPartyRole = thirdPartyRole
    },
    SET_VOICE_CUBE_SESSION: (state, sessionId) => {
      state.voice.session.cubeId = sessionId
    },
    SET_VOICE_CUBE_STATUS: (state, nextStatus) => {
      state.voice.currentStatus = nextStatus
    },
    VOICE_DEFAULT_SESSION: (state, { id, place, placeip, location }) => {
      state.voice.session.id = id
      state.voice.session.place = place
      state.voice.session.placeip = placeip
      state.voice.session.location = location
    },
    SET_VOICE_CALL_G_SANI: (state, g_sAni) => {
      state.voice.g_sAni = g_sAni
    },
    UPDATE_CONSULT_SESSION: (state, updateSession) => {
      state.voice.consultSession = Object.assign(state.voice.consultSession, updateSession)
    },
    SET_VOICE_QUEUE_DATA: (state, { id, queueData }) => {
      state.sessions[id].queueData = queueData
    },
    CLOSE_VOICE_SESSION: (state, session) => {
      Vue.delete(state.sessions, session.id)
      if (state.currentSessionID === session.id) {
        const nextVoiceSession = Object.values(state.sessions).find(session => session.client_type === ClientType.Telephone)
        state.currentSessionID = nextVoiceSession ? nextVoiceSession.id : null
      }
    }
  },
  actions: {
    ...actions
  }
}
