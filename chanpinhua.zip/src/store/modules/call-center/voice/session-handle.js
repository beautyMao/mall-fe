/* eslint-disable */
import {
  MessageType,
  CallState,
  EngineerStatus,
  AgentState,
  MessageName,
  CallType,
  ThirdPartyRole,
  FunctionPoint
} from '@call/voice/enum'
import get from 'lodash.get'
import * as callApi from '@/api/call-center/call-center-phone'
import * as util from './util'
import * as api from '@/api/call-center/softphone'
import { sleep } from '@/utils'
import Message from '@/utils/message-intercept'

let mankindOperationFlag = false
let currentEngineerStatus = EngineerStatus.Callin

/**
 * 新的事件处理器，尝试用新的方式去归纳整理会话相关逻辑
 * 这里只处理session 相关、魔方状态同步相关
 *
 * 会话将拆分为：
 * - preSession 即工程师转接、多方时的内部沟通，不计入正式的会话时长
 * - session 即原有正式session，可能由preSession 转换而来
 * @param commit
 * @param state
 * @param rootGetters
 * @param dispatch
 * @param message
 * @param type
 */
export default ({ commit, state, rootGetters, dispatch, message, type }) => {
  if (type === MessageType.DeviceStateChange) {
    const agentStateExt = get(message, 'data.devices[0].userState.displayName')

    // softphone 和魔方系统的状态map
    const agentStateMap = {
      [AgentState.NotReady]: (() => {
        // 创建会话时魔方会主动更改agent 为not ready，附加了reasonCode = 50，这里过滤掉
        const reasonCode = get(message, 'data.devices[0].userState.reasonCode')
        if (reasonCode === '50') {
          return false
        }
        return EngineerStatus.Offline
      })(),
      [AgentState.Ready]: EngineerStatus.Online,
      [AgentState.AfterCallWork]: EngineerStatus.Acw,
      [AgentState.AuxWork]: EngineerStatus.Rest,
      // [AgentState.Online]: EngineerStatus.Offline,
      // callApi.phoneEngineerLogout 会自动genesys offline
      [AgentState.Offline]: EngineerStatus.Logout
    }
    const nextState = agentStateMap[agentStateExt]
    if (nextState) {
      dispatch('changeCubeWorkStatus', nextState)
    }
  }

  // 恩，接下来都是处理CallStateChange 的内容了
  if (type !== MessageType.CallStateChange) {
    return
  }

  // 移除影响判断的随路数据
  checkAndUpdateUserData(message)

  // 如果是自动流程产生的事件消息，跳过
  mankindOperationFlag = util.isMankindOperation({ data: message.data })
  if (!mankindOperationFlag) {
    return
  }

  const { call: { state: callState, callType }, messageName } = message.data

  // 保存会话初始时，工程师的callType，为之后的retrieved 服务
  if (messageName === MessageName.EventDialing) {
    currentEngineerStatus = EngineerStatus.Callout
  } else if (messageName === MessageName.EventRinging) {
    currentEngineerStatus = EngineerStatus.Callin
  }

  const messageNameMap = {
    [MessageName.EventDialing]: EngineerStatus.Callout,
    [MessageName.EventRinging]: EngineerStatus.Callin,
    // 一部分主动或用户挂断的会话，将主动api.afterCallWork()
    // [MessageName.EventReleased]: (() => {
    //   return ''
    // })(),
    // 理物理机发出的hold 也会通过这里同步
    [MessageName.EventHeld]: EngineerStatus.Hold,
    [MessageName.EventRetrieved]: (() => {
      // 外呼被转入，对于工程师来看，仍然是callin，这是工程师的状态而非会话状态
      return currentEngineerStatus
    })()
  }

  const nextState = messageNameMap[messageName]
  if (nextState) {
    dispatch('changeCubeWorkStatus', nextState)
  }

  // 每次被接起时更下数据，这样就显得是实时的了
  if ([MessageName.EventRetrieved, MessageName.EventEstablished].includes(messageName)) {
    dispatch('getApiCscServiceDetails')
  }

  const mapAction = {
    [CallState.Dialing]: onCallStateDialing,
    [CallState.Established]: onCallStateEstablished,
    [CallState.Retrieve]: onCallStateRetrieve,
    [CallState.Held]: onCallStateHeld,
    [CallState.Released]: onCallStateReleased,
    [CallState.Ringing]: onCallStateRinging
  }
  const action = mapAction[callState]
  if (action) {
    action({ commit, state, rootGetters, dispatch }, message.data)
  }
}

const onCallStateDialing = ({ commit, state, rootGetters, dispatch }, data) => {
  const { call: { transferConnId } } = data

  // 魔方系统记录会话开始，满意度、转接拨号不在这里建立会话
  // 如果这里的transferId 不为空，就不能执行开始会话
  if (!transferConnId) {
    // 每次开始振铃时，将话机状态置为NotReady，reasonCode = '50'
    api.notReadyForConversion()

    dispatch('startConversion', {
      data, isCallout: true
    })
  }
}

const onCallStateEstablished = ({ commit, state, rootGetters, dispatch }, data) => {
  const { call: { transferConnId, callType }, messageName, thirdPartyRole } = data

  // 二步转接接受、多方通话加入
  const acceptRoles = [ThirdPartyRole.ConferencedBy, ThirdPartyRole.TransferredBy]
  if (messageName === MessageName.EventPartyChanged && acceptRoles.includes(thirdPartyRole)) {
    dispatch('startConversion', {
      data,
      // 转接后的内容都被认为是callin
      isCallout: false
    })
  }

  // hold 接起
  if (messageName === MessageName.EventRetrieved) {
    // 两次hold 调用才能完成一次hold 动作
    callApi.getApiCscPhoneHoldOperation({
      engineer_code: rootGetters.allInfo.code,
      session_id: state.voice.session.cubeId
    })
  }
}

// 据说这个状态出现在转接接起时 目前没有见到过
const onCallStateRetrieve = ({ commit, state, rootGetters, dispatch }, data) => {
// 两次hold 调用才能完成一次hold 动作
  callApi.getApiCscPhoneHoldOperation({
    engineer_code: rootGetters.allInfo.code,
    session_id: state.voice.session.cubeId
  })
}

const onCallStateHeld = ({ commit, state, rootGetters, dispatch }, data) => {
  callApi.getApiCscPhoneHoldOperation({
    engineer_code: rootGetters.allInfo.code,
    session_id: state.voice.session.cubeId
  })
}

const onCallStateReleased = async ({ commit, state, rootGetters, dispatch }, data) => {
  const { call: { connId, callType }, messageName } = data

  // 在每一通会话关闭时，获取服务列表和首问列表 更新服务量
  dispatch('getServiceProblem')
  dispatch('getApiCscServiceDetails')

  // 尝试检查三次，每次间隔2s
  let tryCount = 3
  while (tryCount > 0 && checkInitSessionLoading(rootGetters, connId)) {
    tryCount -= 1
    await sleep(2000)
  }

  // 等待后如果仍然没有产生需要release 的session，放弃操作并给出提示
  const session = Object.values(state.sessions).find(s => s.phone_conn_id === connId)
  if (!session) {
    Message('收到了释放会话的事件，但左侧会话列表里没有这条会话信息，已忽略')
    return
  }

  const functionPoint = get(data, 'call.userData.functionPoint')
  // 避开满意度转接等操作导致的错误的关闭调用
  // todo 当session 初始化接口timeout 导致release 无法释放session 的问题需要考虑
  // state 覆盖了release 和abandon
  const releasePromise = dispatch('releaseVoiceConversion', {
    sessionId: session.id,
    // 魔方所需会话类型： 呼入结束：callin 或 呼出结束：callout
    type: callType === CallType.Inbound ? 'callin' : 'callout',
    isTransferSatisfaction: functionPoint === FunctionPoint.ToSatisfaction
  })

  if (messageName === MessageName.EventAbandoned) {
    releasePromise.then(() => {
      dispatch('removeVoiceSession', session)
      Message(`${session.phone} 收到会话废弃事件，自动关闭了该会话`)
    })
  }
}

const onCallStateRinging = ({ commit, state, rootGetters, dispatch }, data) => {
  const { call: { transferConnId, callType } } = data

  // 每次开始振铃时，将话机状态置为NotReady，reasonCode = '50'
  api.notReadyForConversion()

  // 魔方系统记录会话开始
  // 如果是转接，那从工程师接起另一个工程师时，不计算会话
  if (callType !== CallType.Consult && !transferConnId) {
    // 正常的呼入
    // 外呼转接的接收方，也计算为呼入
    dispatch('startConversion', {
      data, isCallout: false
    })
  }
}

/**
 * 检查当前是否存在正在初始化的session
 *
 * 为避免release abandon 事件到来时，init session 流程未完成导致的错误和空框
 * 这里将通过target session 和api store 来判定流程是否完成，loading 将涉及到主要几个接口
 * - /api/wb/phone/callout
 * - /api/wb/phone/start/conversation
 * - /api/wb/phone/phoneLocation
 * - /api/wb/phone/specialReminder
 * - /api/wb/weather/forecast
 * @param rootGetters
 * @param connId
 * @return {boolean}
 */
const checkInitSessionLoading = (rootGetters, connId) => {
  const session = Object.values(rootGetters['call/sessions']).find(s => s.phone_conn_id === connId)
  if (!session) {
    return true
  }

  const checkList = [
    'phone/callout',
    'phone/start/conversation',
    'phone/phoneLocation',
    'phone/specialReminder',
    'weather/forecast'
  ]
  return checkList.some(api => {
    return rootGetters['api/loading'](api)
  })
}

/**
 * 检查并发出更新随路数据的请求
 * @param data
 */
const checkAndUpdateUserData = ({ data }) => {
  // 如果有随路数据Function，将其移除，之后的事件仍然能够通过随路数据下的Function 来判断是主动触发or被动触发
  // 不能移除太快，可能导致报工号功能部分失效，所以增加延迟
  // 报工号的几个初始事件间隔在几百ms，所以一般情况下大于1s 能够保证运行顺利
  const functionPoint = get(data, 'call.userData.functionPoint')
  // const operation = get(data, 'call.userData.ecloud_consult_operation')

  // 报工号function 997 remove
  // 进线报工号偶发缺少 EventPartyAdded，现将EventReleased 也加入判断
  if (functionPoint === FunctionPoint.AgentReport && [MessageName.EventPartyAdded, MessageName.EventRetrieved].includes(data.messageName)) {
    util.updateVoiceUserData(data.call.connId,{
      'functionPoint': ''
    })
  }

  // 单步转接队列function 998 remove
  if (functionPoint === FunctionPoint.Transfer && data.messageName === MessageName.EventHeld) {
    util.updateVoiceUserData(data.call.connId,{
      'functionPoint': ''
    })
  }

  // const operationNames = ['transfer', 'conference']
  // if (data.messageName === MessageName.EventHeld && operationNames.includes(operation)) {
  //   util.updateVoiceUserData(data.call.connId,{
  //     'ecloud_consult_operation': ''
  //   })
  // }
}
