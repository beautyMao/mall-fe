/**
 * 魔方电话通路状态
 * @see http://g.lenovo.com.cn/RD/cube/wikis/updateWorkSatus
 * @type {{Rest: string, Acw: string, Logout: string, Offline: string, Absence: string, Hangup: string, Login: string, Online: string, Callout: string, Callin: string, Hold: string}}
 */
export const EngineerStatus = {
  // agent state change
  Online: 'online',
  Rest: 'rest',
  Offline: 'offline',
  Absence: 'absence',
  Acw: 'acw',
  Login: 'login',
  Logout: 'logout',
  // call state change
  Callin: 'callin',
  Callout: 'callout',
  Hangup: 'hangup',
  Hold: 'hold'
}

/**
 * 设备状态枚举
 * @type {{Active: string, Inactive: string}}
 */
export const DeviceState = {
  Active: 'Active',
  Inactive: 'Inactive'
}

/**
 * 呼叫类型
 * @type {{Outbound: string, Consult: string, Internal: string, Inbound: string}}
 */
export const CallType = {
  Internal: 'Internal', // 内部通话
  Inbound: 'Inbound', // 呼入通话
  Outbound: 'Outbound', // 呼出通话
  Consult: 'Consult' // 咨询通话
}

/**
 * 座席状态枚举
 * @type {{Ready: string, NotReady: string, LoggedOut: string, LoggedIn: string}}
 */
export const AgentState = {
  NotReady: 'NotReady', // 未就绪
  Ready: 'Ready', // 就绪
  LoggedIn: 'LoggedIn', // 登录
  LoggedOut: 'LoggedOut', // 登出
  // 以下内容是由上述内容派生出来的
  AfterCallWork: 'AfterCallWork', // 事后处理
  AuxWork: 'AuxWork',
  Offline: 'Offline',
  Online: 'Online',
  DoNotDisturbOn: 'DoNotDisturbOn',
  DoNotDisturbOff: 'DoNotDisturbOff'
}

/**
 * 呼叫状态
 * @type {{Released: string, Held: string, Ringing: string, Established: string, Dialing: string}}
 */
export const CallState = {
  Dialing: 'Dialing', // 呼出响铃状态
  Ringing: 'Ringing', // 响铃状态
  Released: 'Released', // 通话挂断状态
  Held: 'Held', // 接通保持状态
  Established: 'Established', // 接通状态
  Retrieve: 'Retrieve' // 发起方在完成转接时有这个状态？
}

/**
 * 消息名称
 * @type {{EventPartyAdded: string, EventPartyDeleted: string, EventPartyChanged: string, EventEstablished: string, EventRetrieved: string}}
 */
export const MessageName = {
  EventPartyAdded: 'EventPartyAdded', // Party添加事件
  EventPartyDeleted: 'EventPartyDeleted', // 成员离开
  EventPartyChanged: 'EventPartyChanged', // Party改变事件?
  EventEstablished: 'EventEstablished', // 通话接通事件
  EventRetrieved: 'EventRetrieved', // 通话保持取回
  EventHeld: 'EventHeld', // 通话保持
  EventDialing: 'EventDialing', // 呼出响铃事件
  EventRinging: 'EventRinging', // 进线响铃
  EventReleased: 'EventReleased',
  EventAbandoned: 'EventAbandoned' // 废弃
}

/**
 * 未知
 * @type {{ConferencedBy: string, TransferredBy: string}}
 */
export const ThirdPartyRole = { // 第三方Party呼叫类型：ConferencedBy：会议、  TransferredBy：转接
  ConferencedBy: 'ConferencedBy',
  TransferredBy: 'TransferredBy'
}

/**
 * websokect 通知类型(todo: 由易迅方工程师说明，NotificationType 为邮件相关，与通话无关)
 * @type {{ParticipantsUpdated: string, StatusChange: string, AttachedDataChanged: string}}
 */
export const NotificationType = {
  StatusChange: 'StatusChange', // 进线（坐席状态的改变）
  ParticipantsUpdated: 'ParticipantsUpdated', // Party 改变（多人相关）
  AttachedDataChanged: 'AttachedDataChanged' // 更新随路之后会收到这个事件
}

/**
 * 消息类型
 * @type {{CallStateChange: string, createInteractionResponse: string, WorkitemStateChange: string, createInteractionErrorResponse: string, DeviceStateChange: string, DndStateChange: string, ChatStateChange: string, ErrorMessage: string, ChannelStateChange: string, EmailStateChange: string}}
 */
export const MessageType = {
  CallStateChange: 'CallStateChangeMessage',
  ChatStateChange: 'ChatStateChangeMessage',
  EmailStateChange: 'EmailStateChangeMessage',
  WorkitemStateChange: 'WorkitemStateChangeMessage',
  createInteractionErrorResponse: 'createInteractionErrorResponse',
  createInteractionResponse: 'createInteractionResponse',
  ErrorMessage: 'ErrorMessage',
  ChannelStateChange: 'ChannelStateChangeMessage',
  DeviceStateChange: 'DeviceStateChangeMessage',
  DndStateChange: 'DndStateChangeMessage'
}

/**
 * 在userData 自定义的function 动作，被认为是易迅封装的一系列动作的组合
 * @type {{ToSatisfaction: string}}
 */
export const FunctionPoint = {
  ToSatisfaction: '999',
  Transfer: '998',
  AgentReport: '997'
}

/**
 * release 事件触发的原因
 * @type {{Agent: string, Client: string}}
 */
export const StopCallType = {
  Client: 'Client',
  Agent: 'Agent'
}

/**
 * 响应状态码
 * @type {{"11": string, "12": string, "13": string, "14": string, "15": string, "16": string, "17": string, "18": string, "19": string, "0": string, "1": string, "2": string, "3": string, "4": string, "5": string, "6": string, "7": string, "8": string, "9": string, "20": string, "10": string}}
 */
export const StatusCode = {
  '0': '当前操作成功，无statusMessage返回',
  '1': '缺少必要的参数',
  '2': '指定的参数对当前的状态无效，如果有正在进行的通话，请先在坐席固机上完成',
  '3': '不允许该操作',
  '4': '内部错误',
  '5': '用户没有权限进行该项操作',
  '6': '发送请求的资源无法找到',
  '7': '部分操作成功',
  '8': '',
  '9': '当前处理未结束',
  '10': '输入校验错误',
  '11': '用户试图修改只读的属性',
  '12': '无法获取资源',
  '13': '无法创建资源',
  '14': '无法删除资源',
  '15': '无法更新资源',
  '16': '',
  '17': '',
  '18': '资源已经存在',
  '19': '资源在使用',
  '20': '用户校验错误'
}

/**
 * 错误响应码
 */
export const ErrorCode = {
  '1': '未注册',
  '2': 'Client类型不对',
  '3': 'Client注册Id不对',
  '6': '租户id没有传入',
  '7': '未知的租户id',
  '8': 'Place没有传入',
  '9': 'Place不存在',
  '10': '工号不存在',
  '11': 'Place被禁用',
  '12': 'Place已经被占用',
  '13': '坐席被禁用',
  '14': '坐席已经迁入',
  '38': '坐席id没有传入',
  '40': '没有更多可用的Licenses',
  '41': '话机异常，请检查换机',
  '42': '资源已回收',
  '43': '',
  '50': '未知的错误代码, 请求不能处理',
  '51': '该座席未上线',
  '52': '内部错误',
  '53': '请求参数是无效的',
  '54': '没有连接到交换机',
  '55': '协议版本错误',
  '56': '无效的connectionId',
  '57': '话机异常，请检查话机',
  '58': '话机异常，请检查话机',
  '59': '未在配置库中配置该分机',
  '61': '请求中的分机无效',
  '71': '无效的号码 或 该工程师正在通话中',
  '93': '目标状态无效',
  '96': '不能添加一个新的呼叫到会议中',
  '415': '目标号码无效',
  '527': '该工号已登录',
  '565': '无效的状态，如果有正在进行的通话，请先坐席上完成通话',
  '1008': '拒绝邀请',
  '1019': '会话无应答',
  '1141': '请求的对象不兼容',
  '1161': '请求的对象状态不正确，请在坐席上完成通话',
  '10101': '与Genesys Server连接失败',
  '10102': '目标号码为空或无效',
  '10103': '通话未开始或已结束',
  '10104': '座席签入失败',
  '10105': '座席签出失败',
  '10106': '座席状态改变失败',
  '10107': '电话呼叫失败',
  '10108': '电话接听失败',
  '10109': '电话挂断失败',
  '10110': '通话保持失败',
  '10111': '通话取回失败',
  '10112': '两步转接发起失败',
  '10113': '两步转接完成失败',
  '10114': '两步会议发起失败',
  '10115': '两步会议完成失败',
  '10116': '单步转接失败',
  '10117': '电话盲转失败',
  '10118': '单步会议失败',
  '10119': '将会议一方置为耳聋模式失败',
  '10120': '将会议一方取消耳聋模式失败',
  '10121': '添加随路数据失败',
  '10122': '删除随路数据失败',
  '10123': '更新随路数据失败',
  '10124': '打开静音失败',
  '10125': '关闭静音失败',
  '10126': '发送DTMF失败',
  '10127': '发送用户事件失败',
  '10128': '监听电话失败',
  '10129': '取消监听电话失败',
  '10130': '将会议一方踢出会议失败',
  '8199': '',
  '8200': ''
}
