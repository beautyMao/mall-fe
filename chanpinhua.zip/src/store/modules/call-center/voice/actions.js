/* eslint-disable */
import * as api from '@/api/call-center/softphone'
import softphone from '@/api/call-center/softphone-ws'
import { MessageType, ThirdPartyRole, CallType } from '@call/voice/enum'
import get from 'lodash.get'
import * as callApi from '@/api/call-center/call-center-phone'
import { getTelToken, removeTelToken, setTelToken } from '@/utils/auth'
import * as types from '@call/mutation-types'
import { ClientType } from '@/store/modules/call-center/enum'
import { convertToVoiceSession } from '@/store/modules/call-center/convert'
import * as util from './util'
import InterceptMessage from '@/utils/message-intercept'
import { stateChangeHandle } from '@/store/modules/call-center/voice/event-handle'
import { getConfig } from '@/api/call-center/softphone-config'
import { sleep } from '@/utils'

// 消息处理函数单例
let stateChangeHandleFunc = null

/**
 * 电话配置实例
 * {{prefix: {}, name: string, api: string, routers: {agent: string, transfer: string, satisfy: string, conferenceTransfer: string}}}
 */
let config

/**
 * 检测是否有软电话，获取session place 信息
 * 在登录页中使用
 * @param commit
 */
export const loginSoftphone = ({ commit }) => {
  const gensysSession = getTelToken()
  if (!gensysSession) {
    return callApi.getApiWbPhoneInitializeEngineer().then(response => {
      // 如果response 里没有data，可以认定为登录失败
      if (!response.data) {
        return Promise.reject('登录失败，未能获取工程师话机状态')
      }
      // { phone_sys_sessid, place }
      if (get(response, 'data.phone_sys_sessid')) {
        const data = {
          id: response.data.phone_sys_sessid,
          place: response.data.place,
          placeip: response.data.placeip
        }
        commit('VOICE_DEFAULT_SESSION', data)
        setTelToken(data)
      }
    })
  } else {
    commit('VOICE_DEFAULT_SESSION', gensysSession)
    return Promise.resolve(gensysSession)
  }
}

/**
 * 登录魔方之后，用户刷新页面
 * 在呼叫中心首页需要根据这里判断并设置电话初始session
 * @param commit
 * @param dispatch
 * @return {*}
 */
export const checkSoftphoneSession = ({ commit, dispatch }) => {
  const gensysSession = getTelToken()
  if (gensysSession) {
    commit('VOICE_DEFAULT_SESSION', gensysSession)
    return Promise.resolve(gensysSession)
  }

  // 需要有无副作用的工程师电话权限检查，否则在离线之后刷新页面，将无法看到工作台
  return callApi.getPhoneEngineerDnno().then((response) => {
    if (response.data.DnNo !== '') {
      return dispatch('initSoftphone')
    }
    return Promise.resolve('no voice permission')
  })
}

/**
 * 将初始化动作交给action，为了能够在ws 里vuex 主动管理电话条的坐席和物理机状态
 * @param commit
 * @param state
 * @param rootGetters
 * @param dispatch
 * @return {PromiseLike<T | never>}
 */
export const initSoftphone = ({ commit, state, rootGetters, dispatch }) => {
  // todo 每次都重新用无魔方副作用的接口去获取session 信息，保障softphone 畅通
  return callApi.engineerReconnect().then((response) => {
    if (response.data.phone_sys_sessid) {
      const data = {
        id: response.data.phone_sys_sessid,
        place: response.data.place,
        placeip: response.data.placeip,
        location: response.data.location
      }
      commit('VOICE_DEFAULT_SESSION', data)
      setTelToken(data)
    }

    // 两地sip server 配置不同，进行下初始化
    api.initService(response.data.location)
    config = getConfig(response.data.location)

    return softphone.init({
      sessionId: response.data.phone_sys_sessid,
      loginCode: rootGetters.engineerCode,
      place: response.data.place,
      location: response.data.location
    })
  }).then(hub => {
    if (!stateChangeHandleFunc) {
      telStatusAll({ commit, state, rootGetters }, 6, 44) // 6
      // 保险一点，因为总是有刷新重登陆的问题
      if (stateChangeHandleFunc) {
        softphone.removeEventListener(MessageType.CallStateChange, stateChangeHandleFunc)
        softphone.removeEventListener(MessageType.ChatStateChange, stateChangeHandleFunc)
        softphone.removeEventListener(MessageType.DeviceStateChange, stateChangeHandleFunc)
      }

      stateChangeHandleFunc = stateChangeHandle(commit, state, rootGetters, dispatch)
      softphone.addEventListener(MessageType.CallStateChange, stateChangeHandleFunc)
      softphone.addEventListener(MessageType.ChatStateChange, stateChangeHandleFunc)
      softphone.addEventListener(MessageType.DeviceStateChange, stateChangeHandleFunc)
    }

    // 初始化时首次获取服务列表和首问列表 更新服务量
    getApiCscServiceDetails({ commit, state, rootGetters })
    getServiceProblem({ commit, state, rootGetters })

    // online 是签入，但也是not ready 状态
    return api.online()
  })
}

/**
 * 签出动作
 * @param commit
 * @param state
 * @param isSync 用于浏览器关闭时的同步调用
 * @return {Promise<string>}
 */
export const logoutSoftphone = ({ commit, state }, isSync = false) => {
  // todo 现在是同步执行的方式，后续推荐用navigator.sendBeacon 但需要处理auth header
  if (isSync) {
    removeTelToken()
    callApi.syncEngineerLogout(state.voice.session.id)
    return Promise.resolve('ok')
  }

  return callApi.phoneEngineerLogout(state.voice.session.id).then((response) => {
    if (stateChangeHandleFunc) {
      // 延迟5s 后再remove 掉事件监听，让最后一个offline event 能被监听到
      sleep(5000).then(() => {
        softphone.removeEventListener(MessageType.CallStateChange, stateChangeHandleFunc)
        softphone.removeEventListener(MessageType.ChatStateChange, stateChangeHandleFunc)
        softphone.removeEventListener(MessageType.DeviceStateChange, stateChangeHandleFunc)
        stateChangeHandleFunc = null
      })
    }
    return Promise.resolve('ok')
  }).finally(() => {
    removeTelToken()
  })
}

/**
 * 多方通话 多人电话
 * @param commit
 * @param state
 * @param rootGetters
 * @param phone
 * @return {PromiseLike<T | never>}
 */
export const makeConference = ({ commit, state, rootGetters }, phone) => {
  return transformationTel({ commit, state, rootGetters }, phone).then(res => {
    const { connId, userData } = state.voice.message.call
    return api.initiateConference(res.phoneNumber, connId, { ...userData, originDnNumber: phone})
  })
}

/**
 * 外呼电话
 * @param commit
 * @param state
 * @param rootGetters
 * @param tel
 * @param skill
 * @param business
 */
export const makeDialCall = ({ commit, state, rootGetters }, { tel, skill }) => {
  return transformationTel({ commit, state, rootGetters }, tel).then(res => {
    return api.dialCall(res.phoneNumber, { cubeSkillId: skill })
  })
}

/**
 * 自动加 前缀
 * @param commit
 * @param state
 * @param rootGetters
 * @param phone
 * @return {Promise<{phoneNumber: *} | never>}
 */
export const transformationTel = ({ commit, state, rootGetters }, phone) => {
  if (util.isMobile(phone)) {
    return Promise.resolve({
      phoneNumber: `9${phone}`
    })
  } else if (phone.startsWith('A')) {
    // 工程师编号处理
    return callApi.getTargetPhoneEngineerDnno(phone).then(res => {
      phone = res.data.DnNo
      if (config.name !== res.data.location) {
        phone = config.prefix[res.data.location] + res.data.DnNo
      }
      return Promise.resolve({
        phoneNumber: phone
      })
    })
  } else if (phone.length !== 7) {
    // 固定电话处理
    return Promise.resolve({
      phoneNumber: `9${phone}`
    })
  } else {
    return Promise.resolve({
      phoneNumber: phone
    })
  }
}

/**
 * 转接第三方、多人会话
 * @param commit
 * @param state
 * @param rootGetters
 * @param phone
 * @return {PromiseLike<T | never>}
 */
export const makeTransfer = ({ commit, state, rootGetters }, phone) => {
  return transformationTel({ commit, state, rootGetters }, phone).then(res => {
    return api.telTransfer(rootGetters['call/connId'], res.phoneNumber)
  })
}

/**
 * 在线两步转接工程师
 * @param commit
 * @param state
 * @param rootGetters
 * @param data
 * @param phone
 * @return {PromiseLike<T | never>}
 */
export const twoConference = ({commit, state, rootGetters}, data) => {
  const query = {
    calling_phone: rootGetters['call/phoneNumber'],
    called_phone: data.code,
    skill: data.skill,
    conn_id: rootGetters['call/connId'],
    enter_type: data.enter_type
  }

  return transformationTel({ commit, state, rootGetters }, data.code).then(res => {
    return callApi.postApiWbPhoneTransfer(query).finally(() => {
      api.twoTelTransfer(rootGetters['call/connId'], res.phoneNumber)
    })
  })
}

/**
 * 在线单步转接工程师
 * @param commit
 * @param state
 * @param rootGetters
 * @param data
 * @param phone
 * @return {PromiseLike<T | never>}
 */
export const conference = ({ commit, state, rootGetters }, data) => {
  const query = {
    calling_phone: rootGetters['call/phoneNumber'],
    called_phone: data.code,
    skill: data.skill,
    conn_id: rootGetters['call/connId'],
    enter_type: data.enter_type
  }

  return transformationTel({ commit, state, rootGetters }, data.code).then(res => {
    return callApi.postApiWbPhoneTransfer(query).finally(() => {
      api.telTransfer(rootGetters['call/connId'], res.phoneNumber)
    })
  })
}

/**
 * 2步转接队列
 * @param commit
 * @param state
 * @param data
 * @param phone
 * @return {PromiseLike<T | never>}
 */
export const twoTransferTelQueue = ({ commit, state, rootGetters }, data) => {
  const query = {
    calling_phone: rootGetters['call/phoneNumber'],
    called_phone: '',
    skill: data.skill,
    conn_id: rootGetters['call/connId'],
    enter_type: data.enter_type
  }

  return callApi.postApiWbPhoneTransfer(query).finally(() => {
    api.twoTransferTelQueue(rootGetters['call/connId'], data.skill)
  })
}

/**
 * 单步转接队列
 * @param commit
 * @param state
 * @param data
 * @param phone
 * @return {PromiseLike<T | never>}
 */
export const transferTelQueue = ({ commit, state, rootGetters }, data) => {
  const query = {
    calling_phone: rootGetters['call/phoneNumber'],
    called_phone: '',
    skill: data.skill,
    conn_id: rootGetters['call/connId'],
    enter_type: data.enter_type
  }

  return callApi.postApiWbPhoneTransfer(query).finally(() => {
    api.transferTelQueue(rootGetters['call/connId'], data.skill)
  })
}

/**
 * 获取服务列表和首问列表
 * @param commit
 * @param state
 * @param rootGetters
 * @return {Promise<any[]>}
 */
export const getServiceProblem = ({ commit, state, rootGetters }) => {
  // 获取我的服务列表
  return callApi.geApiWbPhoneEngineerServiceLog(rootGetters.engineerCode).then(response => {
    commit('SET_VOICE_SERVICE', response.data)
    return response.data
  })
}

/**
 * 获取服务量
 * @param commit
 * @param state
 * @param rootGetters
 * @return {Promise<any | never>}
 */
export const getApiCscServiceDetails = ({ commit, state, rootGetters }) => {
  return callApi.getApiCscServiceDetails(rootGetters.engineerCode).then(res => {
    commit('SET_VOICE_WORKLOAD', res.data)
    return res
  })
}

/**
 * 魔方系统记录会话开始
 * @param commit
 * @param state
 * @param rootGetters
 * @param data
 * @param isCallout
 * @return {PromiseLike<T | never> | Promise<T | never> | *}
 */
export const startConversion = ({ commit, state, rootGetters }, { data, isCallout = false }) => {
  const action = isCallout ? callApi.startCalloutConversion : callApi.startPhoneConversion

  let phoneNumber = util.removePhonePrefix(data.phoneNumber)
  if (!util.isMobile(phoneNumber)) {
    // 对于单步转接外呼动作，只有otherDn 才是真实用户手机号
    phoneNumber = util.removePhonePrefix(data.otherDn)
  }
  // 如果仍然为空，可以认为是多方通话的被接起方，从里面筛出第一个手机号
  // extensions: {OrigDN-1: "8051212", BusinessCall: "0", NumOfOrigDNs: "2", WrapUpTime: "0", OrigDN-2: "915652349710"}
  if (!phoneNumber && data.thirdPartyRole === ThirdPartyRole.ConferencedBy) {
    let targetDNIndex = 0
    while (targetDNIndex <  data.extensions.NumOfOrigDNs) {
      targetDNIndex++
      const phoneLike = util.removePhonePrefix(data.extensions[`OrigDN-${targetDNIndex}`])
      if (phoneLike && util.isMobile(phoneLike)) {
        phoneNumber = phoneLike
        break
      }
    }
  }

  const postData = {
    engineer_code: rootGetters.engineerCode,
    calling_phone: phoneNumber,
    called_phone: util.removePhonePrefix(data.thisDn),
    // 被转接过来的用户，transferConnId 才是接下来要通话的connId
    // 两步转接过程中，临时沟通用的是connId，并且在完成转接之后会被release 掉
    conn_id: data.call.transferConnId || data.call.connId
  }

  // callout 没有skill 属性
  const skill = get(data, 'call.userData.VirualQueue', '')
  if (skill) {
    postData.skill = skill.replace(/^V/, '')
  }

  // callout 将skill ID 携带上
  const cubeSkillId = get(data, 'call.userData.cubeSkillId')
  if (cubeSkillId) {
    postData.skill = cubeSkillId
  }

  return action(postData).then((response) => {
    if (!response.data.session_id) {
      return Promise.reject('初始化会话失败')
    }
    commit(types.SET_VOICE_CUBE_SESSION, response.data.session_id)
    const session = convertToVoiceSession(Object.assign({
      call_id: response.data.call_id
    }, response.data.detail), data)
    commit(types.RECEIVE_SESSION, session)

    // session 创建成功之后，更新录音数据到随路数据里
    const userData = {
      'CallID': response.data.call_id,
      'strCurCallID': response.data.call_id,
      'lenovo_callId': response.data.call_id
    }
    userData['lenovo_agentId:' + state.voice.session.place] = rootGetters.engineerCode
    userData['lenovo_agentIp:' + state.voice.session.place] = state.voice.session.placeip
    util.updateVoiceUserData(response.data.conn_id, userData)

    return initVoiceSession({ commit, state }, { session })
  })
}

/**
 * 初始化一个voice cube session
 * 在上层的动作（比如refreshSessions），新加入的session 都会根据session client type 来分别初始化
 * @param commit
 * @param state
 * @param session
 * @return {Promise<string>}
 */
export const initVoiceSession = ({ commit, state }, { session }) => {
  commit(types.TRY_SWITCH_SESSION, session.id)

  // 对手机号，获取手机号归属地信息
  if (util.isMobile(session.phone)) {
    const remindPromise = callApi.getApiWbPhonePhoneLocation(session.phone).then(response => {
      if (!get(response, 'data.city')) {
        return Promise.reject('初始化电话会话：获取归属地信息失败')
      }
      // 获取存储特殊提醒
      commit('SET_VOICE_REGION', { session, region: response.data })
    })

    // 获取存储天气
    const weatherPromise = callApi.getApiWbWeatherForecast({ mobile: session.phone }).then(response => {
      commit('SET_VOICE_WEATHER', { session, weatherInfo: get(response, 'data[0]') })
    })

    // 存储真实手机号
    // todo 在辅助数据都放到session 里之后，这里再次存储似乎意义不大了
    commit('SET_VOICE_PHONE_NUMBER', session.phone)

    // 由于初始化动作多数情况下是在事件里被调起的，所以异常处理就放到了action 里
    remindPromise.catch((e) => {
      InterceptMessage.warning(e)
    })
    weatherPromise.catch((e) => {
      InterceptMessage.warning('获取来点归属地天气失败：' + e)
    })
  }

  // 存储随路数据
  let connId = get(session, 'voiceData.call.connId')
  let messageName = get(session, 'voiceData.messageName')
  let callState = get(session, 'voiceData.call.state')
  let callType = get(session, 'voiceData.call.callType')
  let thirdPartyRole = get(session, 'voiceData.thirdPartyRole')
  let VirualQueue = get(session, 'voiceData.call.userData.VirualQueue')
  let queueData = get(session, 'voiceData.call.userData.queueData')
  let parseQueueData = []

  // 将队列信息更新到随路数据里
  const isUserCall = [CallType.Inbound, CallType.Outbound].includes(callType)
  if ((messageName === 'EventRinging' && isUserCall) || (messageName === 'EventPartyChanged' && callState === 'Established' && isUserCall && thirdPartyRole === 'TransferredBy')) {
    if (queueData === undefined) {
      if (VirualQueue && VirualQueue !== '') {
        parseQueueData.push(VirualQueue.replace(/^V/, ''))
      }
      api.attachUserData(connId, { queueData: `${parseQueueData}` })
    } else if (queueData !== '') {
      parseQueueData = queueData.split(',')
    }
    commit('SET_VOICE_QUEUE_DATA', { id: session.id, queueData: parseQueueData })
  }

  return Promise.resolve('voice session initialized')
}

/**
 * 魔方系统，主动断开电话会话
 * 将进入案面状态，并且voice session 是保留状态
 * TODO 再次就绪之后，才会移除voice session，但在此之前，期望能够在刷新页面后维持案面状态
 * @param commit
 * @param state
 * @param dispatch
 * @param connId
 * @param sessionId
 * @param type
 */
export const closeVoiceConversion = ({ commit, state, dispatch }, { connId, sessionId, type }) => {
  return api.hangup(connId).then(() => {
    return callApi.closePhoneConversion({ sessionId, type })
  }).then(() => {
    // 将会话设置为虚拟，用于voice 案面
    commit(types.SET_VIRTUAL_SESSION, { sessionId })
    return api.afterCallWork()
  }).then(() => {
    return dispatch('refreshSessions')
  })
}

/**
 * 被动断开电话会话后，同步到魔方系统
 * @param commit
 * @param state
 * @param dispatch
 * @param sessionId optional
 * @param type
 * @param isTransferSatisfaction
 * @return {PromiseLike<T | never>}
 */
export const releaseVoiceConversion = ({ commit, state, dispatch }, { sessionId, type, isTransferSatisfaction }) => {
  // 如果有文本session 直接使用currentSessionID会出错
  // 我们保证active voice session 的唯一性
  sessionId = sessionId || state.voice.session.cubeId
  return callApi.closePhoneConversion(sessionId, type, isTransferSatisfaction).then(() => {
    // 将会话设置为虚拟，用于voice 案面
    commit(types.SET_VIRTUAL_SESSION, { sessionId })
    // todo 多方通话用户挂断，acw 可能报错问题处理，这个时候两个工程师仍然在通话中
    api.afterCallWork()
    return dispatch('refreshSessions')
  })
}

/**
 * 释放所有的电话会话
 * 目前用于手动登录后关闭异常的通话
 * @param commit
 * @param state
 * @param dispatch
 * @return {Promise<any[] | never>}
 */
export const releaseAllVoiceConversion = ({ commit, state, dispatch }) => {
  const actionPromises = Object.values(state.sessions).filter(session => session.client_type === ClientType.Telephone).map(session => {
    const type = session.callType === CallType.Inbound ? 'callin' : 'callout'
    return callApi.closePhoneConversion(session.id, type, false).then((res) => {
      commit(types.SET_VIRTUAL_SESSION, { sessionId: session.id })
      return res
    })
  })

  return Promise.all(actionPromises).then(() => {
    return dispatch('refreshSessions')
  })
}

/**
 * 移除所有案面状态的电话会话
 * @param state
 * @param dispatch
 */
export const removeAllVirtualVoiceConversion = ({ state, dispatch }) => {
  Object.values(state.sessions).filter(session => {
    return session.client_type === ClientType.Telephone && session.isVirtual
  }).forEach(session => {
    dispatch('removeVoiceSession', session)
  })
  return Promise.resolve('remove done')
}

/**
 * 移除一个电话会话
 * 与removeSession 不同的是，移除电话session 之后会跳转到剩余的session 上
 * 或者直接显示“等待接入”session
 * @param commit
 * @param state
 * @param session
 * @return {Promise<string>}
 */
export const removeVoiceSession = ({ commit }, session) => {
  commit('CLOSE_VOICE_SESSION', session)
}

/**
 * 更新魔方工程师电话通路状态
 * 如果是两个相同状态，则不更新
 * @param commit
 * @param state
 * @param rootGetters
 * @param nextStatus
 */
export const changeCubeWorkStatus = ({ commit, state, rootGetters }, nextStatus) => {
  if (state.voice.currentStatus === nextStatus) {
    return Promise.resolve('same status')
  }
  return callApi.engineerStateUpdate(rootGetters.engineerCode, state.voice.currentStatus, nextStatus).then((response) => {
    commit('SET_VOICE_CUBE_STATUS', nextStatus)
    return response
  })
}

/**
 * 按钮状态状态函数
 * @param commit
 * @param state
 * @param rootGetters
 * @param status
 */
export const telStatusAll = ({ commit, state, rootGetters }, status) => {
  switch (status) {
    case 2:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        holdStatus: false,
        dialStatus: true,
        hangUpStatus: false,
        pickUpStatus: false,
        transferStatus: false,
        completeTransferStatus: false,
        meetingStatus: false,
        completeMeetingStatus: false,
        satisfactionDegreeStatus: false
      }) // 2
      break;
    case 3:
      if (!rootGetters['call/showButtons'].hangUpStatus) {
        commit(types.SHOW_BUTTONS, {
          ...rootGetters['call/showButtons'],
          answer: false,
          holdStatus: false,
          pickUpStatus: false,
          dialStatus: true,
          hangUpStatus: false,
          transferStatus: false,
          completeTransferStatus: false,
          meetingStatus: false,
          completeMeetingStatus: false,
          satisfactionDegreeStatus: false
        }) // 3
      }
      break;
    case 4:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons']
      }) // 4
      break;
    case 5:
      commit(types.SHOW_BUTTONS, {...rootGetters['call/showButtons']}) // 5
      break;
    case 6:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        transferStatus: false,
        completeTransferStatus: false,
        completeMeetingStatus: false,
        satisfactionDegreeStatus: false,
        holdStatus: false,
        pickUpStatus: false,
        hangUpStatus: false,
        dialStatus: false,
        meetingStatus: false
      }) // 6
      break;
    case 7:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        hangUpStatus: true,
        holdStatus: false,
        pickUpStatus: false,
        dialStatus: false,
        transferStatus: false,
        completeTransferStatus: false,
        meetingStatus: false,
        completeMeetingStatus: false,
        satisfactionDegreeStatus: false
      }) // 7
      break;
    case 8:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: true,
        hangUpStatus: true,
        holdStatus: false,
        pickUpStatus: false,
        dialStatus: false,
        transferStatus: false,
        completeTransferStatus: false,
        meetingStatus: false,
        completeMeetingStatus: false,
        satisfactionDegreeStatus: false
      }) // 8
      break;
    case 9:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        hangUpStatus: true,
        holdStatus: true,
        dialStatus: false,
        pickUpStatus: false,
        transferStatus: true,
        completeTransferStatus: false,
        meetingStatus: true,
        completeMeetingStatus: false,
        satisfactionDegreeStatus: true
      }) // 9
      break;
    case 10:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        holdStatus: false,
        pickUpStatus: true
      }) // 10
      break;
    case 11:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        holdStatus: true,
        pickUpStatus: false
      }) // 11
      break;
    case 13:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        hangUpStatus: false,
        holdStatus: false,
        pickUpStatus: false,
        dialStatus: true,
        transferStatus: false,
        completeTransferStatus: false,
        meetingStatus: false,
        completeMeetingStatus: false,
        satisfactionDegreeStatus: false
      }) // 13
      break;
    case 14:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        hangUpStatus: true,
        dialStatus: false,
        transferStatus: false,
        completeTransferStatus: false,
        meetingStatus: false,
        completeMeetingStatus: false,
        satisfactionDegreeStatus: false
      }) // 14
      break;
    case 17:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        hangUpStatus: true,
        holdStatus: true,
        pickUpStatus: false,
        dialStatus: false,
        transferStatus: false,
        completeTransferStatus: false,
        meetingStatus: false,
        completeMeetingStatus: false,
        satisfactionDegreeStatus: false
      }) // 17
      break;
    case 18:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        hangUpStatus: true,
        holdStatus: false,
        pickUpStatus: false,
        dialStatus: false,
        transferStatus: false,
        completeTransferStatus: false,
        meetingStatus: false,
        completeMeetingStatus: true,
        satisfactionDegreeStatus: false
      }) // 18
      break;
    case 19:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        hangUpStatus: true,
        holdStatus: true,
        dialStatus: false,
        pickUpStatus: false,
        transferStatus: false,
        completeTransferStatus: false,
        meetingStatus: true,
        completeMeetingStatus: false,
        satisfactionDegreeStatus: false
      }) // 19
      break;
    case 20:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        hangUpStatus: true,
        holdStatus: false,
        pickUpStatus: false,
        dialStatus: false,
        transferStatus: false,
        completeTransferStatus: true,
        meetingStatus: false,
        completeMeetingStatus: false,
        satisfactionDegreeStatus: false
      }) // 20
      break;
    case 21:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        answer: false,
        hangUpStatus: true,
        holdStatus: false,
        pickUpStatus: false,
        dialStatus: false,
        satisfactionDegreeStatus: false
      }) // 21
      break;
    case 22:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        holdStatus: false,
        pickUpStatus: false
      }) // 22
      break;
    case 23:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        satisfactionDegreeStatus: false
      }) // 23
      break;
    case 24:
      commit(types.SHOW_BUTTONS, {
        ...rootGetters['call/showButtons'],
        satisfactionDegreeStatus: true
      }) // 24
      break;
    default:
      break;
  }
}
