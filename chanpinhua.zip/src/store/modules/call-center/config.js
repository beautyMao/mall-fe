import { CUBE } from '@/configuration'

export default {
  IM: {
    APPID: CUBE.im.appid,
    ACCOUNTTYPE: 36862,
    isLogOn: false,
    ADMIN_ACCOUNT: 'xcube'
  },
  // unit seconds
  overtimeSetting: {
    unactive: 5 * 60,

    // 长时间未回复话术
    unReplyConfig: {
      list: [
        {
          overtime: 3 * 60,
          pushTalk: '您好，您还在线吗？真的很想帮助您，还请您尽快回复我哦~'
        },
        {
          overtime: 5 * 60,
          pushTalk: '您好，您还在线吗？还没有收到您的回复，麻烦您看到消息后，尽快回复一下，以免对话超时自动关闭，感谢~'
        },
        {
          overtime: 7 * 60,
          closeSession: true
        }
      ]
    },
    // 空框话术
    unActiveConfig: {
      list: [
        {
          overtime: 2 * 60,
          pushTalk: '您好，您还在线吗？有什么可以帮助您的~'
        },
        {
          overtime: 4 * 60,
          pushTalk: '您好，您还在线吗？仍然没有收到您的回复，麻烦您看到消息后，尽快回复一下，以免对话自动关闭，谢谢~'
        },
        {
          overtime: 5 * 60,
          closeSession: true
        }
      ]
    }
  },
  voiceOvertimeSetting: {
    overActive: 15 * 60 // 通话超时时间
  },
  robot: {
    name: '小约',
    code: 'robot',
    avatar: 'static/call-center/img/default-head.png'
  },
  system: {
    defaultAvatar: 'static/call-center/img/default-head.png',
    // 队列查询轮询间隔
    queueQueryLoop: 30,
    // 是否开启消息时间间隔显示
    showMsgDistance: false,
    // 是否在退出浏览器前logout（实验特性）
    logoutBeforeUnload: false
  }
}
