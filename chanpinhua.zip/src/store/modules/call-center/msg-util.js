export const MESSAGE_TYPE = {
  Text: 'Text',
  Image: 'Image',
  Voice: 'Voice',
  Video: 'Video'
}

export const CLUSTER_DISTANCE = 60 * 1000

/**
 * 计算消息的发送间距
 * @param message
 * @param preMessage
 */
export const singleMessageDistance = (message, preMessage) => {
  if (!message || !preMessage || !MESSAGE_TYPE[message.type] || !MESSAGE_TYPE[preMessage.type]) {
    return
  }

  // 有时出现重复的数据，会造成连续的dis = 0，导致界面上多个相同时间点的消息
  const dis = message.timestamp - preMessage.timestamp || 0.1
  if (dis + preMessage.distance > CLUSTER_DISTANCE) {
    message.distance = 0
    return
  }

  message.distance = preMessage.distance + dis
}

/**
 * 批量处理，计算消息的发送间距
 * @param messages
 */
export const messageDistance = (messages) => {
  if (!messages || !messages.length) {
    return
  }
  const filterMessages = messages.filter(message => MESSAGE_TYPE[message.type])
  if (!filterMessages.length) {
    return
  }

  filterMessages.reduce((previousValue, currentMsg) => {
    // 有时出现重复的数据，会造成连续的dis = 0，导致界面上多个相同时间点的消息
    const dis = currentMsg.timestamp - previousValue.timestamp || 0.1
    if (dis > CLUSTER_DISTANCE) {
      currentMsg.distance = 0
      return {
        dis: 0,
        timestamp: currentMsg.timestamp
      }
    }

    currentMsg.distance = previousValue.dis + dis
    return {
      dis: currentMsg.distance,
      timestamp: currentMsg.timestamp
    }
  }, {
    dis: 0,
    timestamp: 0
  })
}
