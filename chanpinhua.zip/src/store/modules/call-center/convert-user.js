/**
 * 将外部的账户格式转换为魔方可用的
 * @param item
 * @return {{name: (string|rules.nickname|{validator, trigger}), mobile: (string|workStatus.phone|{rest, offline, online, hangup}|*|rules.phone|{message, required}|string), company: *, originData: *, id}}
 */
export function convertToCubeUser(item) {
  return {
    uid: '',
    cid: item.lenovoid,
    name: item.nickname,
    mobile: item.phone,
    sex: item.sex,
    company: item.company_name,
    originData: { ...item }
  }
}

/**
 * 从session 中获得魔方用户
 * @param session
 * @return {{uid: (string), name: (*|string), mobile: (string|workStatus.phone|{rest, offline, online, hangup}|*|rules.phone|{message, required}|string), company: string, originData, avatar: (string|string), cid}}
 */
export function convertCubeUserFromSession(session) {
  return {
    uid: session.cube_uid,
    cid: session.lenovoid,
    name: session.user_name,
    avatar: session.user_avatar,
    mobile: session.phone,
    sex: session.sex,
    company: '',
    originData: { ...session }
  }
}
