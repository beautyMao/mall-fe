import * as actions from './actions'
import * as getters from './getters'
import mutations from './mutations'
import voice from './voice'

import { CallType } from './voice/enum'
import { ClientType } from '@/store/modules/call-center/enum'

/**
 * 呼叫中心状态管理
 * @type {{state: {}, mutations: {}, actions: {}}}
 */
const callCenter = {
  namespaced: true,
  state: {
    system: {
      audioPlaying: false, // 客服播放用户语音时，全局只能有一个正在播放的
      defaultSession: null
    },
    currentSessionID: null,
    im: {
      userSig: null,
      ready: false
    },
    voice: voice.state,
    sessions: {},
    engineerQueue: {
      totalService: 0,
      privateQueue: 0, // 个人队列排队
      publicQueue: 0, // 大队列排队
      mainQueue: 0, // 主队列排队
      assistQueue: 0 // 辅队列排队
    }
  },
  mutations: {
    ...mutations,
    ...voice.mutations
  },
  getters: {
    ...getters,
    ...voice.getters
  },
  actions: {
    ...actions,
    ...voice.actions
  }
}

/**
 * 默认的消息对象
 */
export const defaultMessage = {
  error: '', // 消息状态
  id: null, // 消息ID
  sessionId: null, // 消息所属的sessionId
  type: '', // 消息类型 [text, image, voice]
  authorName: null,
  avatar: null,
  isEngineer: false, // 是否是客服发送的消息
  userType: 'wechat', // 消息类型 [wechat, lenovo]
  sendTime: '',
  timestamp: '', // 消息发送时间戳
  content: '', // 消息内容
  safeContent: '', // 安全显示的消息内容，仅在文本下有效
  emotion: 0,
  text: '', // 仅在语音下有效
  distance: 0, // 单位时间内的消息是否聚合，这是一个与上一条消息距离时间+上一条消息cluster 的值
  recommendData: null // 智能推荐匹配到的信息
}

/**
 * 默认的Session 对象
 */
export const defaultSession = {
  'rightRoute': '',
  // -- 会话属性 --
  'id': '',
  'cube_uid': '',
  'customer_id': '',
  'user_name': '',
  'user_avatar': '',
  'user_color': '#ffffff',
  'type': 2, // 1=机器人会话，2=人工会话
  'start_talking_at': '',
  'end_talking_at': '',
  'emotion': 0,
  'client_type': ClientType.Wechat,
  'access_name': '',
  'business_name': '',
  'last_queue_code': '',
  'last_queue_name': '',
  'current_queue_code': '',
  'current_queue_name': '',
  'consult_way': 3,
  'created_at': '',
  'updated_at': '',

  // 消息记录
  'caseList': [], // 用户历史咨询记录
  'messages': [],
  'draft': '',
  'isNewSession': false, // 是否由消息推送创建的新会话

  // -- 会话类型 --
  'userType': 'lenovo',

  // -- 会话状态 --
  'state': null, // value in [null, stop, close, unactive, active]  会话状态,
  'userActive': false, // 用户是否处于活跃状态
  'isVirtual': false // 是否是虚拟会话，用于客服案面工作使用
}

/**
 * 默认的VoiceSession 对象
 */
export const defaultVoiceSession = {
  'rightRoute': '',
  'id': '',
  'last_queue_code': '',
  'last_queue_name': '',
  'current_queue_code': '',
  'current_queue_name': '',
  'client_type': ClientType.Telephone,

  // 电话附加属性
  'connId': '', // session convert 时填入，等价于下方
  'call_id': '', // 电话CALLID 也用于录音系统的通话识别，仅在实时创建的session 里存在
  'phone_conn_id': '', // RD在创建时接收并填入
  'initCallState': '', // session convert 时填入
  'callType': CallType.Inbound, // in or out 在主动创建时填入
  'weather': {},
  'region': null,
  'remind': [],
  'voiceData': null, // 初次构建session 时使用的事件对象
  'queueData': [], // 随路数据

  // -- 会话属性 --
  'details': null,
  'tags': [],

  // -- 会话类型 --
  'userType': 'lenovo',

  // -- 会话状态 --
  'state': null, // value in [null, stop, unactive, active]  会话状态,
  'isVirtual': false // 是否是虚拟会话，用于客服案面工作使用
}

export default callCenter
