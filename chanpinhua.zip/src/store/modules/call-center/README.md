# call center vuex module 资料

## 全局的IM 事件监听

我们已经将腾讯IM 进行了二次封装，并且基于Vue 的eventHub 方式来实现全局事件监听。
可以方便的在各个组件中添加监听，比如获取服务器推送的管理员消息等。

### 如何使用？

对于vue 组件，可以方便的使用vuex mapActions 方式，将初始化IM action 映射进来。

这是推荐做法，但是考虑到其中有异步过程，整个客服App 只调用一次（即登录一次）即可。
其他组件希望用到IM的各项功能，只需要注册监听事件即可。
```javascript
export default {
  mounted() {
    // 初始化im
    this.initIM().then(txim => {
      // todo demo
      txim.addEventListener(txim.EVENT_TYPE.MSG, message => {
        console.log('我们可以多处监听IM传来的消息了', message.text)
      })
      txim.addEventListener(txim.EVENT_TYPE.NOTIFY, message => {
        console.log('这里是管理员消息：', message)
      })
    })
  },
  methods: {
    ...mapActions('call', ['initIM'])
  }
}
```

如果想直接使用，可以参考这里，
```javascript
import txim from '@/store/modules/call-center/im-tx'

txim.getInstance
txim.stop
txim.sendMessage
txim.addEventListener
txim.removeEventListener
txim.EVENT_TYPE
txim.ACTION_TYPE
```