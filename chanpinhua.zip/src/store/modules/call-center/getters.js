export const engineerQueue = state => state.engineerQueue
export const sessions = state => state.sessions
export const system = state => state.system
export const IMReady = state => state.im.ready
export const audioPlaying = state => state.system.audioPlaying
export const currentSession = state => state.sessions[state.currentSessionID]
export const currentSessionOrDefault = state => state.sessions[state.currentSessionID] || state.system.defaultSession
export const currentSessionID = state => state.currentSessionID
export const currentStatus = state => state.currentStatus
export const workStatus = state => state.workStatus

export const hasVoicePermission = (state) => {
  return state.voice.session.id !== ''
}
