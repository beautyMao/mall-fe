import * as types from './mutation-types'
import * as api from '@/api/call-center/call-center'
import { personTransfer, queueTransfer } from '@/api/call-center/call-center'
import txim from './im-tx'
import { cubeUploadFile } from '@/api/qiniu'
import { MESSAGE_TYPE } from '@/store/modules/call-center/msg-util'
// import get from 'lodash.get'

import config from './config'

import {
  convertCharacterEntity, convertRecommendMessage,
  convertSplitMessage,
  convertToEngineerTmpMessage,
  convertToMessage,
  convertToSession,
  convertToVoiceSession,
  uuid
} from '@/store/modules/call-center/convert'
import { captureException } from '@/utils/error-report'
import { ClientType, IMActionType, IMEventType, IMNotifyType } from '@/store/modules/call-center/enum'
import { convertHistoryToMessage } from '@call/convert'
import { sleep } from '@/utils'
import { convertHttpLink, convertToSimpleLink } from '@/utils/conver-util'

/**
 * 获取机器人的答案
 * @param commit
 * @param sessionId
 * @param question
 * @param message
 * @returns {Promise.<T>}
 */
export const getRobotAnswer = ({ commit }, { sessionId, question, message }) => {
  return api.getAnswerRecommend(question, sessionId).then(res => {
    if (res.data.recommend && res.data.recommend.length) {
      const recommends = res.data.recommend.map(text => {
        return {
          content: convertRecommendMessage(text),
          html: text,
          isNoSend: text.indexOf('[nsd]') > -1
        }
      }).filter(item => item.content.trim() !== '')
      commit(types.SET_RECOMMEND_DATA, { sessionId, message, recommendData: {
        standard: res.data.standard,
        recommends
      }})
    }

    return Promise.resolve(res)
  }).catch(() => {})
}

/**
 * 消息发送给机器人检查是否有推荐话术
 * @param commit
 * @param rootState
 * @param rootGetters
 * @param message
 * @param session
 * @param input
 */
export const messageToRobot = ({ commit, rootState, rootGetters }, message, session) => {
  // 只有当文本或者语音时，才请求智能推荐接口
  if (message.type !== MESSAGE_TYPE.Text && message.type !== MESSAGE_TYPE.Voice) {
    return
  }

  let question = message.content
  if (message.type === MESSAGE_TYPE.Voice) {
    question = message.text
  }
  return getRobotAnswer({ commit }, {
    sessionId: session.id,
    question,
    message
  })
}

/**
 * 初始化客服服务数量信息
 * @param commit
 * @param engineerCode
 * @return {PromiseLike<T | never> | Promise<T | never>}
 */
export const initEngineerServeNum = ({ commit }, engineerCode) => {
  return api.getEngineerQueueNum(engineerCode).then(response => {
    commit(types.SET_ENGINEER_SERVE_NUM, response.data)
    return response
  })
}

/**
 * 初始化IM 工具
 * @param commit
 * @param rootState
 * @return {PromiseLike<T | never> | Promise<T | never> | *}
 */
export const initIM = ({ commit, rootState }) => {
  const userSig = rootState.user.allInfo.im_sign
  const engineerCode = rootState.user.allInfo.code
  commit(types.SET_ENGINEER_SIGN, userSig)
  return txim.getInstance(engineerCode, userSig)
}

// 消息处理函数单例
let messageHandleFunc = null
let multipleLoginFunc = null

/**
 * 客服上线动作
 * 如果有软电话权限，则登录座机
 * @param commit
 * @param state
 * @param rootGetters
 * @param getters
 * @param rootState
 * @param dispatch
 * @param engineerCode
 * @return {PromiseLike<T | never> | Promise<T | never>}
 */
export const login = ({ commit, state, rootGetters, getters, rootState, dispatch }, engineerCode) => {
  // 避免消息处理函数被注册两次
  if (!messageHandleFunc && !multipleLoginFunc) {
    messageHandleFunc = messageHandle(commit, rootState, rootGetters, getters, engineerCode, state, dispatch)
    multipleLoginFunc = handleMultipleLogin(commit)

    txim.addEventListener(IMActionType.ChatMessage, messageHandleFunc)
    txim.addEventListener(IMActionType.Notification, messageHandleFunc)
    txim.addEventListener(IMEventType.KICKOFF, multipleLoginFunc)
    commit(types.SET_IM_READY, true)
  }

  // todo 但此时可能未就绪，是否考虑就绪后再拉取正在进行的对话列表（session list）
  return api.getCaseList(engineerCode).then(response => {
    const promises = response.data.map(data => {
      return dispatch('initSession', {
        sessionData: data
      })
    })

    return Promise.all(promises)
  })
}

/**
 * 客服注销下线
 * 同时移除TX IM 上的事件监听，防止客服二次收到消息
 * @param commit
 * @param rootState
 */
export const logout = ({ commit, rootState }) => {
  txim.removeEventListener(IMActionType.ChatMessage, messageHandleFunc)
  txim.removeEventListener(IMActionType.Notification, messageHandleFunc)
  txim.removeEventListener(IMEventType.KICKOFF, multipleLoginFunc)

  messageHandleFunc = null
  multipleLoginFunc = null
}

/**
 * 客服主动刷新用户列表
 * @param commit
 * @param getters
 * @param state
 * @param rootGetters
 * @param dispatch
 * @return {PromiseLike<T | never> | Promise<T | never>}
 */
export const refreshSessions = ({ commit, getters, state, rootGetters, dispatch }) => {
  return api.getCaseList(rootGetters.allInfo.code).then((response) => {
    // todo 只处理了新增session 丢失session 尚未处理
    // 新加入的sessions
    const newSessions = response.data.filter((session) => {
      return !state.sessions[session.id]
    })
    // 找出丢失的session 关闭他们并返回被关的session
    const sessionIds = Object.keys(state.sessions)
    const newSessionIds = response.data.map(session => session.id)
    let removeSessions = []
    for (let i = 0; i < sessionIds.length; i++) {
      !newSessionIds.includes(sessionIds[i]) && removeSessions.push(state.sessions[sessionIds[i]])
    }
    // 排除虚拟session（案面用）
    removeSessions = removeSessions.filter(session => !session.isVirtual)

    // 待处理promise list
    const sessionsPromises = []

    // 新增session 通用处理
    sessionsPromises.push(...newSessions.map(data => {
      return dispatch('initSession', {
        sessionData: data
      })
    }))

    // todo client_type 继续增加时，这里需要抽离
    // 文本类session 处理
    sessionsPromises.push(...removeSessions.filter(session => session.client_type === ClientType.Wechat).map(session => {
      commit(types.CLOSE_SESSION, session)
      return Promise.resolve('closeSession')
    }))

    // 语音类session 处理
    sessionsPromises.push(...removeSessions.filter(session => session.client_type === ClientType.Telephone).map(session => {
      // 为了避免左右两次内容信息不同步，不再主动移除session
      // commit(types.CLOSE_SESSION, session)
      return Promise.resolve('voice sesession closed:' + session.id)
    }))

    // 已修改为后端在用户进入会话前统计，只需要刷服务量接口即可
    sessionsPromises.push(initEngineerServeNum({ commit }, rootGetters.allInfo.code))

    // 最后一个promise 是默认必定存在的，所以根据promise return data length 即可判断是否有增减
    // 如果有增减，就应该触发检查IM轮询是否正常
    return Promise.all(sessionsPromises)
  })
}

/**
 * 初始化webchat
 * @param commit
 * @param getters
 * @param state
 * @param session
 * @param isNewSession
 */
export const initChatSession = ({ commit, getters, state }, { session, isNewSession }) => {
  commit(types.TRY_SWITCH_SESSION, session.id)
  let thisSession = null

  // TODO 这里是分页获取的 history sessions，更多历史记录尚未处理
  return api.getAllSessions(session.cube_uid).then(async caseList => {
    let loadCaseid = 0

    if (caseList.data.length) {
      thisSession = caseList.data[0]
      loadCaseid = thisSession.id
    }

    commit(types.SET_CASE_LIST, { sessionId: session.id, list: caseList.data })
    if (!loadCaseid) {
      return 'no more message'
    }

    await sleep(1000) // 因为欢迎语消息是异步在存储在后端，所以延迟1s 后做历史消息的拉取

    return loadMoreMessages({ commit }, {
      session, nextSessionId: loadCaseid, isFirstLoad: true, isNewSession
    })
  }).catch(e => {
    console.log('[initChatSession] e:', e)
  })
}

/**
 * 通用的会话初始化，将自动区别于wechat telephone 等类型的会话
 * @param commit
 * @param rootGetters
 * @param getters
 * @param state
 * @param dispatch
 * @param sessionData
 * @param isNewSession
 * @return {Promise<string>}
 */
export const initSession = async({ commit, rootGetters, getters, state, dispatch }, { sessionData, isNewSession }) => {
  let session
  let rePromise = Promise.resolve('unknown session init')
  const type = sessionData.client_type
  // 目前保证在session 中取得所需的用户信息，就不用额外获取用户详情了
  // const userInfoData = await getUserInfo(sessionData.cube_uid)

  if ([ClientType.Webchat, ClientType.Wechat].includes(type)) {
    // session = convertToSession(sessionData, userInfoData.data)
    session = convertToSession(sessionData, { isNewSession })
    rePromise = initChatSession({ commit, getters, state }, { session, isNewSession })
  } else if (type === ClientType.Telephone) {
    session = convertToVoiceSession(sessionData)
    rePromise = dispatch('initVoiceSession', { session })
  }

  commit(types.RECEIVE_SESSION, session)
  return rePromise
}

/**
 * 加载更多聊天记录
 * 如果用户有多个历史咨询记录，该功能将依次加载历史对话信息
 * @param commit
 * @param session
 * @param nextSessionId
 * @param isFirstLoad 针对initSession，初始化的第一次load history，这里为true
 * @param isNewSession
 * @return {PromiseLike<number | never>}
 */
export const loadMoreMessages = ({ commit }, { session, nextSessionId, isFirstLoad, isNewSession }) => {
  const caseList = session.caseList.map(item => item.id)
  const index = caseList.indexOf(nextSessionId)
  const hasMore = caseList.length > index + 1
  const messages = []

  // 加载更多历史消息
  if (hasMore) {
    messages.push({
      id: uuid('more'),
      type: 'more',
      next: caseList[index + 1]
    })
  } else {
    messages.push(convertSplitMessage('已无更多记录'))
  }

  return api.getHistory(nextSessionId, session.cube_uid).then(response => {
    const caseSession = convertToSession(session.caseList[index])
    // 使用的是用户开始对话的时间，并非排队时间：created_at
    const createTime = caseSession.start_talking_at
    const dataMessages = response.data.data

    if (dataMessages && dataMessages.length) {
      messages.push(convertSplitMessage(`与客服 ${caseSession.engineer_name}(${caseSession.engineer_code}) 的对话记录 ${createTime}`))

      dataMessages.reverse().forEach(data => {
        // 预先对历史消息内的content 做一次不安全的字符串转译
        data.text = convertCharacterEntity(data.text)
        // 转换消息时，需要用到当时的session 信息
        messages.push(convertHistoryToMessage(data, caseSession))
      })

      // if (isFirstLoad) {
      //   messages.push(convertSplitMessage('———— 历史消息 ————'))
      // }
    } else {
      // 空会话过滤
      if (hasMore && !isFirstLoad) {
        return loadMoreMessages({ commit }, {
          session,
          nextSessionId: caseList[index + 1],
          isFirstLoad: false,
          isNewSession
        })
      }
    }
    commit(types.HISTORY_MESSAGE, { session, messages })

    // 有顺序问题，先set messages，再标记loaded = true
    // if (isFirstLoad) {
    //   commit(types.HISTORY_FIRST_LAODED, { session })
    // }
    return Promise.resolve(1)
  })
}

/**
 * 转接操作，根据参数自动判断是转接到个人or 队列
 * 转接成功后服务量加1
 * @param commit
 * @param session
 * @param toSkill
 * @param type
 * @param toEngineerCode
 * @return {PromiseLike<T | never> | Promise<T | never> | *}
 */
export const transferSession = ({ commit }, { session, toSkill, toEngineerCode }) => {
  const action = toEngineerCode ? personTransfer : queueTransfer
  return action(session.id, toSkill, toEngineerCode).then(response => {
    // 转接成功 本地服务量+1 并关闭UI session
    commit(types.CLOSE_SESSION, session)
    return response
  })
}

/**
 * 在会话历史记录里增加一条系统提示信息（本地）
 * @param commit
 * @param session
 * @param text
 * @param systemMessage
 */
export const addSystemMessage = ({ commit }, { session, text }) => {
  const message = convertSplitMessage(text)
  commit(types.SEND_MESSAGE, { sessionId: session.id, message })
}

/**
 * 客服发送消息
 * @param commit
 * @param rootState
 * @param rootGetters
 * @param text
 * @param session
 * @param safeMessage
 * @returns {Promise}
 */
export const sendMessage = ({ commit, rootState, rootGetters }, { text, session, safeMessage }) => {
  const tmpMessage = convertToEngineerTmpMessage(text, MESSAGE_TYPE.Text, session)
  commit(types.SEND_MESSAGE, { sessionId: session.id, message: tmpMessage })

  // 允许客服发送安全域下的链接，并转换为a tag
  // 如果完全信任消息里的链接，则safeMessage = true,一般用于机器人消息
  let tximMsgContent = convertHttpLink(text)
  if (safeMessage) {
    tximMsgContent = text
  }
  // 如果是工程师发送的消息，在微信通路下，a tag 不能有target attr
  if (ClientType.Wechat === session.client_type) {
    text = convertToSimpleLink(text)
  }
  return txim.sendMessage(tximMsgContent, 'Text', session).then(({ content, type, sessionId }) => {
    tmpMessage.error = ''

    commit(types.UPDATE_SENDING_STATE, { sessionId: session.id, message: tmpMessage })
    messageToRobot({ commit, rootState, rootGetters }, tmpMessage, session)

    return Promise.resolve(tmpMessage)
  }).catch((error) => {
    tmpMessage.error = 'error'
    commit(types.UPDATE_SENDING_STATE, { sessionId: session.id, message: tmpMessage })
    // 将异常抛出，外层处理
    return Promise.reject({
      error,
      message: `${error.SrcErrorInfo}, ${error.ErrorCode}`
    })
  })
}

/**
 * 检测到lenovo 用户未正确导入到TXIM 账号体系下，尝试重新导入
 * @param commit
 * @param session
 * @return {PromiseLike<T | never | never> | Promise<T | never | never> | *}
 */
export const tryFixUserAccount = ({ commit }, { session }) => {
  return api.getSign(config.IM.ADMIN_ACCOUNT).then(response => {
    const adSig = response.data
    const { lenovo_id, user_name, user_avatar } = session
    return txim.fixUserAccount(adSig, lenovo_id, user_name, user_avatar)
  })
}

/**
 * 保存聊天草稿
 * @param commit
 * @param sessionId
 * @param draft
 * @returns {Promise}
 */
export const saveDraft = ({ commit }, { sessionId, draft }) => {
  commit(types.DRAFT_MESSAGE, { sessionId, draft })
  return Promise.resolve(types.DRAFT_MESSAGE)
}

/**
 * 客服发送图片消息
 * @param commit
 * @param rootGetters
 * @param base64
 * @param session
 * @returns {Promise}
 */
export const sendImage = ({ commit, rootGetters }, { base64, session }) => {
  const tmpMessage = convertToEngineerTmpMessage(base64, MESSAGE_TYPE.Image, session)
  commit(types.SEND_MESSAGE, { sessionId: session.id, message: tmpMessage })

  // 发起http请求,发送图片
  const _http = (blob) => {
    return cubeUploadFile(blob).then((data) => {
      return txim.sendMessage(data.url, MESSAGE_TYPE.Image, session)
    }).then((imResponse) => {
      if (imResponse.ActionStatus === 'OK') {
        tmpMessage.error = ''
        commit(types.UPDATE_SENDING_STATE, { sessionId: session.id, tmpMessage })
        return tmpMessage
      } else {
        return imResponse.ActionStatus
      }
    }).catch((error) => {
      tmpMessage.error = 'error'
      commit(types.UPDATE_SENDING_STATE, { sessionId: session.id, message: tmpMessage })
      return Promise.reject({
        error,
        message: error.response.data.error
      }) // 将异常抛出到UI层处理
    })
  }

  // http://devdocs.io/dom/fetch_api/using_fetch
  // base64 to blob
  return fetch(base64).then((res) => {
    return res.blob()
  }).then(_http)
}

/**
 * 从聊天记录列表中删除消息,通常用于发送失败的图片重发时使用
 * @param commit
 * @param id
 * @param session
 */
export const deleteMessageFromList = ({ commit }, { id, session }) => {
  commit(types.DELETE_MESSAGE_FROM_LIST, { sessionId: session.id, id })
}

/**
 * 用户发送的图片加载错误调用方法
 * @param commit
 * @param message
 * @param session
 */
export const customerImageLoadError = ({ commit }, { message, session }) => {
  commit(types.UPDATE_MESSAGE_STATE_ERROR, { sessionId: session.id, message })
}

/**
 * 用户发送的图片加载错误调用方法
 * @param commit
 * @param message
 * @param session
 */
export const customerImageLoadSuccess = ({ commit }, { message, session }) => {
  commit(types.UPDATE_MESSAGE_STATE_SUCCESS, { sessionId: session.id, message })
}

/**
 * 用户发送的图片加载错误调用方法
 * @param commit
 * @param message
 * @param session
 */
export const reloadCustomerImage = ({ commit }, { message, session }) => {
  commit(types.RELOAD_CUSTOMER_IMAGE, { sessionId: session.id, message })
}

/**
 * 关闭会话
 * @param commit
 * @param session
 * @param isAuto 如果是自动关闭的会话，这里 = 'auto'
 * @return {PromiseLike<T | never> | Promise<T | never>}
 */
export const closeSession = ({ commit }, { session, isAuto }) => {
  // 如果是案面会话，直接移除即可
  if (session.isVirtual) {
    return removeSession({ commit }, session)
  }
  return api.endConversation(session.id, isAuto).then(() => {
    commit(types.CLOSE_SESSION, session)
    return Promise.resolve('closeSession')
  })
}

/**
 * 用户主动关闭了会话
 * 工作台不关闭会话，让其处于案面状态
 * @param commit
 * @param sessionId
 */
export const userCloseSession = ({ commit }, sessionId) => {
  commit(types.SET_VIRTUAL_SESSION, { sessionId })
  return Promise.resolve('userCloseSession')
}

/**
 * 用于移除失效的或者虚拟session
 * 仅修改vuex state，并没有额外动作
 * @param commit
 * @param session
 */
export const removeSession = ({ commit }, session) => {
  commit(types.CLOSE_SESSION, session)
  return Promise.resolve('removeSession')
}

/**
 * 切换会话
 * @param commit
 * @param nextSession
 */
export const switchSession = ({ commit }, nextSession) => {
  commit(types.SWITCH_SESSION, nextSession.id)
}

/**
 * 获得一个消息处理函数
 * @param commit
 * @param rootState
 * @param rootGetters
 * @param getters
 * @param engineerCode
 * @param state
 * @param dispatch
 * @return {Function}
 */
const messageHandle = function(commit, rootState, rootGetters, getters, engineerCode, state, dispatch) {
  return (message, messageType, bodyType) => {
    console.log('[IM INFO]', JSON.stringify(message))
    const currentSessions = getters.sessions
    // 处理实时消息
    if (messageType === IMActionType.ChatMessage) {
      const targetSession = currentSessions[message.SessionID]
      // todo 可能存在收到消息，但是没有session 在会话列表里
      if (targetSession) {
        message = convertToMessage(message, targetSession)

        commit(types.USER_SEND_MESSAGE, {
          sessionId: targetSession.id,
          message
        })
        messageToRobot({ commit, rootState, rootGetters }, message, targetSession)
      } else {
        captureException('ACTION_ERROR_REPORT', new Error('收到了用户消息，但该用户并未在会话列表中'), {
          message,
          currentSessions
        })
      }
    }

    // 开始处理通知类消息，这里需要关注两个类别
    if (messageType !== IMActionType.Notification) {
      return
    }
    if (bodyType === IMNotifyType.CreateSession) {
      // 新用户进入通知
      api.getCaseList(engineerCode).then(caseList => {
        const newSessionData = caseList.data.find(item => currentSessions[item.id] === undefined)
        if (newSessionData) {
          return dispatch('initSession', {
            sessionData: newSessionData,
            isNewSession: true
          })
        }
      }).then(res => {
        // 已修改为后端在用户进入会话前统计，只需要刷服务量接口即可
        initEngineerServeNum({ commit }, engineerCode)
      })
    } else if (bodyType === IMNotifyType.Timeout) {
      // 服务端有个shell 处理，自动关闭超过两小时没有交互的会话
      refreshSessions({ commit, getters, rootGetters, state: rootState.call })
    } else if (bodyType === IMNotifyType.UserCloseSession) {
      // webchat 用户主动关闭了会话
      userCloseSession({ commit }, message.session_id)
    }
  }
}

/**
 * 呼叫中心右侧功能区切换
 * @param commit
 * @param tabName
 */
export const changeRightRouter = function({ commit }, { tabName }) {
  commit(types.CHANGE_RIGHT_ROUTE, { tabName })
}

/**
 * 登出 处理TXIM 多人登录时logout
 * @param commit
 * @returns {function()}
 */
const handleMultipleLogin = function(commit) {
  return () => {
    commit(types.SET_IM_READY, false)
  }
}
