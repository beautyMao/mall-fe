import Vue from 'vue'
import * as types from './mutation-types'
import { messageDistance, singleMessageDistance } from '@/store/modules/call-center/msg-util'
import config from '@/store/modules/call-center/config'

export default {
  // 初始化IM SIGN
  [types.SET_ENGINEER_SIGN](state, data) {
    state.im.userSig = data
  },

  // 初始化客服服务量
  [types.SET_ENGINEER_SERVE_NUM](state, data) {
    // BigQueueNum: 0
    // personalQueueNum: 0
    // serviceNum: 0
    // phoneWaitNum
    state.engineerQueue.totalService = data.serviceNum
    state.engineerQueue.publicQueue = data.BigQueueNum
    state.engineerQueue.privateQueue = data.personalQueueNum
    state.engineerQueue.mainQueue = data.phoneWaitNum
  },

  // 更新IM 的状态
  [types.SET_IM_READY](state, isReady) {
    state.im.ready = isReady
  },

  // 客服登录后，收到新的会话
  [types.RECEIVE_SESSION](state, session) {
    Vue.set(state.sessions, session.id, session)
  },

  // 设置一个会话为虚拟会话，用于客服的案面工作
  // 虚拟会话只能被客服手动关闭，不会被自动刷新移除
  [types.SET_VIRTUAL_SESSION](state, { sessionId, isVirtual = true }) {
    state.sessions[sessionId].isVirtual = isVirtual
  },

  // 获取历史会话列表
  [types.SET_CASE_LIST](state, { sessionId, list }) {
    state.sessions[sessionId].caseList = list
  },

  // 获取会话的历史记录
  [types.HISTORY_MESSAGE](state, { session, messages }) {
    config.system.showMsgDistance && messageDistance(messages)
    const origin = state.sessions[session.id].messages.filter(item => item.type !== 'more')
    state.sessions[session.id].messages = [].concat(messages, origin)
  },

  // 客服发送内容
  [types.SEND_MESSAGE](state, { sessionId, message }) {
    const session = state.sessions[sessionId]
    if (session) {
      config.system.showMsgDistance && singleMessageDistance(message, session.messages[session.messages.length - 1])
      session.messages.push(message)
    } else {
      alert('客服尝试发送消息，但是未能为该用户建立会话，请联系产品经理获得帮助')
    }
  },

  // 用户发送内容
  [types.USER_SEND_MESSAGE](state, { sessionId, message }) {
    const session = state.sessions[sessionId]
    if (session) {
      config.system.showMsgDistance && singleMessageDistance(message, session.messages[session.messages.length - 1])
      session.messages.push(message)

      // If user not active, set user active
      if (!session.userActive) {
        session.userActive = true
      }
    } else {
      alert('收到用户消息，但是未能为该用户建立会话，请联系产品经理获得帮助')
    }
  },

  // 播放另一条语音的时候，其他症状播放的语音要停止
  [types.AUDIO_PLAYING](state, playItem) {
    state.system.audioPlaying = playItem
  },

  // 设置用户活跃状态
  [types.UPDATE_USER_ACTIVE](state, { sessionId, isActive }) {
    const session = state.sessions[sessionId]
    if (session) {
      session.userActive = isActive
    }
  },

  // 设置会话状态
  [types.UPDATE_SESSION_STATE](state, { sessionId, sessionState }) {
    const session = state.sessions[sessionId]
    if (session) {
      session.state = sessionState
    }
  },

  // 消息发送完成回调
  [types.UPDATE_SENDING_STATE](state, { sessionId, message }) {
    const session = state.sessions[sessionId]
    if (!session) {
      return
    }

    const messages = session.messages
    for (let i = 0; i < messages.length; i++) {
      if (messages[i].id === message.id) {
        messages[i] = { ...message }
        break
      }
    }

    state.sessions[sessionId].messages = [...messages]
  },

  // 消息发送失败，做标记
  [types.UPDATE_MESSAGE_STATE_ERROR](state, { sessionId, message }) {
    const session = state.sessions[sessionId]
    if (!session) {
      return
    }

    const target = session.messages.find(m => m.id === message.id)
    if (target) {
      target.error = 'error'
    }
  },

  // 消息接收/发送成功
  [types.UPDATE_MESSAGE_STATE_SUCCESS](state, { sessionId, message }) {
    const session = state.sessions[sessionId]
    if (!session) {
      return
    }

    const target = session.messages.find(m => m.id === message.id)
    if (target) {
      target.error = null
    }
  },

  // 重新加载用户发送的图片
  [types.RELOAD_CUSTOMER_IMAGE](state, { sessionId, message }) {
    const session = state.sessions[sessionId]
    if (!session) {
      return
    }

    const target = session.messages.find(m => m.id === message.id)
    if (target) {
      target.content = `${message.content.split('?')[0]}?${Math.random()}`
      target.error = ''
    }
  },

  // 从聊天列表中根据ID删除某条消息
  [types.DELETE_MESSAGE_FROM_LIST](state, { sessionId, id }) {
    const session = state.sessions[sessionId]
    if (!session) {
      return
    }

    const messages = session.messages
    for (let i = 0; i < messages.length; i++) {
      if (messages[i].id === id) {
        messages.splice(i, 1)
        break
      }
    }
  },

  // 草稿内容
  [types.DRAFT_MESSAGE](state, { sessionId, draft }) {
    if (state.sessions[sessionId]) {
      state.sessions[sessionId].draft = draft
    }
  },

  // 切换会话
  [types.SWITCH_SESSION](state, id) {
    state.currentSessionID = id
  },

  // 切换会话，仅当客户端没有会话时才切换
  [types.TRY_SWITCH_SESSION](state, id) {
    if (!state.currentSessionID) {
      state.currentSessionID = id
    }
  },

  // 关闭会话
  [types.CLOSE_SESSION](state, session) {
    Vue.delete(state.sessions, session.id)
    if (state.currentSessionID === session.id) {
      if (Object.keys(state.sessions).length > 0) {
        state.currentSessionID = Object.keys(state.sessions)[0]
      } else {
        state.currentSessionID = null
      }
    }
  },

  // 收到有效的智能推荐信息
  [types.SET_RECOMMEND_DATA](state, { sessionId, message, recommendData }) {
    const session = state.sessions[sessionId]
    if (session) {
      const msg = session.messages.find(m => m.id === message.id)
      Vue.set(msg, 'recommendData', recommendData)
    }
  },

  // 当前会话，右侧功能区切换记录
  [types.CHANGE_RIGHT_ROUTE](state, { tabName }) {
    const session = state.sessions[state.currentSessionID]
    if (session) {
      session.rightRoute = tabName
    }
  },

  // 腾讯IM 签名
  [types.SET_ENGINEER_SIGN](state, data) {
    state.im.userSig = data
  }
}
