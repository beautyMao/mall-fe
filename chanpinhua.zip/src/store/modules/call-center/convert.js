/* eslint-disable */
import { defaultMessage, defaultSession, defaultVoiceSession } from '@/store/modules/call-center'
import { MESSAGE_TYPE } from './msg-util'
import config from './config'
import { deepClone, getDateFormat, html2Text, stringToIntHash } from '@/utils'
import { ClientType, IMActionType } from '@/store/modules/call-center/enum'
import { CallState, CallType, ThirdPartyRole } from '@/store/modules/call-center/voice/enum'
import md5 from 'js-md5'
import { convertEmoji } from '@/utils/emoji'
import { convertHttpLink, convertLink, convertNewLine, convertXSS } from '@/utils/conver-util'
import { CUBE } from '@/configuration'

const colors = ['#1abc9c', '#37d078', '#3f9ddd', '#9b59b6', '#34495e', '#f39c12', '#d35400', '#e74c3c', '#7f8c8d']

const adjective = ["温柔", "内向", "腼腆", "害羞", "率性", "活泼", "开朗", "多情", "热情", "飘逸", "可爱", "慈祥", "老实", "暴躁", "急躁", "虚心", "勤奋", "热心", "自信", "任性", "冲动", "胆小", "安静", "憨厚", "淡定", "坚强", "火爆", "奔放", "痴情", "调皮", "捣蛋", "坏坏", "安静", "斯文", "愉快", "兴奋", "活泼", "幸福", "高兴", "微笑", "乐观", "深情", "快乐", "激动", "欢乐", "欢快", "痛苦", "烦恼", "紧张", "忧郁", "焦虑", "苦闷", "着急", "难过", "愤怒", "失望", "苦恼", "悲伤", "开心", "不开心", "无聊", "孤独", "空虚", "寂寞", "失恋", "单身", "发呆", "发怒", "失眠", "睡不着", "刚分手", "刚失恋", "曾经爱过", "曾深爱过", "伤情", "时尚", "路过", "飞翔", "行走", "奔跑", "暴走", "飞奔", "销魂", "火星上", "星星上", "月球上", "奋斗", "逆袭", "拉风", "咆哮", "很拉风", "要出家", "想出家", "呐喊", "笑点低", "没人理", "会搭讪", "爱搭讪", "私奔", "逃跑", "越狱", "打盹", "喝醉", "微醺", "求醉", "买醉", "耍酷", "酷酷", "灰常酷", "很酷", "非常酷", "想发财", "发财", "犯傻", "想旅行", "旅行中", "旅途中", "想表白", "不敢表白", "从未表白", "被表白", "千年单身", "一直单身", "至今单身", "还单身", "道上混", "玩手机", "不要命", "玩命", "有爱心", "热心肠", "会开车", "闯红灯", "唠叨", "迷茫", "彷徨", "忐忑", "茫然", "失落", "逃课", "怕考试", "想出国", "考研", "读研", "没读研", "爱逃课", "挂过科", "不爱学习", "暗恋学妹", "爱玩", "贪玩", "有腹肌", "瘦瘦", "小眼睛", "眼睛小", "鼻子大", "大鼻子", "眉毛粗", "粗眉毛", "帅气", "帅呆", "好帅", "近视", "跑龙套", "打酱油", "八块腹肌", "一身肌肉", "满身肌肉", "没有腹肌", "爱听歌", "爱跑步", "爱看球", "玩滑板", "爱看书", "爱热闹", "爱吹牛", "健身", "爱健身", "阳光", "帅气", "温暖", "绅士", "礼貌", "宽容", "大气", "爱笑", "温柔", "不羁", "追风", "完美", "耍酷", "魁梧", "睿智", "深沉", "稳重", "豪爽", "低调", "淡定", "活泼", "狂野", "开朗", "安静", "高大", "仗义", "正直", "博学", "爽快", "直爽", "果断", "豁达", "沉着", "儒雅", "冷静", "从容", "谦逊", "精明", "干练", "机灵", "聪明", "健壮", "阳刚", "慷慨", "善良", "坚强", "乐观", "心软", "刚毅", "俊逸", "俊秀", "严肃", "飘逸", "成熟", "沉稳", "谦和", "坚韧", "憨厚", "老实", "含蓄", "文雅", "大方", "强悍", "强健", "高大", "深情", "长情", "踏实", "痴情", "体贴", "细心", "任性", "独立", "个性", "另类", "腹黑", "腼腆", "纯真", "酷酷", "怕老婆", "冷冷", "听话", "乖乖", "卖萌", "逆袭", "叛逆", "鬼畜", "无邪", "傻傻", "逼格高", "性感", "坏坏", "留胡子", "小胡子", "英俊", "潇洒", "风流", "大力", "爱运动", "爱旅游", "打篮球", "踢足球", "玩篮球", "玩足球", "霸气", "豪气", "威武", "重情义", "讲道义", "重感情", "爱喝酒", "酒量大", "酒量小", "骑白马", "风流倜傥", "玉树临风", "神勇威武", "文武双全", "力能扛鼎", "刀枪不入", "侠义非凡", "谦虚好学", "聪明伶俐", "慷慨大方", "有情有义", "有胆有识", "谈吐大方", "风度翩翩", "气势凌人", "气宇轩昂", "英勇无比", "千杯不醉", "坐怀不乱", "知识渊博", "才高八斗", "傲视众生", "光明磊落", "文质彬彬", "面冷心慈", "豪情万千", "温文尔雅", "年轻有为", "英姿勃勃", "朝气蓬勃", "不拘小节", "胡子拉碴", "阳光", "帅气", "温暖", "绅士", "礼貌", "宽容", "大气", "爱笑", "温柔", "不羁", "追风", "完美", "耍酷", "魁梧", "睿智", "深沉", "稳重", "豪爽", "低调", "淡定", "活泼", "狂野", "开朗", "安静", "高大", "仗义", "正直", "博学", "爽快", "直爽", "果断", "豁达", "沉着", "儒雅", "冷静", "从容", "谦逊", "精明", "干练", "机灵", "聪明", "健壮", "阳刚", "慷慨", "善良", "坚强", "乐观", "心软", "刚毅", "俊逸", "俊秀", "严肃", "飘逸", "成熟", "沉稳", "谦和", "坚韧", "憨厚", "老实", "含蓄", "文雅", "强悍", "闷骚", "大方", "强健", "高大", "深情", "长情", "踏实", "痴情", "体贴", "细心", "任性", "独立", "个性", "另类", "腹黑", "腼腆", "纯真", "酷酷", "怕老婆", "冷冷", "听话", "乖乖", "卖萌", "逆袭", "叛逆", "鬼畜", "无邪", "傻傻", "逼格高", "性感", "坏坏", "留胡子", "小胡子", "英俊", "潇洒", "风流", "大力", "爱运动", "爱旅游", "打篮球", "踢足球", "玩篮球", "玩足球", "霸气", "豪气", "威武", "重情义", "讲道义", "重感情", "爱喝酒", "酒量大", "酒量小", "骑白马", "风流倜傥", "玉树临风", "神勇威武", "文武双全", "力能扛鼎", "刀枪不入", "侠义非凡", "谦虚好学", "聪明伶俐", "慷慨大方", "有情有义", "有胆有识", "谈吐大方", "风度翩翩", "气势凌人", "气宇轩昂", "英勇无比", "千杯不醉", "坐怀不乱", "知识渊博", "才高八斗", "傲视众生", "光明磊落", "文质彬彬", "面冷心慈", "豪情万千", "温文尔雅", "年轻有为", "英姿勃勃", "朝气蓬勃", "不拘小节", "胡子拉碴", "有腹肌", "瘦瘦", "小眼睛", "眼睛小", "鼻子大", "大鼻子", "眉毛粗", "粗眉毛", "帅气", "帅呆", "好帅", "近视", "跑龙套", "打酱油", "八块腹肌", "一身肌肉", "满身肌肉", "没有腹肌", ""]
const noun = ["西红柿", "番茄", "菠萝", "西瓜", "香蕉", "柚子", "桔子", "橙子", "苹果", "柠檬", "梨子", "椰子", "葡萄", "甘蔗", "芒果", "木瓜", "柿子", "石榴", "槟榔", "猕猴桃", "蟠桃", "山楂", "香瓜", "甜瓜", "地瓜", "李子", "杨桃", "枇杷", "柑橘", "荔枝", "火龙果", "南瓜", "玉米", "生菜", "莴苣", "大白菜", "萝卜", "胡萝卜", "韭菜", "木耳", "豌豆", "马铃薯", "土豆", "黄瓜", "苦瓜", "洋葱", "芹菜", "蘑菇", "菠菜", "莲藕", "紫菜", "茄子", "香菜", "青椒", "四季豆", "茴香", "金针菇", "扁豆", "竹笋", "绿豆", "红豆", "黄豆", "毛豆", "黄花菜", "豆芽", "丝瓜", "大蒜", "生姜", "大葱", "香菇", "酱牛肉", "酱肘子", "小虾米", "鸡蛋", "鸭蛋", "皮蛋", "牛腩", "罐头", "豆腐", "火腿肠", "脆皮肠", "小马驹", "斑马", "山羊", "长颈鹿", "大象", "鸵鸟", "骆驼", "猴子", "松鼠", "蚂蚁", "刺猬", "企鹅", "啄木鸟", "小蝌蚪", "青蛙", "海龟", "海豚", "熊猫", "大熊猫", "小熊猫", "野马", "烈马", "奔马", "小狗", "热带鱼", "红金鱼", "金鱼", "仙人掌", "仙人球", "松树", "柳树", "圣诞树", "筷子", "碗", "勺子", "凳子", "板凳", "椅子", "电脑桌", "沙发", "台灯", "杯子", "保温杯", "茶壶", "灯泡", "日光灯", "钱包", "钥匙", "蜡烛", "手电筒", "钥匙扣", "热水瓶", "开水瓶", "水桶", "水龙头", "脸盆", "镜子", "火柴", "打火机", "抽屉", "剪刀", "枕头", "毛巾", "牙膏", "电池", "路灯", "拖把", "马克杯", "砖头", "鞭炮", "硬币", "水煮鱼", "水煮肉", "酸菜鱼", "红烧肉", "回锅肉", "紫菜汤", "米饭", "稀饭", "肉夹馍", "灌汤包", "小笼包", "馒头", "花卷", "包子", "油条", "煎饼", "煎饼果子", "牛肉面", "汉堡包", "炒饭", "炒粉", "炒面", "烤地瓜", "红薯", "烤红薯", "泡面", "鸡蛋面", "乌冬面", "牛肉面", "饺子", "凉面", "春卷", "羊肉串", "汤圆", "八宝粥", "牛排", "煎鸡蛋", "卤蛋", "盒饭", "便当", "花生", "开心果", "板栗", "核桃", "薯片", "棒棒糖", "吐司", "烤土司", "面包", "烤面包", "蛋挞", "冰淇淋", "冰棍", "雪糕", "饼干", "麦片", "爆米花", "铅笔", "钢笔", "日记本", "课本", "橡皮擦", "书包", "饭卡", "书签", "电影票", "草稿纸", "作业本", "草稿本", "签字笔", "啤酒", "红酒", "伏特加", "烈酒", "葡萄酒", "香槟", "汽水", "豆浆", "可乐", "凉茶", "白开水", "乌龙茶", "红茶", "绿茶", "咖啡", "苦咖啡", "茶叶", "咖啡豆", "卡布奇诺", "足球", "篮球", "排球", "羽毛球", "乒乓球", "显示器", "键盘", "数据线", "充电器", "移动电源", "硬盘", "鼠标", "鼠标垫", "投影仪", "充值卡", "火锅", "麻辣香锅", "铁板烧", "葫芦", "佛珠", "手链", "大脸猫", "机器人", "机器猫", "上铺", "创口贴", "伤痕", "伤疤", "手术刀", "饭盒", "楼梯", "楼房", "电梯", "口罩", "灭火器", "遥控器", "闹钟", "拐杖", "感冒药", "消炎药", "山寨机", "自行车", "小摩托", "单车", "滑板", "火车", "警车", "消防车", "围巾", "手套", "帽子", "风衣", "沙滩裤", "跑步鞋", "人字拖", "眼镜", "墨镜", "毛衣", "针织衫", "黑框眼镜", "皮带", "领带", "西装", "领结", "冲锋衣", "登山鞋", "瀑布", "树叶", "松球", "夕阳", "太阳", "大海", "高山", "荒野", "双杠", "单杠", "哑铃", "跑步机", "打火机", "香烟", "匕首", "小刀", "弓箭", "铁链", "打火机", "香烟", "匕首", "小刀", "弓箭", "铁链", "围巾", "手套", "帽子", "风衣", "沙滩裤", "跑步鞋", "人字拖", "眼镜", "墨镜", "毛衣", "针织衫", "黑框眼镜", "皮带", "领带", "西装", "领结", "冲锋衣", "登山鞋", "小马驹", "斑马", "山羊", "长颈鹿", "大象", "鸵鸟", "骆驼", "猴子", "松鼠", "蚂蚁", "刺猬", "企鹅", "啄木鸟", "小蝌蚪", "青蛙", "海龟", "海豚", "熊猫", "大熊猫", "小熊猫", "野马", "烈马", "奔马"]
const nicknames = [
  adjective,
  '的,之,的,,,'.split(','),
  noun
]

/**
 * 提供多个随机头像来源
 * @param hashString
 * @return {string}
 */
export function getRandomHeadImage(hashString = Date.now() + '') {
  const avatar = stringToIntHash(hashString, 9)
  return `static/call-center/img/avatar/${avatar >= 10 ? avatar : `0${avatar}`}.png`
  // return `//secure.gravatar.com/avatar/${hash}?s=100&d=identicon`
  // return `https://api.adorable.io/avatars/200/${hash}`
}

/**
 * 提供随机头像背景色
 * @param hashString
 * @return {string}
 */
export function getRandomHeadColor(hashString = Date.now() + '') {
  return colors[stringToIntHash(md5(hashString), 9)]
}

export function getRandomNickname(hashString) {
  if (hashString) {
    let nextHashString = hashString
    return nicknames.map(group => {
      nextHashString = md5(nextHashString)
      return group[stringToIntHash(nextHashString, group.length)]
    }).join('')
  }
  return nicknames.map(group => {
    return group[Math.floor(Math.random() * group.length)]
  }).join('')
}

/**
 * 获取唯一ID
 * @param prefix
 * @return {string}
 */
export function uuid(prefix = 'id') {
  return `${prefix}_${Math.random().toString(36).substr(2)}`
}

/**
 * 将api提供的原始数据，转化为本项目自定义的Session结构
 * 对接第三方，从这里开始改造
 * @param item
 * @param extData 附加数据
 * @return {{}}
 */
export const convertToSession = function(item, extData) {
  item = { ...defaultSession, ...item }
  item.userType = item.client_type || 'wechat'

  // item.headBackgroudColor = getRandomHeadColor()
  item.user_name = item.user_name || '[匿名] ' + getRandomNickname(item.cube_uid)
  // todo 更明确一些，现在似乎用不到
  item.userType = 'wechat'
  item.messages = []

  // 如果engineer_name 为空，应该是机器人小乐
  if (!item.engineer_code) {
    item.engineer_name = config.robot.name
    item.engineer_code = 'robot'
  }

  // 历史记录里的客服头像，是一个对象
  if (!item.engineer_avatar && item.engineer) {
    item.engineer_avatar = item.engineer.avatar
  }

  // 针对相同的用户，随机头像也应该是相同的
  if (!item.user_avatar) {
    item.user_avatar = getRandomHeadImage(item.cube_uid)
    item.user_color = getRandomHeadColor(item.cube_uid)
  }

  // 当前session 是否由消息推送后主动构建的
  if (extData && extData.isNewSession) {
    item.isNewSession = true
  }

  // 第三方数据对接处理
  // todo 之后应该抽离成为一个转换函数
  // headimgurl: "http://wx.qlogo.cn/mmopen/LSIcGLqz7Md7Kd1YwSqffAwIT6icSZFGhxFgNhXJ5OM7Nw42serd8uHDKWhc3bzOTQXfEbpPdXwoRlWmV3QdOCFCmCITytP0y/0"
  // name: "张双双"
  // nickname: "zss"
  // phone: "18910860201"
  // sex: 2
  if (extData && extData.headimgurl) {
    item.user_avatar = extData.headimgurl
  }
  if (extData && extData.name) {
    item.user_name = extData.name
  }

  return item
}

/**
 * 转换为voice session 有属性变换在这里处理
 * @param sessionData
 * @param voiceData
 */
export const convertToVoiceSession = function(sessionData, voiceData) {
  const copyVoice = voiceData ? deepClone(voiceData) : null
  const re = { ...defaultVoiceSession, ...sessionData, voiceData: copyVoice }
  re.client_type = ClientType.Telephone
  // 如果是callout 的电话，是没有队列的，这里重置一下，这个数据属性是由后端带过来的
  if (re.current_queue_code === 'callout') {
    re.current_queue_code = ''
    re.callType = CallType.Outbound
  }

  re.connId = sessionData.phone_conn_id

  if (voiceData) {
    // 由转接or多方通话接起创建的会话 初始用户通话状态为Established
    if ([ThirdPartyRole.ConferencedBy, ThirdPartyRole.TransferredBy].includes(voiceData.thirdPartyRole)) {
      re.initCallState = CallState.Established
    } else {
      re.initCallState = voiceData.call.state
    }
  }

  return re
}

/**
 * 将接收到的TX消息转化为客户端规则下的结构体
 * @param txMessage
 * @param session
 * @param isEngineer
 * @returns {{}}
 */
export const convertToMessage = function(txMessage, session, isEngineer) {
  const re = { ...defaultMessage }

  // Error Message from server for push image into Message.vue before send it to server
  re.error = txMessage.error || ''

  re.id = uuid('m')
  re.sessionId = txMessage.SessionID || session.session_id || session.id
  re.type = txMessage.Body.Type || MESSAGE_TYPE.Text
  re.isEngineer = txMessage.ClientType !== 'user'

  if (isEngineer !== undefined) {
    re.isEngineer = isEngineer
  }

  re.authorName = session.user_name
  re.avatar = session.user_avatar
  re.sendTime = txMessage.SendTime || getDateFormat()
  re.timestamp = Date.parse(txMessage.SendTime)
  re.content = txMessage.Body.Content.Text || txMessage.Body.Content.MediaUrl
  re.emotion = txMessage.Body.Content.Emotion

  if (re.type === MESSAGE_TYPE.Text) {
    re.safeContent = convertSafeContent(re.content, re.isEngineer)
  }

  if (re.isEngineer) {
    re.avatar = session.engineer_avatar || config.system.defaultAvatar
    re.authorName = session.engineer_name
  } else {
    re.avatar = session.user_avatar
  }

  re.robotIndex = '-1'

  // 如果消息来自于机器人对话
  // robot=机器人回复
  if (txMessage.ClientType === 'robot') {
    re.isEngineer = true
  }

  // 语音带翻译
  if (txMessage.Body.Type === 'Voice') {
    re.text = txMessage.Body.Content.Text
    re.content = txMessage.Body.Content.MediaUrl
  }

  return re
}

/**
 * 历史消息进行转换
 *
 * 在实时消息和数据库历史消息的结构体不一致
 * 所以才有了两个convert
 * @param hMessage
 * @param session
 */
export const convertHistoryToMessage = function(hMessage, session) {
  const isEngineer = hMessage.client_type !== 'user'
  const re = {
    ...defaultMessage,
    ...{
      id: uuid('m'), // 消息ID
      sessionId: session.id, // 消息所属的sessionId
      type: hMessage.message_type || MESSAGE_TYPE.Text, // 消息类型 [text, image, voice]
      authorName: session.user_name,
      avatar: session.user_avatar,
      isEngineer: isEngineer, // 是否是客服发送的消息
      userType: hMessage.chat_route, // 消息类型 [wechat, lenovo]
      sendTime: hMessage.send_time,
      timestamp: Date.parse(hMessage.send_time), // 消息发送时间戳
      content: hMessage.media_url || hMessage.text, // 消息内容
      emotion: hMessage.emotion,
      text: hMessage.text // 仅在语音下有效
    }
  }

  if (re.type === MESSAGE_TYPE.Text) {
    re.safeContent = convertSafeContent(re.content, re.isEngineer)
  }

  // 客服头像处理
  if (isEngineer) {
    re.avatar = session.engineer_avatar || config.system.defaultAvatar
    re.authorName = session.engineer_name
  }

  // 如果消息来自于机器人对话
  // robot=机器人回复
  if (hMessage.client_type === 'robot') {
    re.isEngineer = true
  }

  return re
}

/**
 * 构建一个用户腾讯IM下的message结构
 * @param content
 * @param type
 * @param session
 */
export const convertToTXMessage = function(content, type, session) {
  const re = {
    'MessageType': IMActionType.ChatMessage,
    'Domain': CUBE.api.domain,
    'MessageBody': {
      'SessionID': session.id,
      'ChatRoute': session.client_type,
      'ClientType': 'engineer',
      'id': uuid('m'),
      'SendTime': getDateFormat(),
      'Body': {
        'Type': type,
        'Content': {
          'Text': content,
          'Emotion': 0
        }
      }
    }
  }

  if (type === MESSAGE_TYPE.Image) {
    re.MessageBody.Body.Content.MediaUrl = content
    re.MessageBody.SourceUrl = content
  }

  return re
}

const arrEntities = {
  '&lt;': '<',
  '&gt;': '>',
  '&amp;': '&',
  '&quot;': '"',
  '&nbsp;': ' '
}

/**
 * 用于将安全的HTML 字符串 转译为标准HTML 字符串
 * @param content
 * @return {*}
 */
export const convertCharacterEntity = function(content) {
  return content.replace(/&lt;|&gt;|&amp;|&quot;|&nbsp;/g, function(match) {
    return arrEntities[match]
  })
}

/**
 * 将智能推荐里的内容进行安全转换
 * @param content
 * @return {*|void|string|never}
 */
export const convertRecommendMessage = function(content) {
	return html2Text(content.replace('[nsd]', ''))
}

/**
 * cube 自定义的TXIM 消息格式的处理
 * @param text
 * @return {{}}
 * @constructor
 */
export const IMMessageToJSON = function(text) {
  let re = null
  try {
    const temp = convertCharacterEntity(text)
    // https://sentry.lenovo.com.cn/lenovo-osd/cube-9g/issues/36216/
    // 这里有一个未解决的问题，im long polling 会拉取出一条客服发出去的消息
    // 并且结构里没有引号作为开头结尾
    re = temp.startsWith('"') ? JSON.parse(temp.substring(1, temp.length - 1)) : JSON.parse(temp)
  } catch (e) {
    console.log('[IMMessageToJSON Error]', text, e)
  }
  return re
}

/**
 * 中划线消息生成
 * @param text
 * @returns {{id: string, text: *, type: string}}
 */
export const convertSplitMessage = function(text) {
  return {
    id: uuid('split'),
    text,
    type: 'split'
  }
}

/**
 * 构建一条客服发送的,先于HTTP请求,进入消息窗口临时消息
 * @param content 消息内容
 * @param type
 * @param session
 * @return {{}}
 */
export const convertToEngineerTmpMessage = function(content, type, session) {
  const txTmpMsg = convertToTXMessage(content, type, session)
  const re = convertToMessage(txTmpMsg.MessageBody, session, true)

  re.error = 'presending'
  return re
}

/**
 * 针对文本消息体进行安全字符处理
 * 信任工程师和机器人的内容，不信任用户内容
 * @param content
 * @param isEngineer
 * @return {string}
 */
const convertSafeContent = function(content, isEngineer) {
  let re = content
  if (!isEngineer) {
    re = convertXSS(re)
  } else {
    re = convertHttpLink(convertLink(re))
  }
  re = convertNewLine(re)
  return convertEmoji(re)
}
