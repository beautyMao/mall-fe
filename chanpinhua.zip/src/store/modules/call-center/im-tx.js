/* eslint-disable */
import config from './config'
import { convertToTXMessage, IMMessageToJSON } from '@/store/modules/call-center/convert'
import Vue from 'vue'
import get from 'lodash.get'
import request from '@/utils/request'
import { param } from '@/utils'
import { IMEventType } from '@call/enum'

let _user_code // 当前聊天会话对象
let promiseInstance // im 实例化，得到Promise
const _commonEngineerHeadUrl = ''
const webim = window.webim
const LOG_NAME = '[TXIM LOG]'
const eventHub = new Vue()

/**
 * ===================== 腾讯IM 调用封装类 =======================
 * @type {{listeners, options, LOGIN_INFO}}
 */
const TX = (() => {
  // Configuration
  const APPID = config.IM.APPID
  const ACCOUNTTYPE = config.IM.ACCOUNTTYPE
  const isLogOn = config.IM.isLogOn

  const messageDispatcher = (newMsg) => {
    newMsg.toAccount = _user_code

    if (!newMsg.elems) {
      return null
    }

    for (let i = 0; i < newMsg.elems.length; i++) {
      const data = newMsg.elems[i]
      if (data.type !== webim.MSG_ELEMENT_TYPE.TEXT) {
        alert('IM发给了我们未知的消息类型')
        console.log(LOG_NAME, '[IM CONVERT OTHER]', data)
        return null
      }

      // data.type === webim.MSG_ELEMENT_TYPE.TEXT
      // 接到消息之后，在IMMessageToJSON 中做第一次的字符串转译，让接下来的流程里正确识别表情等符号
      const msg = IMMessageToJSON(data.content.text)
      if (!msg) {
        return
      }

      // const actionType = msg.chat_type
      // const type = msg.message_type
      // 消息大类型 chat、notice、robot、createSession 等
      // 每条消息类型 text/image/voice/video
      const messageType = msg.MessageType
      const bodyType = get(msg, 'MessageBody.Body.Type')
      eventHub.$emit(msg.MessageType, msg.MessageBody, messageType, bodyType)
    }

    webim.setAutoRead(newMsg.getSession(), true, true)
  }

  // 监听新消息事件
  // newMsgList 为新消息数组，结构为[Msg]
  function onMsgNotify(newMsgList) {
    if (!newMsgList) {
      return
    }

    newMsgList.map(messageDispatcher)
    webim.setAutoRead(newMsgList[0].getSession(), true, false)
  }

  // 监听连接状态回调变化事件
  function onConnNotify(resp) {
    switch (resp.ErrorCode) {
      case webim.CONNECTION_STATUS.ON:
        eventHub.$emit(IMEventType.CONNECTRET)
        return
      case webim.CONNECTION_STATUS.OFF:
        eventHub.$emit(IMEventType.RECONNECT, 'AppChat连接已断开,请检查网络连接')
        break
      case webim.CONNECTION_STATUS.RECONNECT:
        eventHub.$emit(IMEventType.CONNECTRET)
        break
      default:
        eventHub.$emit(IMEventType.UNKNOWN)
        break
    }
  }

  // 被其他登录实例踢下线
  function onKickedEventCall(e) {
    eventHub.$emit(IMEventType.KICKOFF, e)
  }

  return {
    listeners: {
      onConnNotify, onMsgNotify, onKickedEventCall
    },
    options: {
      'isAccessFormalEnv': true, // 是否访问正式环境，默认访问正式，选填
      isLogOn // 是否开启控制台打印日志,默认开启，选填
    },
    LOGIN_INFO: {
      'sdkAppID': APPID, // 用户所属应用id,必填
      'accountType': ACCOUNTTYPE, // 用户所属应用帐号类型，必填
      'identifier': null, // 当前用户ID,必须是否字符串类型，必填
      'identifierNick': null, // 当前用户昵称，选填
      'userSig': null, // 当前用户身份凭证，必须是字符串类型，必填
      'headurl': 'img/2016.gif' // 当前用户默认头像，选填
    }
  }
})()

/**
 * 登录腾讯云IM
 * @param user_code
 * @param userSig
 * @return {*}
 */
function getInstance(user_code, userSig) {
  if (promiseInstance) {
    return promiseInstance
  }

  const info = Object.assign({}, TX.LOGIN_INFO, {
    identifier: user_code,
    identifierNick: user_code,
    userSig
  })

  _user_code = user_code

  promiseInstance = new Promise((resolve, reject) => {
    // IMSDK登录
    webim.login(
      info, TX.listeners, TX.options,
      (resp) => {
        eventHub.$emit(IMEventType.LOGIN, resp)
        info.identifierNick = resp.identifierNick
        resolve(txim)
      }, error => reject(error)
    )
  })

  return promiseInstance
}

/**
 * 当客服端检测到无法给未登录的用户发送消息时
 * 尝试用该方法让用户登录
 * @param userIdentifier
 * @param userSig
 * @return {Promise<any>}
 */
function tryUserLoginIM(userIdentifier, userSig) {
  const info = Object.assign({}, TX.LOGIN_INFO, {
    identifier: userIdentifier,
    identifierNick: userIdentifier,
    userSig
  })
  const listeners = {}

  return new Promise((resolve, reject) => {
    // IMSDK登录
    webim.login(
      info, listeners, TX.options,
      (resp) => {
        eventHub.$emit(IMEventType.USER_TRY_LOGIN, resp)
        resolve(txim)
      }, error => reject(error)
    )
  })
}

/**
 * 添加消息监听
 * @param type
 * @param func
 */
function addEventListener(type, func) {
  eventHub.$on(type, func)
}

/**
 * 移除消息监听
 * @param type
 * @param func
 */
function removeEventListener(type, func) {
  eventHub.$off(type, func)
}

// 存放历史以来所有session
const webimSessions = new Map()

/**
 * 腾讯SDK 发送文本消息
 * @param content
 * @param type
 * @param session
 * @returns {Promise}
 */
function sendMessage(content, type, session) {
  let sess = webimSessions.get(session.cube_uid)
  if (!sess) {
    sess = new webim.Session(
      webim.SESSION_TYPE.C2C, session.cube_uid, session.cube_uid, _commonEngineerHeadUrl,
      Math.round(new Date().getTime() / 1000)
    )
    webimSessions.set(session.cube_uid, sess)
  }

  const msg = new webim.Msg(sess, true, -1, -1, -1, _user_code, webim.C2C_MSG_SUB_TYPE.COMMON, _user_code)
  const message = convertToTXMessage(content, type, session)
  msg.addText(new webim.Msg.Elem.Text(JSON.stringify(message)))

  return new Promise((resolve, reject) => {
    webim.sendMsg(msg, (data) => {
      resolve({
        content,
        type,
        sessionId: session.id,
        data
      })
    }, (error) => {
      console.log(LOG_NAME, JSON.stringify({
        msg: '消息发送失败',
        error,
        cube_uid: session.cube_uid,
        engid: _user_code,
        content
      }))
      reject(error)
    })
  })
}

function stop() {
  // TODO finish stop function
  webim.logout(function(resp) {
    eventHub.$emit(IMEventType.LOGOUT, resp)
    console.log(LOG_NAME, 'logout', resp)
  })
}

/**
 * 尝试修复用户账户，解决TXIM 20003问题
 * @param adSig
 * @param identifier
 * @param nickName
 * @param headImg
 * @return {PromiseLike<T | never>}
 */
function fixUserAccount(adSig, identifier, nickName, headImg) {
  let message
  if (!adSig) {
    message = '修复流程调用失败'
  }
  if (!identifier) {
    message = '该用户身份为空，无法修复'
  }
  if (message) {
    return Promise.reject({ message })
  }

  return IMApi.imAccountImport(adSig, identifier, nickName, headImg).then(response => {
    if (response.ActionStatus === 'OK') {
      console.log(LOG_NAME, '用户账户导入：成功')
      return IMApi.imAccountStateQuery(adSig, identifier)
    }

    return Promise.reject({
      message: '用户账户导入：失败'
    })
  }).then(response => {
    if (get(response, 'QueryResult[0].To_Account') === identifier) {
      console.log(LOG_NAME, '检测用户状态：正常')
      return response
    }

    return Promise.reject({
      message: '检测用户状态：异常，未能修复该账户'
    })
  })
}

const IMApi = {
  /**
   * IM 修复用户账户，尝试重新导入
   * usersig=xxx&identifier=admin&sdkappid=88888888&random=99999999&contenttype=json
   * @param adSig
   * @param identifier
   * @param nickName
   * @param headImg
   * @return {*}
   */
  imAccountImport(adSig, identifier, nickName, headImg) {
    const query = param({
      usersig: adSig,
      identifier: config.IM.ADMIN_ACCOUNT,
      sdkappid: config.IM.APPID,
      random: Date.now(),
      contenttype: 'json'
    })
    return request({
      url: 'https://console.tim.qq.com/v4/im_open_login_svc/account_import?' + query,
      method: 'post',
      data: {
        'Identifier': identifier,
        'Nick': nickName,
        'FaceUrl': headImg
      }
    })
  },
  /**
   * IM 检测用户账户状态
   * usersig=xxx&identifier=admin&sdkappid=88888888&random=99999999&contenttype=json
   * @param adSig
   * @param identifier
   * @return {*}
   */
  imAccountStateQuery(adSig, identifier) {
    const query = param({
      usersig: adSig,
      identifier: config.IM.ADMIN_ACCOUNT,
      sdkappid: config.IM.APPID,
      random: Date.now(),
      contenttype: 'json'
    })

    return request({
      url: 'https://console.tim.qq.com/v4/openim/querystate?' + query,
      method: 'post',
      param: {
        usersig: adSig,
        identifier: config.IM.ADMIN_ACCOUNT,
        sdkappid: config.IM.APPID,
        random: Date.now(),
        contenttype: 'json'
      },
      data: {
        'To_Account': [identifier]
      }
    })
  }
}

const txim = {
  getInstance,
  stop,
  sendMessage,
  addEventListener,
  removeEventListener,
  fixUserAccount
}

// public
export default txim
