/**
 * 会话类型
 * @type {{Chat: string, Voice: string}}
 */
export const SessionType = {
  Voice: 'voice',
  Chat: 'text'
}

export const IMActionType = {
  Notification: 'BC.Notification',
  ChatMessage: 'CC.ChatMessage'
}

export const IMNotifyType = {
  Timeout: 'Timeout',
  CreateSession: 'CreateSession',
  UserCloseSession: 'UserCloseSession',
  Appraise: 'Appraise',
  CheckStatus: 'CheckStatus'
}

export const IMEventType = {
  KICKOFF: 'KICKOFF',
  CONNECTRET: 'CONNECTRET',
  RECONNECT: 'RECONNECT',
  UNKNOWN: 'UNKNOWN',
  LOGOUT: 'LOGOUT',
  LOGIN: 'LOGIN',
  USER_TRY_LOGIN: 'USER_TRY_LOGIN'
}

// IRType(电话	1 虚拟IR	10 微信	11 Video	12 AppChat	13 chat	2 E-mail	3 网上报修	4 微博	5 短信	6 RTO	7 站内排队号	8 外部客户邮件	9)
export const IRType = {
  Wechat: 11,
  Webchat: 2,
  Appchat: 13,
  Telephone: 1
}

/**
 * 用户客户端类型: wechat, webchat, appchat, telephone
 * @type {{Telephone: string, Wechat: string, Appchat: string, Webchat: string}}
 */
export const ClientType = {
  Wechat: 'wechat',
  Webchat: 'webchat',
  Appchat: 'appchat',
  Telephone: 'telephone'
}

/**
 * 右侧功能区Tab
 * @type {{Msg: string, User: string, UserQuery: string, Search: string, Record: string, Case: string}}
 */
export const FunctionTab = {
  User: 'user',
  UserQuery: 'user-query',
  UserRegister: 'user-register',
  Case: 'case',
  Search: 'search',
  Record: 'record',
  Msg: 'push'
}

/**
 * 魔方文本通路状态
 * @type {{Rest: string, Offline: string, Hangup: string, Online: string}}
 */
export const EngineerStatus = {
  Online: 'online',
  Rest: 'rest',
  Hangup: 'hangup',
  Offline: 'offline'
}

/**
 * 队列类型
 * @type {{Chat: number, Voice: number}}
 */
export const QueueType = {
  Voice: 2,
  Chat: 1
}
