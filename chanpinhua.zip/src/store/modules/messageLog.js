import { getDateFormat, uuid } from '@/utils'

const MAX_LOG_NUMBER = 200

const errorLog = {
  state: {
    logs: []
  },
  mutations: {
    ADD_MESSAGE_LOG: (state, { type, message }) => {
      if (state.logs.length > MAX_LOG_NUMBER) {
        state.logs.pop()
      }

      state.logs.unshift({
        id: uuid('log'),
        time: getDateFormat('hh:mm:ss'),
        type,
        message
      })
    }
  },
  actions: {
    addMessageLog({ commit }, { type, message }) {
      commit('ADD_MESSAGE_LOG', { type, message })
    }
  }
}

export default errorLog
