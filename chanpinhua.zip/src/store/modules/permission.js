/* eslint-disable */
import { asyncRouterMap, constantRouterMap } from '@/router'

/**
 * 通过path 判断是否与当前用户权限匹配
 * todo route 需要根据fullPath 来判定
 * todo 空白menu item
 * todo 外链部分异常处理
 * todo menu item order
 * @param permissionList 传进来的返回权限列表
 * @param route // 当前动态路由表中传入的每个子路由对象
 */
function hasPermission(permissionList, route) {
  if (permissionList.includes(route.name)) {
    if (!route.children || !route.children.length) {
      // console.log('有沒有匹配上？？？', permissionList.includes(route.name), route.name)
      return permissionList.includes(route.name)
    } else {
      return true
    }
  } else {
    return false
  }
  // if (permissionList.includes(route.name)) {
  //   if (!route.children || !route.children.length) {
  //     // console.log('有沒有匹配上？？？', permissionList.includes(route.name), route.name)
  //     return permissionList.includes(route.name)
  //   } else {
  //     // console.log(1111, route.name)
  //     return true
  //   }
  // } else {
  //   // console.log(route.name, '无权限111')
  //   return false
  // }
}

/**
 * 通过hidden 判断是否子页面
 * @param route // 当前动态路由表中传入的每个子路由对象
 */
function isHidden(route) {
  // console.log(route)
  if (!route.children || !route.children.length) {
    // console.log('是否是隐藏页面？？？', route && route.hidden !== undefined && route.hidden !== null && route.hidden === true)
    return route && route.hidden !== undefined && route.hidden !== null && route.hidden === true
  } else {
    return true
  }
}

/**
 * 递归过滤异步路由表，返回符合用户角色权限的路由表
 * @param asyncRouterMap
 * @param permissionList
 */
function filterAsyncRouter(asyncRouterMap, permissionList) {
  const res = []
  if (!permissionList.length) {
    return res
  }
  asyncRouterMap.forEach(route => {
    const tmp = { ...route }
    console.log(tmp.name, '菜单名称')
    if (hasPermission(permissionList, tmp)) { // 有权限的状态
      if (tmp.children) {
        tmp.children = filterAsyncRouter(tmp.children, permissionList)
      }
      if (!tmp.children || tmp.children.length) {
        res.push(tmp)
      }
    } else { // 无权限的状态需要检查是否是不显示在菜单栏里的子页面
      if (tmp.children) { // 没有权限先判定一次是否是菜单页面
        tmp.children = filterAsyncRouter(tmp.children, permissionList)
      } else {
        if (isHidden(tmp)) { // 如果是不显示在菜单栏里的子页面
          if (tmp.children) {
            tmp.children = filterAsyncRouter(tmp.children, permissionList)
          }
          if (!tmp.children || tmp.children.length) {
            res.push(tmp)
          }
        }
      }
    }
  })
  return res
}

const permission = {
  state: {
    routers: constantRouterMap,
    addRouters: []
  },
  mutations: {
    SET_ROUTERS: (state, routers) => {
      state.addRouters = routers
      state.routers = constantRouterMap.concat(routers)
      // console.log(state.addRouters)
    }
  },
  actions: {
    GenerateRoutes({ commit }, permissionList) {
      return new Promise(resolve => {
        commit('SET_ROUTERS', asyncRouterMap)
        if (process.env.VUE_APP_ENV_CONFIG === 'dev') {
          commit('SET_ROUTERS', asyncRouterMap)
        } else {
          console.log(asyncRouterMap, permissionList)
          const accessedRouters = filterAsyncRouter(asyncRouterMap, permissionList)
          // console.log('accessedRouters', accessedRouters)// 将接口返回权限列表与全部权限列表做对比
          console.log('accessedRouters', accessedRouters)
          commit('SET_ROUTERS', accessedRouters)
        }
        resolve()
      })
    }
  }
}

export default permission
