import vue from 'vue'

/**
 * 提供对所有api 接口是否处于loading 状态的vuex state
 * 方便使用者对局部loading UI 的处理
 *
 * 此方案针对单个api 调用产生的loading。
 * 如若是多个api 依次调用完成一个动作，亦或是通过一个包含异步的action 完成动作，仍然建议在自己的组件内部实现loading 处理。
 *
 * 此方案的比较麻烦的是，需要查阅api url、书写mapGetter loading。
 * TODO 可以考虑针对做一个vue mixin 组件，专门wrap action 并提供局部loading。
 * @example
 * js: ...mapGetters('api', ['loading'])
 * element-ui container: v-loading="loading('GetSRItemInfoByIDProdSNProblemSln')"
 * or v-loading="loading('/api/wb/notification/email')"
 * @type {{namespaced: boolean, state: {loading: {}}, mutations: {START_LOADING: api.mutations.START_LOADING, STOP_LOADING: api.mutations.STOP_LOADING}, getters: {allLoading: (function(*): *), loading: (function(*): function(*=): *)}}}
 */
const api = {
  namespaced: true,
  state: {
    loading: {}
  },
  mutations: {
    START_LOADING: (state, api) => {
      vue.set(state.loading, api, true)
    },
    STOP_LOADING: (state, api) => {
      vue.set(state.loading, api, false)
    }
  },
  getters: {
    allLoading: state => state.loading,
    // 支持精确和模糊匹配loading api
    loading: state => (api) => {
      let loading = state.loading[api]
      // 进行模糊检索
      if (!loading && state.loading !== undefined) {
        const findKey = Object.keys(state.loading).find(key => key.includes(api))
        if (findKey) {
          loading = state.loading[findKey]
        }
      }
      return loading
    }
  }
}

export default api
