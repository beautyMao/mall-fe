import Vue from 'vue'
import Vuex from 'vuex'
import app from './modules/app'
import user from './modules/user'
import tagsView from './modules/tagsView'
import errorLog from './modules/errorLog'
import messageLog from './modules/messageLog'
import permission from './modules/permission'
import getters from './getters'
import call from './modules/call-center'
import api from './modules/api'

Vue.use(Vuex)

const store = new Vuex.Store({
  modules: {
    app, // ui
    user, // 当前客服状态信息
    tagsView, // 顶部快捷导航
    errorLog, // 错误日志
    messageLog, // 记录消息日志
    permission, // 权限
    call, // 呼叫中心
    api // 全局 Loading
  },
  getters
})
export default store
