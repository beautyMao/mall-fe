<template>
  <div class="search-classify">
    <now-phone />
    <div class="classify-box">
      <!--table切换-->
      <div class="tabs">
        <ul>
          <li v-for="(item, index) in tabsnav" :key="index" :class="{'selblue': index == active}" @click="cleckShow(index)">{{ item }}<span class="line" /></li>
        </ul>
      </div>
      <!--筛选-->
      <div class="classify-filter">
        <p class="tips-title">筛选</p>
        <div>
          <span class="tips-test">请选择需要查询的组别</span>
          <el-select v-show="ifisengineer" v-model="selectlist" multiple collapse-tags :placeholder="selplaceholder" :size="'medium'" @change="currentSel">
            <el-option v-for="(item,index) in selectdata" :key="index" :label="item.name" :value="item.code" />
          </el-select>
          <el-select v-show="!ifisengineer" v-model="selectlist" multiple collapse-tags :placeholder="selplaceholder" @change="currentSel">
            <el-option v-for="(item,index) in selectdata" :key="index" :label="item.name" :value="item.name" />
          </el-select>
        </div>
      </div>
      <!--情感状况对比-->
      <div class="emotion-compare">
        <div class="top-tips">
          <p class="title">情感概况对比</p>
          <ol>
            <li><span />愤怒</li>
            <li><span />不满</li>
            <li><span />正常</li>
            <li><span />愉悦</li>
            <li><span />惊喜</li>
          </ol>
        </div>
        <!--对比详情-->
        <div class="compare-details">
          <ul>
            <li v-for="item in groupdatas.breakdown">
              <p class="area-name">{{ item.name }}</p>
              <div class="compare-result">
                <p v-show="item.survey.not_at_all != 0 && item.survey.not_at_all > 0"><span :style="'width: '+item.survey.not_at_all+'%'" /></p>
                <p v-show="item.survey.slightly != 0 && item.survey.slightly > 0"><span :style="'width: '+item.survey.slightly+'%'" /></p>
                <p v-show="item.survey.moderately != 0 && item.survey.moderately > 0"><span :style="'width: '+item.survey.moderately+'%'" /></p>
                <p v-show="item.survey.very != 0 && item.survey.very > 0"><span :style="'width: '+item.survey.very+'%'" /></p>
                <p v-show="item.survey.extremely != 0 && item.survey.extremely > 0"><span :style="'width: '+item.survey.extremely+'%'" /></p>
              </div>
            </li>
          </ul>
        </div>
        <!--情感详情-->
        <div class="selemotion-detail">
          <p class="tips-title">愤怒情感详情</p>
          <div class="detail-table">
            <el-table
              :data="tableData"
              style="width: 100%"
            >
              <el-table-column
                prop="no"
                label="序号"
                width="180"
              />
              <el-table-column
                label="会话ID"
                width="180"
              >
                <template slot-scope="scope">
                  <span class="clickSessonid" style="color:#4A90E2;" @click="goSessionDetail(scope.row.id)">{{ scope.row.id }}</span>
                </template>
              </el-table-column>
              <el-table-column
                prop="status"
                label="状态"
              />
              <el-table-column
                prop="duration"
                label="持续时间"
              />
              <el-table-column
                prop="engineer_name"
                label="工程师"
              />
              <el-table-column
                prop="group"
                label="组别"
              />
              <el-table-column
                prop="sat_score"
                label="用户情感"
              />
            </el-table>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import NowPhone from '@/components/nowproductlines/index'
  import servers from '@/api/ccp/useremotion-management/emotion-management'
  export default {
    name: 'searchclassify',
    components: {
      NowPhone
    },
    data() {
      return {
        tabsnav: ['通路', '队列', '地域', '组别', '个人'],
        active: null,
        selectlist: [], // select的model
        selectdata: '', // 初始化下拉框
        tableData: [], // 愤怒详情list
        classtype: '', // 来源类型
        source: '', // 点击select需要调用下面数据需要传来源
        groupdatas: '', // 初始化情感分布
        ifisengineer: false,
        selplaceholder: '请选择工程师',
        businessID: this.$route.query.businessID,
        accessID: this.$route.query.accessID,
        seldate: this.$route.query.seldate
      }
    },
    mounted() {
      if (this.$route.params.from === 'engineer') { // 点击某个工程师
        this.cleckShow(4, 'initpage') // 获取select框的值
      } else if (this.$route.params.from === 'group') {
        this.cleckShow(3, 'initpage') // 获取select框的值
      } else if (this.$route.params.from === 'indexpage') {
        this.cleckShow(0) // 获取select框的值
      }
    },
    methods: {
      // 点击导航
      cleckShow(index, type) {
        this.active = index
        if (index === 0 || index === 3) {
          this.ifisengineer = false
        } else {
          this.ifisengineer = true
        }
        if (index === 0) {
          if (localStorage.getItem('channelselist') !== '' && localStorage.getItem('channelselist')) {
            this.selectlist = this.resolveSeldata(localStorage.getItem('channelselist').split(','))
          } else {
            this.selectlist = []
          }
          this.classtype = 'channel'
          this.source = 'channels'
          this.selplaceholder = '请选择通路'
        } else if (index === 1) {
          this.selectlist = []
          if (localStorage.getItem('queueselist') !== '' && localStorage.getItem('queueselist')) {
            this.selectlist = this.resolveSeldata(localStorage.getItem('queueselist').split(','))
          } else {
            this.selectlist = []
          }
          this.classtype = 'queue'
          this.source = 'queues'
          this.selplaceholder = '请选择队列'
        } else if (index === 2) {
          if (localStorage.getItem('regionselist') !== '' && localStorage.getItem('regionselist')) {
            this.selectlist = this.resolveSeldata(localStorage.getItem('regionselist').split(','))
          } else {
            this.selectlist = []
          }
          this.classtype = 'region'
          this.source = 'regions'
          this.selplaceholder = '请选择地域'
        } else if (index === 3) {
          if (localStorage.getItem('groupselist') !== '' && localStorage.getItem('groupselist')) {
            this.selectlist = this.resolveSeldata(localStorage.getItem('groupselist').split(','))
          } else {
            this.selectlist = []
          }
          this.classtype = 'group'
          this.source = 'groups'
          this.selplaceholder = '请选择组别'
        } else if (index === 4) {
          if (localStorage.getItem('engineerselist') !== '' && localStorage.getItem('engineerselist')) {
            this.selectlist = this.resolveSeldata(localStorage.getItem('engineerselist').split(','))
          } else {
            this.selectlist = []
          }
          this.classtype = 'engineer'
          this.source = 'engineers'
          this.selplaceholder = '请选择工程师'
        }
        // 从详情页面选择组别或者工程师跳转过来的，要选择到指定的情感、显示指定愤怒详情、选择框要写上值.
        if (type === 'initpage') {
          this.getSelectData(this.classtype, index) // 获取下拉框数据
          this.getGroupList(this.$route.params.cate)// 获取分组的情感分布
          this.getnotatallList(this.source, this.$route.params.cate)// 获取愤怒list
          // 从组别跳转过来，需要默认选择这个组别
          if (index === 3) {
            this.selectlist = [`${this.$route.params.cate}`]
          }
        } else {
          this.getSelectData(this.classtype) // 获取下拉框数据
          this.getGroupList(this.selectlist.join(';'))// 获取分组的情感分布
          this.getnotatallList(this.source, this.selectlist.join(';'))// 获取愤怒list
        }
      },
      // 获取各个来源的select值
      getSelectData(type, ifneedinit) {
        servers.getEmotionClassify(this.businessID, this.accessID, type).then((res) => {
          this.selectdata = res.data
          // 从工程师跳转过来,默认选择这个工程师
          if (ifneedinit === 4 && this.classtype === 'engineer') {
            for (let i = 0; i < res.data.length; i++) {
              if (this.$route.params.cate === res.data[i].code) {
                this.selectlist = [`${res.data[i].name}`]
              }
            }
          }
        })
      },
      // 点击select框
      currentSel(selval) {
        if (this.classtype === 'engineer') {
          for (let i = 0; i < this.selectdata.length; i++) {
            if (selval[0] === this.selectdata[i].name) {
              selval[0] = this.selectdata[i].code
            }
          }
        }
        const newdata = []
        for (let i = 0; i < selval.length; i++) {
          newdata.push(encodeURIComponent(selval[i]))
        }
        this.getGroupList(newdata.join(';'))
        // 获取愤怒list
        this.getnotatallList(this.source, newdata.join(';'))
        if (this.classtype === 'channel') {
          localStorage.setItem('channelselist', newdata)
        } else if (this.classtype === 'queue') {
          localStorage.setItem('queueselist', newdata)
        } else if (this.classtype === 'region') {
          localStorage.setItem('regionselist', newdata)
        } else if (this.classtype === 'group') {
          localStorage.setItem('groupselist', newdata)
        } else if (this.classtype === 'engineer') {
          localStorage.setItem('engineerselist', newdata)
        }
      },
      // 获取愤怒list
      getnotatallList(source, val) {
        const loading = this.$loading({
          text: ''
        })
        servers.getEmotionnotatallList(this.businessID, this.accessID, this.classtype, source, val, this.seldate).then((res) => {
          this.tableData = res.data
          loading.close()
        }).catch(() => {
          loading.close()
          this.tableData = []
        })
      },
      // 获取分组情感
      getGroupList(data) {
        servers.getEmotionDetail(this.businessID, this.accessID, this.classtype, this.source, data, this.seldate).then((res) => {
          this.groupdatas = res.data
        }).catch(() => {
          this.groupdatas = ''
        })
      },
      // 看会话详情
      goSessionDetail(ID) {
        this.$router.push({
          path: `/call-center/history?id=${ID}`
        })
      },
      // 去看分类
      goClassify(group, type) {
        this.$router.push({
          path: `/devccp-management/searchclassify/${group}/${type}/${this.$route.query.businessID}${this.$route.query.accessID}`,
          query: {
            businessID: this.$route.query.businessID,
            business: this.$route.query.business,
            accessID: this.$route.query.accessID,
            access: this.$route.query.access
          }
        })
      },
      // 处理文案decodeURIComponent
      resolveSeldata(data) {
        const newarr = []
        data.map((value) => {
          newarr.push(decodeURIComponent(value))
        })
        return newarr
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss">
  @import '../../../../styles/index.scss';
  .search-classify{
    padding: 0 14px;
    // tabs
    .tabs{
      ul li{
        float:left;
        width:20%;
        height:60px;
        text-align: center;
        color:#303133;
        font-size: 20px;
        line-height: 60px;
        border-bottom:1px solid #909399;
        cursor: pointer;
        .line{
          display: inline-block;
          height:40px;
          width:1px;
          background:#909399;
          float: right;
          margin-top:10px;
        }
      }
      ul li:last-child{
        .line{
          width:0;
        }
      }
      .selblue{
        color:#4A90E2;
        font-weight: bold;
        border-bottom: 2px solid #4A90E2;
      }
    }
    .classify-box{
      border:1px solid  $color7ed;
      padding:0 14px 20px;
      overflow: hidden;
      background: #fff;
      // 筛选
      .classify-filter{
        padding:5px 0 30px;
        border-bottom: 1px solid $color7ed;
        margin-top:30px;
        clear: both;
        .tips-title{
          font-size: 20px;
          color:$color133;
        }
        .tips-test{
          color:$color266;
          font-size: 14px;
          margin-right:16px;
        }
        .el-select{
          width:260px;
        }
        .el-form-item--mini .el-form-item__content, .el-form-item--mini .el-form-item__label{
          line-height: 40px;
        }
        .el-input--mini .el-input__inner{
          height:40px;
          line-height: 40px;
          color:$color266;
          font-size: 14px;
        }
      }
      //情感对比
      .emotion-compare{
        margin-top:6px;
        .top-tips{
          margin-bottom:12px;
          height:60px;
          .title{
            float:left;
            font-size: 20px;
            color:$color133;
            width:150px;
          }
          ol{
            float:right;
            margin-top:20px;
            li{
              float: left;
              font-size: 20px;
              margin-right:20px;
              color:#FF8060;
              span{
                width:10px;
                height:10px;
                border-radius: 100%;
                background: #FF8060;
                display:inline-block;
                margin-right:8px;
              }
            }
            li:nth-child(2){
              color:#F5A623;
              span{
                background: #F5A623;
              }
            }
            li:nth-child(3){
              color:#00D6D5;
              span{
                background: #00D6D5;
              }
            }
            li:nth-child(4){
              color:#00A1FF;
              span{
                background: #00A1FF;
              }
            }
            li:nth-child(5){
              color:#D18AE2;
              span{
                background: #D18AE2;
              }
            }
          }
        }
      }
      // 对比详情
      .compare-details{
        ul li{
          padding:10px;
          border-top:1px solid $color7ed;
          clear: both;
          overflow: hidden;
          .area-name{
            float: left;
            font-size: 14px;
            color:$color266;
            width:150px;
          }
          .compare-result{
            float: left;
            margin-left:20px;
            p{
              width: 500px;
              height:7px;
              border-radius: 250px;
              span{
                width:300px;
                height:7px;
                background: #FF8060;
                display: inline-block;
                border-radius: 150px;
              }
            }
            p:nth-child(2){
              span{
                background: #FFD200;
              }
            }
            p:nth-child(3){
              span{
                background: #00D6D5;
              }
            }
            p:nth-child(4){
              span{
                background: #00A1FF;
              }
            }
            p:nth-child(5){
              span{
                background: #D18AE2;
              }
            }
          }
        }
      }
      //情感详情
      .selemotion-detail {
        border-top: 1px solid $color7ed;
        clear: both;
        .tips-title {
          font-size: 20px;
          color: $color133;
          marign: 26px 0;
        }
        .detail-table {
          border: 1px solid #ccc;
          border-radius: 4px;
          padding-bottom: 50px;
          background: #fff;
          .el-table th > .cell {
            background: #F0F4FB;
            height: 36px;
            line-height: 36px;
            text-align: center;
            font-size: 14px;
            color:#303133;
          }
          .el-table--mini td, .el-table--mini th {
            padding: 0;
            height: 36px;
          }
          .el-table__empty-text{
            color:#606266;
          }
          .el-table__empty-block{
            min-height: 36px;
          }
          .el-table .cell{
            text-align: center;
            font-size: 14px;
            color:#606266;
          }
          .clickSessonid{
            cursor: pointer;
          }
        }
      }
    }
  }

</style>

