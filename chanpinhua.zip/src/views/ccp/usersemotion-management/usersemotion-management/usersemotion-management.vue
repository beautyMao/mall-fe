<template>
  <div class="emotions-home">
    <now-phone />
    <div class="seldate">
      <el-date-picker
        v-model="seldate"
        type="date"
        :picker-options="pickerOptions"
        value-format="yyyy-MM-dd"
        placeholder="选择日期"
        @change="userseldate"
      />
    </div>
    <!--内容区-->
    <div class="con-box">

      <div class="top-tips">
        <ol>
          <li>情感分类</li>
          <li>数量（个）</li>
        </ol>
      </div>
      <div v-loading="cardLoading" class="emotions-classify">
        <ul>
          <li @click="goDetail('not_at_all')">
            <span>愤怒</span>
            <span>{{ emotionnums.not_at_all ? emotionnums.not_at_all : 0 }}</span>
          </li>
          <li @click="goDetail('slightly')">
            <span>不满</span>
            <span>{{ emotionnums.slightly ? emotionnums.slightly : 0 }}</span>
          </li>
          <li @click="goDetail('moderately')">
            <span>正常</span>
            <span>{{ emotionnums.moderately ? emotionnums.moderately : 0 }}</span>
          </li>
          <li @click="goDetail('very')">
            <span>愉悦</span>
            <span>{{ emotionnums.very ? emotionnums.very : 0 }}</span>
          </li>
          <li @click="goDetail('extremely')">
            <span>惊喜</span>
            <span>{{ emotionnums.extremely ? emotionnums.extremely : 0 }}</span>
          </li>
        </ul>
      </div>
    </div>
    <!--分类查询按钮-->
    <!-- <el-button type="primary" class="search-btn" @click="searchBtn">分类查询</el-button> -->
  </div>
</template>

<script>
  import NowPhone from '@/components/nowproductlines/index'
  import servers from '@/api/ccp/useremotion-management/emotion-management'
  export default {
    name: 'mainhome',
    components: {
      NowPhone
    },
    data() {
      return {
        seldate: '',
        emotionnums: '',
        cardLoading: true,
        timer: null,
        businessID: this.$route.query.businessID,
        accessID: this.$route.query.accessID,
        pickerOptions: ''
      }
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    mounted() {
      const initdate = new Date()
      const curentday = initdate.getDate() < 10 ? '0' + initdate.getDate() : initdate.getDate()
      const curentmonth = initdate.getMonth() + 1 < 10 ? '0' + `${initdate.getMonth() + 1}` : `${initdate.getMonth() + 1}`
      this.seldate = `${initdate.getFullYear()}-${curentmonth}-${curentday}`
      this.pickerOptions = {
        disabledDate(time) {
          return time.getTime() > Date.now()
        }
      }
      clearInterval(this.timer)
      this.timer = setInterval(() => {
        this.getEmotions()
      }, 15000)
      this.getEmotions()
      localStorage.removeItem('channelselist')
      localStorage.removeItem('queueselist')
      localStorage.removeItem('regionselist')
      localStorage.removeItem('groupselist')
      localStorage.removeItem('engineerselist')
    },
    methods: {
      getEmotions() {
        if (!this.seldate) return
        servers.getEmotionnums(this.businessID, this.accessID, this.seldate).then((res) => {
          this.cardLoading = false
          if (res.message.info === 'Success') {
            this.emotionnums = res.data
          }
        })
      },
      goDetail(id) {
        this.$router.push({
          // /emotionsdetails/:emotiontype/:busnessaccessid
          path: `/devccp-management/emotionsdetails/${id}/${this.$route.query.businessID}${this.$route.query.accessID}`,
          query: {
            businessID: this.$route.query.businessID,
            business: this.$route.query.business,
            accessID: this.$route.query.accessID,
            access: this.$route.query.access,
            seldate: this.seldate
          }
        })
      },
      searchBtn() {
        this.$router.push({
          path: `/devccp-management/searchclassify/indexpage/indexpage/${this.$route.query.businessID}${this.$route.query.accessID}`,
          query: {
            businessID: this.$route.query.businessID,
            business: this.$route.query.business,
            accessID: this.$route.query.accessID,
            access: this.$route.query.access,
            seldate: this.seldate
          }
        })
      },
      userseldate(res) {
        this.getEmotions()
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  @import '../../../../styles/index.scss';
  .seldate{
    float: right;
    margin: 0 0 20px;
  }
  .emotions-home{
    padding: 0 14px;
    .now-phone{
      color:$color133;
      font-size: 24px;
      font-weight: bold;
    }
   // 内容区
    .con-box{
      clear: both;
      border:1px solid $colorccc;
      border-radius: 4px;
      padding-bottom:20px;
      //头部
      .top-tips{
        height:60px;
        background: $colorback;
        ol li{
          line-height:60px;
          width:49%;
          float:left;
          text-align:center;
          font-size: 14px;
          color:$color133;
        }
        li:nth-child(2){
          float:right;
        }
      }
      // 中间内容区域
      .emotions-classify{
        clear: both;
        ul li {
          height:60px;
          margin-bottom:12px;
          span{
            width:49%;
            line-height: 60px;
            display:inline-block;
            float:left;
            text-align: center;
            border:1px solid #FF8060;
            background:rgba(255,140,111,0.2);
            color:#FF8C6F;
            font-size: 20px;
            cursor: pointer;
          }
          span:nth-child(2){
            float:right;
          }
        }
        ul li:nth-child(2){
          span{
            border:1px solid #ffd200;
            background:rgba(255,210,0,0.2);
            color:#ffd200;
          }
        }
        ul li:nth-child(3){
          span{
            border:1px solid #1dd781;
            background:rgba(29,215,129,0.2);
            color:#1dd781;
          }
        }
        ul li:nth-child(4){
          span{
            border:1px solid #00a1ff;
            background:rgba(0,161,255,0.2);
            color:#00a1ff;
          }
        }
        ul li:nth-child(5){
          span{
            border:1px solid #d18ae2;
            background:rgba(209,138,226,0.2);
            color:#d18ae2;
          }
        }
      }
    }
    // 分类按钮
    .search-btn{
      float: right;
      width:150px;
      height:40px;
      margin-top:14px;
      font-size: 14px;
    }
  }

</style>

