<template>
  <div class="app-container">
    <now-phone />
    <el-card v-loading="tableLoading">
      <el-table :data="tableData">
        <el-table-column
          prop="no"
          label="序号"
          align="center"
          width="80"
        />
        <el-table-column
          label="会话ID"
          width="180"
        >
          <template slot-scope="scope">
            <el-button type="text" @click="goSessionDetail(scope.row.id)"> {{ scope.row.id }} </el-button>
          </template>
        </el-table-column>
        <el-table-column
          prop="status"
          label="状态"
        />
        <el-table-column
          prop="duration"
          label="持续时间"
        />
        <el-table-column
          label="工程师"
        >
          <template slot-scope="scope">
            <span @click="goClassify(scope.row.engineer_code, 'engineer')">{{ scope.row.engineer_name }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="技能组"
        >
          <template slot-scope="scope">
            <span @click="goClassify(scope.row.group, 'group')">{{ scope.row.group }}</span>
          </template>
        </el-table-column>
        <el-table-column
          prop="sat_score"
          label="用户情感"
        />
      </el-table>
    </el-card>
  </div>
</template>

<script>
  import NowPhone from '@/components/nowproductlines/index'
  import servers from '@/api/ccp/useremotion-management/emotion-management'

  export default {
    name: 'details',
    components: {
      NowPhone
    },
    data() {
      return {
        tableData: [],
        tableLoading: true,
        businessID: this.$route.query.businessID,
        accessID: this.$route.query.accessID
      }
    },
    mounted() {
      servers.getEmotionList(this.businessID, this.accessID, this.$route.params.emotiontype, this.$route.query.seldate).then((res) => {
        if (res.message.info === 'Success') {
          this.tableData = res.data
        }
        this.tableLoading = false
      })
        .catch(() => {
          this.tableLoading = false
        })
    },
    methods: {
      goSessionDetail(ID) {
        this.$router.push({
          path: `/call-center/history?id=${ID}`
        })
      },
      // goSessionDetail(ID) {
      //   this.$router.push({
      //     path: `/devccp-management/sessiondetails/${ID}/${this.$route.query.businessID}${this.$route.query.accessID}`,
      //     query: {
      //       businessID: this.$route.query.businessID,
      //       business: this.$route.query.business,
      //       accessID: this.$route.query.accessID,
      //       access: this.$route.query.access
      //     }
      //   })
      // },
      goClassify(group, type) {
        // this.$router.push({
        //   path: `/devccp-management/searchclassify/${group}/${type}/${this.$route.query.businessID}${this.$route.query.accessID}`,
        //   query: {
        //     businessID: this.$route.query.businessID,
        //     business: this.$route.query.business,
        //     accessID: this.$route.query.accessID,
        //     access: this.$route.query.access,
        //     seldate: this.$route.query.seldate
        //   }
        // })
      }
    }
  }
</script>

