<template>
  <div class="emotions-details">
    <now-phone />
    <!--详情列表-->
    <div v-loading="tableLoading" class="detail-table">
      <el-table
        :data="tableData"
        style="width: 100%"
      >
        <el-table-column
          prop="no"
          label="序号"
        />
        <el-table-column
          prop="name"
          label="姓名"
          width="180"
        />
        <el-table-column
          prop="code"
          label="工号"
        />
        <el-table-column
          prop="group"
          label="组别"
        />
        <!--<el-table-column-->
        <!--prop="shao"-->
        <!--label="缺勤类型">-->
        <!--</el-table-column>-->
        <el-table-column
          prop="duration"
          label="缺勤小时数"
        />
        <el-table-column
          prop="region"
          label="地域"
        />
      </el-table>
      <div class="pagination-con">
        <el-pagination
          background
          :current-page="currentPage"
          :page-sizes="[10, 20, 30]"
          :page-size="10"
          layout="sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
    </div>

  </div>
</template>

<script>
  import NowPhone from '@/components/nowproductlines/index'
  import servers from '@/api/devccp/engineer-management/engineer-management'
  export default {
    components: {
      NowPhone
    },
    data() {
      return {
        tableData: [],
        tableLoading: false,
        currentPage: 1,
        pagenum: 1,
        businessID: this.$route.query.businessID,
        accessID: this.$route.query.accessID,
        total: null
      }
    },
    mounted() {
      this.getAbsenceList(this.pagenum)
    },
    methods: {
      handleSizeChange(val) {
        console.log(`每页 ${val} 条`)
        this.getAbsenceList(val)
      },
      handleCurrentChange(val) {
        console.log(`当前页: ${val}`)
        this.getAbsenceList(val)
      },
      getAbsenceList(page) {
        servers.getAbsenceList(this.businessID, this.accessID, page, 'all')
          .then((res) => {
            this.tableData = res.data.items
            this.total = res.data.pagination.total
          })
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss">
  .emotions-details{
    padding: 0 14px;
    .detail-table{
      border:1px solid #ccc;
      border-radius:4px;
      padding-bottom:20px;
      background: #fff;
      overflow: hidden;
      .el-table th>.cell{
        background: #F0F4FB;
        height:36px;
        line-height: 36px;
        color:#303133;
        text-align: center;
      }
      .el-table--mini td, .el-table--mini th{
        padding:0;
        height:36px;
      }
      .el-table .cell{
        text-align: center;
        color:#606266;
      }
      .el-table__empty-block{
        min-height: 36px;
      }
      .el-table__empty-text{
        color:#606266;
      }
      .clickSessonid{
        cursor: pointer;
      }
      .pagination-con{
        margin-top:120px;
        float: right;
      }
    }
  }
</style>

