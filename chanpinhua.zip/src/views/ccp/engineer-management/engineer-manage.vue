<template>
  <div class="engineer-manage">
    <!--职位选择-->
    <!--<div class="sel-jobs">-->
    <!--<el-select v-model="seljobvalue" placeholder="请选择职位" @change="userseljob">-->
    <!--<el-option-->
    <!--v-for="item in jobs"-->
    <!--:key="item.label"-->
    <!--:value="item.label"-->
    <!--:label="item.value"-->
    <!--/>-->
    <!--</el-select>-->
    <!--</div>-->
    <!--&lt;!&ndash;顶部图表&ndash;&gt;-->
    <!--<div class="top-content">-->
    <!--&lt;!&ndash;图表&ndash;&gt;-->
    <!--<div class="pie-one">-->
    <!--<pie-show :width="'200px'" :piedata="pieonedata" @clickpie="pieonclick" />-->
    <!--<div class="onepie">-->
    <!--<p v-for="(item,index) in onepiedata" :key="index" :style="{color: needshowcolor[index]}">{{ item.name }}</p>-->
    <!--</div>-->
    <!--</div>-->
    <!--<div class="pie-two">-->
    <!--<pie-show v-show="ifshowtwopie" :width="'200px'" :piedata="pietwodata" @clickpie="pietwoclick" />-->
    <!--<div class="onepie">-->
    <!--<p v-for="(item,index) in twopiedata" :key="index" :style="{color: needshowcolor[index]}">{{ item.name }}</p>-->
    <!--</div>-->
    <!--</div>-->
    <!--<div class="pie-three">-->
    <!--<pie-show v-show="ifshowthreepie" :width="'200px'" :piedata="piethreedata" @clickpie="piethreeclick" />-->
    <!--<div class="onepie">-->
    <!--<p v-for="(item,index) in threepiedata" :key="index" :style="{color: needshowcolor[index]}">{{ item.name }}</p>-->
    <!--</div>-->
    <!--</div>-->
    <!--&lt;!&ndash;点击图表，右侧显示数据&ndash;&gt;-->
    <!--<div class="employee-work">-->
    <!--&lt;!&ndash;产线对应出勤的总数列表&ndash;&gt;-->
    <!--<div class="work-allcount">-->
    <!--<p class="title-tips">{{ selbussinessname }} {{ selchannelname }} {{ regionname }}</p>-->
    <!--<ul>-->
    <!--<li>-->
    <!--<p>应当出勤</p>-->
    <!--<p>{{ engineerwork.planned }}<span>人</span></p>-->
    <!--</li>-->
    <!--<li>-->
    <!--<p>实际出勤</p>-->
    <!--<p>{{ engineerwork.present }}<span>人</span></p>-->
    <!--</li>-->
    <!--<li>-->
    <!--<p>缺勤</p>-->
    <!--<p>{{ engineerwork.absent }}<span>人</span></p>-->
    <!--</li>-->
    <!--</ul>-->
    <!--</div>-->
    <!--&lt;!&ndash;缺勤原因&ndash;&gt;-->
    <!--&lt;!&ndash; <div class="absence-reasons">-->
    <!--<p v-show="ifshownoabsence" class="noabsence">没有缺勤数据</p>-->
    <!--<div v-show="!ifshownoabsence">-->
    <!--<div class="left-arrow" @click="prevpage"><span /></div>-->
    <!--<div class="center-box">-->
    <!--<p v-for="(item,index) in absentlist.items" :key="index"><span>{{ item.name }}</span><span>{{ item.leave }}</span><span>{{ item.duration }}小时</span></p>-->
    <!--</div>-->
    <!--<div class="right-arrow" @click="nextpage"><span>></span></div>-->
    <!--</div>-->

    <!--</div> &ndash;&gt;-->
    <!--</div>-->
    <!--</div>-->
    <!--工程师分组员工-->
    <div class="groups-emploies">
      <!--选择的业务信息-->
      <div class="business-infos">
        <ul>
          <li>业务：{{ selbussinessname }}</li>
          <li>通路：{{ selchannelname }}</li>
          <li>{{ regionname }}</li>
        </ul>
      </div>
      <!--员工头像表示当前的状态-->
      <div class="emploies-status">
        <!--状态说明-->
        <div class="status-decrite" :class="{hasgroupstatus: hasgroupstatus}">
          <ul>
            <li v-for="(groupitem, index) in groupstatus" :key="index">
              <div v-if="groupitem.status == 'online'">
                <svg-icon icon-class="user" class="iconuser online" style="color: #4a90e2;" />
                <span>就绪：{{ groupitem.count }}人</span>
              </div>

              <div v-else-if="groupitem.status == 'rest'">
                <svg-icon icon-class="user" class="iconuser rest" style="color: #D18AE2;" />
                <span>小休：{{ groupitem.count }}人</span>
              </div>

              <div v-else-if="groupitem.status == 'acw'">
                <svg-icon icon-class="user" class="iconuser acw" style="color: #50C1B9;" />
                <span>案面：{{ groupitem.count }}人</span>
              </div>

              <div v-else-if="groupitem.status == 'hangup'">
                <svg-icon icon-class="user" class="iconuser hangup" style="color: #FFCC01;" />
                <span>挂起：{{ groupitem.count }}人</span>
              </div>

              <div v-else-if="groupitem.status == 'callin'">
                <svg-icon icon-class="user" class="iconuser callin" style="color: #F5A623;" />
                <span>呼入：{{ groupitem.count }}人</span>
              </div>

              <div v-else-if="groupitem.status == 'callout'">
                <svg-icon icon-class="user" class="iconuser callout" style="color: #FF8060;" />
                <span>呼出：{{ groupitem.count }}人</span>
              </div>

              <div v-else-if="groupitem.status == 'hold'">
                <svg-icon icon-class="user" class="iconuser hold" style="color: #909399;" />
                <span>保持：{{ groupitem.count }}人</span>
              </div>

              <div v-else-if="groupitem.status == 'offline'">
                <svg-icon icon-class="mine" class="iconuser offline employbac" style="color: #979797;" />
                <span>离线：{{ groupitem.count }}人</span>
              </div>

              <div v-else-if="groupitem.status == 'absence'">
                <svg-icon icon-class="user" class="iconuser absence" style="color: #000;" />
                <span>缺勤：{{ groupitem.count }}人</span>
              </div>

              <!--<div v-else>-->
              <!--<svg-icon   icon-class="mine"  class="iconuser offline employbac" style="color: #979797;"/>-->
              <!--<span>其他：{{groupitem.count}}人</span>-->
              <!--</div>-->
            </li>
          </ul>
        </div>
      </div>
      <!--每个组的说明-->
      <div class="group">
        <ul>
          <li v-for="(item,index) in enginnerstatus" :key="index" class="out-li">
            <el-popover
              placement="bottom"
              title=""
              width="200"
              trigger="click"
            >
              <div class="status-decrite">
                <ul>
                  <li v-for="(groupitem,groupindex) in groupstatusdata" :key="groupindex">
                    <div v-if="groupitem.status == 'online'">
                      <svg-icon icon-class="user" class="iconuser online" style="color: #4a90e2;" />
                      <span>就绪：{{ groupitem.count }}人</span>
                    </div>

                    <div v-else-if="groupitem.status == 'rest'">
                      <svg-icon icon-class="user" class="iconuser rest" style="color: #D18AE2;" />
                      <span>小休：{{ groupitem.count }}人</span>
                    </div>

                    <div v-else-if="groupitem.status == 'acw'">
                      <svg-icon icon-class="user" class="iconuser acw" style="color: #50C1B9;" />
                      <span>案面：{{ groupitem.count }}人</span>
                    </div>

                    <div v-else-if="groupitem.status == 'hangup'">
                      <svg-icon icon-class="user" class="iconuser hangup" style="color: #FFCC01;" />
                      <span>挂起：{{ groupitem.count }}人</span>
                    </div>

                    <div v-else-if="groupitem.status == 'callin'">
                      <svg-icon icon-class="user" class="iconuser callin" style="color: #F5A623;" />
                      <span>呼入：{{ groupitem.count }}人</span>
                    </div>

                    <div v-else-if="groupitem.status == 'callout'">
                      <svg-icon icon-class="user" class="iconuser callout" style="color: #FF8060;" />
                      <span>呼出：{{ groupitem.count }}人</span>
                    </div>

                    <div v-else-if="groupitem.status == 'hold'">
                      <svg-icon icon-class="user" class="iconuser hold" style="color: #909399;" />
                      <span>保持：{{ groupitem.count }}人</span>
                    </div>

                    <div v-else-if="groupitem.status == 'offline'">
                      <svg-icon icon-class="mine" class="iconuser offline employbac" style="color: #979797;" />
                      <span>离线：{{ groupitem.count }}人</span>
                    </div>

                    <div v-else-if="groupitem.status == 'absence'">
                      <svg-icon icon-class="user" class="iconuser absence" style="color: #000;" />
                      <span>缺勤：{{ groupitem.count }}人</span>
                    </div>

                    <!--<div v-else>-->
                    <!--<svg-icon   icon-class="mine"  class="iconuser offline employbac" style="color: #979797;"/>-->
                    <!--<span>其他：{{groupitem.count}}人</span>-->
                    <!--</div>-->
                  </li>
                </ul>
              </div>
              <p slot="reference" class="group-name" @click="getGroupstatus(item.code, 'clickgroup')">{{ item.name }}</p>
            </el-popover>
            <!--<p class="group-name" >{{item.name}}</p>-->

            <ol>
              <li v-for="(datastatus,ind) in item.items" :key="ind" style="min-height: 95px">
                <el-popover
                  placement="bottom"
                  width="260"
                  trigger="hover"
                >
                  <div class="window-content">
                    <div class="top-con">
                      <p>工号：{{ datastatus.code }}</p>
                      <p>姓名：{{ datastatus.name }}</p>
                      <p v-if="datastatus.status == 'online'">坐席状态：就绪</p>
                      <p v-if="datastatus.status == 'rest'">坐席状态：小休</p>
                      <p v-if="datastatus.status == 'acw'">坐席状态：案面</p>
                      <p v-if="datastatus.status == 'hangup'">坐席状态：挂起</p>
                      <p v-if="datastatus.status == 'callin'">坐席状态：呼入</p>
                      <p v-if="datastatus.status == 'callout'">坐席状态：呼出</p>
                      <p v-if="datastatus.status == 'hold'">坐席状态：保持</p>
                      <p v-if="datastatus.status == 'offline'">坐席状态：离线</p>
                      <p v-if="datastatus.status == 'absence'">坐席状态：缺勤</p>
                      <!--<p v-else>坐席状态：其他</p>-->
                      <!--<p>点评等级：{{ datastatus.comment_level }}</p>-->
                      <!--<p>入职时间：{{ datastatus.onboard }}</p>-->
                      <!--<p>岗位：{{ datastatus.position }}</p>-->
                    </div>
                  </div>

                  <div v-if="datastatus.status == 'online'" slot="reference">
                    <svg-icon icon-class="user" class="iconuser online" />
                    <p class="online">{{ datastatus.name }}</p>
                  </div>

                  <div v-if="datastatus.status == 'rest'" slot="reference">
                    <svg-icon icon-class="user" class="iconuser rest" />
                    <p class="rest">{{ datastatus.name }}</p>
                  </div>

                  <div v-if="datastatus.status == 'acw'" slot="reference">
                    <svg-icon icon-class="user" class="iconuser acw" />
                    <p class="acw">{{ datastatus.name }}</p>
                  </div>

                  <div v-if="datastatus.status == 'hangup'" slot="reference">
                    <svg-icon icon-class="user" class="iconuser hangup" />
                    <p class="hangup">{{ datastatus.name }}</p>
                  </div>

                  <div v-if="datastatus.status == 'callin'" slot="reference">
                    <svg-icon icon-class="user" class="iconuser callin" />
                    <p class="callin">{{ datastatus.name }}</p>
                  </div>

                  <div v-if="datastatus.status == 'callout'" slot="reference">
                    <svg-icon icon-class="user" class="iconuser callout" />
                    <p class="callout">{{ datastatus.name }}</p>
                  </div>

                  <div v-if="datastatus.status == 'hold'" slot="reference">
                    <svg-icon icon-class="user" class="iconuser hold" />
                    <p class="hold">{{ datastatus.name }}</p>
                  </div>

                  <div v-if="datastatus.status == 'offline'" slot="reference">
                    <svg-icon icon-class="mine" class="iconuser offline employbac" />
                    <p class="offline">{{ datastatus.name }}</p>
                  </div>

                  <div v-if="datastatus.status == 'absence'" slot="reference">
                    <svg-icon icon-class="user" class="iconuser absence" />
                    <p class="absence">{{ datastatus.name }}</p>
                  </div>

                  <!--<div v-else slot="reference">-->
                  <!--<svg-icon   icon-class="mine"  class="iconuser offline employbac" />-->
                  <!--<p class="offline">{{datastatus.name}}</p>-->
                  <!--</div>-->
                </el-popover>
              </li>
            </ol>
          </li>
        </ul>
      </div>
    </div>
    <!--鼠标移动上显示的框-->

  </div>
</template>

<script>
  import { Loading } from 'element-ui'
  import PieShow from './pie'
  import servers from '@/api/engineer-management/engineer-management'
  export default {
    name: 'engineer-manage',
    components: {
      PieShow,
      Loading
    },
    data() {
      return {
        pieonedata: null, // 第一个图表
        pietwodata: null, // 第二个图表
        piethreedata: null, // 第三个图表
        engineerwork: '', // 出勤状态数据
        absentlist: '', // 缺勤人数
        selbussinesscode: this.$route.query.businessID, // 业务code
        selbussinessname: this.$route.query.business, // 业务名字
        selchannelcode: this.$route.query.accessID, // 通路code
        selchannelname: this.$route.query.access, // 通路名字
        regionname: '', // 地域名字
        regioncode: '', // 地域code
        pagenum: 1,
        savestatus: 'channel', // 存储点击了哪个图表，点击分页的时候用
        enginnerstatus: '',
        groupstatus: [],
        groupstatusdata: '',
        hasgroupstatus: false,
        ifshownoabsence: false, // 是否显示没有缺勤信息
        ifshowthreepie: false,
        ifshowtwopie: true,
        businessID: this.$route.query.businessID,
        accessID: this.$route.query.accessID,
        onepiedata: [], // 图表下方的模块描述
        twopiedata: [],
        threepiedata: [],
        jobs: [
          {
            value: 'CSR',
            label: 'csr'
          },
          {
            value: 'Team Leader',
            label: 'team'
          },
          {
            value: 'Tec Leader',
            label: 'tech'
          }
        ], // 职位选择
        seljobvalue: 'csr', // 默认职位
        needshowcolor: ['#FF8060', '#FDC94D', '#4ECC74', '#d48265', '#91c7ae', '#749f83', '#ca8622', '#bda29a', '#6e7074', '#546570', '#c4ccd3']
      }
    },
    watch: {
    },
    mounted() {
      this.getpiedata() // 默认加载第一个图标
      this.gettwopiedata(this.selbussinesscode) // 默认加载第二个图标
      this.getEngineerWorkStatus('channel', this.selbussinesscode, this.selchannelcode, '', 'one') // 右侧工程师的出勤状态
      this.engineerAbsentList('channel', this.selbussinesscode, this.selchannelcode, '') // 右侧缺勤人数
      this.getattendStatus('group', this.selbussinesscode, this.selchannelcode, '') // 进入页面默认的坐席状态
      this.getGroupstatus('', 'initpage') // 获取所有组的的状态
    },
    methods: {
      // 第一个图标
      getpiedata() {
        // 清空图表下面显示的值
        servers.getPiedata(this.businessID, this.accessID, 'biz', '', '', this.seljobvalue)
          .then((res) => {
            this.pieonedata = res.data
            for (var i = 0; i < res.data.items.length; i++) {
              const result = res.data.items[i]
              if (result.percent !== 0) {
                this.onepiedata.push({
                  name: `${result.name}：${result.count}`,
                  value: result.percent,
                  code: result.code
                })
              }
            }
          })
      },
      // 第二个图标
      gettwopiedata(code) {
        servers.getPiedata(this.businessID, this.accessID, 'channel', code, '', this.seljobvalue)
          .then((res) => {
            this.pietwodata = res.data
            console.log(res.data)
            for (var i = 0; i < res.data.items.length; i++) {
              const result = res.data.items[i]
              if (result.percent !== 0) {
                this.twopiedata.push({
                  name: `${result.name}：${result.count}`,
                  value: result.percent,
                  code: result.code
                })
              }
            }
          })
        // .catch((error) => {
        //   this.$message({
        //     message: error,
        //     type: 'warning'
        //   })
        // })
      },
      // 第三个图标
      getthreepiedata(channel) {
        servers.getPiedata(this.businessID, this.accessID, 'region', this.selbussinesscode, channel, this.seljobvalue)
          .then((res) => {
            const arr = []
            this.piethreedata = res.data
            for (let i = 0; i < res.data.items.length; i++) {
              arr.push(res.data.items[i].name)
            }
            this.regionname = arr.join('/')
            for (var i = 0; i < res.data.items.length; i++) {
              const result = res.data.items[i]
              if (result.percent !== 0) {
                this.threepiedata.push({
                  name: `${result.name}：${result.count}`,
                  value: result.percent,
                  code: result.code
                })
              }
            }
          })
        // .catch((error) => {
        //   this.$message({
        //     message: error,
        //     type: 'warning'
        //   })
        // })
      },
      // 第一个图表的点击事件，联动后面两个图表
      pieonclick(res) {
        this.ifshowthreepie = false // 隐藏第三个饼图
        this.ifshowtwopie = true // 显示第二个饼图
        this.hasgroupstatus = false // 隐藏选择组的状态的
        this.groupstatus = [] // 清空选择的组的状态数据
        this.twopiedata = []
        this.threepiedata = []
        this.enginnerstatus = '' // 清空坐席数据
        this.savestatus = 'biz'
        this.selbussinesscode = res.code
        this.selchannelcode = '' // 通路code清空
        this.regioncode = '' // 地域code清
        this.selbussinessname = res.name.split(',')[0] // 通路名字置空
        this.selchannelname = '' // 清空通路名字
        this.regionname = '' // 清空地域名字
        this.gettwopiedata(res.code)
        this.getEngineerWorkStatus('biz', res.code, '', '', 'one') // 重新渲染工程师出勤状况
        this.engineerAbsentList('biz', res.code, '', '') // 右侧缺勤人数
      },
      // 第二个图表的点击事件
      pietwoclick(res) {
        this.hasgroupstatus = false // 隐藏选择组的状态的线
        this.groupstatus = [] // 清空选择的组的状态数据
        this.threepiedata = []
        this.savestatus = 'channel'
        this.selchannelname = res.name.split(',')[0] // 地域名字置空
        this.selchannelcode = res.code
        this.regioncode = '' // 地域code清空
        this.getthreepiedata(res.code)
        this.getEngineerWorkStatus('channel', this.selbussinesscode, res.code, '', 'two') // 重新渲染工程师出勤状况
        this.engineerAbsentList('channel', this.selbussinesscode, res.code, '') // 右侧缺勤人数
        this.getattendStatus('group', this.selbussinesscode, res.code, '') // 获取组的坐席状态
        this.ifshowthreepie = true
        this.getGroupstatus('', 'initpage') // 获取所有组的的状态
      },
      // 第三个点击图表事件
      piethreeclick(res) {
        this.hasgroupstatus = false // 隐藏选择组的状态的线
        this.groupstatus = [] // 清空选择的组的状态
        this.savestatus = 'region'
        this.regioncode = res.code
        this.regionname = res.name.split(',')[0]
        this.getEngineerWorkStatus('region', this.selbussinesscode, this.selchannelcode, res.code, 'three') // 重新渲染工程师出勤状况
        this.engineerAbsentList('region', this.selbussinesscode, this.selchannelcode, res.code) // 右侧缺勤人数
        this.getattendStatus('group', this.selbussinesscode, this.selchannelcode, res.code) // 获取组的坐席状态
        this.getGroupstatus('', 'initpage') // 获取所有组的的状态
      },
      // 缺勤list点击上一页
      prevpage() {
        this.pagenum--
        if (this.pagenum > 0) {
          if (this.savestatus === 'biz') {
            this.engineerAbsentList('biz', this.selbussinesscode, '', '')
          } else if (this.savestatus === 'channel') {
            this.engineerAbsentList('channel', this.selbussinesscode, this.selchannelcode, '')
          } else {
            this.engineerAbsentList('region', this.selbussinesscode, this.selchannelcode, this.regioncode)
          }
        } else {
          this.pagenum = 1
        }
      },
      // 缺勤list点击下一页
      nextpage() {
        this.pagenum++
        if (this.pagenum > this.absentlist.pagination.page_in_total) {
          this.pagenum = this.absentlist.pagination.page_in_total
        }
        if (this.savestatus === 'biz') {
          this.engineerAbsentList('biz', this.selbussinesscode, '', '')
        } else if (this.savestatus === 'channel') {
          this.engineerAbsentList('channel', this.selbussinesscode, this.selchannelcode, '')
        } else {
          this.engineerAbsentList('region', this.selbussinesscode, this.selchannelcode, this.regioncode)
        }
      },
      // 工程师的出勤状态
      getEngineerWorkStatus(cate, biz, channel, region, type) {
        const loadingInstance = Loading.service({ fullscreen: true })
        this.engineerwork = []
        servers.getEngineerWorkStatus(this.businessID, this.accessID, cate, biz, channel, region, this.seljobvalue)
          .then((res) => {
            this.engineerwork = res.data
            loadingInstance.close()
          })
          .catch((error) => {
            loadingInstance.close()
            this.$message({
              message: error,
              type: 'warning'
            })
          })
      },
      // 缺勤人数
      engineerAbsentList(cate, biz, channel, region) {
        const loadingInstance = Loading.service({ fullscreen: true })
        this.absentlist = []
        servers.engineerAbsentList(this.businessID, this.accessID, cate, biz, channel, region, this.pagenum, this.seljobvalue)
          .then((res) => {
            if (res.data.items.length === 0) {
              this.ifshownoabsence = true
            } else {
              this.ifshownoabsence = false
            }
            if (this.pagenum <= res.data.pagination.page_in_total) {
              this.absentlist = res.data
            } else {
              // this.$message({
              //   message: '123没有更多数据了',
              //   type: 'warning'
              // })
            }
            loadingInstance.close()
          })
          .catch((error) => {
            loadingInstance.close()
            this.$message({
              message: error,
              type: 'warning'
            })
          })
      },
      // 获取工程师的坐席状态
      getattendStatus(cate, biz, channel, region) {
        const loadingInstance = Loading.service({ fullscreen: true })
        this.enginnerstatus = []
        servers.getattendStatus(this.businessID, this.accessID, cate, biz, channel, region, this.seljobvalue)
          .then((res) => {
            this.enginnerstatus = res.data
            console.log(res.data)
            loadingInstance.close()
          })
          .catch((error) => {
            loadingInstance.close()
            this.$message({
              message: error,
              type: 'warning'
            })
          })
      },
      // 获取组的状态
      getGroupstatus(groupid, type) {
        servers.getGroupStatus(this.businessID, this.accessID, this.selbussinesscode, this.selchannelcode, this.regioncode, groupid, this.seljobvalue)
          .then((res) => {
            if (res.data !== '') {
              if (type === 'initpage') {
                this.groupstatus = res.data
                this.hasgroupstatus = true
              } else if (type === 'clickgroup') {
                this.groupstatusdata = res.data
              }
            }
          })
          .catch((error) => {
            this.$message({
              message: error,
              type: 'warning'
            })
          })
      },
      // 选择职位触发的change事件
      userseljob() {
        // 清空三个图标下的文字描述、隐藏第三/第一个图表、清空坐席数据、清空通路/地域名字
        this.onepiedata = []
        this.twopiedata = []
        this.threepiedata = []
        this.ifshowthreepie = false
        this.ifshowtwopie = false
        this.groupstatus = []
        this.groupstatusdata = []
        this.enginnerstatus = []
        this.hasgroupstatus = false
        this.selchannelname = ''
        this.regionname = ''
        // 职位改变加载第一个图表，出勤、缺勤数据
        this.getpiedata()
        this.getEngineerWorkStatus('biz', this.selbussinesscode, this.selchannelcode, '', 'one') // 右侧工程师的出勤状态
        this.engineerAbsentList('biz', this.selbussinesscode, this.selchannelcode, '') // 右侧缺勤人数
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" >
  @import '../../../styles/index.scss';
  .sel-jobs{
    margin-top:30px;
  }
  .engineer-manage{
    width:100%;
    padding: 0 14px;
    .top-content{
      padding-bottom:30px;
      overflow: hidden;
      //图表
      .pie-one, .pie-two, .pie-three{
        width:20%;
        /*height:320px;*/
        float:left;
        margin-right:0px;
        margin-top:-17px;
      }
      .pie-three{
        margin-right:10px;
      }
      .onepie{
        clear: both;
        padding:0 20px;
        p{
          width:200px;
          line-height: 20px;
          font-size: 16px;
        }
      }
      // 点击图表，右侧显示数据
      .employee-work{
        width:36%;
        height:235px;
        float: right;
        padding: 0px 10px;
        background: #fff;
        margin-top:40px;
        // 产线对应出勤的总数列表
        .work-allcount{
          border-bottom:1px solid $color7ed;
          padding-bottom: 10px;
          .title-tips{
            font-size: 20px;
            color:$color222;
          }
          ul{
            display: flex;
          }
          ul li{
            flex: 1;
            p{
              text-align: center;
              line-height: 0;
              color:$color266;
            }
            p:nth-child(1){
              font-size: 14px;
            }
            p:nth-child(2){
              font-size: 24px;
              span{
                font-size: 14px;
              }
            }
          }
        }
        // 缺勤原因
        .absence-reasons{
          .left-arrow, .right-arrow{
            float: left;
            width:20px;
            height:62px;
            border:1px solid $color7ed;
            border-radius: 4px;
            margin-top:11px;
            cursor: pointer;
            span{
              color:$color266;
              margin: 20px 0 0 6px;
              display: inline-block;
            }
          }
          .noabsence{
            text-align: center;
            margin:40px 0;
            font-size: 14px;
            color:red;
          }
          .right-arrow{
            float:right;
          }
          .center-box{
            float: left;
            width:80%;
            margin-left:19px;
            p{
              width:50%;
              float: left;
              span{
                font-size: 14px;
                color:$color266;
                margin-right:12px;
              }
              span:last-child{
                margin-right:0;
              }
            }
            p:nth-child(even){
              margin-right:0;
            }
          }
        }
      }
    }
    // 员工分组
    .groups-emploies{
      margin-top: 30px;
      width:100%;
      padding: 20px 10px;
      background: #fff;
      // 选择的业务信息
      .business-infos{
        border-bottom: 1px solid $color7ed;
        clear: both;
        padding-bottom: 20px;
        ul{
          padding: 0 30px;
          display: flex;
        }
        ul li{
          flex:1;
          font-size: 20px;
          color:$color222;
        }
      }
      //员工头像表示当前的状态
      .emploies-status{
        .status-decrite{
          ul {
            li{
              display: inline-block;
              position: relative;
              margin-right:20px;
              .iconuser{
                width:30px;
                height:30px;
                float: left;
                margin-top:3px;
              }
              .employbac{
                width:24px;
              }
              img{
                width:29px;
                height:40px;
                background: #FF8060;
                display: inline-block;
                float: left;
              }
              span{
                font-size: 14px;
                color:$color266;
                position: relative;
                top:10px;
              }
            }
          }
        }
        .hasgroupstatus{
          padding:20px;
          border-bottom: 1px solid $color7ed;
        }
      }
      // 每个组说明
      .group{
        ul{
          .out-li{
            padding:10px;
            padding-bottom: 8px;
            border-bottom:1px solid $color7ed;
            overflow: hidden;
          }
          .group-name{
            float:left;
            font-size: 20px;
            color:$color222;
            cursor: pointer;
            width:10%;
            margin-right:20px;
          }
          ol{
            width:85%;
            float: left;
            li{
              width:50px;
              /*display: inline-block;*/
              margin-right:12px;
              float: left;
              cursor: pointer;
              position: relative;
              top: 5px;
              .iconuser{
                width:30px;
                height:30px;
              }
              .employbac{
                width:24px;
              }
              p{
                line-height: 15px;
                font-size: 14px;
                margin-top:6px;
              }
            }
          }
        }
        .clear{
          clear:both;
        }
      }
        .online{
            color: $colore2;
        }
        .rest{
            color: $colorae2;
        }
        .acw{
            color: $color1b9;
        }
        .hangup{
            color: $colorc01;
        }
        .callin{
            color: $color623;
        }
        .callout{
            color: $color060;
        }
        .hold{
            color: #909399;
        }
        .offline{
            color: #979797;
        }
        .absence{
            color: #000;
        }
    }
  }
  .clear{
    clear:both;
  }
  .el-popover{
    .window-content{
      /*width:200px;*/
      /*height:200px;*/
      /*background: #fff;*/
      /*padding:10px 10px;*/
      /*position: absolute;*/
      /*box-shadow: 0px 2px 3px 2px #ccc;*/
      /*z-index: 300;*/
      .top-con, .bottom-con{
        p{
          font-size: 14px;
          color:$color266;
          line-height: 0;
          padding-bottom:6px;
        }
        ol{
          margin-left:18px;
          margin-top:-8px;
        }
        ol li{
          list-style-type:disc
        }
      }
      .bottom-con{
        margin-top:36px;
      }
    }
  }

</style>

