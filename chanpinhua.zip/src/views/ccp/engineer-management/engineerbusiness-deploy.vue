<template>
  <div class="business-deploy">
    <!--配置详情-->
    <!--<div class="indexdeploy">-->
    <!--<el-button type="primary" class="indexdeploy-btn">首页配置</el-button>-->
    <!--</div>-->
    <!--<div class="other-deploy">-->
    <!--<div class="hot">-->
    <!--<span>热线工作时段配置</span>-->
    <!--<el-input placeholder="上传文件" class="downfile"></el-input>-->
    <!--<a href="">模板下载</a>-->
    <!--<a href="">浏览上传</a>-->
    <!--</div>-->
    <!--<div class="shiliang">-->
    <!--<span>适量时段分配配置</span>-->
    <!--<el-input placeholder="上传文件" class="downfile"></el-input>-->
    <!--<a href="">模板下载</a>-->
    <!--<a href="">浏览上传</a>-->
    <!--</div>-->
    <!--</div>-->
    <!--缺勤情配置-->
    <div class="sel-actions">
      <el-cascader ref="a" v-model="scene" :options="options" :show-all-levels="false" placeholder="现场选择" size="medium" @change="handleChange" />
    </div>

    <div class="absence-deploy">
      <p class="big-title">缺勤情况配置</p>
      <div class="plan-people"><span>计划在线人数</span><el-input v-model="planonlinepeoples" placeholder="" class="downfile" /><el-button type="primary" class="add" @click="addplanpeople">保存</el-button></div>
      <div class="other-input">
        <div class="absence-name">
          <p>
            <span>缺勤人员姓名</span>
            <el-input v-model="name" placeholder="" class="need-msrginleft" @input="userinputname" @blur="userinputblur" />
          </p>
          <ul v-if="ifshowengineerlist">
            <li v-for="item in engineername" @mousedown="selengineername(item.name)">
              <span>{{ item.name }}</span>
            </li>
          </ul>
        </div>
        <p><span>缺勤类型</span>
          <el-select v-model="absencetype" placeholder="请选择">
            <el-option
              v-for="item in absenceoptions"
              :key="item"
              :value="item"
            />
          </el-select></p>
        <p><span>缺勤时长</span><el-input v-model="absencetime" placeholder="" /><span class="add-timetips">小时</span></p>
        <el-button type="primary" class="add" @click="addabsencelist">保存</el-button>
      </div>
      <div class="needsubmit-deploy">
        <el-table
          :data="tableData"
          style="width: 100%"
        >
          <el-table-column
            prop="no"
            label="序号"
          />
          <el-table-column
            prop="name"
            label="姓名"
            width="180"
          />
          <el-table-column
            prop="code"
            label="工号"
          />
          <el-table-column
            prop="group"
            label="组别"
          />
          <!--<el-table-column-->
          <!--prop="shao"-->
          <!--label="缺勤类型">-->
          <!--</el-table-column>-->
          <el-table-column
            prop="duration"
            label="缺勤小时数"
          />
          <el-table-column
            prop="region"
            label="地域"
          />
          <el-table-column label="操作">
            <template slot-scope="scope">
              <span class="del-onelist" @click="listDelete(scope.row.id)">删除</span>
            </template>
          </el-table-column>

        </el-table>
        <div v-if="ifshowpage" class="pagination-con">
          <el-pagination
            background
            :current-page="currentPage"
            :page-sizes="[10, 20, 30]"
            :page-size="10"
            layout="sizes, prev, pager, next, jumper"
            :total="total"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          />
        </div>
      </div>

      <!--<div class="submit-form">-->
      <!--<el-button type="primary" class="needsumit-deploylist" @click="absenceSubmit">提交</el-button>-->
      <!--</div>-->

    </div>
  </div>
</template>

<script>
  import servers from '@/api/devccp/engineer-management/engineer-management'
  import { BusinessDeploy } from '@/api/devccp/link'
  import { EngineerLocales } from '@/api/devccp/index'
  export default {
    beforeRouteEnter: BusinessDeploy,
    beforeRouteUpdate: BusinessDeploy,
    data() {
      return {
        options: [],
        scene: [Number(this.$route.query.businessID), Number(this.$route.query.accessID)],
        tableData: [],
        currentPage: 1,
        total: null,
        planonlinepeoples: '',
        name: '',
        absencetime: '',
        absencetype: '',
        pagenum: 1,
        engineername: [],
        ifshowengineerlist: false,
        ifshowpage: false,
        absenceoptions: ['事假', '病假', '年假', '婚假', '产假', '其他'],
        businessID: this.$route.query.businessID,
        accessID: this.$route.query.accessID
      }
    },
    mounted() {
      // 获取计划在线人数
      this.getPlanPeople()
      this.getEngineer()
      this.getAbsenceList(this.pagenum)
    },
    methods: {
      // 现场选择
      getEngineer() {
        EngineerLocales(this.$route.query.businessID, this.$route.query.accessID).then(response => {
          var item = response.data
          for (const i in item) {
            const childrenList = []
            for (const j in item[i].children) {
              if (item[i].children[j].power === 2) {
                childrenList.push(item[i].children[j])
              }
            }
            if (childrenList.length > 0) {
              this.options.push({
                'value': item[i].value,
                'label': item[i].label,
                'children': childrenList
              })
            }
          }
        })
      },
      // 通路切换
      handleChange(value) {
        this.businessID = value[0]
        this.accessID = value[1]
        this.getAbsenceList(this.pagenum) // 更新缺勤列表
        this.getPlanPeople() // 更新现场人数
      },
      // 获取计划在线人数
      getPlanPeople() {
        servers.getPlanPeople(this.businessID, this.accessID)
          .then(res => {
            this.planonlinepeoples = res.data
          })
      },
      // 添加计划人数
      addplanpeople() {
        if (this.planonlinepeoples === '') {
          this.$message({
            message: '请填写计划在线人数',
            type: 'warning'
          })
        } else {
          const obj = {
            planned: this.planonlinepeoples
          }
          servers.setPlanPeople(this.businessID, this.accessID, obj)
            .then(res => {
              this.$message({
                message: '添加成功',
                type: 'success'
              })
            })
            .catch(err => {
              this.$message({
                message: err,
                type: 'warning'
              })
            })
        }
      },
      // 点击添加
      addabsencelist() {
        if (this.name === '') {
          this.$message({
            message: '请填写工程师名字',
            type: 'warning'
          })
        } else if (this.absencetype === '') {
          this.$message({
            message: '请选择缺勤类型',
            type: 'warning'
          })
        } else if (this.absencetime === '') {
          this.$message({
            message: '请填写缺勤时长',
            type: 'warning'
          })
        } else {
          const obj = {
            name: this.name,
            leave: this.absencetype,
            hour: this.absencetime
          }
          servers.submitAbsenceList(this.businessID, this.accessID, obj)
            .then(res => {
              this.$message({
                message: '添加成功',
                type: 'success'
              })
              this.getAbsenceList(1)
            })
            .catch(err => {
              this.$message({
                message: err,
                type: 'warning'
              })
            })
        }
      },
      handleSizeChange(val) {
        this.getAbsenceList(val)
      },
      handleCurrentChange(val) {
        this.getAbsenceList(val)
      },
      getAbsenceList(page) {
        servers.getAbsenceList(this.businessID, this.accessID, page, 'specific')
          .then((res) => {
            if (res.data.items.length > 0) {
              this.ifshowpage = true
            } else {
              this.ifshowpage = false
            }
            this.tableData = res.data.items
            this.total = res.data.pagination.total
          })
      },
      userinputname() {
        const ifchinese = /[^/u4e00 - /u9fa5]+$/
        const ifnum = /^[0-9a-zA-Z]/
        if (this.name === '') {
          this.ifshowengineerlist = false
        }
        if (ifchinese.test(this.name) && this.name.length >= 2) {
          this.searchEngineer(this.name)
        }
        if (ifnum.test(this.name) && this.name.length >= 3) {
          this.searchEngineer(this.name)
        }
      },
      // 工程师名字搜索联动
      searchEngineer(q) {
        servers.engineerNameSearch(this.businessID, this.accessID, q)
          .then((res) => {
            if (res.data.length > 0) {
              this.ifshowengineerlist = true
              this.engineername = res.data
            } else {
              this.ifshowengineerlist = false
            }
          })
      },
      selengineername(selname) {
        this.name = selname
      },
      // 失去焦点隐藏下拉框
      userinputblur() {
        this.ifshowengineerlist = false
      },
      // 删除某一条添加的数据
      listDelete(enginid) {
        const obj = {
          id: enginid
        }
        servers.absenceEngineerDel(this.businessID, this.accessID, obj)
          .then((res) => {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
            this.getAbsenceList(1)
          })
          .catch(err => {
            this.$message({
              message: err,
              type: 'warning'
            })
          })
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss">
  $color266: #606266;
  $colorblue:#4A90E2;
  .business-deploy{
    padding: 0 14px;
    .sel-actions{
      margin-top:30px;
    }
    .indexdeploy{
      border:1px solid #ccc;
      background: #fff;
      border-radius: 4px;
      padding:30px;
      margin:30px 0;
      .indexdeploy-btn{
        width:260px;
      }
    }
    .other-deploy{
      border:1px solid #ccc;
      background: #fff;
      border-radius: 4px;
      padding:30px;
      .el-input{
        width:580px;
      }
      span{
        font-size: 14px;
        color:$color266;
        margin-right:14px;
      }
      a{
        font-size: 14px;
        color:$colorblue;
        margin-left:14px;
      }
      .shiliang{
        margin-top:14px;
      }
    }
    .absence-deploy{
      border:1px solid #ccc;
      background: #fff;
      border-radius: 4px;
      padding:30px 0;
      margin-top:30px;
      overflow: hidden;
      .big-title{
        font-size: 20px;
        clear: both;
        padding:0 30px;
        line-height: 0;
        margin-top:0;
      }
      .el-input{
        width:190px;
      }
      .el-input--mini .el-input__inner{
        height:38px;
        line-height: 38px;
      }
      .need-msrginleft{
        marign-left:-3px;
      }
      span{
        font-size: 14px;
        color:$color266;
        margin-right:14px;
      }
      .el-input__suffix{
        margin-right:0;
        right:-3px;
      }
      .add-timetips{
        margin-left:6px;
      }
      .del-onelist{
        margin-left:18px;
        cursor: pointer;
      }
      .plan-people{
        padding:0px 30px;
        .add{
          background: #E5F2FF;
          border:1px solid $colorblue;
          padding:6px 30px;
          margin-top:13px;
          height:36px;
          span{
            color:$colorblue;
            margin-right:0;
          }
        }
        .downfile{
          margin-right:26px;
          span{
            margin-right:0;
          }
        }
        .el-input--mini .el-input__inner{
          margin-left:3px;
        }
      }
      .other-input{
        padding:0px 30px;
        height:60px;
        .add{
          background: #E5F2FF;
          border:1px solid $colorblue;
          padding:6px 30px;
          margin-top:13px;
          height:36px;
          span{
            color:$colorblue;
            margin-right:0;
          }
        }
        p{
          float: left;
          margin-right:10px;
        }
        .absence-name{
          position: relative;
          ul{
            width:190px;
            left:100px;
            background: #fafafa;
            border-radius:4px;
            margin-top: 4px;
            position: absolute;
            top:50px;
            z-index: 300;
            padding:10px;
            li{
              cursor: pointer;
              color:$color266;
              font-size: 14px;
              margin-bottom:10px;
            }
            li:last-child{
              margin:0;
            }
          }
        }
      }
      .submit-form{
        width:300px;
        margin:0 auto;
        margin-top:20px;
        .needsumit-deploylist{
          width:300px;
          height:40px;
          span{
            color:#fff;
            font-size: 14px;
          }
        }
      }
      .needsubmit-deploy{
        margin-top:10px;
        .el-table th{
          background: #F0F4FB;
          border-top:1px solid #ccc;
          height:36px;
          font-size: 14px;
        }
        .el-table th>.cell{
          color:#303133;
          text-align: center;
        }
        .el-table .cell{
          text-align: center;
          color:#606266;
        }
        .el-table--mini td{
          height:36px;
          line-height: 36px;
          font-size: 14px;
        }
        .el-table__empty-block{
          min-height: 36px;
        }
        .pagination-con{
          margin-top:60px;
          float: right;
          .el-input{
            width:100px;
          }
        }
      }
    }
  }
</style>

