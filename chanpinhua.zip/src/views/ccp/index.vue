<template>
  <div class="dashboard-contenter">
    <div class="dashboard_select">
      <div ref="box" class="box" />
      <el-cascader
        ref="cascader"
        v-model="scene"
        :options="options"
        :show-all-levels="false"
        placeholder="现场选择"
        size="medium"
        class="cascader"
        @visible-change="handleVisibleChange"
        @change="handleChange"
      />
      <div class="time">当前时间： {{ currentTime }}</div>
    </div>
    <div class="elcontent-pad">
      <div class="elcontent-left">
        <el-card class="box-card call" content="呼叫中心总体服务量">
          <div class="bg-blur" :style="left_H" />
          <div class="servciceNum">
            <span>呼叫中心总体服务量</span>
            <span style="font-size: 2em">{{ sNum }}</span>
          </div>
        </el-card>
        <el-card
          class="box-card elcontent-servciceNum services"
          content="客服"
          @click.native="handlengineerManage"
        >
          <servcice-chart :ser-chart="serChart" />
        </el-card>
        <el-card
          class="box-card elcontent-queuingNum lineup"
          content="排队量"
          @click.native="handleBigQueueShow"
        >
          <lineup-chart :lin-chart="linChart" />
        </el-card>
        <el-card
          class="box-card elcontent-queuingNum abandon"
          content="放弃率"
          @click.native="handleBigQueueShow"
        >
          <abandon-chart :aba-chart="abaChart" />
        </el-card>
      </div>
      <div class="elcontent-center">
        <el-card class="box-card elcontent-abandonment linechart" :style="center_top_H" content="时段服务明细">
          <line-chart v-if="lineChart.begin_time.length" :line-chart="lineChart" />
        </el-card>
        <el-card class="box-card elcontent-abandonment" content="地域来电分析" style="flex: 1;margin: 0;min-height: 470px" :style="center_bottom_H">
          <map-chart ref="mapChart" :map-h="center_bottom_H" />
        </el-card>
      </div>
      <div class="elcontent-right">
        <el-card class="box-card elcontent-abandonment" :style="right_H" content="重要业务数据">
          <business-canvas ref="businessCanvas" :heights="right_H" :business-h="business_H" />
        </el-card>
        <el-card
          class="box-card elcontent-abandonment emotion"
          content="用户情感监控"
          :style="right_H"
          @click.native="handleusersemotion"
        >
          <emotion-chart v-if="emotionData !== null" :emotion-data="emotionData" />
        </el-card>
        <el-card
          class="box-card elcontent-abandonment"
          content="问题分类"
          :style="right_H"
        >
          <class-chart ref="classChart" />
        </el-card>
      </div>
    </div>
  </div>
</template>

<script>
  import {
    EngineerLocales,
    getCount,
    getFeedDetail,
    getStatusCount,
    getLocalesCount,
    getLineupNum,
    getAhtCount,
    getLineupTime,
    getNotAtAll,
    getGaveupRate,
    getIntervalData
  } from '@/api/ccp/index' // getIntervalNowData
  import LineChart from './components/LineChart'
  import MapChart from './components/MapChart'
  import BusinessCanvas from './components/BusinessCanvas'
  import EmotionChart from './components/EmotionChart'
  import ClassChart from './components/ClassChart'
  import ServciceChart from './components/ServciceChart'
  import LineupChart from './components/LineupChart'
  import AbandonChart from './components/AbandonChart'
  import { getDateFormat } from '@/utils'
  export default {
    name: 'ccp-dashboard',
    components: {
      AbandonChart,
      LineupChart,
      ServciceChart,
      LineChart,
      MapChart,
      BusinessCanvas,
      EmotionChart,
      ClassChart
    },
    data() {
      return {
        permissionShow: false,
        sNum: 0,
        ss: {
          rest: 0,
          ready: 73,
          hangUp: 20,
          Total: 108
        },
        query: {
          businessID: '',
          business: '',
          accessID: '',
          access: ''
        },
        para: {
          businessId: 10,
          accessId: 21
        },
        LocalesDtate: [],
        options: [],
        scene: [],
        serChart: {
          rest: 0,
          online: 0,
          hangup: 0,
          total: 0
        }, // 客服信息
        linChart: {
          aht_count: '00:00:00',
          queues_count: 0,
          locale_count: 0
        },
        abaChart: {
          section_abandon_rate: '0%',
          section_avg_wait_time: '00:00:00',
          not_at_all: 0
        },
        lineChart: {
          begin_time: [],
          section_num_into: [],
          section_abandon_rate: []
        },
        timer: null,
        timer1: null,
        currentTime: null,
        emotionData: null,
        left_H: '',
        right_H: '',
        business_H: '',
        center_top_H: '',
        center_bottom_H: '',
        center_H: '',
        mockTimer: null,
        mockServiceTimer: null
      }
    },
    activated() {
      // /* 测试 */
      // this.mockJson()
      // this.mockServiceJson()
      // /* 测试 */
      EngineerLocales().then(response => {
        if (!response.data.length) {
          this.permissionShow = false
          this.$message({
            message: '请配置看板权限',
            type: 'warning'
          })
          setTimeout(this.toSearchPage, 1500)
        } else {
          this.permissionShow = true
          this.options = []
          this.options.push(response.data[0])
          this._getAllCanLocale()
        }
      })
    },
    deactivated() {
      clearInterval(this.timer)
      clearInterval(this.mockTimer)
    },
    beforeDestroy() {
      clearInterval(this.timer)
      clearInterval(this.mockTimer)
    },
    mounted() {
      const call_H = document.getElementsByClassName('elcontent-left')[0].scrollHeight
      const line_H = document.getElementsByClassName('linechart')[0].scrollHeight
      this.center_H = `heigth: ${call_H - line_H}px`
      this.left_H = `width: ${call_H / 4 - 10}px; height: ${call_H / 4 - 10}px`
      this.center_top_H = `height: ${call_H * 0.4}px`
      this.center_bottom_H = `height: ${call_H - (call_H * 0.4) - 50}px`
      this.right_H = `height: ${(call_H / 3) - 16}px; min-height: 250px`
      this.business_H = `height: ${call_H / 3 - 20}px; min-height: 250px`
    },
    methods: {
      /* 测试 */
      mockJson() {
        clearInterval(this.mockTimer)
        const Random = Math.floor((Math.random() * 5) + 1)
        this.sNum = this.sNum + Random
        // this.linChart = {
        //   aht_count: `00:02:2${Random}`,
        //   queues_count: this.linChart.queues_count + Random + 1,
        //   locale_count: this.linChart.locale_count + Random
        // }
        this.linChart.aht_count = `00:02:${Random}${Random + 3}`
        this.linChart.locale_count = this.linChart.locale_count + Random
        this.abaChart.section_avg_wait_time = `00:02:${Random}${Random + 2}`
        // this.linChart = {
        //   aht_count: `00:02:2${Random}`,
        //   queues_count: this.linChart.queues_count + Random,
        //   locale_count: this.linChart.locale_count + Random
        // }
        this.mockTimer = setInterval(this.mockJson, 1000)
      },
      /* 测试 */
      mockServiceJson() {
        // this.$refs.businessCanvas._getBusinessInfoTest()
        this.serChart = {
          rest: 4,
          online: 28,
          hangup: 3,
          total: 35
        }
        setTimeout(() => {
          // this.$refs.businessCanvas.busCanvas.num_info = {
          //   num: this.$refs.businessCanvas.busCanvas.num_info.num + 1,
          //   rate: 100,
          //   title: '30秒接起率',
          //   text: '接起量'
          // }
          // this.$refs.businessCanvas.busCanvas.info = {
          //   num: this.$refs.businessCanvas.busCanvas.info.num + 1,
          //   rate: 98.3,
          //   title: '满意度',
          //   text: '点评发送量'
          // }
          // this.$refs.businessCanvas.busCanvas.robot_info = {
          //   num: this.$refs.businessCanvas.busCanvas.robot_info.num + 1,
          //   rate: 99.3,
          //   title: '机器人转人工',
          //   text: '机器人进入量'
          // }
          this.linChart.queues_count = 5
          this.abaChart.not_at_all = 1
          this.abaChart.section_abandon_rate = '2%'
          // this.$refs.businessCanvas._getBusinessInfoTest()
        }, 3 * 1000)
        setTimeout(() => {
          // this.$refs.businessCanvas.busCanvas.num_info = {
          //   num: this.$refs.businessCanvas.busCanvas.num_info.num,
          //   rate: 98.1,
          //   title: '30秒接起率',
          //   text: '接起量'
          // }
          // this.$refs.businessCanvas.busCanvas.info = {
          //   num: this.$refs.businessCanvas.busCanvas.info.num,
          //   rate: 97.7,
          //   title: '满意度',
          //   text: '点评发送量'
          // }
          // this.$refs.businessCanvas.busCanvas.robot_info = {
          //   num: this.$refs.businessCanvas.busCanvas.robot_info.num,
          //   rate: 99.5,
          //   title: '机器人转人工',
          //   text: '机器人进入量'
          // }
          this.linChart.queues_count = 8
          this.abaChart.not_at_all = this.abaChart.not_at_all + 1
          this.abaChart.section_abandon_rate = '4%'
          // this.$refs.businessCanvas._getBusinessInfoTest()
        }, 3 * 1000)
        setTimeout(() => {
          // this.$refs.businessCanvas.busCanvas.num_info = {
          //   num: this.$refs.businessCanvas.busCanvas.num_info.num,
          //   rate: 99,
          //   title: '30秒接起率',
          //   text: '接起量'
          // }
          this.linChart.queues_count = 2
          this.abaChart.not_at_all = this.abaChart.not_at_all + 2
          this.abaChart.section_abandon_rate = '1%'
          // this.$refs.businessCanvas._getBusinessInfoTest()
        }, 3 * 1000)
        setTimeout(() => {
          this.mockServiceJson()
          // this.$refs.businessCanvas._getBusinessInfoTest()
        }, 3 * 1000)
      },
      // 关闭当前页
      toSearchPage() {
        const currentPath = this.$route.path
        for (const [i, v] of this.$store.getters.visitedViews.entries()) {
          if (v.path === currentPath) {
            this.$store.getters.visitedViews.splice(i, 1)
            const latestView = this.$store.getters.visitedViews.slice(-1)[0]
            if (latestView) {
              return this.$router.back(-1)
            } else {
              this.$router.push('/')
            }
          }
        }
      },
      handlengineerManage() {
        // 工程师管理
        const query = { ...(this.$route.query || {}) }
        this.$router.push({
          path: `engineer-manage/${this.$route.query.businessID}${
            this.$route.query.accessID
          }`,
          query: query
        })
      },
      handleBigQueueShow() {
        // 队列管理 大队列
        const query = { ...(this.$route.query || {}) }
        this.$router.push({
          path: `actioncontrol/bigQueue/${this.$route.query.businessID}${
            this.$route.query.accessID
          }`,
          query: query
        })
        // chrome
        document.body.scrollTop = 0
        // firefox
        document.documentElement.scrollTop = 0
      },
      handleusersemotion() {
        // 用户情感
        if (this.emotionData.length) {
          const query = { ...(this.$route.query || {}) }
          this.$router.push({
            path: `usersemotion-management/${this.$route.query.businessID}${
              this.$route.query.accessID
            }`,
            query: query
          })
        }
      },
      // _getIntervalNowData() {
      //   getIntervalNowData(
      //     this.$route.query.businessID,
      //     this.$route.query.accessID
      //   ).then(res => {
      //     console.log(res, '当前放弃率')
      //     this.$refs.feed.section_abandon_rate = res.data.section_abandon_rate
      //     this.$refs.business.num_into.rate = 80 // res.data.section_abandon_rate
      //   })
      // },
      _getCount() {
        getCount(this.$route.query.businessID, this.$route.query.accessID).then(
          res => {
            // console.log(res, '总服务量')
            this.sNum = res.data
          }
        )
      },
      _getFeedDetail() {
        getFeedDetail(
          this.$route.query.businessID,
          this.$route.query.accessID
        ).then(res => {
          // console.log(res, '用户情感值')
          // this.feed = res.data.not_at_all
          // this.$refs.feed.not_at_all = res.data.not_at_all
          if (res.data instanceof Array) {
            this.emotionData = res.data
          } else {
            this.emotionData = [res.data]
          }
        })
      },
      _getStatusCount() {
        getStatusCount(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          // console.log(res, '客服人数')
          this.serChart = res.data
        })
      },
      _staffState() {
        getAhtCount(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          // console.log(res, 'AHT')
          this.linChart.aht_count = res.data
        })
        getLineupNum(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          // console.log(res, '本现场排队量')
          this.linChart.queues_count = res.data
        })
        getLocalesCount(this.$route.query.business, this.$route.query.access).then(res => {
          // console.log(res, '本现场服务量')
          this.linChart.locale_count = res.data
        })
      },
      _staffState1() {
        getLineupTime(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          if (!res.data) return
          this.abaChart.section_avg_wait_time = res.data
        })
        getNotAtAll(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          if (!res.statusCode === 200) return
          this.abaChart.not_at_all = res.data
        })
        getGaveupRate(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          if (!res.statusCode === 200) return
          this.abaChart.section_abandon_rate = res.data
        })
      },
      _getIntervalData() {
        getIntervalData(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          this.lineChart = {
            begin_time: [],
            section_num_into: [],
            section_abandon_rate: []
          }
          res.data.map((k) => {
            this.lineChart.begin_time.push(k.begin_time)
            this.lineChart.section_num_into.push(k.section_num_into)
            this.lineChart.section_abandon_rate.push(k.section_abandon_rate)
          })
        })
      },
      init() {
        this.dealWithTime() // 当前时间
        this.timer1 = setInterval(this.dealWithTime, 1000) // 当前时间
        clearInterval(this.timer)
        this.timer = setInterval(this.init, 15000)
        this._getCount()
        this._getFeedDetail()
        this._getStatusCount()
        this._staffState()
        this._staffState1()
        this._getIntervalData()
        this.$refs.businessCanvas._getBusinessInfo()
        this.$refs.classChart._getNewCaseLabels()
        this.$refs.mapChart._getPhoneCallData()
        this.$refs.mapChart._getweatherWarn()
      },
      _getAllCanLocale() { // 现场选择
        EngineerLocales().then(response => {
          if (!response.data.length) {
            this.permissionShow = false
            this.$message({
              message: '请配置看板权限',
              type: 'warning'
            })
            setTimeout(this.toSearchPage, 1500)
          } else {
            this.permissionShow = true
            this.options = []
            this.scene = []
            this.LocalesDtate = response.data
            this.options.push(this.LocalesDtate[0])
            this.scene = [this.options[0].value, this.options[0].children[0].value]
            this.query = {
              businessID: this.options[0].value,
              business: this.options[0].label,
              accessID: this.options[0].children[0].value,
              access: this.options[0].children[0].label
            }
            this.$router.replace({
              path: this.$route.path,
              query: this.query
            })
            this.init()
          }
        })
      },
      handleVisibleChange(val) {
        if (val) {
          this.$refs.box.className = 'box box-focus'
        } else {
          this.$refs.box.className = 'box'
        }
      },
      handleChange(d) {
        this.options.map(item => {
          if (item.value === d[0]) {
            item.children.map(data => {
              if (data.value === d[1]) {
                this.query = {
                  businessID: d[0],
                  business: item.label,
                  accessID: d[1],
                  access: data.label
                }
                this.$router.push({
                  path: this.$route.path,
                  query: this.query
                })
                this.init()
              }
            })
          }
        })
      },
      dealWithTime() {
        this.currentTime = getDateFormat()
      }
    }
  }
</script>

<style lang='scss' scoped>
.dashboard_select {
  position: relative;
  display: flex;
  justify-content: space-between;
  margin: 18px 2% 0;
  line-height: 36px;
  .cascader /deep/ .el-input__suffix {
    display: none;
  }
  .box {
    position: absolute;
    left: 160px;
    top: 14px;
    width: 0;
    height: 0;
    transform-origin: center;
    transition: transform .3s;
    border-top: 8px solid #6675FF;
    border-right: 8px solid  rgba(0,0,0,0);
    border-left: 8px solid  rgba(0,0,0,0);
  }
  .box-focus {
    transform: rotate(180deg);
    transition: transform .3s
  }
  & /deep/ .el-input__inner{
    width: 180px;
    border: 0;
    background: rgba(0,0,0,0);
    color: #303133;
    font-weight: 600;
  }
  & /deep/ .el-input__icon {
    font-size: 0;
  }
  .time{
    font-size:16px;
    color: #303133;
  }
  p {
    text-align: right;
    color: #4a90e2;
    font-size: 16px;
    font-weight: bold;
    margin: 0;
    float: left;
    width: 100%;
    i {
      font-style: normal;
      font-size: 24px;
      color: #ff8060;
      line-height: 36px;
      padding-left: 4px;
    }
  }
  .btn {
    width: 100px;
    height: 36px;
    margin-left: 20px;
  }
}
.elcontent-pad {
  display: flex;
  // text-align: center;
  margin: 0 2% 15px;
  height: calc(100vh - 150px);
  .box-card {
    position: relative;
    margin: 10px 10px 0px 0;
  }
  .elcontent-left {
    width: 28%;
    min-width: 280px;
    // width: 280px;
    // border: 1px solid #ccc;
    .box-card {
      // height: 180px;
      height: calc((100vh - 210px)/4);
      min-height: 190px;
    }
    /deep/ .el-card__body {
      padding: 0;
    }
    .call /deep/ .el-card__body {
      display: flex;
      justify-content: center;
      align-items: center;
      width: 100%;
      height: 100%;
      .bg-blur {
        display: flex;
        justify-content: center;
        align-items: center;
        // width: 100%;
        height: 100%;
        background: linear-gradient(#1890ff, #866df8);
        border-radius: 50%;
        filter: blur(1px);
        border: 10px solid #f7f7f7de;
      }
      .servciceNum {
        position: absolute;
      }
    }
    .elcontent-queuingNum {
      // height: 140px;
      position: relative;
    }
    .lineup,
    .abandon,
    .services,
    .emotion {
      cursor: pointer;
    }
    .servciceNum {
      text-align: center;
      color: #fff;
      span {
        font-size: 1rem;
        display: block;
        line-height: 2;
      }
      span:nth-child(2) {
        font-weight: bold;
      }
    }
    #myCanvas {
      position: relative;
      width: 100%;
      height: 135px;
      // background: linear-gradient(#1890FF,#866DF8);
    }
    .servcice_content {
      position: absolute;
      left: 0;
      bottom: 10px;
      display: flex;
      width: 80%;
      margin: 0 10%;
      .s {
        flex: 1;
        text-align: center;
        color: #606266;
        span {
          font-size: 14px;
          display: block;
          line-height: 26px;
        }
      }
    }
    /deep/ .elcontent-queuingNum .el-card__body {
      display: flex;
      position: absolute;
      height: 100%;
      top: 50%;
      margin-top: -25%;
      width: 100%;
      .qContent {
        text-align: center;
        flex: 1;
        line-height: 40px;
        .qNum {
          font-size: 20px;
          font-weight: bold;
        }
        .qinfo {
          color: #606266;
        }
      }
    }
  }
  .elcontent-center {
    width: 60%;
    min-width: 680px;
    flex: 1;
    // display: flex;
    // flex-direction: column;
    .box-card {
      position: relative;
      margin: 10px 0;
    }
  }
  .elcontent-right {
    width: 25%;
    min-width: 460px;
    .box-card {
      position: relative;
      margin: 10px 0 10px 10px;
      height: calc((100vh - 210px)/3);
      min-height: 190px;
    }
  }
}
.class-title {
    color: #303133;
    font-size: 17px;
    line-height: 30px;
    font-weight: bold;
  }

</style>
