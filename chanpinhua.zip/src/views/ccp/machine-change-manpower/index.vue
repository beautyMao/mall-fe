<template>
  <div class="Wrap">
    <p class="title">当前现场：{{ this.$route.query.business }} {{ this.$route.query.access }}</p>
    <div class="main">
      <span class="alert"> <a @click="handleSkipHistory">历史数据</a></span>
      <ul class="explain">
        <li><span style="background:#1890FF" />机器人进入量</li>
        <li><span style="background:#00D6D5" />转人工量</li>
        <li><span style="background:#FFCC01" />机器人转人工率</li>
      </ul>
      <div id="threshold" class="threshold" />
    </div>
  </div>
</template>

<script>
  import Vue from 'vue'
  import echarts from 'echarts'
  Vue.prototype.$echarts = echarts
  import { getEnterInfo } from '@/api/ccp/machine-change-manpowe'
  export default {
    name: 'manpower',
    data() {
      return {
        timer: null,
        option: {
          tooltip: { // 图例的提示工具配置
            trigger: 'axis', // 鼠标滑过状态显示
            axisPointer: { type: 'cross' } // 十字准星指示器
          },
          legend: { // 图例组件
            data: [
              {
                name: '机器人进入量'
              }, {
                name: '转人工量'
              }, {
                name: '机器人转人工率',
                icon: 'image://static/images/Rectangle.png'
              }],
            right: 0,
            itemGap: 50,
            itemWidth: 14,
            itemHeight: 14,
            textStyle: {
              fontSize: 16,
              color: '#000',
              padding: [0, 0, 0, 5]
            }
          },
          grid: {
            left: '1%',
            right: '1%',
            bottom: '0',
            containLabel: true
          },
          xAxis: [{ // X轴
            type: 'category', // 坐标轴类型：类目轴
            axisLabel: { // 坐标轴刻度标签的相关设置
              interval: 0, // 坐标轴刻度标签的显示间隔，在类目轴中有效。
              rotate: 45 // 刻度标签旋转的角度
            },
            axisTick: { // 刻度线和标签对齐
              alignWithLabel: true
            },
            data: []
          }],
          yAxis: [ // Y轴
            { minInterval: 1 },
            {
              type: 'value', // 坐标轴类型：连续数据
              max: 1000
              // name: '机器人进入量+转人工量' // 坐标轴名称
            },
            {
              type: 'value',
              // name: '机器人转人工率',
              max: 100,
              axisLabel: {
                formatter: '{value} %' // 刻度标签的内容格式器
              }
            }
          ],
          series: [ // 系列列表
            {
              name: '机器人进入量', // 系列名称
              type: 'bar', // 柱状/条形图
              stack: '进入量', // 数据堆叠
              itemStyle: { color: '#1890FF' }, // 柱条的颜色
              data: []
            },
            {
              name: '转人工量',
              type: 'bar',
              stack: '进入量',
              itemStyle: { color: '#13C2C2' },
              data: []
            },
            {
              name: '机器人转人工率',
              type: 'line', // 折线/面积图
              yAxisIndex: 2, // 使用的 x 轴的 index，在单个图表实例中存在多个 x 轴的时候有用
              itemStyle: { color: '#FFCC01' },
              data: []
            }
          ]
        }
      }
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    mounted() {
      this.init()
    },
    methods: {
      handleSkipHistory() { // 历史
        clearInterval(this.timer)
        this.$router.push({
          path: '/actioncontrol/setThreshold',
          query: {
            businessID: this.$route.query.businessID,
            business: this.$route.query.business,
            accessID: this.$route.query.accessID,
            access: this.$route.query.access
          }
        })
      },
      init() {
        const accessID = this.$route.query.accessID
        const businessID = this.$route.query.businessID
        getEnterInfo(accessID, businessID).then(res => {
          this.option.series[0].data = res.data.robotAccessCountByHour // 机器人进入量
          this.option.series[1].data = res.data.manualAccessCountByHour // 转人工量
          this.option.series[2].data = res.data.conversionRatioByHour // 机器人转人工率
          this.option.xAxis[0].data = res.data.accessTime // X轴 时间显示样式
          this.drawLine()
        })
        this.timer = setInterval(() => {
          getEnterInfo(accessID, businessID).then(res => {
            this.option.series[0].data = res.data.robotAccessCountByHour // 机器人进入量
            this.option.series[1].data = res.data.manualAccessCountByHour // 转人工量
            this.option.series[2].data = res.data.conversionRatioByHour // 机器人转人工率
            this.option.xAxis[0].data = res.data.accessTime // X轴 时间显示样式
            this.drawLine()
          })
        }, 15000)
      },
      drawLine() {
        const myChart = this.$echarts.init(document.getElementById('threshold'))
        myChart.setOption(this.option)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .Wrap {
    padding: 0 23px 14px 23px;
    .title {
      margin: 21px 0;
      font-size: 20px;
      font-weight: 700;
      padding-left: 10px;
      color: #303133;
    }
    .main {
      width: 100%;
      height: 100%;
      padding: 0 30px;
      background: #fff;
      box-shadow: 0 0 5px 2px #d8d6d6;
      .alert {
        display: block;
        padding-top: 24px;
        font-size: 20px;
        color: #3E8DDD;
        text-align: right;
      }
      .explain {
        display: none;
        text-align: right;
        li {
          display:  inline-block;
          margin-left: 50px;
          color: #E4E7ED;
          span {
            display: inline-block;
            width: 12px;
            height: 12px;
            margin-right: 10px;
          }
        }
      }
      .threshold {
        height: 566px;
        margin: 24px 0;
      }
    }
  }
</style>
