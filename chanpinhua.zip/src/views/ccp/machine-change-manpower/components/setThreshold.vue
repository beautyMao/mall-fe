<template>
  <div v-if="list" class="Wrap">
    <p class="title">当前现场：{{ this.$route.query.business }} {{ this.$route.query.access }}</p>
    <el-table :data="list" tooltip-effect="light" :header-cell-style="getRowClass" class="main">
      <el-table-column prop="date" label="日期" />
      <el-table-column prop="week" label="星期" />
      <el-table-column prop="worker_holiday" label="工作日/节假日" />
      <el-table-column prop="robot_into_num" label="机器人进入量" />
      <el-table-column prop="to_person_num" label="转人工量" />
      <el-table-column prop="to_person_rate" label="转人工率" />
    </el-table>
  </div>
</template>

<script>
  import { history } from '@/api/ccp/machine-change-manpowe'
  export default {
    name: 'history',
    data() {
      return {
        list: null
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      getRowClass({ row, column, rowIndex, columnIndex }) { // 设置table 标题背景色
        if (rowIndex === 0) { return 'background:#F0F4FB' } else { return '' }
      },
      init() {
        const accessID = this.$route.query.accessID
        const businessID = this.$route.query.businessID
        history(accessID, businessID).then(res => {
          this.list = res.data
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .Wrap {
    padding: 0 23px;
    .title {
      margin: 21px 0;
      font-size: 20px;
      font-weight: 700;
      padding-left: 10px;
      color: #303133;
    }
    .main {
      width: 100%;
      height: 100%;
      background: #fff;
      border: 1px solid #ccc;
      border-radius:4px;
    }
    .main /deep/ .cell {
      /*height: 36px;*/
      /*line-height: 36px;*/
      text-align: center;
    }
    .main /deep/ th .cell {
      /*height: 36px;*/
      /*line-height: 36px;*/
      color:#303133;
    }
  }
</style>
