<template>
  <!-- 升级单级处理 -->
  <div class="wrapper">
    <h3 style="display:inline-block;margin:0 20px 20px 0">当前现场：{{ businessName }}/{{ accessName }}</h3>
    <el-tabs
      v-model="activeName"
      @tab-click="handleTabClick"
    >
      <el-tab-pane
        label="全国天气监控"
        name="first"
      >
        <el-row :gutter="20">
          <el-col :span="12">
            <div class="legend">
              <el-row :gutter="20">
                <el-col :span="12">
                  <!-- <div class="legendItem" @click="getAllWeather('')">
                      <span class="legend-desc" >全部</span><span class="dot all"></span>
                    </div> -->
                  <div
                    class="legendItem"
                    @click="getRainWeather('rainstorm')"
                  >
                    <span class="legend-desc rain-desc">暴雨</span>
                    <span
                      class="dot"
                      :class="{'singlecolor': !togglerainstorm, 'rainstorm':togglerainstorm }"
                    />
                  </div>
                </el-col>
                <el-col :span="12">
                  <div class="legendItem">
                    <!-- <span class="legend-desc" >暴雨</span><span class="dot rainstorm"></span> -->
                  </div>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="12">
                  <div
                    class="legendItem"
                    @click="getLightingWeather('lightning')"
                  >
                    <span>雷电</span>
                    <span
                      class="dot "
                      :class="{'singlecolor': !togglelightning, 'lightning':togglelightning }"
                    />
                  </div>
                </el-col>
                <el-col :span="12">
                  <div
                    class="legendItem"
                    @click="getSnowWeather('snowstorm')"
                  >
                    <span>暴雪</span>
                    <span
                      class="dot"
                      :class="{'singlecolor': !togglesnowstorm, 'snowstorm':togglesnowstorm }"
                    />
                  </div>
                </el-col>
              </el-row>
              <el-row :gutter="20">
                <el-col :span="12">
                  <div
                    class="legendItem"
                    @click="getFrostWeather('frost')"
                  >
                    <span>结冰</span>
                    <span
                      class="dot "
                      :class="{'singlecolor': !togglefrost, 'frost':togglefrost }"
                    />
                  </div>
                </el-col>
                <el-col :span="12">
                  <div
                    class="legendItem"
                    @click="getColdSpellWeather('cold_spell')"
                  >
                    <span>降温</span>
                    <span
                      class="dot "
                      :class="{'singlecolor': !togglecold_spell, 'cold_spell':togglecold_spell }"
                    />
                  </div>
                </el-col>
              </el-row>
            </div>
            <el-card>
              <div
                id="Weatherhold"
                class="Weatherhold"
              />
            </el-card>
            <!-- <weathermap @popdata="getprovincedata" @popcasedata="getcasedata"></weathermap> -->
          </el-col>
          <el-col :span="12">
            <el-card class="box-card callCard">
              <callPie
                :piedata="piedata"
                :pierange="pierange"
                :clickedprovince="clickedprovince"
                :businessid="businessID"
                :accessid="accessID"
                @cityname="getcityname"
              />
            </el-card>
            <el-card class="box-card">
              <div
                v-if="showCaseTxt"
                class="caseText"
              >
                <div>
                  <span class="boldtxt">{{ clickedCity }}：</span>
                  <span>{{ cityweather }}</span>
                </div>
                <div class="boldtxt">当前：</div>
                <div>省内来电占比：{{ citypercent }}%</div>
                <div>全国来电占比：</div>
                <div class="boldtxt">历史：无</div>
              </div>
              <casePie
                :casedata="casedata"
                :clickedprovince="clickedprovince"
                :businessid="businessID"
                :accessid="accessID"
                :clickedcity="clickedCity"
              />
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
      <el-tab-pane
        label="来电量监控"
        name="second"
      >
        <el-row :gutter="20">
          <el-col :span="12">
            <el-card>
              <callmap
                :calldistribute="calldistribute"
                :callmaprange="callmaprange"
                :businessid="businessID"
                :accessid="accessID"
                @provincecall="getprovincecall"
              />
            </el-card>
          </el-col>
          <el-col :span="12">
            <el-card class="box-card callCard">
              <callprovincepie
                :callprovincedata="callprovincedata"
                :currentprovince="currentprovince"
                :provincerange="provincerange"
                :businessid="businessID"
                :accessid="accessID"
                :showprovincetitle="showprovincetitle"
                @citycasedata="citycasedata"
              />
            </el-card>
            <el-card class="box-card">
              <callcitypie
                :callcitydata="callcitydata"
                :citycaserange="citycaserange"
                :businessid="businessID"
                :accessid="accessID"
              />
            </el-card>
          </el-col>
        </el-row>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
  // import addSolutions from './components/addSolutions'
  import weathermap from './weather'
  import callPie from './callPie'
  import casePie from './callCasePie'
  import callmap from './call/callMap'
  import callprovincepie from './call/callProvincePie'
  import callcitypie from './call/callCityPie'
  import 'echarts/map/js/china.js'
  import {
    getWeatherDistribute,
    getProvinceCallPercent,
    getProvinceCallCasePercent } from '@/api/ccp/pickup'

  import { getCaseClass } from '@/api/ccp/case'
  export default {
    name: 'weather-map',
    components: {
      weathermap,
      callPie,
      casePie,
      callmap,
      callprovincepie,
      callcitypie
    },
    data() {
      return {
        activeName: 'first',
        businessID: '',
        accessID: '',
        businessName: '',
        accessName: '',
        piedata: [],
        casedata: [],
        pierange: [],
        callmaprange: [0, 0],
        callDistribute: [],
        calldistribute: [],
        callprovincedata: [],
        currentprovince: '',
        callcitydata: [],
        provincerange: [0, 0],
        citycaserange: [0, 0],
        weatherdata: [],
        customWeatherData: [],
        customSettings: [],
        range: [0, 1000],
        legendData: [],
        mColor: [],
        provincesCode: [
          {
            code: '01',
            name: '北京'
          },
          {
            code: '02',
            name: '上海'
          },
          {
            code: '03',
            name: '天津'
          },
          {
            code: '04',
            name: '重庆'
          },
          {
            code: '05',
            name: '黑龙江'
          },
          {
            code: '06',
            name: '吉林'
          },
          {
            code: '07',
            name: '辽宁'
          },
          {
            code: '08',
            name: '内蒙古'
          },
          {
            code: '09',
            name: '河北'
          },
          {
            code: '10',
            name: '山西'
          },
          {
            code: '11',
            name: '陕西'
          },
          {
            code: '12',
            name: '山东'
          },
          {
            code: '13',
            name: '新疆'
          },
          {
            code: '14',
            name: '西藏'
          },
          {
            code: '15',
            name: '青海'
          },
          {
            code: '16',
            name: '甘肃'
          },
          {
            code: '17',
            name: '宁夏'
          },
          {
            code: '18',
            name: '河南'
          },
          {
            code: '19',
            name: '江苏'
          },
          {
            code: '20',
            name: '湖北'
          },
          {
            code: '21',
            name: '浙江'
          },
          {
            code: '22',
            name: '安徽'
          },
          {
            code: '23',
            name: '福建'
          },
          {
            code: '24',
            name: '江西'
          },
          {
            code: '25',
            name: '湖南'
          },
          {
            code: '26',
            name: '贵州'
          },
          {
            code: '27',
            name: '四川'
          },
          {
            code: '28',
            name: '广东'
          },
          {
            code: '29',
            name: '云南'
          },
          {
            code: '30',
            name: '广西'
          },
          {
            code: '31',
            name: '海南'
          },
          {
            code: '32',
            name: '云南'
          },
          {
            code: '33',
            name: '澳门'
          },
          {
            code: '34',
            name: '台湾'
          }
        ],
        clickedprovince: '',
        toggleAll: false,
        togglelightning: true,
        togglerainstorm: true,
        togglesnowstorm: true,
        togglefrost: true,
        togglecold_spell: true,
        showCaseTxt: false,
        cityweather: '',
        clickedCity: '',
        citypercent: '',
        cityfromprovince: '',
        showprovincetitle: true
      }
    },
    computed: {
      rainStyle: function() {
        return {

        }
      }
    },
    watch: {
      clickedprovince(newVal, oldVal) {
        if (newVal !== oldVal) {
          this.showCaseTxt = false
          // this.clickedCity = ''
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        console.log(this.$route.query)
        if (this.$route.query) {
          this.businessID = this.$route.query.businessID + ''
          this.accessID = this.$route.query.accessID + ''
          this.businessName = this.$route.query.business
          this.accessName = this.$route.query.access
        }

        const mapdom = document.getElementById('Weatherhold')
        mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
        mapdom.style.height = (document.body.clientHeight - 260) + 'px'
        window.onresize = () => {
          return (() => {
            mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
            mapdom.style.height = (document.body.clientHeight - 260) + 'px'
          })()
        }
        // 获取全国异常天气
        this._getWeatherDistribute('', 0)
        // setInterval(() => {
        //   this._getWeatherDistribute('')
        // }, 10000)
        // 获取全国case
        this.getShowTab()
        this.getInitAllCase()
      })
    },
    methods: {
      getShowTab() {
        if (this.$route.query.type === 'a') {
          this.activeName = 'second'
          const data = {
            businessId: this.businessID,
            accessId: this.accessID,
            cate: 'pro'
          }
          this._getCallDistribute(data)
        } else {
          this.activeName = 'first'
        }
      },
      getInitAllCase() {
        getCaseClass(this.businessID, this.accessID).then(res => {
          // 计算比例
          let sum = 0
          res.data.forEach(ele => {
            sum += Number(ele.value)
          })
          res.data.forEach(ele => {
            ele['percent'] = (ele.value / sum).toFixed(2)
          })
          this.casedata = res.data
          this.clickedcity = '全国'
          // 渲染来电量tab的全国case饼图
          this.callcitydata = res.data
          const dataTemp = res.data
          const sortBy = (field) => {
            return (a, b) => {
              return a[field] - b[field]
            }
          }
          if (dataTemp.length > 0) {
            dataTemp.sort(sortBy('value'))
            this.citycaserange = [dataTemp[0].value, dataTemp[dataTemp.length - 1].value]
          }
        })
      },
      changeWeather(val) {
        // false点过，true未点-要点，初始状态
        if (val.length === 0) {
          if (this.toggleAll) {
            this._getWeatherDistribute('')
          } else {
            const data = {
              cate: val
            }
            this._getWeatherDistribute(data)
          }
        }
        // if (val.length === 0) {
        //   this._getWeatherDistribute('')
        // } else {
        //   const data = {
        //     cate: val
        //   }
        //   this._getWeatherDistribute(data)
        // }
      },
      // 所有天气图例
      getAllWeather(val) {

      },
      // 获取暴雨
      getRainWeather(val) {
        if (this.togglerainstorm) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data, 1)
          this.togglerainstorm = false
        } else {
          this._getWeatherDistribute('', '')
          this.togglerainstorm = true
        }
        this.togglelightning = true
        this.togglesnowstorm = true
        this.togglefrost = true
        this.togglecold_spell = true
      },
      getLightingWeather(val) {
        if (this.togglelightning) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data, 1)
          this.togglelightning = false
        } else {
          this._getWeatherDistribute('', '')
          this.togglelightning = true
        }
        this.togglerainstorm = true
        this.togglesnowstorm = true
        this.togglefrost = true
        this.togglecold_spell = true
      },
      getSnowWeather(val) {
        if (this.togglesnowstorm) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data, 1)
          this.togglesnowstorm = false
        } else {
          this._getWeatherDistribute('', '')
          this.togglesnowstorm = true
        }
        this.togglerainstorm = true
        this.togglelightning = true
        this.togglefrost = true
        this.togglecold_spell = true
      },
      getFrostWeather(val) {
        if (this.togglefrost) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data, 1)
          this.togglefrost = false
        } else {
          this._getWeatherDistribute('', '')
          this.togglefrost = true
        }
        this.togglerainstorm = true
        this.togglelightning = true
        this.togglesnowstorm = true
        this.togglecold_spell = true
      },
      getColdSpellWeather(val) {
        if (this.togglecold_spell) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data, 1)
          this.togglecold_spell = false
        } else {
          this._getWeatherDistribute('', '')
          this.togglecold_spell = true
        }
        this.togglerainstorm = true
        this.togglelightning = true
        this.togglesnowstorm = true
        this.togglefrost = true
      },
      handleTabClick(tab) {
        if (tab.name === 'second') {
          const data = {
            businessId: this.businessID,
            accessId: this.accessID,
            cate: 'pro'
          }
          this._getCallDistribute(data)
        }
        // if (tab.name === 'first') {
        //   this._getWeatherDistribute('', '')
        // }
      },
      getprovincedata(data, range) {
        const a = []
        data.forEach(ele => {
          ele['value'] = ele.count
          a.push(ele)
        })
        this.piedata = a
        this.pierange = range
      },
      getcasedata(data) {
        const a = []
        data.forEach(ele => {
          ele['value'] = ele.count
          a.push(ele)
        })
        this.casedata = a
      },
      // 获取全国各省来电量分布
      _getCallDistribute(data) {
        getProvinceCallPercent(data).then(res => {
          const a = []
          if (res.data.province.length > 0) {
            res.data.province.forEach(ele => {
              ele['value'] = ele.count
              a.push(ele)
            })
            const dataTemp = res.data.province
            const sortBy = (field) => {
              return (a, b) => {
                return a[field] - b[field]
              }
            }
            dataTemp.sort(sortBy('count'))
            if (dataTemp.length < 2) {
              if (dataTemp.length === 1) {
                this.callmaprange = [0, dataTemp[dataTemp.length - 1].count]
              }
            } else {
              this.callmaprange = [dataTemp[0].count, dataTemp[dataTemp.length - 1].count]
            }
          }
          this.calldistribute = a
          // 初始化时，全国各省来电量饼图绘制
          this.callprovincedata = a
          this.provincerange = this.callmaprange
          this.showprovincetitle = true
          // 缺少全国case占比接口，待做
        }).catch(err => { console.error(err) })
      },
      // 点击某省获取该省下的来电量分布
      getprovincecall(data, province) {
        const a = []
        if (data.length > 0) {
          data.forEach(ele => {
            ele['value'] = ele.percent
            a.push(ele)
          })
          const dataTemp = data
          const sortBy = (field) => {
            return (a, b) => {
              return a[field] - b[field]
            }
          }
          dataTemp.sort(sortBy('count'))
          this.provincerange = [dataTemp[0].count, dataTemp[dataTemp.length - 1].count]
        }
        this.showprovincetitle = false
        this.callprovincedata = a
        this.currentprovince = province
      },
      citycasedata(data, citycaserange) {
        this.callcitydata = data
        this.citycaserange = citycaserange
      },
      // 获取天气
      _getWeatherDistribute(data, type) {
        this.customWeatherData = []
        getWeatherDistribute(data).then(res => {
          // res.data = [
          //   {
          //     province_code: '01',
          //     province: '北京',
          //     warning: [
          //       {
          //         area: '北京',
          //         cate: 'rainstorm',
          //         signal: '暴雨',
          //         level: '01'
          //       }
          //     ]
          //   },
          //   {
          //     province_code: '02',
          //     province: '上海',
          //     warning: [
          //       {
          //         area: '上海',
          //         cate: 'lightning',
          //         signal: '雷电',
          //         level: '01'
          //       }
          //     ]
          //   },
          //   {
          //     province_code: '05',
          //     province: '黑龙江',
          //     warning: [
          //       {
          //         area: '大庆',
          //         cate: 'snowstorm',
          //         signal: '暴雪',
          //         level: '01'
          //       }
          //     ]
          //   },
          //   {
          //     province_code: '12',
          //     province: '山东',
          //     warning: [
          //       {
          //         area: '山东',
          //         cate: 'cold_spell',
          //         signal: '降温',
          //         level: '01'
          //       }
          //     ]
          //   }
          // ]
          this.weatherdata = res.data
          let color = ''
          const provinceGroup = []
          this.weatherdata.forEach(ele => {
            provinceGroup.push(ele.province_code)
            const weathers = new Set()
            if (ele.warning.length > 0) {
              ele.warning.forEach(inner => {
                weathers.add(inner.signal)
              })
            }
            switch (ele.warning[0].cate) {
            case 'snowstorm':
              color = '#D1E8FF'
              break
            case 'rainstorm':
              color = '#63ABED'
              break
            case 'lightning':
              color = '#FFCC00'
              break
            case 'frost':
              color = '#B3D9FF'
              break
            case 'cold_spell':
              color = '#BDC6DF'
              break
            }
            this.customWeatherData.push({
              name: ele.province,
              value: ele.warning,
              weathers: Array.from(weathers),
              itemStyle: {
                normal: {
                  color: color,
                  label: {
                    show: true,
                    textStyle: {
                      color: '#fff',
                      fontSize: 12
                    }
                  }
                },
                emphasis: {// 也是选中样式
                  borderWidth: 1,
                  borderColor: '#ccc',
                  areaColor: '#cd5c5c',
                  label: {
                    show: true,
                    textStyle: {
                      color: 'blue'
                    }
                  }
                }
              }
            })
          })
          this.drawPie()
          // 单击单一天气，如果返回一个省，则请求该省内各城市当天的来电量占比
          if (type === 1) {
            if (res.data.length === 1) {
              const parameter = {
                businessId: this.businessID,
                accessId: this.accessID,
                cate: 'pre',
                code: res.data[0].province_code
              }
              this.clickedprovince = res.data[0].province
              this._getProvinceCallPercent(parameter)
            }
          }
          // type 0 ，则为初始化时查询全国各省来电量
          if (type === 0) {
            // 获取全国各省来电量
            const data = {
              businessId: this.businessID,
              accessId: this.accessID,
              cate: 'pro'
            }
            if (provinceGroup.length > 0) {
              data['code'] = provinceGroup.join(';')
            }
            getProvinceCallPercent(data).then(res => {
              const a = []
              if (res.data.length > 0) {
                res.data.forEach(ele => {
                  ele['value'] = ele.percent
                  a.push(ele)
                })
              }
              this.piedata = a
            }).catch(err => { console.error(err) })
          }
        }).catch(err => { console.error(err) })
      },
      drawPie() {
        const myChart = this.$echarts.init(document.getElementById('Weatherhold'))
        myChart.setOption({
          tooltip: {
            trigger: 'item',
            confine: true,
            formatter: function(params) {
              let a = ''
              if (params.data) {
                params.data.value.forEach(ele => {
                  a = a + ele.area + ':' + ele.signal + '<br/>'
                })
                return a
              }
            }
          },
          series:
            [
              {
                name: '',
                type: 'map',
                mapType: 'china',
                selectedMode: 'multiple',
                showLegendSymbol: false,
                // top: '20px',
                // left: '10%',
                layoutCenter: ['30%', '10%'],
                label: {
                  normal: {
                    show: true,
                    textStyle: {
                      fontSize: 8,
                      fontWeight: 'normal',
                      color: '#1A1919'
                    }
                  },
                  emphasis: {
                    show: true
                  }
                },
                itemStyle: {
                  normal: {
                    label: { show: true },
                    borderWidth: 1, // 省份的边框宽度
                    borderColor: '#ccc', // 省份的边框颜色
                    areaColor: '#fff', // 地图背景颜色
                    areaStyle: { color: 'orange' }// 设置地图颜色
                  },
                  emphasis: { label: { show: true }}
                },
                data: this.customWeatherData
              }
            ]
        })
        // echart图表自适应
        window.addEventListener('resize', function() {
          myChart.resize()
        })
        const self = this
        myChart.on('click', function(params) {
          if (params.name.length > 0) {
            const clickObj = self.provincesCode.find((clickObj) => {
              return clickObj.name === params.name
            })
            const data = {
              businessId: self.businessID,
              accessId: self.accessID,
              cate: 'pre',
              code: clickObj.code
            }
            const dataforcase = {
              businessId: self.businessID,
              accessId: self.accessID,
              province: params.name,
              prefecture: ''
            }
            self.clickedprovince = params.name
            self.clickedCity = params.name
            // console.log('self.clickedCity', self.clickedprovince, self.clickedCity)
            self._getProvinceCallPercent(data)
            self._getProvinceCallCasePercent(dataforcase)
          }
        })
      },
      _getProvinceCallPercent(data) {
        getProvinceCallPercent(data).then(res => {
          // res.data = [
          //   {
          //     name: '伊春', //	String	名称
          //     count: 5, //	Number	数量
          //     percent: 30 //	Number	占比
          //   },
          //   {
          //     name: '大庆', //	String	名称
          //     count: 10, //	Number	数量
          //     percent: 70 //	Number	占比
          //   }
          // ]
          if (res.data.length > 0) {
            res.data.forEach(ele => {
              ele['value'] = ele.percent
            })
          }
          this.piedata = res.data
          this.pierange = this.range
          // this.$emit('popdata', res.data, this.range)
        }).catch(err => {
          console.error(err)
        })
      },
      _getProvinceCallCasePercent(data) {
        getProvinceCallCasePercent(data).then(res => {
          // this.$emit('popcasedata', res.data)
          // res.data = [
          //   {
          //     name: '伊春', //	String	名称
          //     count: 5, //	Number	数量
          //     percent: 30 //	Number	占比
          //   },
          //   {
          //     name: '大庆', //	String	名称
          //     count: 10, //	Number	数量
          //     percent: 70 //	Number	占比
          //   }
          // ]
          if (res.data.length > 0) {
            res.data.forEach(ele => {
              ele['value'] = ele.percent
            })
          }
          this.casedata = res.data
        }).catch(err => {
          console.error(err)
        })
      },
      // 点击省内城市来电量饼图，右下饼图切换为点击市的case分类，且出现tips
      getcityname(city, percent) {
        // cityweather
        // this.clickedCity = ''
        this.clickedCity = city
        const tempProvince = this.weatherdata.find((tempProvince) => {
          return tempProvince.province === this.clickedprovince
        })
        let a = {}
        // || Object.keys(tempProvince).length > 0
        if (tempProvince !== undefined) {
          tempProvince.warning.forEach(ele => {
            if (ele.area.includes(city)) {
              a = ele
            }
          })
          this.cityweather = a.signal
          this.showCaseTxt = true
          this.citypercent = percent
          const dataforcase = {
            businessId: this.businessID,
            accessId: this.accessID
          }
          const municipality = ['北京', '上海', '天津', '重庆']
          if (municipality.indexOf(this.clickedprovince) > -1) {
            dataforcase['province'] = this.clickedprovince
          } else {
            dataforcase['province'] = this.clickedprovince
            dataforcase['prefecture'] = city
          }
          this._getProvinceCallCasePercent(dataforcase)
          // 下饼图切换为城市时，tips显示城市天气
          const tipObj = this.customWeatherData.find(tipObj => {
            return tipObj.name === this.clickedprovince
          })
          if (municipality.indexOf(this.clickedprovince) > -1) {
            this.cityweather = tipObj.value[0].signal
          } else {
            const tipcityObj = tipObj.value.find(tipcityObj => {
              return tipcityObj.area === this.clickedCity
            })
            if (tipcityObj !== undefined) {
              this.cityweather = tipcityObj.signal
            }
          }
        } else {
          // 没有点击地图的省，初始化后直接点击上饼图的省，请求该省内城市case，渲染下饼图
          const dataforcase = {
            businessId: this.businessID,
            accessId: this.accessID,
            province: city
          }
          this._getProvinceCallCasePercent(dataforcase)
        }
      }
    }
  }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
  // @import "./common.scss";
  .wrapper {
    padding: 20px;
    /deep/ .el-card__body {
      padding: 10px !important;
    }
    h3 {
      color: #303133;
      font-size: 18px;
      font-weight: 700;
      margin: 0;
      margin-bottom: 20px;
    }
    /deep/ .el-tabs__header {
      margin: 0 !important;
    }
    .callCard {
      margin-bottom: 20px !important;
    }
    .el-tab-pane {
      // border: 1px solid #ccc;
      margin-top: 20px;
      .item {
        float: left;
        width: 48%;
        .left {
          margin-right: 10px;
        }
      }
    }
    .legend {
      position: absolute;
      bottom: 10px;
      left: 40px;
      width: 216px;
      height: 100px;
      z-index: 999;
      .legendItem {
        font-size: 14px;
        cursor: pointer;
        margin-bottom: 12px;
        .lengend-desc {
          display: inline-block;
          margin-right: 5px;
          font-size: 14px !important;
          float: left;
        }
      }
      .dot {
        display: inline-block;
        width: 50px;
        height: 14px;
        float: right;
      }
      .singlecolor {
        background: #c2c2c2;
      }
      .rainstorm {
        background: #63abed;
      }
      .rainstorm:hover {
        background: #74b8f6;
      }
      .lightning {
        background: #ffcc00;
      }
      .lightning:hover {
        background: #ffe82c;
      }
      .snowstorm {
        background: #d1e8ff;
      }
      .snowstorm:hover {
        background: #e0efff;
      }
      .frost {
        background: #b3d9ff;
      }
      .frost:hover {
        background: #d8ebff;
      }
      .cold_spell {
        background: #bdc6df;
      }
      .cold_spell:hover {
        background: #d8e0f6;
      }
      .all {
        background: #000;
      }
    }
    .caseText {
      position: absolute;
      right: 0;
      bottom: 0;
      width: 140px;
      font-size: 14px;
      div {
        margin-bottom: 4px;
      }
      .boldtxt {
        font-weight: bold;
      }
    }
  }
</style>
