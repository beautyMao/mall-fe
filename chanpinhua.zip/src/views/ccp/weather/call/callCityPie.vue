<template>
  <!-- 城市case分类 -->
  <div
    id="citycasePie"
    class="Weatherhold"
    :style="{width: '600px', height: '200px'}"
  />
</template>

<script>
// import addSolutions from './components/addSolutions'
  import echarts from 'echarts'
  export default {
    name: 'callcitypie',
    props: {
      callcitydata: {
        type: Array,
        default: () => []
      },
      citycaserange: {
        type: Array,
        default: () => []
      },
      businessid: {
        type: String,
        default: ''
      },
      accessid: {
        type: String,
        default: ''
      }
    },
    data() {
      return {
      }
    },
    watch: {
      callcitydata(newVal, oldVal) {
        this.drawPie()
      }
    },
    //   components: {
    //     addSolutions
    //   },
    mounted() {
      this.$nextTick(() => {
        const mapdom = document.getElementById('citycasePie')
        mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
        mapdom.style.height = ((document.body.clientHeight - 320) / 2) + 'px'
        window.addEventListener('resize', () => {
          mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
          mapdom.style.height = ((document.body.clientHeight - 320) / 2) + 'px'
        })
      })
    },
    methods: {
      drawPie() {
        this.iChart = echarts.init(document.getElementById('citycasePie'))
        this.iChart.setOption({
          title: {
            text: '问题分类',
            subtext: '',
            textStyle: {// 标题字体风格
              color: '#303133',
              fontStyle: 'normal',
              fontWeight: 'bold',
              fontFamily: 'sans-serif',
              fontSize: 16
            },
            x: 'center'
          },
          tooltip: {
            trigger: 'item',
            confine: true,
            formatter: function(params) {
              return params.name
            }
          },
          center: ['50%', '60%'],
          legend: {
            orient: 'vertical',
            x: 'left',
            data: ['1', '2', '3', '4', '5']
          },
          visualMap: {
            show: false,
            min: this.citycaserange[0],
            max: this.citycaserange[1],
            left: 20,
            bottom: 10,
            text: ['High', 'Low'], // 文本，默认为数值文本
            color: ['#3E8DDD', '#E0EDFA'],
            calculable: false
          },
          series: [
            {
              name: 'case分类',
              type: 'pie',
              radius: ['30%', '65%'],
              center: ['50%', '60%'],
              avoidLabelOverlap: false,
              formatter: '{a|{a}}{abg|}\n{hr|}\n  {b|{b}：}{c}  {per|{d}%}  ',
              data: this.callcitydata,
              labelLine: {
                normal: {
                  length: 5, // 改变标示线的长度
                  lineStyle: {
                    color: '#303133' // 改变标示线的颜色
                  }

                }
              },
              label: {
                normal: {
                  textStyle: {
                    color: '#303133' // 改变标示文字的颜色
                  },
                  formatter: function(params) {
                    return params.name + ':' + params.percent + '%'
                  }
                }
              },
              itemStyle: {
                normal: {
                  label: {
                    show: true,
                    formatter: '{b} : {c}%'
                  },
                  labelLine: { show: true }
                }
              }
            }
          ]
        })
      // window.addEventListener('resize', function() {
      //   myChart.resize()
      // })
      //   const self = this
      //   this.iChart.on('click', function(params) {
      //     // const clickObj = self.provincesCode.find((clickObj) => {
      //     //   return clickObj.name === params.name
      //     // })
      //     // const data = { code: clickObj.code }
      //     // self._getProvinceCallPercent(data)
      //     self._getProvinceCallCasePercent(self.currentprovince, params.name)
      //   })
      }
    }
  }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
// @import "./common.scss";
.wrapper {
  padding: 20px;
  h3 {
    color: #303133;
    font-size: 18px;
    font-weight: 700;
    margin: 0;
    margin-bottom: 20px;
  }
  .queryContent {
    background: #fff;
    border: 1px solid #ccc;
    margin-top: 20px;
  }
  .pager {
    text-align: right;
    margin-top: 50px;
    margin-bottom: 20px;
  }
}
</style>
