<template>
  <div
    id="CallMap"
    class="Weatherhold"
    :style="{width: '600px', height: '400px'}"
  />
</template>
<script>
  import Vue from 'vue'
  import echarts from 'echarts'
  import 'echarts/map/js/china.js'
  import {
    getProvinceCallPercent } from '@/api/ccp/pickup'
  Vue.prototype.$echarts = echarts
  export default {
    name: 'call-map',
    props: {
      calldistribute: {
        type: Array,
        default: () => [{
          code: '01',
          name: '北京',
          value: 0
        }]
      },
      callmaprange: {
        type: Array,
        default: () => []
      },
      accessid: {
        type: String,
        default: ''
      },
      businessid: {
        type: String,
        default: ''
      }
    },
    data() {
      return {
        weatherdata: [],
        customWeatherData: [],
        customSettings: [],
        currentprovince: '',
        // range: [0, 0],
        provincesCode: [
          {
            code: '01',
            name: '北京'
          },
          {
            code: '02',
            name: '上海'
          },
          {
            code: '03',
            name: '天津'
          },
          {
            code: '04',
            name: '重庆'
          },
          {
            code: '05',
            name: '黑龙江'
          },
          {
            code: '06',
            name: '吉林'
          },
          {
            code: '07',
            name: '辽宁'
          },
          {
            code: '08',
            name: '内蒙古'
          },
          {
            code: '09',
            name: '河北'
          },
          {
            code: '10',
            name: '山西'
          },
          {
            code: '11',
            name: '陕西'
          },
          {
            code: '12',
            name: '山东'
          },
          {
            code: '13',
            name: '新疆'
          },
          {
            code: '14',
            name: '西藏'
          },
          {
            code: '15',
            name: '青海'
          },
          {
            code: '16',
            name: '甘肃'
          },
          {
            code: '17',
            name: '宁夏'
          },
          {
            code: '18',
            name: '河南'
          },
          {
            code: '19',
            name: '江苏'
          },
          {
            code: '20',
            name: '湖北'
          },
          {
            code: '21',
            name: '浙江'
          },
          {
            code: '22',
            name: '安徽'
          },
          {
            code: '23',
            name: '福建'
          },
          {
            code: '24',
            name: '江西'
          },
          {
            code: '25',
            name: '湖南'
          },
          {
            code: '26',
            name: '贵州'
          },
          {
            code: '27',
            name: '四川'
          },
          {
            code: '28',
            name: '广东'
          },
          {
            code: '29',
            name: '云南'
          },
          {
            code: '30',
            name: '广西'
          },
          {
            code: '31',
            name: '海南'
          },
          {
            code: '32',
            name: '云南'
          },
          {
            code: '33',
            name: '澳门'
          },
          {
            code: '34',
            name: '台湾'
          }
        ]
      }
    },
    watch: {
      calldistribute(newVal, oldVal) {
        if (newVal) {
          this.drawPie()
        }
      }
    },
    mounted() {
      this.$nextTick(() => {
        const mapdom = document.getElementById('CallMap')
        mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
        mapdom.style.height = (document.body.clientHeight - 260) + 'px'
        window.addEventListener('resize', () => {
          mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
          mapdom.style.height = (document.body.clientHeight - 260) + 'px'
        })
      })
    },
    methods: {
      drawPie() {
        const myChart = this.$echarts.init(document.getElementById('CallMap'))
        // myChart.setOption(this.option)
        myChart.setOption({
          tooltip: {
            trigger: 'item',
            formatter: function(params) {
              if (params.name.length > 0) {
                return params.name + '：' + '来电量' + params.data.count
              }
            }
          },
          // legend: {
          //   data: [
          //     { name: '台风', textStyle: { color: '#4AC0E0' }}, // 设置图例文字颜色
          //     { name: '雷电', textStyle: { color: '#FFCC00' }},
          //     { name: '暴雨', textStyle: { color: '#63ABED' }},
          //     { name: '雾霾', textStyle: { color: '#BDC6DF' }},
          //     { name: '暴雪', textStyle: { color: '#D1E8FF' }},
          //     { name: '沙尘', textStyle: { color: '#AF8761' }}
          //   ],
          //   orient: 'vertical',
          //   top: 'bottom',
          //   left: 'right'
          // },
          visualMap: {
            min: this.callmaprange[0],
            max: this.callmaprange[1],
            left: 20,
            bottom: 10,
            text: ['High', 'Low'], // 文本，默认为数值文本
            color: ['#3E8DDD', '#E0EDFA'],
            calculable: true
          },
          series: [
            {
              name: '',
              type: 'map',
              mapType: 'china',
              layoutCenter: ['30%', '10%'],
              selectedMode: 'multiple',
              label: {
                normal: {
                  show: true,
                  textStyle: {
                    fontSize: 8,
                    fontWeight: 'normal',
                    color: '#1A1919'
                  }
                },
                emphasis: {
                  show: true
                }
              },
              itemStyle: {
                normal: {
                  label: { show: true },
                  borderWidth: 1, // 省份的边框宽度
                  borderColor: '#ccc', // 省份的边框颜色
                  areaColor: '#fff' // 地图背景颜色
                },
                emphasis: { label: { show: true }}
              },
              data: this.calldistribute
            }
          ]
        })
        window.addEventListener('resize', function() {
          myChart.resize()
        })
        const self = this
        myChart.on('click', function(params) {
          console.log('热力图', params)
          if (params.name.length > 0) {
            self.currentprovince = params.name
            const clickObj = self.provincesCode.find((clickObj) => {
              return clickObj.name === params.name
            })
            const data = {
              businessId: self.businessid,
              accessId: self.accessid,
              cate: 'pre',
              code: clickObj.code
            }
            self._getProvinceCallPercent(data)
          }
        })
      },
      _getProvinceCallPercent(data) {
        getProvinceCallPercent(data).then(res => {
          // res.data = [
          //   {
          //     code: 1, // 可选	String	省份编码(仅限于按省份拆分时)
          //     name: 'aa',	// String	名称
          //     count: 5, //	Number	数量
          //     percent: 11	// Numbe
          //   },
          //   {
          //     code: 2, // 可选	String	省份编码(仅限于按省份拆分时)
          //     name: 'bb',	// String	名称
          //     count: 10, //	Number	数量
          //     percent: 12	// Numbe
          //   },
          //   {
          //     code: 3, // 可选	String	省份编码(仅限于按省份拆分时)
          //     name: 'cc',	// String	名称
          //     count: 12, //	Number	数量
          //     percent: 13	// Numbe
          //   },
          //   {
          //     code: 4, // 可选	String	省份编码(仅限于按省份拆分时)
          //     name: 'dd',	// String	名称
          //     count: 13, //	Number	数量
          //     percent: 14	// Numbe
          //   },
          //   {
          //     code: 5, // 可选	String	省份编码(仅限于按省份拆分时)
          //     name: 'ee',	// String	名称
          //     count: 14, //	Number	数量
          //     percent: 15	// Numbe
          //   }
          // ]     // res.data = [
          //   {
          //     code: 1, // 可选	String	省份编码(仅限于按省份拆分时)
          //     name: 'aa',	// String	名称
          //     count: 5, //	Number	数量
          //     percent: 11	// Numbe
          //   },
          //   {
          //     code: 2, // 可选	String	省份编码(仅限于按省份拆分时)
          //     name: 'bb',	// String	名称
          //     count: 10, //	Number	数量
          //     percent: 12	// Numbe
          //   },
          //   {
          //     code: 3, // 可选	String	省份编码(仅限于按省份拆分时)
          //     name: 'cc',	// String	名称
          //     count: 12, //	Number	数量
          //     percent: 13	// Numbe
          //   },
          //   {
          //     code: 4, // 可选	String	省份编码(仅限于按省份拆分时)
          //     name: 'dd',	// String	名称
          //     count: 13, //	Number	数量
          //     percent: 14	// Numbe
          //   },
          //   {
          //     code: 5, // 可选	String	省份编码(仅限于按省份拆分时)
          //     name: 'ee',	// String	名称
          //     count: 14, //	Number	数量
          //     percent: 15	// Numbe
          //   }
          // ]
          if (res.data.length > 0) {
            res.data.forEach(ele => {
              ele['value'] = ele.percent
            })
          }
          this.$emit('provincecall', res.data, this.currentprovince)
        }).catch(err => {
          console.error(err)
        })
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  h2 {
    padding: 0;
    font-weight: 600;
    font-size: 24px;
    line-height: 24px;
    color: #303133;
    margin: 12px auto;
    width: 95%;
  }
  .caseBox {
    width: 98%;
    height: 100%;
    background: #fff;
    margin: 0 auto;
    border: 1px solid #dcdfe6;
  }
  .el-button--primary.is-plain {
    width: 150px;
    font-size: 14px;
  }
  .elbox {
    text-align: center;
    margin-top: 20px;
  }
</style>
