<template>
  <div id="provincePie" class="Weatherhold" />
</template>
<script>
// import addSolutions from './components/addSolutions'
  import { getProvinceCallCasePercent } from '@/api/ccp/pickup'
  import echarts from 'echarts'
  export default {
    name: 'callprovincepie',
    props: {
      callprovincedata: {
        type: Array,
        default: () => []
      },
      provincerange: {
        type: Array,
        default: () => []
      },
      currentprovince: {
        type: String,
        default: ''
      },
      accessid: {
        type: String,
        default: ''
      },
      businessid: {
        type: String,
        default: ''
      },
      showprovincetitle: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        caserange: [0, 0]
      }
    },
    watch: {
      callprovincedata(newVal, oldVal) {
        if (newVal) {
          this.drawPie()
        }
      }
    },
    //   components: {
    //     addSolutions
    //   },
    mounted() {
      this.$nextTick(() => {
        const mapdom = document.getElementById('provincePie')
        mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
        mapdom.style.height = ((document.body.clientHeight - 280) / 2) + 'px'
        window.addEventListener('resize', () => {
          mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
          mapdom.style.height = ((document.body.clientHeight - 280) / 2) + 'px'
        })
      })
    },
    methods: {
      drawPie() {
        this.iChart = echarts.init(document.getElementById('provincePie'))
        this.iChart.setOption({
          title: {
            text: this.showprovincetitle ? '全国各省来电量占比' : '城市来电占比',
            // text: '',
            subtext: '',
            textStyle: {// 标题字体风格
              color: '#303133',
              fontStyle: 'normal',
              fontWeight: 'bold',
              fontFamily: 'sans-serif',
              fontSize: 16
            },
            x: 'center'
          },
          center: ['50%', '60%'],
          tooltip: {
            trigger: 'item',
            formatter: function(params) {
              if (params.name.length > 0) {
                return params.name + '：' + '来电量' + params.data.count
              }
            }
          },
          legend: {
            orient: 'vertical',
            x: 'left',
            data: ['1', '2', '3', '4', '5']
          },
          visualMap: {
            show: false,
            min: this.provincerange[0],
            max: this.provincerange[1],
            left: 20,
            bottom: 10,
            text: ['High', 'Low'], // 文本，默认为数值文本
            color: ['#3E8DDD', '#E0EDFA'],
            calculable: false
          },
          series: [
            {
              name: '',
              type: 'pie',
              radius: ['30%', '65%'],
              center: ['50%', '60%'],
              avoidLabelOverlap: false,
              formatter: '{a|{a}}{abg|}\n{hr|}\n  {b|{b}：}{c}  {per|{d}%}  ',
              data: this.callprovincedata,
              labelLine: {
                normal: {
                  show: false,
                  length: 25, // 改变标示线的长度
                  lineStyle: {
                    color: '#303133' // 改变标示线的颜色
                  }
                }
              },
              label: {
                normal: {
                  show: false,
                  textStyle: {
                    color: '#303133' // 改变标示文字的颜色
                  }
                }
              },
              itemStyle: {
                normal: {
                  label: {
                    show: true,
                    formatter: '{b} : {c}%'
                  },
                  labelLine: { show: true }
                }
              }
            }
          ]
        })
        // window.addEventListener('resize', function() {
        //   this.iChart.resize()
        // })
        const self = this
        self.iChart.on('click', function(params) {
          console.log('params', params)
          console.log(self.currentprovince)
          const data = {
            businessId: self.businessid,
            accessId: self.accessid
          }
          if (self.currentprovince) {
            const municipality = ['北京', '天津', '重庆', '上海']
            if (municipality.indexOf(self.currentprovince) > -1) {
              data['province'] = params.name
            } else {
              data['province'] = self.currentprovince
              data['prefecture'] = params.name
            }
          } else {
            data['province'] = params.name
          }
          self._getProvinceCallCasePercent(data)
        })
      },
      _getProvinceCallCasePercent(data) {
        getProvinceCallCasePercent(data).then(res => {
          if (res.data.length > 0) {
            res.data.forEach(ele => {
              ele['value'] = ele.percent
            })
            const dataTemp = res.data
            const sortBy = (field) => {
              return (a, b) => {
                return a[field] - b[field]
              }
            }
            dataTemp.sort(sortBy('count'))
            this.caserange = [dataTemp[0].count, dataTemp[dataTemp.length - 1].count]
          }
          console.log('res.data', res.data)
          this.$emit('citycasedata', res.data, this.caserange)
        }).catch(err => {
          console.error(err)
        })
      }
    }
  }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
// @import "./common.scss";
.wrapper {
  padding: 20px;
  h3 {
    color: #303133;
    font-size: 18px;
    font-weight: 700;
    margin: 0;
    margin-bottom: 20px;
  }
  .queryContent {
    background: #fff;
    border: 1px solid #ccc;
    margin-top: 20px;
  }
  .pager {
    text-align: right;
    margin-top: 50px;
    margin-bottom: 20px;
  }
}
</style>
