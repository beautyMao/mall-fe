<template>
  <div id="Weatherhold" class="Weatherhold" :style="{width: '600px', height: '400px'}" />
</template>
<script>
  import Vue from 'vue'
  import echarts from 'echarts'
  import 'echarts/map/js/china.js'
  import {
    getWeatherDistribute,
    getProvinceCallPercent,
    getProvinceCallCasePercent } from '@/api/ccp/pickup'
  Vue.prototype.$echarts = echarts
  export default {
    name: 'weather',
    // props: {
    //   weatherdata: null
    // },
    data() {
      return {
        weatherdata: [],
        customWeatherData: [],
        customSettings: [],
        range: [0, 1000],
        legendData: [],
        mColor: [],
        provincesCode: [
          {
            code: '01',
            name: '北京'
          },
          {
            code: '02',
            name: '上海'
          },
          {
            code: '03',
            name: '天津'
          },
          {
            code: '04',
            name: '重庆'
          },
          {
            code: '05',
            name: '黑龙江'
          },
          {
            code: '06',
            name: '吉林'
          },
          {
            code: '07',
            name: '辽宁'
          },
          {
            code: '08',
            name: '内蒙古'
          },
          {
            code: '09',
            name: '河北'
          },
          {
            code: '10',
            name: '山西'
          },
          {
            code: '11',
            name: '陕西'
          },
          {
            code: '12',
            name: '山东'
          },
          {
            code: '13',
            name: '新疆'
          },
          {
            code: '14',
            name: '西藏'
          },
          {
            code: '15',
            name: '青海'
          },
          {
            code: '16',
            name: '甘肃'
          },
          {
            code: '17',
            name: '宁夏'
          },
          {
            code: '18',
            name: '河南'
          },
          {
            code: '19',
            name: '江苏'
          },
          {
            code: '20',
            name: '湖北'
          },
          {
            code: '21',
            name: '浙江'
          },
          {
            code: '22',
            name: '安徽'
          },
          {
            code: '23',
            name: '福建'
          },
          {
            code: '24',
            name: '江西'
          },
          {
            code: '25',
            name: '湖南'
          },
          {
            code: '26',
            name: '贵州'
          },
          {
            code: '27',
            name: '四川'
          },
          {
            code: '28',
            name: '广东'
          },
          {
            code: '29',
            name: '云南'
          },
          {
            code: '30',
            name: '广西'
          },
          {
            code: '31',
            name: '海南'
          },
          {
            code: '32',
            name: '云南'
          },
          {
            code: '33',
            name: '澳门'
          },
          {
            code: '34',
            name: '台湾'
          }
        ],
        obj_rainstorm: {},
        obj_lightning: {},
        obj_snowstorm: {},
        obj_cold_spell: {},
        obj_frost: {}

      }
    },
    mounted() {
      this.$nextTick(() => {
        this._getWeatherDistribute('')
      })
    },
    methods: {
      // 获取天气
      _getWeatherDistribute(data) {
        getWeatherDistribute(data).then(res => {
          // this.weatherdata = res.data
          const weatherTemp = res.data
          // const color = ''
          // res.data.forEach(ele => {
          //   switch (ele.warning[0].cate) {
          //     case 'snowstorm':
          //       color = '#63ABED'
          //       break
          //     case 'rainstorm':
          //       color = '#63ABED'
          //       break
          //     case 'lightning':
          //       color = '#FFCC00'
          //       break
          //     case 'frost':
          //       color = '#D1E8FF'
          //       break
          //     case 'cold_spell':
          //       color = '#BDC6DF'
          //       break
          //   }
          //   weatherTemp.push({
          //     name: ele.province,
          //     value: ele.warning,
          //     itemStyle: {
          //       normal: {
          //         color: color,
          //         label: {
          //           show: true,
          //           textStyle: {
          //             color: '#fff',
          //             fontSize: 15
          //           }
          //         }
          //       },
          //       emphasis: {// 也是选中样式
          //         borderWidth: 1,
          //         borderColor: '#ccc',
          //         areaColor: '#cd5c5c',
          //         label: {
          //           show: true,
          //           textStyle: {
          //             color: 'blue'
          //           }
          //         }
          //       }
          //     }
          //   })
          // })
          this.obj_rainstorm = {
            name: 'rainstorm',
            type: 'map',
            mapType: 'china',
            showLegendSymbol: true,
            roam: false,
            label: { normal: { show: true },
                     emphasis: { show: true }
            },
            data: []
          }
          this.obj_lightning = {
            name: 'lightning',
            type: 'map',
            mapType: 'china',
            showLegendSymbol: true,
            roam: false,
            label: { normal: { show: true },
                     emphasis: { show: true }
            },
            data: []
          }
          this.obj_snowstorm = {
            name: 'snowstorm',
            type: 'map',
            mapType: 'china',
            showLegendSymbol: true,
            roam: false,
            label: { normal: { show: true },
                     emphasis: { show: true }
            },
            data: []
          }
          this.obj_cold_spell = {
            name: 'cold_spell',
            type: 'map',
            mapType: 'china',
            showLegendSymbol: true,
            roam: false,
            label: { normal: { show: true },
                     emphasis: { show: true }
            },
            data: []
          }
          this.obj_frost = {
            name: 'frost',
            type: 'map',
            mapType: 'china',
            showLegendSymbol: true,
            roam: false,
            label: { normal: { show: true },
                     emphasis: { show: true }
            },
            data: []
          }
          weatherTemp.forEach(ele => {
            ele['name'] = ele.province
            const rainObj = ele.warning.find((rainObj) => {
              return rainObj.cate === 'rainstorm'
            })
            if (rainObj) {
              ele['value'] = Number(rainObj.level)
              this.obj_rainstorm.data.push(ele)
            }
            const lightObj = ele.warning.find((lightObj) => {
              return lightObj.cate === 'lightning'
            })
            if (lightObj) {
              ele['value'] = Number(lightObj.level)
              this.obj_lightning.data.push(ele)
            }
            const snowObj = ele.warning.find((snowObj) => {
              return snowObj.cate === 'snowstorm'
            })
            if (snowObj) {
              ele['value'] = Number(snowObj.level)
              this.obj_snowstorm.data.push(ele)
            }
            const coldspellObj = ele.warning.find((coldspellObj) => {
              return coldspellObj.cate === 'cold_spell'
            })
            if (coldspellObj) {
              ele['value'] = Number(coldspellObj.level)
              this.obj_cold_spell.data.push(ele)
            }
            const frostObj = ele.warning.find((frostObj) => {
              return frostObj.cate === 'frost'
            })
            if (frostObj) {
              ele['value'] = Number(frostObj.level)
              this.obj_frost.data.push(ele)
            }
          })
          // 设置图例
          if (this.obj_rainstorm.data.length > 0) {
            this.legendData.push({ name: 'rainstorm', textStyle: { color: '#606266' }})
            this.mColor.push('#63ABED')
            this.weatherdata.push(this.obj_rainstorm)
          }
          if (this.obj_lightning.data.length > 0) {
            this.legendData.push({ name: 'lightning', textStyle: { color: '#606266' }})
            this.mColor.push('#FFCC00')
            this.weatherdata.push(this.obj_lightning)
          }
          if (this.obj_snowstorm.data.length > 0) {
            this.legendData.push({ name: 'snowstorm', textStyle: { color: '#606266' }})
            this.mColor.push('#D1E8FF')
            this.weatherdata.push(this.obj_snowstorm)
          }
          if (this.obj_cold_spell.data.length > 0) {
            this.legendData.push({ name: 'cold_spell', textStyle: { color: '#606266' }})
            this.mColor.push('#BDC6DF')
            this.weatherdata.push(this.obj_cold_spell)
          }
          if (this.obj_frost.data.length > 0) {
            this.legendData.push({ name: 'frost', textStyle: { color: '#606266' }})
            this.mColor.push('#B3D9FF')
            this.weatherdata.push(this.obj_frost)
          }
          console.log('legendData', this.legendData)
          console.log('weatherdata', this.weatherdata)
          this.drawPie()
          // echart图表自适应
        // window.addEventListener("resize", function() {
        //     mapBoxEchart.resize();
        // });
        }).catch(err => { console.error(err) })
      },
      drawPie() {
        const myChart = this.$echarts.init(document.getElementById('Weatherhold'))
        myChart.setOption({
          tooltip: {
            trigger: 'item',
            formatter: function(params) {
            }
          },
          geo: {
            map: 'china',
            roam: true,
            label: {
              normal: {
                show: true,
                textStyle: {
                  color: 'rgba(0,0,0,0.4)'
                }
              }
            },
            itemStyle: {
              normal: {
                borderColor: 'rgba(0, 0, 0, 0.2)'
              },
              emphasis: {
                areaColor: null,
                shadowOffsetX: 0,
                shadowOffsetY: 0,
                shadowBlur: 20,
                borderWidth: 0,
                shadowColor: 'rgba(0, 0, 0, 0.5)'
              }
            }
          },
          visualMap: {
            min: 0,
            max: 5,
            left: 'left',
            top: 'bottom',
            text: ['高', '低'], // 文本，默认为数值文本
            calculable: true
          },
          color: this.mColor,
          // ['#63ABED', '#FFCC00', '#D1E8FF', '#BDC6DF', '#4AC0E0']
          legend: {
            orient: 'vertical',
            left: 'left',
            data: this.legendData
            // selectedMode: 'single'
            // [
            //   { name: 'rainstorm', textStyle: { color: '#606266' }},
            //   { name: 'lightning', textStyle: { color: '#606266' }},
            //   { name: 'snowstorm', textStyle: { color: '#606266' }},
            //   { name: 'frost', textStyle: { color: '#606266' }},
            //   { name: 'cold_spell', textStyle: { color: '#606266' }}]
          },
          // series: []
          series: this.weatherdata
          // [
          //   {
          //     name: '',
          //     type: 'map',
          //     mapType: 'china',
          //     selectedMode: 'multiple',
          //     label: {
          //       normal: {
          //         show: true
          //       },
          //       emphasis: {
          //         show: true
          //       }
          //     },
          //     itemStyle: {
          //       normal: {
          //         label: { show: true },
          //         borderWidth: 1, // 省份的边框宽度
          //         borderColor: '#777776', // 省份的边框颜色
          //         color: '#fff'// 地图背景颜色
          //       // areaStyle:{color:'#f60'}//设置地图颜色
          //       },
          //       emphasis: { label: { show: true }}
          //     },
          //     data: this.customWeatherData
          //   }
          // ]
        })
        const self = this
        myChart.on('click', function(params) {
          console.log('params', params)
          const clickObj = self.provincesCode.find((clickObj) => {
            return clickObj.name === params.name
          })
          const data = {
            businessId: 16,
            accessId: 1,
            code: clickObj.code
          }
          const dataforcase = {
            businessId: 16,
            accessId: 1,
            province: params.name,
            prefecture: ''
          }
          self._getProvinceCallPercent(data)
          self._getProvinceCallCasePercent(dataforcase)
        })
        // 图例开关的行为只会触发 legendselectchanged 事件
        myChart.on('legendselectchanged', function(params) {
          // 获取点击图例的选中状态
          var isSelected = params.selected[params.name]
          // 在控制台中打印
          console.log((isSelected ? '选中了' : '取消选中了') + '图例' + params.name)
          // 打印所有图例的状态
          console.log(params.selected)
          console.log('this.obj_rainstorm', self.obj_rainstorm)
          console.log(self.weatherdata)
          // self.drawPie()
        })
      },
      _getProvinceCallPercent(data) {
        getProvinceCallPercent(data).then(res => {
          if (res.data.length > 0) {
            const dataTemp = res.data
            const sortBy = (field) => {
              return (a, b) => {
                return a[field] - b[field]
              }
            }
            dataTemp.sort(sortBy('count'))
            this.range = [dataTemp[0].count, dataTemp[dataTemp.length - 1].count]
          }
          this.$emit('popdata', res.data, this.range)
        }).catch(err => {
          console.error(err)
        })
      },
      _getProvinceCallCasePercent(data) {
        getProvinceCallCasePercent(data).then(res => {
          this.$emit('popcasedata', res.data)
        }).catch(err => {
          console.error(err)
        })
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  h2{
    padding: 0;
    font-weight:600;
    font-size: 24px;
    line-height: 24px;
    color: #303133;
    margin: 12px auto;
    width:95%;
  }
  .caseBox{
    width:98%;
    height:100%;
    background: #fff;
    margin: 0 auto;
    border: 1px solid #DCDFE6;
  }
  .el-button--primary.is-plain{
    width:150px;
    font-size: 14px;
  }
  .elbox{ text-align: center; margin-top: 20px; }
</style>
