<template>
  <!-- 显示全国各省用户来电 -->
  <div id="provinceCall" />
</template>

<script>
  import echarts from 'echarts'
  require('echarts/theme/macarons')
  // import {
  //   getProvinceCallCasePercent } from '@/api/ccp/pickup'
  export default {
    name: 'call-pie',
    props: {
      piedata: {
        type: Array,
        default: () => []
      },
      pierange: {
        type: Array,
        default: () => []
      },
      businessid: {
        type: String,
        default: ''
      },
      clickedprovince: {
        type: String,
        default: ''
      },
      accessid: {
        type: String,
        default: ''
      }
    },
    data() {
      return {
      }
    },
    watch: {
      piedata(newVal, oldVal) {
        if (newVal) {
          this.drawPie()
        }
      }
    },
    //   components: {
    //     addSolutions
    //   },
    mounted() {
      this.$nextTick(() => {
        const mapdom = document.getElementById('provinceCall')
        mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
        mapdom.style.height = ((document.body.clientHeight - 280) / 2) + 'px'
        window.addEventListener('resize', () => {
          mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
          mapdom.style.height = ((document.body.clientHeight - 280) / 2) + 'px'
        // if (this.iChart !== undefined) {
        //   window.addEventListener('resize', function() {
        //     console.log('resize', this.iChart)
        //     this.iChart.resize()
        //   })
        // }
        })
      })
    },
    methods: {
      drawPie() {
        this.iChart = echarts.init(document.getElementById('provinceCall'), 'macarons')
        this.iChart.setOption({
          title: {
            // text: '',
            text: this.clickedprovince.length > 0 ? this.clickedprovince + '：各城市当前来电占比' : '全国各省来电量占比',
            subtext: '',
            textStyle: {// 标题字体风格
              color: '#303133',
              fontStyle: 'normal',
              fontWeight: 'bold',
              fontFamily: 'sans-serif',
              fontSize: 16
            },
            x: 'center'
          },
          tooltip: {
            trigger: 'item',
            formatter: function(params) {
              if (params.name.length > 0) {
                return params.name + '：' + '来电量' + params.data.count
              }
            }
          },
          center: ['50%', '50%'],
          legend: {
            orient: 'vertical',
            x: 'left',
            data: ['1', '2', '3', '4', '5']
          },
          series: [
            {
              name: '',
              type: 'pie',
              radius: ['30%', '65%'],
              center: ['50%', '60%'],
              avoidLabelOverlap: false,
              formatter: '{a|{a}}{abg|}\n{hr|}\n  {b|{b}：}{c}  {per|{d}%}  ',
              data: this.piedata,
              labelLine: {
                normal: {
                  show: false,
                  length: 35, // 改变标示线的长度
                  lineStyle: {
                    color: '#303133' // 改变标示线的颜色
                  }
                }
              },
              label: {
                normal: {
                  show: false,
                  textStyle: {
                    color: '#303133' // 改变标示文字的颜色
                  }
                }
              },
              itemStyle: {
                normal: {
                  label: {
                    show: true,
                    formatter: '{b} : {c}%'
                  },
                  labelLine: { show: true }
                }
              }
            }
          ]
        })

        const self = this
        self.iChart.on('click', function(params) {
          console.log('天气上饼图', params)
          self.$emit('cityname', params.name, params.percent)
        })
      }
    }
  }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
// @import "./common.scss";
.wrapper {
  padding: 20px;
  h3 {
    color: #303133;
    font-size: 18px;
    font-weight: 700;
    margin: 0;
    margin-bottom: 20px;
  }
  .queryContent {
    background: #fff;
    border: 1px solid #ccc;
    margin-top: 20px;
  }
  .pager {
    text-align: right;
    margin-top: 50px;
    margin-bottom: 20px;
  }
}
</style>
