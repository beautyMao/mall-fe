<template>
  <!-- 升级单级处理 -->
  <div id="caseCall" />
</template>

<script>
  import echarts from 'echarts'
  require('echarts/theme/macarons')
  export default {
    name: 'call-pie',
    props: {
      casedata: {
        type: Array,
        default: () => []
      },
      clickedprovince: {
        type: String,
        default: ''
      },
      businessid: {
        type: String,
        default: ''
      },
      accessid: {
        type: String,
        default: ''
      },
      clickedcity: {
        type: String,
        default: '全国'
      }
    },
    data() {
      return {
      }
    },
    //   components: {
    //     addSolutions
    //   },
    watch: {
      casedata(newVal, oldVal) {
        if (newVal) {
          this.drawCasePie()
        }
      },
      clickedcity(newVal, oldVal) {
        console.log('组件内clickedcity', newVal)
      }
    },
    mounted() {
      this.$nextTick(() => {
        const mapdom = document.getElementById('caseCall')
        mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
        mapdom.style.height = ((document.body.clientHeight - 320) / 2) + 'px'
        window.addEventListener('resize', () => {
          mapdom.style.width = (window.innerWidth - 220) * 0.5 + 'px'
          mapdom.style.height = ((document.body.clientHeight - 320) / 2) + 'px'
        //  if(this.iChart !== undefined) {
        //     this.iChart.resize()
        //  }
        })
      // if(this.iChart !== undefined) {
      //   window.addEventListener('resize', function() {
      //     this.iChart.resize()
      //   })
      // }
      })
    },
    methods: {
      drawCasePie() {
        this.iChart = echarts.init(document.getElementById('caseCall'), 'macarons')
        this.iChart.setOption({
          title: {
            text: this.clickedcity.length > 0 ? this.clickedcity + '：来电问题分类占比' : '全国来电问题分类占比',
            subtext: '',
            textStyle: {// 标题字体风格
              color: '#303133',
              fontStyle: 'normal',
              fontWeight: 'bold',
              fontFamily: 'sans-serif',
              fontSize: 16
            },
            x: 'center'
          },
          center: ['50%', '60%'],
          tooltip: {
            trigger: 'item',
            confine: true,
            formatter: function(params) {
              return params.name
            }
          },
          legend: {
            orient: 'vertical',
            x: 'left',
            data: ['1', '2', '3', '4', '5']
          },
          series: [
            {
              name: '问题分类占比',
              type: 'pie',
              radius: ['30%', '65%'],
              center: ['50%', '60%'],
              avoidLabelOverlap: false,
              formatter: '{a|{a}}{abg|}\n{hr|}\n  {b|{b}：}{c}  {per|{d}%}  ',
              data: this.casedata,
              labelLine: {
                normal: {
                  length: 5, // 改变标示线的长度
                  lineStyle: {
                    color: '#303133' // 改变标示线的颜色
                  }
                }
              },
              label: {
                normal: {
                  textStyle: {
                    color: '#303133' // 改变标示文字的颜色
                  },
                  formatter: function(params) {
                    return params.name + ':' + params.percent + '%'
                  }
                }
              },
              itemStyle: {
                normal: {
                  label: {
                    show: true,
                    formatter: '{b} : {c}%'
                  },
                  labelLine: { show: true }
                }
              }
            }
          ]
        })
      }
    }
  }
</script>

<style scoped rel="stylesheet/scss" lang="scss">
// @import "./common.scss";
.wrapper {
  padding: 20px;
  h3 {
    color: #303133;
    font-size: 18px;
    font-weight: 700;
    margin: 0;
    margin-bottom: 20px;
  }
  .queryContent {
    background: #fff;
    border: 1px solid #ccc;
    margin-top: 20px;
  }
  .pager {
    text-align: right;
    margin-top: 50px;
    margin-bottom: 20px;
  }
}
</style>
