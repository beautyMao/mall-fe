<template>
  <div class="forecast-box">
    <div class="top-title clearfix">
      <p class="operates">
        <a href="https://driverdl.lenovo.com.cn/ioccube/业务量日预测模板.xlsx">模板下载</a>&nbsp;&nbsp;&nbsp;
        <el-upload
          class="upload-demo"
          :action="action"
          :headers="headers"
          :file-list="fileList"
          :on-change="handleChange"
        >
          <a href="javascript:void(0)">浏览上传</a>
        </el-upload>
      </p>
      <p style="color:#303133;font-size: 24px;font-weight: bold;margin:0 auto;">当前现场：{{ businessName }} {{ accessName }}</p>
    </div>
    <div class="scroll-box">
      <el-table :data="tableData">
        <el-table-column
          label="时段"
          class="red"
        >
          <template slot-scope="scope">{{ scope.row.begin_time.substr(0,5) }}-{{ scope.row.over_time.substr(0,5) }}</template>
        </el-table-column>
        <el-table-column
          label="系统预测值"
          prop="system_predicted_num"
        />
        <el-table-column
          label="时段累计值"
          prop="system_predicted_sum_num"
        />
        <el-table-column
          label="实际来电"
          prop="section_num_into"
        />
        <el-table-column
          label="实际累计值"
          prop="count_num_into"
        />
        <el-table-column label="人工校准值">
          <template slot-scope="scope">
            <!--<div v-if="scope.$index>disableIndex">-->
            <div>
              <el-input
                v-if="scope.row.operateTxt=='保存'"
                v-model="scope.row.manual_calibrator_num"
                class="inline-block"
                :data-index="scope.$index"
                @focus="inputfocus"
              />
              <span
                v-else
                class="inline-block"
              >{{ scope.row.manual_calibrator_num }}</span>
              <!-- <a class="a-edit" href="javascript:void(0)" @click="clickOperateTxt(scope.$index)">{{scope.row.operateTxt}}</a> -->
            </div>
            <!--<div v-else>{{scope.row.manual_calibrator_num}}</div>-->
          </template>
        </el-table-column>
        <el-table-column
          label="差值"
          prop="diff_num"
        />
        <!--<el-table-column label="系统自动校准" prop="auto_calibrator_num"></el-table-column>-->
        <el-table-column
          width="100"
          label="操作"
        >
          <template slot-scope="scope">
            <!--<div v-if="scope.$index>disableIndex">-->
            <div>
              <a
                class="a-edit"
                href="javascript:void(0)"
                @click="clickOperateTxt(scope.$index)"
              >{{ scope.row.operateTxt }}</a>
            </div>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <!-- <div class="clearfix">
        <el-button class="btn" type="primary" @click="handleSaveEdit">确认修改</el-button>
      </div> -->
  </div>
</template>
<script>
  import * as fetch from '@/api/devccp/usercall-management/index'
  import Moment from 'moment'
  import { getToken } from '@/utils/auth'
  import { getQueryString } from '@/utils/index'
  export default {
    data() {
      return {
        accessName: getQueryString('access'),
        businessName: getQueryString('business'),
        access: getQueryString('accessID'),
        business: getQueryString('businessID'),
        fileList: [],
        tableData: [],
        disableIndex: -1,
        action: `/api/ccmc/intoNum/guess/excel/import?access=${getQueryString('accessID')}&business=${getQueryString('businessID')}&date=${getQueryString('date')}`,
        headers: {
          Authorization: `Bearer ${getToken()}`
        }
      }
    },
    mounted() {
      this.fetchDetail(this.$route.params.id)
    },
    methods: {
      // 时段预测电量 修改
      handleSaveEdit() {
      // console.log('save-', this.tableData)
      },
      inputfocus(eve) {
      // console.log('input--', eve.target)
      },
      handleChange(file, fileList) {
        this.fileList = fileList
        if (file.response) {
          if (file.response.statusCode === 200) {
            this.$message({
              type: 'success',
              message: '浏览上传成功',
              duration: 2000
            })
            this.fetchDetail(this.$route.params.id)
          } else {
            this.$message({
              type: 'error',
              message: file.response.message.info,
              duration: 2000
            })
          }
        }
      },
      clickOperateTxt(index) {
        if (this.tableData[index].operateTxt === '编辑') {
          this.tableData[index].operateTxt = '保存'
        } else {
          const record = this.tableData[index]
          this.fetchEdit({ id: record.id, calibrator: record.manual_calibrator_num, access: this.access, business: this.business }, index)
        }
      },
      async fetchDetail(id) {
        const callsData = await fetch.userCallDetail({ sort: '正', mode: 'nowTime', access: this.access, business: this.business })
        const nowDataLength = callsData.data.length
        this.disableIndex = nowDataLength - 1 // 初始禁止编辑项
        fetch.fetchPredictiveCaliListByTime({ id, access: this.access, business: this.business }).then(res => {
          if (res.statusCode === 200 && res.data && res.data.length > 0) {
            // 判断如果日期晚于今天以前的，都不可编辑
            const today = Moment().format('YYYY-MM-DD')
            const resDate = res.data[0].date
            if (Moment(resDate) < Moment(today)) {
              this.disableIndex = res.data.length - 1
            } else if (Moment(resDate) > Moment(today)) {
              this.disableIndex = -1
            }
            res.data && res.data.map((item, index) => {
              item.operateTxt = '编辑'
            })
            this.tableData = res.data
          }
        })
      },
      fetchEdit(data, index) {
        fetch.fetchEditPredictiveCall(data).then(res => {
          if (res.statusCode === 200) {
            this.$message({
              type: 'success',
              message: '编辑成功',
              duration: 2000
            })
            this.tableData[index].operateTxt = '编辑'
            this.fetchDetail(this.$route.params.id)
          }
        })
      }
    }
  }
</script>
<style lang='scss' ref="stylesheet/scss">
$trHeadColor: #f0f4fb;
$tableheadcolor: #303133;
$tablecontentcolor: #606266;
.clearfix:after {
  display: table;
  content: '';
  clear: both;
}
.clearfix {
  *zoom: 1;
}
.forecast-box {
  padding: 20px;
  .top-title {
    margin-bottom: 16px;
    margin-top: 4px;
  }
  .operates {
    float: right;
    margin-top: 0px;
    margin-bottom: 0px;
    .upload-demo {
      display: inline-block;
      .el-upload-list {
        display: none;
      }
    }
    a {
      font-size: 20px;
      color: #4a90e2;
    }
  }
  .scroll-box {
    width: 100%;
    border: 1px solid rgba(204, 204, 204, 1);
    max-height: 500px;
    overflow-y: auto;
    .el-table th {
      color: $tableheadcolor !important;
      background-color: $trHeadColor !important;
    }
    .el-table .cell {
      text-align: center;
    }
    .el-table__header th:first-child .cell,
    .el-table__body tr td:first-child .cell {
      text-align: left;
      padding-left: 20px;
    }
    .el-table__header th:nth-last-child(2) .cell,
    .el-table__body tr td:last-child .cell {
      text-align: right;
      padding-right: 20px;
    }
    .el-table__body td {
      color: $tablecontentcolor !important;
    }
    .el-table__body tr:hover > td {
      background-color: #e5f2ff !important;
    }
    .inline-block {
      /*width: 50%;*/
    }
    .a-edit {
      color: #4a90e2;
    }
  }
  .btn {
    margin-top: 20px;
    float: right;
  }
}
</style>
