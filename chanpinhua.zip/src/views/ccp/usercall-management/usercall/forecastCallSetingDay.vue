<template>
  <div class="forecast-box">
    <div clss="title clearfix">
      <p class="operates">
        <a href="https://driverdl.lenovo.com.cn/ioccube/%E4%B8%9A%E5%8A%A1%E9%87%8F%E9%A2%84%E6%B5%8B%E6%A8%A1%E6%9D%BF.xlsx">模板下载</a>&nbsp;&nbsp;&nbsp;
        <el-upload
          class="upload-demo"
          :action="action"
          :headers="headers"
          :file-list="fileList"
          :on-change="handleChangedoc"
        >
          <a href="javascript:void(0)">浏览上传</a>
        </el-upload>
      </p>
      <!-- <p>当前现场：{{businessName}} {{accessName}}</p> -->

      <!-- 现场选择 -->
      <div class="sel-actions">
        <el-cascader ref="a" v-model="scene" :options="options" :show-all-levels="true" placeholder="现场选择" size="medium" @change="handleChange" />
      </div>

    </div>
    <div class="scroll-box">
      <el-table :data="tableData" @row-click="showDayDetail">
        <el-table-column label="年" prop="year" />
        <el-table-column label="月" prop="month" />
        <el-table-column label="日" prop="day" />
        <el-table-column label="星期" prop="week" />
        <el-table-column label="法定节假日" prop="worker_holiday" />
        <el-table-column label="电商节" width="180">
          <template slot-scope="scope">
            <div>
              <el-input v-if="scope.row.operateTxt=='保存'" v-model="scope.row.sales_holiday" :data-index="scope.$index" />
              <span v-else>{{ scope.row.sales_holiday }}</span>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="系统预测值" prop="system_predicted_num" />
        <el-table-column width="180" label="人工校准值">
          <template slot-scope="scope">
            <el-input v-if="scope.row.operateTxt=='保存'" v-model="scope.row.manual_calibrator_num" class="inline-block" :data-index="scope.$index" />
            <span v-else class="inline-block">{{ scope.row.manual_calibrator_num }}</span>
            <!--  <a v-if="scope.row.date>today" class="a-edit" href="javascript:void(0)" @click="clickOperateTxt(scope.$index)">{{scope.row.operateTxt}}</a> -->
          </template>
        </el-table-column>
        <el-table-column width="100" label="操作">
          <template slot-scope="scope">
            <!--<a v-if="scope.row.date>today" class="a-edit" href="javascript:void(0)" @click="clickOperateTxt(scope.$index)">{{scope.row.operateTxt}}</a>-->
            <a class="a-edit" href="javascript:void(0)" @click="clickOperateTxt(scope.$index)">{{ scope.row.operateTxt }}</a>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
  import * as fetch from '@/api/devccp/usercall-management/index'
  import { getQueryString } from '@/utils/index'
  import { getToken } from '@/utils/auth'
  import { forecastCallDay } from '@/api/devccp/link'
  import { EngineerLocales } from '@/api/devccp/index'
  import debounce from 'throttle-debounce/debounce'
  export default {
    beforeRouteEnter: debounce(200, forecastCallDay),
    beforeRouteUpdate: debounce(200, forecastCallDay),
    data() {
      return {
        options: [], // 现场选择
        scene: [Number(this.$route.query.businessID), Number(this.$route.query.accessID)],
        accessName: getQueryString('access'),
        businessName: getQueryString('business'),
        access: getQueryString('accessID'),
        business: getQueryString('businessID'),
        tableData: [],
        disableIndex: -1,
        today: '',
        fileList: [],
        action: `/api/ccmc/intoNum/guess/excel/importTemplet?access=${Number(this.$route.query.accessID)}&business=${Number(this.$route.query.businessID)}`,
        headers: {
          Authorization: `Bearer ${getToken()}`
        }
      }
    },
    watch: {
      access() {
        this.action = `/api/ccmc/intoNum/guess/excel/importTemplet?access=${this.access}&business=${this.business}`
      }
    },
    mounted() {
      this.getEngineer()
      this.fetchDetail()
      this.getTodayStr()
    },
    methods: {
      // 现场选择现场
      getEngineer() {
        EngineerLocales(this.$route.query.businessID, this.$route.query.accessID).then(response => {
          var item = response.data
          for (const i in item) {
            const childrenList = []
            for (const j in item[i].children) {
              if (item[i].children[j].power === 2) {
                childrenList.push(item[i].children[j])
              }
            }
            if (childrenList.length > 0) {
              this.options.push({
                'value': item[i].value,
                'label': item[i].label,
                'children': childrenList
              })
            }
          }
        })
      },
      // 通路切换
      handleChange(value) {
        this.business = value[0]
        this.access = value[1]
        this.businessName = this.$refs.a.currentLabels[0]
        this.accessName = this.$refs.a.currentLabels[1]
        // console.log('选择的值', value)
        this.fetchDetail()
      },
      getTodayStr() {
        // 获取当前日期
        const date = new Date()
        const month = (date.getMonth() + 1) > 9 ? date.getMonth() + 1 : '0' + (date.getMonth() + 1)
        const day = date.getDate() > 9 ? date.getDate() : '0' + date.getDate()
        const dateStr = date.getFullYear() + '-' + month + '-' + day
        this.today = dateStr
      },
      clickOperateTxt(index) {
        if (this.tableData[index].operateTxt === '编辑') {
          this.tableData[index].operateTxt = '保存'
        } else {
          const record = this.tableData[index]
          const { id, manual_calibrator_num, worker_holiday, sales_holiday } = record
          this.fetchEdit({ id, calibrator: manual_calibrator_num, worker_holiday, sales_holiday, access: this.access, business: this.business }, index)
        }
        const evt = window.event
        evt.stopPropagation ? evt.stopPropagation() : evt.cancelBubble = true
      },
      fetchDetail() {
        fetch.fetchPredictiveCaliList({ access: this.access, business: this.business }).then(res => {
          if (res.statusCode === 200) {
            res.data && res.data.map((item, index) => {
              item.operateTxt = '编辑'
            })
            this.tableData = res.data
          }
        })
      },
      fetchEdit(data, index) {
        fetch.fetchEditPredictiveCallDay(data).then(res => {
          if (res.statusCode === 200) {
            this.$message({
              type: 'success',
              message: '编辑成功',
              duration: 2000
            })
            this.tableData[index].operateTxt = '编辑'
          }
        })
      },
      showDayDetail(row) {
        if (row.operateTxt !== '保存') {
          this.$router.push({
            path: `/devccp-management/forecastCall/${row.id}`,
            query: {
              businessID: this.business,
              business: this.businessName,
              accessID: this.access,
              access: this.accessName,
              date: row.date
            }
          })
        }
      },
      // 浏览上传
      handleChangedoc(file, fileList) {
        this.fileList = fileList
        if (file.response) {
          if (file.response.statusCode === 200) {
            this.$message({
              type: 'success',
              message: '浏览上传成功',
              duration: 2000
            })
            this.fetchDetail()
          } else {
            this.$message({
              type: 'error',
              message: file.response.message.info,
              duration: 2000
            })
          }
        }
      }
    }
  }
</script>
<style lang='scss' ref="stylesheet/scss">
$trHeadColor: #F0F4FB;
$tableheadcolor: #303133;
$tablecontentcolor: #606266;
.clearfix:after {
  display: table;
  content: "";
  clear: both;
}
.clearfix{*zoom:1;}

.forecast-box{
  padding: 20px;
  .title{
    clear: both;
  }
  .sel-actions{
    margin-top: 3px;
    margin-bottom:16px;
  }
  .operates{
    float: right;
    margin-top: 15px;
    margin-bottom: 0px;
    .upload-demo{
      display: inline-block;
      .el-upload-list{
        display: none;
      }
    }
    a{
      color: #4A90E2;
      font-size: 20px;
    }
  }
  .scroll-box{
    width:100%;
    border: 1px solid rgba(204,204,204,1);
    max-height: 500px;
    overflow-y: auto;
    .el-table .cell{
      text-align: center;
    }
    .el-table__header th:first-child .cell,.el-table__body tr td:first-child .cell{
      text-align: left;
      padding-left: 20px;
    }
    .el-table__header th:nth-last-child(2) .cell,.el-table__body tr td:last-child .cell{
      text-align: right;
      padding-right: 20px;
    }
    .el-table th{
      color: $tableheadcolor !important;
      background-color: $trHeadColor !important;
    }
    .el-table__body td{
      color: $tablecontentcolor !important;
    }
    .el-table__body tr:hover>td{
      background-color: #E5F2FF !important;
    }
    .inline-block{
      width: 70%;
    }
    .a-edit{
      color: #4A90E2;
    }
  }
  .btn{
    margin-top: 20px;
    float: right;
  }
}
</style>
