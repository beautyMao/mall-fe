<template>
  <div>
    <h2 class="top-title">当前现场：{{ businessName }} {{ accessName }}</h2>
    <div id="chart" class="line-chart" :style="{height:'500px'}" />
  </div>
</template>
<script>
  import echarts from 'echarts'
  import { getIntervalData } from '@/api/ccp/index'
  export default {
    name: 'line-chart',
    data() {
      return {
        accessName: this.$route.query.access,
        businessName: this.$route.query.business,
        access: this.$route.query.accessID,
        business: this.$route.query.businessID,
        timer: null,
        option: {
          color: ['#2295FF', '#DAF0FF'],
          title: {
            // text: '时段服务明细'
          },
          tooltip: {
            trigger: 'axis',
            formatter: '{b} <br/>{a} : {c} <br/> {a1} : {c1}%',
            backgroundColor: '#1890FF',
            axisPointer: {
              type: 'cross',
              label: {
                backgroundColor: '#6a7985'
              }
            }
          },
          legend: {
            type: 'plain',
            top: '5%',
            left: '38%',
            data: [{
              name: '时段服务量'
            }, {
              name: '放弃率',
              icon: 'rect',
              itemWidth: '10',
              itemHeight: '5'
            }],
            textStyle: {
              color: 'rgba(0,0,0,0.45)',
              fontSize: 10
            },
            // itemGap: 45,
            // itemWidth: 30,
            symbolKeepAspect: false
          },
          grid: {
            left: '6%',
            right: '6%',
            bottom: '1%',
            containLabel: true
          },
          xAxis: [
            {
              type: 'category',
              data: ['0:00', '4:00', '8:00', '12:00', '16:00', '20:00', '24:00'],
              axisLine: {
                onZero: false,
                lineStyle: {
                  color: '#2295FF'
                }
              },
              axisPointer: {
                type: 'shadow'
              }
            }
          ],
          yAxis: [
            {
              type: 'value',
              name: '时段服务量',
              axisLabel: {
                formatter: '{value}' // 刻度标签的内容格式器
              }
            },
            {
              type: 'value',
              name: '放弃率',
              splitLine: {
                show: false
              },
              axisLabel: {
                formatter: '{value} %'
              }
            }
          ],
          series: [
            {
              name: '时段服务量',
              type: 'line',
              smooth: true,
              symbolSize: 10,
              sampling: 'average', // 是否平滑曲线显示
              lineStyle: {
                normal: {
                  color: '#2295FF',
                  width: 2
                }
              },
              data: []
            },
            {
              name: '放弃率',
              type: 'line',
              smooth: true,
              symbol: 'none', // 是否显示小圆点  默认不写
              sampling: 'average', // 是否平滑曲线显示
              lineStyle: {
                normal: {
                  color: '#2FC25B',
                  width: 0
                }
              },
              // 填充色
              areaStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                  offset: 0,
                  color: '#DAF0FF'
                }])
              },
              yAxisIndex: 1,
              data: []
            }
          ]
        }
      }
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    mounted() {
      this._getIntervalData()
      clearInterval(this.timer)
      this.timer = setInterval(this._getIntervalData, 15000)
    },
    methods: {
      _getIntervalData() {
        this.option.series[0].data = []
        this.option.series[1].data = []
        this.option.xAxis[0].data = []
        getIntervalData(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          res.data.map((k) => {
            this.option.xAxis[0].data.push(k.begin_time)
            this.option.series[0].data.push(k.section_num_into)
            this.option.series[1].data.push(k.section_abandon_rate)
          })
          this.showChart()
        })
      },
      showChart() {
        this.chart = echarts.init(document.getElementById('chart'))
        this.chart.setOption(this.option)
      }
    }
  }
</script>
<style lang="scss" scoped>
.chart {
  position: relative;
}
.top-title {
  margin-left: 30px;
}
.getInfo {
  color:#1990ff;
  width: 100%;
  position: absolute;
  left: 0;
  bottom: -5px;
  text-align: center;
  font-size: 12px;
  span {
    cursor: pointer;
  }
}
.count {
  margin-left: 50px;
  .num {
    font-size: 18px;
    color: #FF8060;
  }
}
</style>

