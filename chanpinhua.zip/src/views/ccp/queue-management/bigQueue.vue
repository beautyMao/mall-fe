<template>
  <div ref="Wrap" class="Wrap">
    <header>当前现场：{{ businessName }} {{ accessName }}</header>
    <div class="main" style="padding-bottom: 0 !important">
      <div class="title">
        <!--<span style="display:inline-block;float:left">排队数量：</span>-->
        <!--<span-->
        <!--v-if="queues_num || queues_num === 0"-->
        <!--style="display:inline-block;float:left"-->
        <!--&gt;个人队列：{{ queues_num }} 个</span>-->
        <!--<span style="display:inline-block;float:left">大队列：{{ this.bigqueues_num }} 个</span>-->
        <p
          class="btn"
          style="display:inline-block;float:right"
        >
          <!--<a>阈值设置</a>-->
          <a @click="handleDownloadClick">下载表单</a>
        </p>
      </div>
      <el-table
        style="width: 100%"
        height="200px"
        tooltip-effect="light"
        border
        :data="tableData"
        class="tab"
        :header-cell-style="getRowClass"
      >
        <el-table-column
          prop="queue_name"
          label="队列名称"
          min-width="120"
        />
        <el-table-column
          prop="queue_num"
          label="当前排队数量"
          width="130"
          sortable
        />
        <!--<el-table-column prop="big_queue" label="大队列排队量" width="130" sortable></el-table-column>-->
        <!--<el-table-column prop="person_queue" label="个人队列排队量" width="140" sortable></el-table-column>-->
        <el-table-column
          prop="num_abandon_30min"
          label="半小时放弃量"
          width="130"
          sortable
        />
        <el-table-column
          prop="num_into"
          label="进入量"
          min-width="90"
          sortable
        />
        <el-table-column
          prop="num_pick_up_30s"
          label="30s内接起量"
          width="130"
          sortable
        />
        <el-table-column
          prop="num_abandon"
          label="放弃量"
          min-width="90"
          sortable
        />
        <el-table-column
          prop="abandon_rate"
          label="放弃率"
          min-width="90"
          sortable
        />
        <el-table-column
          prop="service_rate"
          label="服务水平"
          width="100"
          sortable
        />
        <el-table-column
          prop="avg_wait_time"
          label="平均等待时长"
          width="130"
          sortable
        />
      </el-table>
    </div>
    <el-select v-model="list" multiple collapse-tags placeholder="筛选条件" class="select" @change="handleListChange">
      <div class="CheckAll">
        <el-checkbox v-model="checkAll" style="display: flex; justify-content: space-between;" :indeterminate="isIndeterminate" @change="handleCheckAllChange">
          全选
        </el-checkbox>
      </div>
      <el-option v-for="item of group" :key="item" :label="item" :value="item">
        <el-checkbox-group v-model="checkedCities" style="margin-top: 7px;" @change="handleCheckedCitiesChange">
          <el-checkbox :label="item" style="display: flex; justify-content: space-between;">{{ item }}</el-checkbox>
        </el-checkbox-group>
      </el-option>
    </el-select>
    <el-scrollbar style="height: 380px;margin-top: 20px;">
      <div
        v-for="(i, index) of rows"
        ref="viewBox"
        :key="i.group"
        class="my-table"
      >
        <p>{{ i.group_name }}</p>
        <MyTableList
          :sort-change="i.result"
          :sort-key="index"
          :statu-type="statuType"
          @sortchange="schange"
        />
      </div>
    </el-scrollbar>
  </div>
</template>
<script>
  import { getQueueInfo, getDownloadFrom, getEngionFrom } from '@/api/ccp/queue-management'
  import { QueuesDate } from '@/api/ccp/index'
  import MyTableList from '../components/MyTableList'
  export default {
    name: 'big-queue',
    components: {
      MyTableList
    },
    data() {
      return {
        Data: [],
        tableData: [],
        tableData1: [],
        tableData2: [],
        list: [],
        rows: [],
        group: [],
        statuType: 1,
        typeShow: false,
        listData: [],
        Datalist: [],
        Datalist1: [],
        status_set: ['', '就绪', '小休', '挂起', '离线'],
        position_set: ['aha', 'CSR', 'Team Leader', 'Tec Leader'],
        checkAll: false,
        isIndeterminate: true,
        checkedCities: [],
        downloadLoading: false,
        timer: null,
        dialogTableVisible: false,
        bigqueues_num: 0,
        queues_num: 0,
        isShow: false,
        accessID: '',
        businessID: '',
        businessName: '',
        accessName: '',
        sortedTableIndex: null,
        sortedColumnName: null,
        sortedType: null,
        sortedParams: null
      }
    },
    watch: {
      list() {
        if (this.list.length < this.group.length) {
          this.checkAll = false
        } else {
          this.checkAll = true
        }
      }
    },
    activated() {
      setTimeout(() => {
        const window = document.getElementsByClassName('app-main')[0]
        window.scrollTop = 0
      }, 10)
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    mounted() {
      setTimeout(() => {
        const window = document.getElementsByClassName('app-main')[0]
        window.scrollTop = 0
      }, 10)
      this.accessID = this.$route.query.accessID
      this.businessID = this.$route.query.businessID
      this.businessName = this.$route.query.business
      this.accessName = this.$route.query.access
      this.getEngionInfo()
      this.init()
    },
    methods: {
      getRowClass({ row, column, rowIndex, columnIndex }) { // 设置table 标题背景色
        if (rowIndex === 0) { return 'background:#F0F4FB' } else { return '' }
      },
      // orderByStatus(a, b) {
      //   console.log(this.$refs, b)
      //   return
      //   const order = this.$refs.reorder_table.columns[4].order
      //   const status_idx = this.status_set.indexOf(a.engineer_info.now_status)
      //   if (order === 'ascending') {
      //     if (status_idx === -1) {
      //       return this.status_set.length
      //     } else {
      //       return status_idx
      //     }
      //   } else {
      //     if (status_idx === -1) {
      //       return 0
      //     } else {
      //       return status_idx
      //     }
      //   }
      // },
      // orderByPosition(a) {
      //   return
      //   const order = this.$refs.reorder_table.columns[2].order
      //   const position_idx = this.position_set.indexOf(a.engineer_info.job_position)
      //   if (order === 'ascending') {
      //     if (position_idx === -1) {
      //       return this.position_set.length
      //     } else {
      //       return position_idx
      //     }
      //   } elpositiose {
      //     if (n_idx === -1) {
      //       return 0
      //     } else {
      //       return position_idx
      //     }
      //   }
      // },
      // handleSort(a) {
      //   const order = this.$refs.sort_table[0].columns[2].order
      //   const status_idx = this.status_set.indexOf(a.now_status)
      //   if (order === 'ascending') {
      //     if (status_idx === -1) {
      //       return this.status_set.length
      //     } else {
      //       return status_idx
      //     }
      //   } else {
      //     if (status_idx === -1) {
      //       return 0
      //     } else {
      //       return status_idx
      //     }
      //   }
      // },
      // 排序
      schange(val) {
        console.log('队列排序', val)
        this.sortedParams = val
        this.sortedTableIndex = val[0]
        this.sortedColumnName = val[1].prop
        this.sortedType = val[1].order
        let sortedData = []
        //  按姓名排序
        if (val[1].prop === 'engineer_info.engineer_name') {
          const sortRule = (a, b) => {
            return a.engineer_info.engineer_name.localeCompare(b.engineer_info.engineer_name, 'zh')
          }
          if (val[1].order === 'ascending') {
            // console.log(this.Data[val[0]])
            this.Data[val[0]].result.sort(sortRule)
          } else {
            this.Data[val[0]].result.sort(sortRule).reverse()
          }
        // 按空闲
        } else if (val[1].prop === 'engineer_info.chat_free') {
          const sortBy = (field) => {
            return (a, b) => {
              return a.engineer_info[field] - b.engineer_info[field]
            }
          }
          if (val[1].order === 'ascending') {
            this.Data[val[0]].result.sort(sortBy('chat_free'))
          } else {
            this.Data[val[0]].result.sort(sortBy('chat_free')).reverse()
          }
        } else if (val[1].prop === 'engineer_info.job_position') {
          const csArr = []
          const teamArr = []
          const tecArr = []
          const spaceArr = []
          const otherArr = []
          this.Data[val[0]].result.forEach(ele => {
            switch (ele.engineer_info.job_position) {
            case 'CSR':
              csArr.push(ele)
              break
            case 'Team Leader':
              teamArr.push(ele)
              break
            case 'Tec Leader':
              tecArr.push(ele)
              break
            case '':
              spaceArr.push(ele)
              break
            case null:
              spaceArr.push(ele)
              break
            default:
              otherArr.push(ele)
            }
            sortedData = csArr.concat(teamArr, tecArr, spaceArr, otherArr)
            if (val[1].order === 'ascending') {
              this.Data[val[0]].result = sortedData
            } else {
              this.Data[val[0]].result = sortedData.reverse()
            }
          })
        // 按小组
        } else if (val[1].prop === 'engineer_info.queue_name') {
          const sortRule = (a, b) => {
            return a.engineer_info.queue_name.localeCompare(b.engineer_info.queue_name, 'zh')
          }
          if (val[1].order === 'ascending') {
            this.Data[val[0]].result.sort(sortRule)
          } else {
            this.Data[val[0]].result.sort(sortRule).reverse()
          }
        // 当前状态
        } else if (this.statuType && val[1].prop === 'engineer_info.now_status') {
          const readyArr = [] // 就绪
          const restArr = [] // 小休
          const holdArr = [] // 挂起
          const callOutArr = [] // 离线
          const spaceArr = []
          const otherArr = []
          this.Data[val[0]].result.forEach(ele => {
            switch (ele.engineer_info.now_status) {
            case '就绪':
              readyArr.push(ele)
              break
            case '小休':
              restArr.push(ele)
              break
            case '挂起':
              holdArr.push(ele)
              break
            case '离线':
              callOutArr.push(ele)
              break
            case '':
              spaceArr.push(ele)
              break
            case null:
              spaceArr.push(ele)
              break
            default:
              otherArr.push(ele)
            }
            sortedData = readyArr.concat(restArr, holdArr, callOutArr, spaceArr, otherArr)
            if (val[1].order === 'ascending') {
              this.Data[val[0]].result = sortedData
            } else {
              this.Data[val[0]].result = sortedData.reverse()
            }
          })
        } else if (!this.statuType && val[1].prop === 'engineer_info.now_status') {
          const readyArrPhone = [] // WaitForNextCall 就绪
          const restArrPhone = [] // NotReadyForNextCall 小休
          const CallWorkPhone = [] // AfterCallWork 案面
          const CallinPhone = [] // Callinbound 呼入
          const CalloutPhone = [] // Calloutbound 呼出
          const CallOnPhone = [] // CallOnHold Hold
          const LoggedOuthone = [] // LoggedOut 登出
          const otherPhoneArr = []
          const spaceArr = []
          // 第一排序：WaitForNextCall 就绪、第二排序：NotReadyForNextCall 小休、第三排序：AfterCallWork  案面、第四排序：Callinbound  呼入、第六排序：Calloutbound 呼出、第七排序：CallOnHold   Hold、第八排序：LoggedOut  登出
          this.Data[val[0]].result.forEach(ele => {
            switch (ele.engineer_info.now_status) {
            case '就绪':
              readyArrPhone.push(ele)
              break
            case '小休':
              restArrPhone.push(ele)
              break
            case '案面':
              CallWorkPhone.push(ele)
              break
            case '呼入':
              CallinPhone.push(ele)
              break
            case '呼出':
              CalloutPhone.push(ele)
              break
            case 'Hold':
              CallOnPhone.push(ele)
              break
            case '登出':
              LoggedOuthone.push(ele)
              break
            case '':
              spaceArr.push(ele)
              break
            case null:
              spaceArr.push(ele)
              break
            default:
              otherPhoneArr.push(ele)
            }
            sortedData = readyArrPhone.concat(restArrPhone, CallWorkPhone, CallinPhone, CalloutPhone, CallOnPhone, LoggedOuthone, otherPhoneArr, spaceArr)
            if (val[1].order === 'ascending') {
              this.Data[val[0]].result = sortedData
            } else {
              this.Data[val[0]].result = sortedData.reverse()
            }
          })
        }
      },
      handleCheckAllChange(val) { // 全选效果
        this.checkedCities = val ? this.group : []
        this.list = val ? this.group : []
        if (val) {
          this.Data.forEach(outer => {
            this.rows.push(outer)
          })
        } else {
          this.rows = []
        }
        this.isIndeterminate = false
      },
      handleCheckedCitiesChange(value) { // 复选框
        this.list = value
        const checkedCount = value.length
        this.checkAll = checkedCount === this.group.length
        this.isIndeterminate = checkedCount > 0 && checkedCount < this.group.length
      },
      handleListChange() { // 保证两个值相同
        setTimeout(this.change, 20)
      },
      change() {
        this.checkedCities = this.list
        this.rows = []
        this.Data.forEach(outer => {
          this.checkedCities.forEach((inner) => {
            if (inner === outer.group_name) {
              this.rows.push(outer)
            }
          })
        })
      },
      handleDownloadClick() { // 下载表单
        getDownloadFrom(this.accessID, this.businessID).then(res => {
          window.location.href = res.data.download
        })
      },
      handleListBlock(index, row) { // 通话时长list
        if (row.talk_sessions.length) {
          this.listData = row.talk_sessions
          this.dialogTableVisible = true
        }
      },
      getEngionInfo() {
        getEngionFrom(this.accessID, this.businessID).then(res => {
          // if (res.data.type === 'statusText') {
          // this.typeShow = true
          // }
          this.statuType = res.data.type === 'statusText' ? 1 : 0
          this.rows = []
          this.group = []
          this.checkedCities = []
          this.Data = res.data.result ? res.data.result : []
          this.Data.forEach(outer => {
            this.rows.push(outer)
          })
          for (var i of this.Data) {
            this.group.push(i.group_name)
            this.checkedCities.push(i.group_name)
            this.list = this.checkedCities
          }
        })
      },
      // getGroupInfo() {
      //   getGroupFrom(this.$route.query.accessID, this.$route.query.businessID).then(res => {
      //     for (const i of res.data.list) {
      //       this.groups.push(i.name)
      //       this.checkedCities.push(i.name)
      //       this.list = this.checkedCities
      //     }
      //   })
      // },
      init() {
        getQueueInfo(this.accessID, this.businessID).then(res => {
          this.tableData = res.data ? res.data : []
        })
        QueuesDate(this.businessID, this.accessID).then(response => {
          if (response.data) {
            this.bigqueues_num = response.data.bigqueues_num
            this.queues_num = response.data.queues_num
          }
        })
        // getInfo(accessID, businessID).then(res => {
        //   this.group = []
        //   this.checkedCities = []
        //   this.checkAll = true
        //   this.isIndeterminate = false
        //   this.Data = res.data ? res.data : []
        //   for (const i of this.Data) {
        //     this.group.push(i.group)
        //     this.checkedCities.push(i.group)
        //     this.list = this.checkedCities
        //   }
        // })
        this.timer = setInterval(() => {
          getQueueInfo(this.accessID, this.businessID).then(res => {
            this.tableData = res.data ? res.data : []
          })
          QueuesDate(this.businessID, this.accessID).then(response => {
            if (response.data) {
              this.bigqueues_num = response.data.bigqueues_num
              this.queues_num = response.data.queues_num
            }
          })
          getEngionFrom(this.accessID, this.businessID).then(res => {
            this.statuType = res.data.type === 'statusText' ? 1 : 0
            this.rows = []
            this.group = []
            this.Data = res.data.result ? res.data.result : []
            for (var i of this.Data) {
              this.group.push(i.group_name)
              for (const item in this.checkedCities) {
                if (i.group_name === this.checkedCities[item]) {
                  this.checkedCities[item] = ''
                  this.checkedCities[item] = i.group_name
                  this.rows.push(i)
                  this.list = this.checkedCities
                }
              }
            }
            this.rows.forEach(out => {
              out.result.forEach(inner => {
                if (inner.engineer_sessions.length > 0) {
                  inner.engineer_sessions.forEach(item => {
                    item['engineer_name'] = inner.engineer_info.engineer_name
                    item['engineer_code'] = inner.engineer_info.engineer_code
                    item['group_name'] = inner.engineer_info.group_name
                  })
                }
              })
            })
            if (this.sortedParams !== null) {
              this.schange(this.sortedParams)
            }
          })
        }, 10000)
      }
    }
  }
</script>
<style lang="scss">
.Mbox {
  padding: 0;
  border: 1px solid #ebeef5;
}
.Mbox .el-table th {
  background: rgba(62, 141, 221, 0.2);
  color: #303133;
}
.Mbox .el-table th:nth-child(1) .cell,
.Mbox .el-table tr td:nth-child(1) .cell {
  padding-left: 20px;
}
</style>
<style scoped lang="scss">
@import '/common.scss';
.my-table {
  // margin-top: 20px;
  // overflow: scroll;
  border: 1px solid #ccc;
  background: #fff;
  margin-bottom: 10px;
}
.my-table p {
  padding: 10px 0 10px 15px;
  font-size: 16px;
  margin: 0;
}
.Wrap /deep/ .my-table thead th.oneCol {
  background: rgba(62, 141, 221, 0.2);
  color: #303133;
}
.Wrap /deep/ .my-table thead th.twoCol {
  background: rgba(80, 193, 185, 0.2);
  color: #303133;
}
.Wrap /deep/ .my-table thead th.threeCol {
  background: #f0f4fb;
  color: #303133;
}
.Wrap /deep/ .my-table thead th.fourCol {
  background: rgba(255, 204, 0, 0.2);
  color: #303133;
}
.Wrap /deep/ .my-table thead th.fiveCol {
  background: rgba(255, 128, 96, 0.2);
  color: #303133;
}
.Wrap /deep/ .my-table .oneBor {
  border-right: 1px solid #ccc;
}
.Wrap /deep/ .el-dialog__body {
  padding: 0;
  // padding-bottom: 20px !important;
}
.Wrap /deep/ .el-dialog__header {
  padding: 10px 20px !important;
  .el-dialog__headerbtn {
    top: 14px;
  }
}
.Wrap /deep/ .el-button--small {
  padding: 0 15px;
}
.icoRight {
  position: absolute;
  right: 3px;
  top: 3px;
  cursor: pointer;
  z-index: 33;
}
.tab /deep/ tr {
  margin: 0 20px;
}
.main /deep/ .el-table th {
  padding: 0;
}
.title {
  // display: flex;
  // justify-content: space-between;
  height: 30px;
  font-size: 20px;
  padding: 10px 31px;
  // border-bottom: 1px solid #e4e7ed;
  .btn {
    margin: 0;
    a {
      color: #4a90e2;
    }
  }
}
.select {
  margin-top: 20px;
  /deep/ .el-input__inner {
    width: 260px;
    height: 36px;
  }
}
.CheckAll {
  margin: 10px 20px;
}
p {
  margin-bottom: 0;
}
.fixedBar {
  position: absolute;
  left: 25px;
  z-index: 999;
  box-shadow: 2px 2px 5px #ccc;
}
</style>
