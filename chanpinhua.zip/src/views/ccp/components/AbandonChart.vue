<template>
  <div class="abandon-chart">
    <div class="qContent">
      <div class="qicon"><svg-icon icon-class="abandon" /></div>
      <div class="qNum">{{ abaChart.section_abandon_rate }}</div>
      <div class="qinfo">实时放弃率</div>
    </div>
    <div class="qContent">
      <div class="qicon"><svg-icon icon-class="hourGlass" /></div>
      <div class="qNum">{{ abaChart.section_avg_wait_time }}</div>
      <div class="qinfo">平均排队时长</div>
    </div>
    <div class="qContent">
      <div class="qicon"><svg-icon icon-class="fennu" /></div>
      <div class="qNum">{{ abaChart.not_at_all }}</div>
      <div class="qinfo">当前愤怒会话</div>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'abandon-chart',
    props: {
      abaChart: {
        type: Object,
        default: function() {
          return {
            section_abandon_rate: 0,
            section_avg_wait_time: '00:00:00',
            not_at_all: 0
          }
        }
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>

	.abandon-chart {
		display: flex;
		width: 100%;
		// padding-top: 20px;
	}
	.qContent {
		text-align: center;
		flex: 1;
		line-height: 36px;
    display: flex;
    flex-direction: column;
    justify-content: center;
		svg {
			width: 20px;
			height: 20px;
		}
		.qNum {
      height: 32px;
			font-size: 20px;
			font-weight: bold;
		}
		.qinfo {
			font-size: 10px;
			color:#606266;
		}
	}
</style>
