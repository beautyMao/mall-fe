<template>
  <div class="lineup-chart">
    <div class="qContent">
      <div class="qicon"><svg-icon icon-class="serNum" /></div>
      <div class="qNum">{{ linChart.locale_count }}</div>
      <div class="qinfo">业务服务量</div>
    </div>
    <div class="qContent">
      <div class="qicon"><svg-icon icon-class="paidui" /></div>
      <div class="qNum">{{ linChart.queues_count }}</div>
      <div class="qinfo">排队量</div>
    </div>
    <div class="qContent">
      <div class="qicon"><svg-icon icon-class="AHT" /></div>
      <div class="qNum">{{ linChart.aht_count }}</div>
      <div class="qinfo">AHT</div>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'lineup-chart',
    props: {
      linChart: {
        type: Object,
        default: function() {
          return {
            aht_count: '00:00:00',
            queues_count: 0,
            locale_count: 0
          }
        }
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
	.lineup-chart {
		display: flex;
		width: 100%;
		// padding-top: 20px;
	}
	.qContent {
		text-align: center;
		flex: 1;
    display: flex;
    flex-direction: column;
    justify-content: center;
		line-height: 36px;
		svg {
			width: 20px;
			height: 20px;
		}
		.qNum {
      height: 32px;
			font-size: 20px;
			font-weight: bold;
		}
		.qinfo {
			font-size: 10px;
			color:#606266;
		}
	}
</style>
