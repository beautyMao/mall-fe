<template>
  <div :style="{height:'290px',width:'90%'}" />
</template>

<script>
  import echarts from 'echarts'
  export default {
    name: 'province-chart-vue',
    data() {
      return {
        chart: null,
        option: {
          title: {
            text: '省份',
            x: 'center'
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)'
          },
          series: [
            {
              name: '访问来源',
              type: 'pie',
              radius: ['50%', '70%'],
              avoidLabelOverlap: false,
              label: {
                emphasis: {
                  show: true,
                  textStyle: {
                    fontSize: '30',
                    fontWeight: 'bold'
                  }
                }
              },
              labelLine: {
                normal: {
                  show: false
                }
              },
              data: [
                // { value:10101, name:'北京' },
                // { value:10102, name:'上海' },
                // { value:10103, name:'天津' },
                // { value:10104, name:'重庆' },
                // { value:10105, name:'黑龙江' },
                // { value:10106, name:'吉林' },
                // { value:10107, name:'辽宁' },
                // { value:10108, name:'内蒙古' },
                // { value:10109, name:'河北' },
                // { value:10110, name:'山西' },
                // { value:10111, name:'陕西' },
                // { value:10112, name:'山东' },
                // { value:10113, name:'新疆' },
                // { value:10114, name:'西藏' },
                // { value:10115, name:'甘肃' },
                // { value:10116, name:'吉林' },
                // { value:10117, name:'辽宁' },
                // { value:10118, name:'内蒙古' },
                // { value:10119, name:'河北' },
                // { value:10120, name:'山西' },
                // { value:10121, name:'陕西' },
                // { value:10122, name:'山东' },
                // { value:10123, name:'新疆' },
                // { value:10124, name:'西藏' },
                // { value:10125, name:'甘肃' },
                // { value:10126, name:'吉林' },
                // { value:10127, name:'辽宁' },
                // { value:10128, name:'内蒙古' },
                // { value:10129, name:'河北' },
                // { value:10130, name:'山西' },
                // { value:10131, name:'内蒙古' },
                // { value:10132, name:'河北' },
                // { value:10133, name:'山西' },
                { value: 10134, name: '山西' }
              ]
            }
          ]
        }
      }
    },
    mounted() {
      this.inchart()
    },
    methods: {
      inchart() {
        this.chart = echarts.init(this.$el)
        this.chart.setOption(this.option)
      }
    }
  }
</script>

<style scoped>

</style>
