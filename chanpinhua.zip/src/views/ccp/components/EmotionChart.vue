<template>
  <div class="emotion">
    <div class="emotion-title">用户情感监控</div>
    <div>
      <div id="emotion-chart" class="emotion-chart" />
      <div class="hot-emotion">
        <ul>
          <li v-for="(item,index) in Emdata" :key="index">
            <span :style="{background: color[index]}" />
            <span>{{ item.name }}</span>
            <span>{{ item.value }} </span>
          </li>
        </ul>
      </div>
    </div>
    <div v-if="!emotionData.length" class="null-info">
      <div class="icon">
        <svg-icon icon-class="null" class="null" />
        <span class="name">暂无数据</span>
      </div>
    </div>
  </div>
</template>
<script>
  import echarts from 'echarts'
  const EMOTION_TYPE = {
    moderately: '正常',
    very: '愉快',
    extremely: '惊喜',
    slightly: '不满',
    not_at_all: '愤怒'
  }
  export default {
    name: 'emotion-chart',
    props: {
      emotionData: {
        type: Array,
        default: function() {
          return []
        }
      }
    },
    data() {
      return {
        chart: null,
        Emdata: [],
        color: ['#1890FF', '#BFB0FF', '#005AAD', '#7EF7FF', '#DAF0FF'],
        list: [
          {
            name: '正常',
            value: '0',
            color: '#1890FF'
          },
          {
            name: '愉快',
            value: '0',
            color: '#BFB0FF'
          },
          {
            name: '惊喜',
            value: '0',
            color: '#005AAD'
          },
          {
            name: '不满',
            value: '0',
            color: '#7EF7FF'
          },
          {
            name: '愤怒',
            value: '0',
            color: '#DAF0FF'
          }
        ]
      }
    },
    watch: {
      emotionData() {
        this.initChart()
      }
    },
    mounted() {
      this.initChart()
    },
    methods: {
      initChart() {
        this.chart = echarts.init(document.getElementById('emotion-chart'))
        this.Emdata = []
        for (const key in this.emotionData[0]) {
          if (EMOTION_TYPE[key]) {
            this.Emdata.push({
              value: this.emotionData[0][key],
              name: EMOTION_TYPE[key]
            })
          }
        }
        this.Emdata.sort((x, y) => y.value - x.value)
        this.chart.setOption({
          color: this.color,
          tooltip: {
            trigger: 'item',
            formatter: '{b} : {c} ({d}%)',
            position: [0, 0],
            extraCssText: 'width:150px; white-space:pre-wrap'
          },
          series: [
            {
              name: '正常',
              type: 'pie',
              radius: ['40%', '65%'],
              center: ['32%', '50%'],
              avoidLabelOverlap: false,
              label: {
                normal: {
                  position: 'outside',
                  formatter: '{d}%'
                }
              },
              labelLine: {
                normal: {
                  show: true
                }
              },
              data: this.Emdata
            }
          ]
        })
      }
    }
  }

</script>
<style lang="scss" scoped>
.emotion {
  position: relative;
  width: 100%;
  height: 175px;
  .emotion-chart {
    min-width: 250px;
    min-height: 150px;
  }
  .hot-emotion {
    position: absolute;
    right: 0;
    bottom: 0;
    text-indent: 20px;
    background-color: #f5f7fa;
    text-align: center;
    color: #303133;
    font-size: 12px;
    line-height: 28px;
    ul {
      width: 150px;
      font-size: 10px;
      color: #606266;
      padding-right: 10px;
      li {
        display: flex;
        margin: 2px 0;
        text-align: left;
      }
      li span:nth-child(2) {
        flex: 1;
      }
      li span:nth-child(1) {
        width: 27.5px;
        height: 27.5px;
        transform: scale(0.5);
        border-radius: 2px;
      }
    }
  }
  .emotion-title {
    color: #303133;
    font-size: 17px;
    line-height: 30px;
    font-weight: bold;
  }
  .null-info {
    position: absolute;
    left: 0;
    right: 0;
    top: 20px;
    bottom: 0;
    margin: auto;
    display: flex;
    .icon {
      display: flex;
      flex-direction: column;
      justify-content: center;
      flex: 1;
      height: 150px;
      align-items: center;
      .null {
        width: 92px;
        height: 62px;
      }
      .name {
        margin-top: 18px;
        font-size: 14px;
        color: #D0DBEE;
      }
    }
  }
}
</style>

