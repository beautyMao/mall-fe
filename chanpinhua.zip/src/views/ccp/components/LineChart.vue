<template>
  <div class="chart">
    <div id="line-chart" class="line-chart" />
    <div class="getInfo"><span @click="handleusercall">查看详情</span></div>
  </div>
</template>

<script>
  import echarts from 'echarts'
  export default {
    name: 'line-chart',
    props: {
      lineChart: {
        type: Object,
        default: function() {
          return {}
        }
      }
    },
    data() {
      return {
        option: {
          color: ['#2295FF', '#DAF0FF'],
          title: {
            text: '时段服务明细'
          },
          tooltip: {
            trigger: 'axis',
            formatter: '{b} <br/>{a} : {c} <br/> {a1} : {c1}%',
            backgroundColor: '#1890FF',
            axisPointer: {
              type: 'cross',
              label: {
                backgroundColor: '#6a7985'
              }
            }
          },
          legend: {
            type: 'plain',
            top: '5%',
            left: '38%',
            data: [{
              name: '时段服务量'
            }, {
              name: '放弃率',
              icon: 'rect',
              itemWidth: '10',
              itemHeight: '5'
            }],
            textStyle: {
              color: 'rgba(0,0,0,0.45)',
              fontSize: 10
            },
            // itemGap: 45,
            // itemWidth: 30,
            symbolKeepAspect: false
          },
          grid: {
            left: '6%',
            right: '6%',
            bottom: 0,
            containLabel: true
          },
          xAxis: [
            {
              type: 'category',
              data: ['0:00', '4:00', '8:00', '12:00', '16:00', '20:00'],
              axisLine: {
                onZero: false,
                lineStyle: {
                  color: '#2295FF'
                }
              },
              axisPointer: {
                type: 'shadow'
              }
            }
          ],
          yAxis: [
            {
              type: 'value',
              axisLabel: {
                formatter: '{value}' // 刻度标签的内容格式器
              }
            },
            {
              type: 'value',
              splitLine: {
                show: false
              },
              axisLabel: {
                formatter: '{value} %'
              }
            }
          ],
          series: [
            {
              name: '时段服务量',
              type: 'line',
              smooth: true,
              symbolSize: 10,
              sampling: 'average', // 是否平滑曲线显示
              lineStyle: {
                normal: {
                  color: '#2295FF',
                  width: 2
                }
              },
              data: []
            },
            {
              name: '放弃率',
              type: 'line',
              smooth: true,
              symbol: 'none', // 是否显示小圆点  默认不写
              sampling: 'average', // 是否平滑曲线显示
              lineStyle: {
                normal: {
                  color: '#2FC25B',
                  width: 0
                }
              },
              // 填充色
              areaStyle: {
                color: new echarts.graphic.LinearGradient(0, 0, 0, 1, [{
                  offset: 0,
                  color: '#DAF0FF'
                }])
              },
              yAxisIndex: 1,
              data: []
            }
          ]
        }
      }
    },
    watch: {
      lineChart() {
        this.init()
      }
    },
    mounted() {
      this.init()
    },
    activated() {
      this.showChart()
    },
    methods: {
      init() {
        // this.option.xAxis[0].data = this.lineChart.begin_time.reverse()
        this.option.series[0].data = this.lineChart.section_num_into
        this.option.series[1].data = this.lineChart.section_abandon_rate
        this.showChart()
      },
      handleusercall() { // 来电量
        const query = { ...this.$route.query || {}}
        this.$router.push({
          path: `usercall/${this.$route.query.businessID}${this.$route.query.accessID}`,
          query
        })
      },
      showChart() {
        this.chart = echarts.init(document.getElementById('line-chart'))
        this.chart.setOption(this.option)
      }
    }
  }
</script>
<style lang="scss" scoped>
.chart {
  position: relative;
  width: 100%;
  min-width: 600px;
  height: 40%;
  // min-height: 225px;
  .line-chart {
    width: 100%;
    min-width: 600px;
    height: 225px;
  }
}
.getInfo {
 color:#1990ff;
  // width: 100%;
  position: absolute;
  right: 0;
  top: 0;
  text-align: right;
  font-size: 12px;
  z-index: 99;
  span {
    cursor: pointer;
  }
}
</style>

