<template>
  <div class="mapEchart" :style="mapH">
    <!-- <div class="echart-title">{{  }} <span>^</span></div> -->
    <el-dropdown class="echart-title" @visible-change="handleVisibleChange" @command="handleCommand">
      <div class="el-dropdown-link">
        {{ title }}
        <div ref="box" class="box" />
        <!--<i class="el-icon-arrow-down el-icon&#45;&#45;right" />-->
      </div>
      <el-dropdown-menu slot="dropdown">
        <el-dropdown-item command="a">地域来电监控</el-dropdown-item>
        <el-dropdown-item command="b">全国天气监控</el-dropdown-item>
      </el-dropdown-menu>
    </el-dropdown>

    <div v-if="isShow" id="myEchart" ref="myEchart" style="width: 100%; height: 100%" :class="isShow ? 'top':'bottom'" />
    <!--<div id="myWeatherEchart" ref="myWeatherEchart" style="width: 100%; height: 95%" :class="!isShow ? 'top':'bottom'"/>-->
    <!-- <mapWarning v-else ref="myWeatherEchart" :data-list="weatherdata" :is-show="isShow" /> -->
    <div v-if="PhoneCallData.length && type==='a'" class="hot-city">
      <div class="hot-city-title">{{ usercall }}</div>
      <ul>
        <li v-for="(item, index) in PhoneCallData" :key="index"><span>{{ item.name }}</span><span>{{ item.value }}</span></li>
      </ul>
    </div>

    <div v-if="orderData.length && type==='b'" class="hot-city">
      <!--<div class="hot-city-title">{{ usercall }}</div>-->
      <!--<ul>-->
      <!--<li v-for="(item, index) in WarnOrderData" :key="index"><span class="colorList" :style="{background: color[index]}" /><span>{{ item.name }}</span><span>{{ item.value }}</span></li>-->
      <!--</ul>-->
    </div>
    <div class="getInfo"><span @click="handleMapcall">查看详情</span></div>
  </div>
</template>
<script>
  import echarts from 'echarts'
  import 'echarts/map/js/china'
  import { getPhoneCallData, getweatherWarn } from '@/api/ccp/index'
  import { getWeatherDistribute } from '@/api/ccp/pickup'
  // import mapWarning from './mapWarning'

  export default {
    name: 'map-chart',
    // components: { mapWarning },
    props: {
      provName: {
        type: Boolean,
        default: true
      },
      mapH: {
        type: String,
        default: ''
      }
    },
    data() {
      return {
        chart: null,
        customWeatherData: [],
        title: '地域来电监控',
        type: 'a',
        usercall: '地域来电量',
        PhoneCallData: [],
        orderData: [],
        WarnCallData: [],
        WarnOrderData: [],
        weatherdata: [],
        myChart: null,
        isShow: true,
        color: ['#1890FF', '#BFB0FF', '#005AAD', '#7EF7FF', '#DAF0FF']
      }
    },
    watch: {
      isShow() {
        if (this.isShow === true) {
          this._getPhoneCallData()
        }
      }
    //   '$route.query': function() {
    //     if (!this.$route.query.businessID) return
    //     this._getPhoneCallData()
    //     this._getweatherWarn()
    //   }
    // },
    // mounted() {
    //   if (!this.$route.query.businessID || !this.$route.query.accessID) return
    //   this._getPhoneCallData()
    //   this._getweatherWarn()
    // setInterval(() => {
    //   if (!this.$route.query.businessID || !this.$route.query.accessID) return
    //   this._getPhoneCallData()
    //   this._getweatherWarn()
    // }, 30000)
    },
    activated() {
      this._getPhoneCallData()
    },
    methods: {
      handleCommand(command) {
        if (command === 'a') {
          this.type = command
          this.title = '地域来电监控'
          this.isShow = true
        }
        if (command === 'b') {
          this.isShow = false
          this.type = command
          this.title = '全国天气监控'
        }
      },
      handleusercall() { // 来电量
        const query = { ...this.$route.query || {}}
        this.$router.push({
          path: `usercall/${this.$route.query.businessID}${this.$route.query.accessID}`,
          query: query
        })
      },
      handleMapcall() { // 天气预警
        const query = { ...this.$route.query || {}}
        query.type = this.type
        this.$router.push({
          // name: 'weather',
          path: `weather/${this.$route.query.businessID}${this.$route.query.accessID}`,
          query: query
        })
      },
      _getPhoneCallData() {
        getPhoneCallData(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          this.PhoneCallData = []
          if (res.data.province.length) {
            res.data.province.map((k) => {
              this.PhoneCallData.push({
                name: k.name,
                value: k.count
              })
            })
            this.PhoneCallData.sort((x, y) => y.value - x.value)
            this.PhoneCallData.length = 6
          }
          if (this.isShow) {
            this.initMapChart()
          }
        })
      },
      _getweatherWarn(data = '') {
        getWeatherDistribute(data).then(res => {
          this.weatherdata = res.data
        })
        getweatherWarn(this.$route.query.businessID, this.$route.query.accessID).then(res => {
        })
        // getPhoneCallData(this.$route.query.businessID, this.$route.query.accessID).then(res => {
        //   this.WarnCallData = []
        //   res.data.province.map((k) => {
        //     this.WarnCallData.push({
        //       name: k.name,
        //       value: k.count
        //     })
        //   })
        //   res.data.order_num.map((k) => {
        //     this.WarnOrderData.push({
        //       name: k.name,
        //       value: k.count
        //     })
        //   })
        //   this.WarnOrderData.sort((x, y) => y.value - x.value)
        //   // this.initWarnChart()
        // })
      },
      initWarnChart() {
        const myWeatherEchart = echarts.init(document.getElementById('myWeatherEchart'))
        myWeatherEchart.setOption({
          // tooltip: {
          //   trigger: 'item',
          //   formatter: function(params) {
          //     if (params.data) {
          //       return params.name + '：' + params.data['weathers'].join()
          //     }
          //   }
          // },
          visualMap: {
            min: 0,
            max: this.WarnOrderData.length ? this.WarnOrderData[0].value : 0,
            right: '-1000%',
            top: 'top',
            // text: ['High', 'Low'], // 文本，默认为数值文本
            calculable: true,
            orient: 'horizontal',
            inRange: {
              color: this.color
            }
          },
          series: [
            {
              name: '',
              type: 'map',
              mapType: 'china',
              selectedMode: 'multiple',
              left: 'left',
              roam: false,
              label: {
                normal: {
                  show: true,
                  textStyle: {
                    fontSize: 8,
                    color: '#606266'
                  }
                },
                emphasis: {
                  show: true
                }
              },
              itemStyle: {
                normal: {
                  label: { show: true },
                  borderWidth: 0.5, // 省份的边框宽度
                  borderColor: '#c2c2c2', // 省份的边框颜色
                  areaColor: '#fff', // 地图背景颜色
                  color: 'transparent',
                  fontSize: 8
                },
                emphasis: {
                  label: { show: true },
                  areaStyle: {
                    color: '#DAF0FF' // 选中状态的地图板块颜色
                  },
                  areaColor: '#DAF0FF' // 选中状态的地图板块颜色
                }
              },
              // itemStyle: {
              //   normal: {
              //     label: { show: true },
              //     borderWidth: 1, // 省份的边框宽度
              //     borderColor: '#c2c2c2', // 省份的边框颜色
              //     areaColor: '#fff' // 地图背景颜色
              //   },
              //   emphasis: { label: { show: true }}
              // },
              data: this.WarnOrderData
            }
          ]
        })
      },
      initMapChart() {
        this.myChart = echarts.init(document.getElementById('myEchart'))
        this.myChart.setOption({
          // title: {
          //   text: '地域来电分析',
          //   left: 'left'
          // },
          tooltip: {
            trigger: 'item'
          },
          // legend: {
          //   orient: 'vertical',
          //   left: 'right',
          //   top: 'bottom',
          //   data: []
          // },
          visualMap: {
            min: 0,
            max: this.PhoneCallData.length ? this.PhoneCallData[0].value : 1,
            right: '0%',
            top: 'top',
            // text: ['High', 'Low'], // 文本，默认为数值文本
            calculable: true,
            orient: 'horizontal',
            inRange: {
              color: ['#e0edfa', '#1890FF']
            }
          },
          series: [
            {
              name: '地域来电量',
              type: 'map',
              mapType: 'china',
              left: 'left',
              top: '40px',
              roam: false,
              label: {
                normal: {
                  show: true,
                  textStyle: {
                    fontSize: 8,
                    color: '#606266'
                  }
                },
                emphasis: {
                  show: true
                }
              },
              itemStyle: {
                normal: {
                  label: { show: true },
                  borderWidth: 0.5, // 省份的边框宽度
                  borderColor: '#c2c2c2', // 省份的边框颜色
                  areaColor: '#fff', // 地图背景颜色
                  color: 'transparent',
                  fontSize: 8
                },
                emphasis: {
                  label: { show: true },
                  areaStyle: {
                    color: '#DAF0FF' // 选中状态的地图板块颜色
                  },
                  areaColor: '#DAF0FF' // 选中状态的地图板块颜色
                }
              },
              data: this.PhoneCallData
            }
          ]
        })
      },
      handleVisibleChange(val) {
        if (val) {
          this.$refs.box.className = 'box box-focus'
        } else {
          this.$refs.box.className = 'box'
        }
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.mapEchart {
  position: relative;
  overflow: hidden;
  height: 100%;
  .el-dropdown-link {
    position: relative;
    .box {
      position: absolute;
      left: 110px;
      top: 10px;
      width: 0;
      height: 0;
      transform-origin: center;
      transition: transform .3s;
      border-top: 8px solid #6675FF;
      border-right: 8px solid  rgba(0,0,0,0);
      border-left: 8px solid  rgba(0,0,0,0);
    }
    .box-focus {
      transform: rotate(180deg);
      transition: transform .3s
    }
  }
  .hot-city {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 120px;
    height: 204px;
    background-color: #F5F7FA;
    text-align: center;
    color: #303133;
    font-size: 12px;
    line-height: 28px;
    ul {
      font-size: 10px;
      color: #606266;
      li {
        display: flex;
      }
      li .colorList {
        width: 27.5px;
        height: 27.5px;
        transform: scale(0.5);
        border-radius: 2px;
      }
      li span {
        flex: 1
      }
    }
  }
}
#myEchart {
  min-width: 100%;
  height: 100%;
  min-height: 380px;
}
.top{
  position: absolute;
  left: 0;
  top: 30px;
}
.bottom {
  position: absolute;
  left: -100%;
  top: 30px;
}
.echart-title {
    color: #303133;
    font-size: 17px;
    line-height: 30px;
    font-weight: bold;
  }
.getInfo {
  color:#1990ff;
  // width: 100%;
  position: absolute;
  right: 0;
  top: 0;
  text-align: right;
  font-size: 12px;
  z-index: 99999;
  span {
    cursor: pointer;
  }
}
</style>
