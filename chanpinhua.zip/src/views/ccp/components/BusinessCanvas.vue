<template>
  <div class="business-canvas" :style="businessH">
    <div class="business-title">重要业务数据</div>
    <div class="canvas-list" :style="businessH">
      <div class="canvas-box">
        <canvas id="num_info" />
        <div>
          <p class="rate">{{ busCanvas.num_info.rate + '%' }}</p>
          <p class="title">{{ busCanvas.num_info.title }}</p>
          <p class="text">{{ busCanvas.num_info.text }}</p>
          <p class="num blue" @click="handleManpower">{{ busCanvas.num_info.num }}</p>
        </div>
      </div>
      <div class="canvas-box">
        <canvas id="robot_info" />
        <div>
          <p class="rate">{{ busCanvas.robot_info.rate + '%' }}</p>
          <p class="title">{{ busCanvas.robot_info.title }}</p>
          <p class="text">{{ busCanvas.robot_info.text }}</p>
          <p class="num blue" @click="handleManpower(1)">{{ busCanvas.robot_info.num }}</p>
        </div>
      </div>
      <div class="canvas-box">
        <canvas id="info" />
        <div>
          <p class="rate">{{ busCanvas.info.rate + '%' }}</p>
          <p class="title">{{ busCanvas.info.title }}</p>
          <p class="text">{{ busCanvas.info.text }}</p>
          <p class="num blue" @click="handleManpower">{{ busCanvas.info.num }}</p>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { getPickupRate, getRobotManual, getSatisfactionDegree } from '@/api/ccp/index'

  export default {
    name: 'business-canvas',
    props: {
      heights: {
        type: String,
        default: ''
      },
      businessH: {
        type: String,
        default: ''
      }
    },
    data() {
      return {
        busCanvas: {
          num_info: {
            num: 0,
            rate: 100,
            title: '30秒接起率',
            text: '接起量'
          },
          info: {
            num: 0,
            rate: 100,
            title: '满意度',
            text: '点评发送量'
          },
          robot_info: {
            num: 0,
            rate: 0,
            title: '机器人转人工',
            text: '机器人进入量'
          }
        }
      }
    },
    mounted() {
      document.querySelectorAll('.canvas-box canvas').forEach(el => {
        el.width = el.parentElement.getBoundingClientRect().width
        el.height = el.parentElement.getBoundingClientRect().width / 2
      })
    },
    methods: {
      _getBusinessInfo() {
        getPickupRate(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          console.log(res, '当前现场进入量、30秒接起率')
          this.busCanvas.num_info.num = res.data.in_num
          this.busCanvas.num_info.rate = res.data.pickup_rate.replace('%', '') || 0
          const numInfo = document.getElementById('num_info')
          drawMain(numInfo, this.busCanvas.num_info.rate, ['#7EF7FF', '#1890FF'], 'transparent', this.busCanvas.num_info, true)
        })
        getSatisfactionDegree(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          // console.log(res, '满意度')
          this.busCanvas.info.num = res.data.total
          this.busCanvas.info.rate = res.data.rate.replace('%', '') || 0
          const info = document.getElementById('info')
          drawMain(info, this.busCanvas.info.rate, ['#866DF8', '#1890FF'], 'transparent', this.busCanvas.info, true)
        })
        // const info = document.getElementById('info')
        // drawMain(info, this.busCanvas.info.rate, ['#866DF8', '#1890FF'], 'transparent', this.busCanvas.info, true)
        getRobotManual(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          console.log(res, '机器人转人工')
          this.busCanvas.robot_info.num = res.data.robotAccessCount || 0
          this.busCanvas.robot_info.rate = res.data.manual_rate.replace('%', '') || 0
          const robotInfo = document.getElementById('robot_info')
          drawMain(robotInfo, this.busCanvas.robot_info.rate, ['#1890FF', '#7EF7FF'], 'transparent', this.busCanvas.robot_info, true)
        })
      },

      handleManpower(type) { // 机器人转人工
        const query = { ...this.$route.query || {}}
        if (type === 1) {
          this.$router.push({
            path: '/demand/record',
            query
          })
        } else {
          // console.log(`/actioncontrol/machine-change-manpower/${this.$route.query.businessID}${this.$route.query.accessID}`)
          this.$router.push({
            path: `actioncontrol/machine-change-manpower/${this.$route.query.businessID}${this.$route.query.accessID}`,
            query: query
          })
        }
      }
    }
  }
  /*
	@drawing_elem: 绘制对象
	@percent：绘制圆环百分比, 范围[0, 100]
	@forecolor: 绘制圆环的前景色，颜色代码
	@bgcolor: 绘制圆环的背景色，颜色代码
	@data: 绘制数据
*/
  function drawMain(drawing_elem, percent, forecolor, bgcolor, data, isLinear) {
    const lineWidth = 10
    const context = drawing_elem.getContext('2d')
    const width = drawing_elem.parentElement.getBoundingClientRect().width

    const x = width / 2
    const y = width / 2
    const radius = width / 2 - lineWidth / 2

    const startNum = 3.45
    const endNum = 5.98
    // const p1 = (endNum - startNum) * (100 / 100) + startNum
    const p2 = (endNum - startNum) * ((data.rate) / 100) + startNum
    // 先清理下
    context.clearRect(0, 0, width, width / 2)

    // 绘制背景圆圈
    function backgroundCircle() {
      context.save()
      context.beginPath()
      context.lineWidth = lineWidth // 设置线宽
      context.lineCap = 'round'
      context.strokeStyle = bgcolor
      // 用于绘制context.arc(x坐标，y坐标，半径，起始角度，终止角度，顺时针/逆时针)
      context.arc(x, y, radius, 0, Math.PI * 2, false)
      context.stroke()
      context.closePath()
      context.restore()
    }
    // 绘制运动半圆环
    function foregroundCircle1() {
      context.save()
      context.strokeStyle = '#DAF0FF'
      context.lineWidth = lineWidth
      context.lineCap = 'round'
      context.beginPath()
      // 用于绘制圆弧context.arc(x坐标，y坐标，半径，终止角度，起始角度，顺时针/逆时针)
      context.arc(x, y, radius, 3.5, 5.98, false)
      context.stroke()
      context.closePath()
      context.restore()
    }
    backgroundCircle()
    foregroundCircle1()
    foregroundCircleRate()
    // text(percent)
    function foregroundCircleRate() {
      context.save()
      context.lineWidth = lineWidth
      context.lineCap = 'round'
      const color = context.createLinearGradient(0, 0, 300, 80)
      color.addColorStop(0, forecolor[0])
      color.addColorStop(1, forecolor[1])
      context.strokeStyle = isLinear ? color : forecolor
      context.beginPath()
      // 用于绘制圆弧context.arc(x坐标，y坐标，半径，终止角度，起始角度，顺时针/逆时针)
      context.arc(x, y, radius, p2, startNum, true)
      context.stroke()
      context.closePath()
      context.restore()
    }
    // 绘制文字
    // function text(n) {
    //   context.save() // save和restore可以保证样式属性只运用于该段canvas元素
    //   context.fillStyle = '#303133'
    //   const font_size = 50
    //   context.textAlign = 'center'
    //   context.font = font_size + 'px Helvetica'
    //   context.fillText(n + '%', 140, 100)
    //   context.font = 20 + 'px Helvetica'
    //   context.textAlign = 'center'
    //   // context.fillText(n.toFixed(0) + '人', 135 + 20, 105)
    //   context.fillText(data.title, 140, 135)
    //   context.restore()
    // }
    // context.clearRect(0, 0, drawing_elem.width, drawing_elem.height)
    // text(percent)
    // backgroundCircle()
    // foregroundCircleRate()
    // foregroundCircle1()
    // 执行动画
    // (function drawFrame() {
    //   const time = requestAnimationFrame(drawFrame)
    //   context.clearRect(0, 0, drawing_elem.width, drawing_elem.height)
    //   text(percent)
    //   backgroundCircle()
    //   foregroundCircle1()
    //   console.log(percent)
    //   if (percent > 0) {
    //     foregroundCircleRate()
    //   }
    //   if (speed < percent) {
    //     speed += 2
    //   } else {
    //     cancelAnimationFrame(time)
    //   }
    // }())
  }
</script>

<style lang="scss" scoped>
.business-canvas {
  height: 100%;
}
.business-title {
  color: #303133;
  font-size: 17px;
  line-height: 30px;
  font-weight: bold;
}

.canvas-list {
  display: flex;
  width: 100%;
  height: 100%;
  padding-top: 20px;
  .canvas-box {
    // float: left;
    flex: 1;
    position: relative;
    width: 100%;
    overflow: hidden;
    margin: 0 auto;

    div {
      position: absolute;
      width: 100%;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
      text-align: center;
      font-size: 10px;
      color: #909399;
    }

    div p:nth-child(2) {
      // color: #303133;
      font-weight: bold;
    }
  }
}
.blue {
  color: #37afff;
  cursor: pointer;
}
.title {
  position: absolute;
  top: 35%;
  width: 100%;
  text-align: center;
}
.text {
  position: absolute;
  top: 50%;
  width: 100%;
  text-align: center;
}
.num {
  position: absolute;
  top: 65%;
  width: 100%;
  text-align: center;
  font-size: 1em;
}
.rate {
  position: absolute;
  top: 12%;
  width: 100%;
  text-align: center;
  font-size: 20px;
}
// canvas {
// 	width: 160px;
// 	height: 90px;
// 	position: absolute;
//   left: 50%;
//   margin-left: -55%;
// }
</style>
