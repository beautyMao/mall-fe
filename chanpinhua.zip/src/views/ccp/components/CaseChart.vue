<template>
  <div :style="{height:'290px',width:'90%'}" />
</template>

<script>
  import echarts from 'echarts'
  export default {
    name: 'case-chart',
    props: {
      province: {
        type: Array,
        default: () => []
      },
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '320px'
      },
      piedata: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        chart: null,
        option: {
          title: {
            text: '问题分类',
            x: 'center'
          },
          tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b}: {c} ({d}%)'
          },
          series: [
            {
              name: '访问来源',
              type: 'pie',
              radius: ['50%', '70%'],
              avoidLabelOverlap: false,
              label: {
                emphasis: {
                  show: true,
                  textStyle: {
                    fontSize: '30',
                    fontWeight: 'bold'
                  }
                }
              },
              labelLine: {
                normal: {
                  show: false
                }
              },
              data: [
                { value: 10101, name: '邢台' }
              ]
            }
          ]
        }
      }
    },
    watch: {
      province() {
        this.option.series[0].data = this.province
        this.chart.setOption(this.option, true)
        console.log(this.option.series[0].data)
      },
      piedata(newval, oldval) {
        this.initCharts(newval)
      },
      deep: true
    },
    mounted() {
      this.inchart()
    },
    methods: {
      inchart() {
        this.chart = echarts.init(this.$el)
        this.chart.setOption(this.option)
      },
      initCharts(newval) {
        this.chart = echarts.init(this.$el)
        this.setOptions(newval)
      },
      get(e) {
        var newStr = ''
        var start, end
        var name_len = e.name.length
        var max_name = 4
        var new_row = Math.ceil(name_len / max_name)
        if (name_len > max_name) {
          for (var i = 0; i < new_row; i++) {
            var old = ''
            start = i * max_name
            end = start + max_name
            if (i === new_row - 1) {
              old = e.name.substring(start)
            } else {
              old = e.name.substring(start, end) + '\n'
            }
            newStr += old
          }
        } else {
          newStr = e.name
        }
        return newStr
      },
      setOptions(newval) {
        const result = newval
        this.chart = echarts.init(this.$el)
        this.chart.setOption({
          title: {
            text: ''
          },
          tooltip: {
            show: true,
            trigger: 'item',
            formatter: '{b}',
            position: ['50%', '50%']
          },
          legend: {
            top: 20,
            show: false
          },
          color: ['#FF8060', '#FDC94D', '#4ECC74', '#d48265', '#91c7ae', '#749f83', '#ca8622', '#bda29a', '#6e7074', '#546570', '#c4ccd3'],
          series: [
            {
              name: '访问来源',
              type: 'pie',
              radius: '90%',
              center: ['50%', '60%'],
              hoverAnimation: false,
              data: (() => {
                var res = []
                var len = result.items.length
                for (var i = 0, size = len; i < size; i++) {
                  if (result.breakdown === 'channel') {
                    if (result.items[i].percent !== 0) {
                      res.push({
                        name: `${result.items[i].name},${result.items[i].percent}%`,
                        value: result.items[i].percent,
                        code: result.items[i].code
                      })
                    }
                  } else {
                    if (result.items[i].percent !== 0) {
                      res.push({
                        name: `${result.items[i].name},${result.items[i].percent}%`,
                        value: result.items[i].percent,
                        code: result.items[i].code
                      })
                    }
                  }
                }
                return res
              })(),
              label: {
                width: '50px',
                height: '30px',
                color: '#fff',
                normal: {
                  formatter(e) {
                    var newStr = ''
                    var start, end
                    var name_len = e.name.length
                    var max_name = 4
                    var new_row = Math.ceil(name_len / max_name)
                    if (name_len > max_name) {
                      for (var i = 0; i < new_row; i++) {
                        var old = ''
                        start = i * max_name
                        end = start + max_name
                        if (i === new_row - 1) {
                          old = e.name.substring(start)
                        } else {
                          old = e.name.substring(start, end) + '\n'
                        }
                        newStr += old
                      }
                    } else {
                      newStr = e.name
                    }
                    return newStr
                  }
                }
              },
              itemStyle: {
                normal: {
                  label: {
                    show: false,
                    position: 'inner',
                    textStyle: {
                      color: '#fff',
                      aligin: 'center',
                      baseline: 'middle'
                    }
                  },
                  lableLine: {
                    show: false
                  }
                },
                emphasis: {
                  shadowBlur: 0,
                  shadowOffsetX: 0,
                  shadowColor: ''
                }
              }
            }
          ]
        })
        // 多个图标的时候防止点击点击除了一个的图标出现重复点击
        this.chart.off('click')
        this.chart.on('click', (params) => {
          this.$emit('clickpie', params.data)
        })
      }
    }
  }
</script>

<style scoped>

</style>
