<template>
  <div class="echart">
    <div class="legend">
      <el-row :gutter="20">
        <el-col :span="12">
          <!-- <div class="legendItem" @click="getAllWeather('')">
          <span class="legend-desc" >全部</span><span class="dot all"></span>
          </div>-->
          <div class="legendItem" @click="getRainWeather('rainstorm')">
            <span class="legend-desc rain-desc">暴雨</span>
            <span
              class="dot"
              :class="{'singlecolor': !togglerainstorm, 'rainstorm':togglerainstorm }"
            />
          </div>
        </el-col>
        <el-col :span="12">
          <div class="legendItem">
            <!-- <span class="legend-desc" >暴雨</span><span class="dot rainstorm"></span> -->
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="legendItem" @click="getLightingWeather('lightning')">
            <span>雷电</span>
            <span
              class="dot"
              :class="{'singlecolor': !togglelightning, 'lightning':togglelightning }"
            />
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="legendItem" @click="getColdSpellWeather('cold_spell')">
            <span>降温</span>
            <span
              class="dot"
              :class="{'singlecolor': !togglecold_spell, 'cold_spell':togglecold_spell }"
            />
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="legendItem" @click="getSnowWeather('snowstorm')">
            <span>暴雪</span>
            <span
              class="dot"
              :class="{'singlecolor': !togglesnowstorm, 'snowstorm':togglesnowstorm }"
            />
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="20">
        <el-col :span="12">
          <div class="legendItem" @click="getFrostWeather('frost')">
            <span>结冰</span>
            <span class="dot" :class="{'singlecolor': !togglefrost, 'frost':togglefrost }" />
          </div>
        </el-col>
      </el-row>
    </div>
    <div id="myEchart" ref="myEchart" style="width: 100%; min-height: 400px;" />
  </div>
</template>
<script>
  import echarts from 'echarts'
  import 'echarts/map/js/china.js'
  import { getWeatherDistribute } from '@/api/ccp/pickup'
  export default {
    name: 'map-warning',
    props: {
      dataList: {
        type: Array,
        default: function() {
          return []
        }
      },
      isShow: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        chart: null,
        customWeatherData: [],
        option: {
          tooltip: {
            trigger: 'item'
          },
          legend: {
            x: 'left',
            right: 10,
            selectedMode: false,
            data: ['台风', '雷电', '暴雨', '雾霾', '暴雪', '沙尘']
          },
          dataRange: {
            orient: 'horizontal',
            min: 0,
            max: 55000,
            text: ['高', '低'],
            splitNumber: 0
          },
          series: [
          ],
          animation: false
        },
        weatherdata: [],
        togglelightning: true,
        togglerainstorm: true,
        togglesnowstorm: true,
        togglefrost: true,
        togglecold_spell: true
      }
    },
    mounted() {
      this.init()
    // this._getWeatherDistribute()
    // this.option.series[0].itemStyle.normal.label.show = this.provName
    },
    beforeDestroy() {
      if (!this.chart) {
        return
      }
      this.chart.dispose()
      this.chart = null
    },
    methods: {
      init() {
        this.weatherdata = this.dataList
        let color = ''
        this.weatherdata.forEach(ele => {
          const weathers = new Set()
          if (ele.warning.length > 0) {
            ele.warning.forEach(inner => {
              weathers.add(inner.signal)
            })
          }
          switch (ele.warning[0].cate) {
          case 'rainstorm':
            color = '#1890FF'
            break
          case 'lightning':
            color = '#7EF7FF'
            break
          case 'cold_spell':
            color = '#005AAD'
            break
          case 'snowstorm':
            color = '#BFB0FF'
            break
          case 'frost':
            color = '#DAF0FF'
            break
          }
          this.customWeatherData.push({
            name: ele.province,
            value: ele.warning,
            weathers: Array.from(weathers),
            itemStyle: {
              normal: {
                color: color,
                label: {
                  show: true,
                  textStyle: {
                    color: '#fff',
                    fontSize: 15
                  }
                }
              },
              emphasis: {
                // 也是选中样式
                borderWidth: 1,
                borderColor: '#ccc',
                areaColor: '#DAF0FF',
                label: {
                  show: true,
                  textStyle: {
                    color: 'blue'
                  }
                }
              }
            }
          })
        })
        this.drawChart()
      },
      // 获取暴雨
      getRainWeather(val) {
        if (this.togglerainstorm) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data)
          this.togglerainstorm = false
        } else {
          this._getWeatherDistribute('')
          this.togglerainstorm = true
        }
        this.togglelightning = true
        this.togglesnowstorm = true
        this.togglefrost = true
        this.togglecold_spell = true
      },
      getLightingWeather(val) {
        if (this.togglelightning) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data)
          this.togglelightning = false
        } else {
          this._getWeatherDistribute('')
          this.togglelightning = true
        }
        this.togglerainstorm = true
        this.togglesnowstorm = true
        this.togglefrost = true
        this.togglecold_spell = true
      },
      getSnowWeather(val) {
        if (this.togglesnowstorm) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data)
          this.togglesnowstorm = false
        } else {
          this._getWeatherDistribute('')
          this.togglesnowstorm = true
        }
        this.togglerainstorm = true
        this.togglelightning = true
        this.togglefrost = true
        this.togglecold_spell = true
      },
      getFrostWeather(val) {
        if (this.togglefrost) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data)
          this.togglefrost = false
        } else {
          this._getWeatherDistribute('')
          this.togglefrost = true
        }
        this.togglerainstorm = true
        this.togglelightning = true
        this.togglesnowstorm = true
        this.togglecold_spell = true
      },
      getColdSpellWeather(val) {
        if (this.togglecold_spell) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data)
          this.togglecold_spell = false
        } else {
          this._getWeatherDistribute('')
          this.togglecold_spell = true
        }
        this.togglerainstorm = true
        this.togglelightning = true
        this.togglesnowstorm = true
        this.togglefrost = true
      },
      // 获取天气
      _getWeatherDistribute(data) {
        this.customWeatherData = []
        getWeatherDistribute(data)
          .then(res => {
            this.weatherdata = res.data
            let color = ''
            this.weatherdata.forEach(ele => {
              const weathers = new Set()
              if (ele.warning.length > 0) {
                ele.warning.forEach(inner => {
                  weathers.add(inner.signal)
                })
              }
              switch (ele.warning[0].cate) {
              case 'rainstorm':
                color = '#1890FF'
                break
              case 'lightning':
                color = '#7EF7FF'
                break
              case 'cold_spell':
                color = '#005AAD'
                break
              case 'snowstorm':
                color = '#BFB0FF'
                break
              case 'frost':
                color = '#DAF0FF'
                break
              }
              this.customWeatherData.push({
                name: ele.province,
                value: ele.warning,
                weathers: Array.from(weathers),
                itemStyle: {
                  normal: {
                    color: color,
                    label: {
                      show: true,
                      textStyle: {
                        color: '#fff',
                        fontSize: 15
                      }
                    }
                  },
                  emphasis: {
                    // 也是选中样式
                    borderWidth: 1,
                    borderColor: '#ccc',
                    areaColor: '#DAF0FF',
                    label: {
                      show: true,
                      textStyle: {
                        color: 'blue'
                      }
                    }
                  }
                }
              })
            })
            // console.log('customWeatherData', this.customWeatherData)
            this.drawChart()
          })
          .catch(err => {
            console.error(err)
          })
      },
      drawChart() {
        const myChart = echarts.init(document.getElementById('myEchart'))
        myChart.setOption({
          tooltip: {
            trigger: 'item',
            formatter: function(params) {
              if (params.data) {
                return params.name + '：' + params.data['weathers'].join()
              }
            }
          },
          series: [
            {
              name: '',
              type: 'map',
              mapType: 'china',
              selectedMode: 'multiple',
              left: '0',
              label: {
                normal: {
                  show: false
                },
                emphasis: {
                  show: true
                }
              },
              itemStyle: {
                normal: {
                  label: { show: true },
                  borderWidth: 0.5, // 省份的边框宽度
                  borderColor: '#c2c2c2', // 省份的边框颜色
                  areaColor: '#fff', // 地图背景颜色
                  color: 'transparent',
                  fontSize: 8
                },
                emphasis: {
                  label: { show: true },
                  areaStyle: {
                    color: '#DAF0FF' // 选中状态的地图板块颜色
                  },
                  areaColor: '#DAF0FF' // 选中状态的地图板块颜色
                }
              },
              data: this.customWeatherData
            }
          ]
        })
      },
      setName(Weathername, data) {
        var pData = []
        var pDataSet = new Set()
        var series = []
        for (const row in data) {
          for (const j in data[row].warning) {
            if (data[row].warning[j].signal === Weathername) {
              pData.push(data[row].province)
              pDataSet = new Set(pData)
            }
          }
        }
        for (const n in [...pDataSet]) {
          series.push({ name: [...pDataSet][n], value: 100 })
        }
        return series
      },
      // inchart() {
      // const accessID = this.$route.query.accessID
      // const businessID = this.$route.query.businessID
      // getweatherWarn(businessID, accessID).then(res => {
      //   this.option.series = []
      //   this.option.legend.data = []
      //   console.log(res.data)
      //   var provinceDate = []
      //   var weather = []
      //   var setweather = new Set()
      //   for (const item of res.data) {
      //     provinceDate.push(item)
      //     for (const row in item.warning) {
      //       weather.push(item.warning[row].signal)
      //       setweather = new Set(weather)
      //     }
      //   }
      //   for (const n in [...setweather]) {
      //     this.option.legend.data.push([...setweather][n])
      //     this.option.series.push(
      //       {
      //         name: [...setweather][n],
      //         type: 'map',
      //         mapType: 'china',
      //         selectedMode: 'multiple',
      //         itemStyle: {
      //           normal: { label: { show: true }},
      //           emphasis: { label: { show: true }}
      //         },
      //         data: this.setName([...setweather][n], provinceDate)
      //       }
      //     )
      //   }
      //   console.log(this.option.series)
      //   const myChart = echarts.init(this.$refs.myEchart) // 这里是为了获得容器所在位置
      //   myChart.setOption(this.option)
      //   // this.chinaConfigure()
      // })
      // },
      chinaConfigure() {
        const myChart = echarts.init(this.$refs.myEchart) // 这里是为了获得容器所在位置
        window.onresize = myChart.resize
        const _this = this
        function consoleb(param) {
          const selected = param.batch[0].selected
          const mapSeries = _this.option.series[0]
          const data = []
          const legendData = []
          for (let p = 0, len = mapSeries.data.length; p < len; p++) {
            const name = mapSeries.data[p].name
            if (selected[name]) {
              data.push({
                name: name,
                value: mapSeries.data[p].value
              })
              legendData.push(name)
            }
          }
          _this.$emit('mapclick', data)
          _this.option.legend.data = legendData
          myChart.setOption(_this.option, true)
        }
        myChart.on('mapselectchanged', consoleb)
        myChart.setOption(this.option, true)
      }
    }
  }
</script>
<style rel='stylesheet/scss' lang='scss' scoped>
.legend {
  position: absolute;
  bottom: 0;
  right: 0;
  width: 110px;
  height: 160px;
  padding: 10px;
  z-index: 999;
  background: #f5f7fa;
  .legendItem {
    font-size: 14px;
    cursor: pointer;
    margin-bottom: 12px;
    .lengend-desc {
      display: inline-block;
      margin-right: 5px;
      font-size: 14px !important;
      float: left;
    }
  }
  /deep/ .el-col-12 {
    width: auto;
  }
  .dot {
    float: left;
    display: inline-block;
    width: 10px;
    height: 10px;
    margin-top: 4px;
    margin-right: 10px;
    border-radius: 2px;
  }
  .singlecolor {
    background: #c2c2c2;
  }
  .rainstorm {
    background: rgba(24, 144, 255, 1);
  }
  .rainstorm:hover {
    background: rgba(24, 144, 255, 0.5);
  }
  .lightning {
    background: rgba(126, 247, 255, 1);
  }
  .lightning:hover {
    background: rgba(126, 247, 255, 0.5);
  }
  .cold_spell {
    background: rgba(0, 90, 173, 1);
  }
  .cold_spell:hover {
    background: rgba(0, 90, 173, 0.5);
  }
  .snowstorm {
    background: rgba(191, 176, 255, 1);
  }
  .snowstorm:hover {
    background: rgba(191, 176, 255, 0.5);
  }
  .frost {
    background: rgba(218, 240, 255, 1);
  }
  .frost:hover {
    background: rgba(218, 240, 255, 0.5);
  }
  .all {
    background: #000;
  }
}
</style>
