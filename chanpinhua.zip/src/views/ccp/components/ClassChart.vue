<template>
  <div style="position: relative" class="wrapper">
    <div class="class-title">问题分类</div>
    <div class="class">
      <div id="class-chart" class="class-chart" />
      <div class="hot-class">
        <ul>
          <li v-for="(item,index) in classChart" :key="index">
            <span :style="{background: color[index]}" />
            <span>{{ item.name }}</span>
            <span>{{ item.value }} </span>
          </li>
        </ul>
      </div>
    </div>
    <div v-if="!classChart.length" class="null-info">
      <div class="icon">
        <svg-icon icon-class="null" class="null" />
        <span class="name">暂无数据</span>
      </div>
    </div>
  </div>
</template>
<script>
  import echarts from 'echarts'
  import { getNewCaseLabels } from '@/api/ccp/index'
  export default {
    name: 'class-chart',
    data() {
      return {
        color: ['#1890FF', '#BFB0FF', '#005AAD', '#7EF7FF', '#DAF0FF'],
        classChart: []
      }
    },
    methods: {
      _getNewCaseLabels() {
        getNewCaseLabels(this.$route.query.businessID, this.$route.query.accessID).then(res => {
          this.classChart = res.data
          this.initChart()
        })
      },
      handleuserclass() {
        if (!this.classChart.length) return
        // 分类
        const query = { ...(this.$route.query || {}) }
        if (this.classChart[0].name === '其他' && this.classChart[0].value === 0) return
        this.$router.push({
          path: `/devccp-management/case/${this.$route.query.businessID}${
            this.$route.query.accessID
          }`,
          query
        })
      },
      initChart() {
        this.chart = echarts.init(document.getElementById('class-chart'))
        // this.classChart.sort((x, y) => y.value - x.value)
        this.chart.setOption({
          color: this.color,
          tooltip: {
            trigger: 'item',
            formatter: '{b} : {c} <br/>({d}%)',
            position: [0, 0],
            extraCssText: 'white-space:pre-wrap'
          },
          series: [
            {
              name: '未激活',
              type: 'pie',
              radius: ['40%', '65%'],
              center: ['32%', '50%'],
              avoidLabelOverlap: false,
              // label: {
              //   normal: {
              //     formatter: '{per|{d}%}',
              //     rich: {
              //       a: {
              //         color: '#999',
              //         lineHeight: 22,
              //         align: 'center'
              //       },
              //       hr: {
              //         borderColor: '#aaa',
              //         width: '100%',
              //         borderWidth: 0.5,
              //         height: 0
              //       },
              //       b: {
              //         fontSize: 16,
              //         lineHeight: 33
              //       },
              //       per: {
              //         color: '#eee',
              //         backgroundColor: '#334455',
              //         padding: [2, 4],
              //         borderRadius: 2
              //       }
              //     }
              //   }
              // },
              labelLine: {
                normal: {
                  show: true
                }
              },
              label: {
                normal: {
                  position: 'outside',
                  formatter: '{d}%'
                }
              },
              data: this.classChart
            }
          ]
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
.wrapper {
  height: 175px;
}
.class {
  position: relative;
  width: 100%;
  height: 145px;
  .class-chart {
    min-width: 250px;
    min-height: 150px;
  }
  }
.hot-class {
  position: absolute;
  right: 0;
  bottom: 0;
  text-indent: 20px;
  background-color: #f5f7fa;
  text-align: center;
  color: #303133;
  z-index: 999;
  font-size: 12px;
  line-height: 28px;
  max-width: 150px;
  height: 155px;
  overflow: hidden;
  ul {
    font-size: 10px;
    color: #606266;
    li {
      display: flex;
      margin: 2px 0;
      text-align: left;
      overflow: hidden;
      padding-right: 5px
    }
    li span:nth-child(2) {
      text-overflow: ellipsis;
      overflow: hidden;
      white-space:nowrap;
      width: 100px;
    }
    li span:nth-child(1) {
      width: 27.5px;
      height: 27.5px;
      transform: scale(0.5);
      border-radius: 2px;
    }
    li span:nth-child(3) {
      flex: 1;
      border-radius: 2px;
    }
  }
}
.class-title {
  color: #303133;
  font-size: 17px;
  line-height: 30px;
  font-weight: bold;
}
.null-info {
  position: absolute;
  left: 0;
  right: 0;
  top: 20px;
  bottom: 0;
  margin: auto;
  display: flex;
  .icon {
    display: flex;
    flex-direction: column;
    justify-content: center;
    flex: 1;
    height: 150px;
    align-items: center;
    .null {
      width: 92px;
      height: 62px;
    }
    .name {
      margin-top: 18px;
      font-size: 14px;
      color: #D0DBEE;
    }
  }
}
</style>
