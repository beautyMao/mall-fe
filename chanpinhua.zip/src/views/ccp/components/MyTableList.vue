<template>
  <div class="my-table1">
    <el-table
      ref="reorder_table"
      :data="sortChange"
      max-height="240"
      @sort-change="handleSort"
    >
      <el-table-column
        prop="engineer_info.engineer_code"
        class-name="oneCol"
        label="员工ID"
        fixed
        width="100"
        sortable
      />
      <el-table-column
        prop="engineer_info.engineer_name"
        class-name="oneCol"
        label="姓名"
        fixed
        width="100"
        sortable="custom"
      />
      <!--<el-table-column-->
      <!--prop="engineer_info.job_position"-->
      <!--class-name="oneCol"-->
      <!--label="岗位"-->
      <!--fixed-->
      <!--width="120"-->
      <!--sortable="custom"-->
      <!--/>-->
      <!--<el-table-column-->
      <!--prop="engineer_info.group_name"-->
      <!--class-name="oneCol"-->
      <!--label="小组"-->
      <!--fixed-->
      <!--width="160"-->
      <!--sortable="custom"-->
      <!--/>-->
      <el-table-column
        prop="engineer_info.now_status"
        class-name="oneCol oneBor"
        label="当前状态时长"
        fixed
        sortable="custom"
        width="130"
      >
        <template slot-scope="scope">
          <span
            v-if="scope.row.engineer_info.now_status"
            :style="{color:scope.row.engineer_info.now_keep_color}"
          >{{ scope.row.engineer_info.now_status }} - {{ scope.row.engineer_info.now_keep_time }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        v-if="statuType"
        prop="engineer_info.wait_num"
        class-name="oneCol"
        label="点选排队量"
        width="120"
        sortable
      />
      <el-table-column
        v-if="statuType"
        prop="engineer_info.chat_free"
        class-name="oneCol oneBor"
        label="空闲/会话上限"
        width="128"
        sortable="custom"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.engineer_info.chat_free }} / {{ scope.row.engineer_info.chat_limit }}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="engineer_emotion.now_not_at_all"
        class-name="twoCol"
        label="愤怒当前"
        width="100"
        sortable
      />
      <el-table-column
        prop="engineer_emotion.count_not_at_all"
        class-name="twoCol"
        label="愤怒累计"
        width="100"
        sortable
      />
      <el-table-column
        prop="engineer_emotion.now_slightly"
        class-name="twoCol"
        label="不满当前"
        width="100"
        sortable
      />
      <el-table-column
        prop="engineer_emotion.count_slightly"
        class-name="twoCol"
        label="不满累计"
        width="100"
        sortable
      />
      <el-table-column
        prop="engineer_emotion.now_moderately"
        class-name="twoCol"
        label="正常当前"
        width="100"
        sortable
      />
      <el-table-column
        prop="engineer_emotion.count_moderately"
        class-name="twoCol"
        label="正常累计"
        width="100"
        sortable
      />
      <el-table-column
        prop="engineer_emotion.now_very"
        class-name="twoCol"
        label="愉悦当前"
        width="100"
        sortable
      />
      <el-table-column
        prop="engineer_emotion.count_very"
        class-name="twoCol"
        label="愉悦累计"
        width="100"
        sortable
      />
      <el-table-column
        prop="engineer_emotion.now_extremely"
        class-name="twoCol"
        label="惊喜当前"
        width="100"
        sortable
      />
      <el-table-column
        prop="engineer_emotion.count_extremely"
        class-name="twoCol"
        label="惊喜累计"
        width="100"
        sortable
      />
      <el-table-column
        label="情感详情"
        class-name="twoCol oneBor"
        width="100"
      >
        <template slot-scope="scope">
          <el-popover
            placement="right"
            width=""
            popper-class="Mbox"
            trigger="click"
          >
            <i
              class="el-icon-close icoRight"
              @click="closed($event)"
            />
            <el-table
              :data="scope.row.engineer_sessions"
              max-height="200px"
            >
              <el-table-column
                width="100"
                prop="session_id"
                label="会话ID"
              />
              <el-table-column
                width="100"
                prop="engineer_code"
                label="工程师ID"
              />
              <el-table-column
                width="100"
                prop="engineer_name"
                label="工程师姓名"
              />
              <el-table-column
                width="100"
                prop="group_name"
                label="技能组"
              />
              <el-table-column
                width="100"
                prop="status"
                label="会话状态"
              />
              <el-table-column
                width="100"
                prop="talk_time"
                label="会话持续时间"
              />
              <el-table-column
                width="100"
                prop="emotion"
                label="用户情感"
              />
            </el-table>
            <a
              slot="reference"
              class="checkbox"
            >查看详情</a>
          </el-popover>
        </template>
      </el-table-column>
      <!--<el-table-column-->
      <!--v-if="statuType"-->
      <!--prop="engineer_monitor.timeout_num"-->
      <!--class-name="threeCol"-->
      <!--label="会话超时数量"-->
      <!--width="120"-->
      <!--sortable-->
      <!--/>-->
      <!--<el-table-column-->
      <!--v-if="statuType"-->
      <!--prop="engineer_monitor.longest_time"-->
      <!--class-name="threeCol"-->
      <!--label="当前最长会话"-->
      <!--width="120"-->
      <!--&gt;-->
      <!--<template slot-scope="scope">-->
      <!--{{ scope.row.engineer_monitor.longest_time }}-{{ scope.row.engineer_monitor.longest_case ? scope.row.engineer_monitor.longest_case: '暂无' }}-->
      <!--</template>-->
      <!--</el-table-column>-->
      <!--<el-table-column-->
      <!--v-if="statuType"-->
      <!--prop="engineer_monitor.reply_timeout_num"-->
      <!--class-name="threeCol"-->
      <!--label="回复超时数量"-->
      <!--width="120"-->
      <!--sortable-->
      <!--/>-->
      <!--<el-table-column-->
      <!--v-if="statuType"-->
      <!--prop="engineer_monitor.reply_timeout_num"-->
      <!--class-name="threeCol oneBor"-->
      <!--label="未回复时长"-->
      <!--width="100"-->
      <!--/>-->
      <el-table-column
        v-if="!statuType"
        prop="engineer_monitor.call_num"
        class-name="threeCol"
        label="通话话量"
        width="120"
        sortable
      />
      <el-table-column
        v-if="!statuType"
        prop="engineer_monitor.callin_num"
        class-name="threeCol"
        label="呼入量"
        width="120"
        sortable
      />
      <el-table-column
        v-if="!statuType"
        prop="engineer_monitor.callout_num"
        class-name="threeCol"
        label="呼出量"
        width="120"
        sortable
      />
      <!-- <el-table-column prop="engineer_monitor.callout_rate" v-if="!statuType"  class-name="threeCol oneBor" label="外呼比例" width="120" sortable></el-table-column> -->
      <el-table-column
        v-if="!statuType"
        prop="engineer_monitor.ioe_callout_rate"
        class-name="threeCol"
        label="IOE-呼出占比"
        width="180"
      />
      <el-table-column
        v-if="!statuType"
        prop="engineer_monitor.crs_callout_rate"
        class-name="threeCol"
        label="CRS-呼出占比"
        width="180"
      />

      <el-table-column
        v-if="statuType"
        prop="engineer_efficient.count_service_num"
        class-name="fourCol"
        label="累计服务量"
        width="100"
      />
      <el-table-column
        prop="engineer_efficient.work_power"
        label="产能"
        class-name="fourCol"
        width="100"
      />
      <el-table-column
        v-if="!statuType"
        prop="engineer_efficient.callin_work_power"
        label="呼入产能"
        class-name="fourCol"
        width="100"
      />
      <el-table-column
        v-if="!statuType"
        prop="engineer_efficient.callout_work_power"
        label="呼出产能"
        class-name="fourCol"
        width="100"
      />
      <el-table-column
        v-if="!statuType"
        prop="engineer_efficient.callin_avg_time"
        label="呼入AHT"
        class-name="fourCol"
        width="100"
      />
      <el-table-column
        v-if="!statuType"
        prop="engineer_efficient.callout_avg_time"
        label="呼出AHT"
        class-name="fourCol"
        width="100"
      />
      <el-table-column
        v-if="statuType"
        prop="engineer_efficient.agv_handle_time"
        class-name="fourCol"
        label="平均处理时长"
        width="100"
      />
      <el-table-column
        prop="engineer_efficient.work_rate"
        label="座席利用率"
        class-name="fourCol oneBor"
        width="100"
      />
      <el-table-column
        prop="engineer_status.online_time"
        label="就绪总时长"
        class-name="fiveCol"
        width="100"
      >
        <template slot-scope="scope">
          <span :style="{color:scope.row.engineer_status.online_color}">
            {{ scope.row.engineer_status.online_time }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        v-if="!statuType"
        prop="engineer_status.acw_time"
        class-name="fiveCol"
        label="案面总时长"
        width="100"
      >
        <template slot-scope="scope">
          <span :style="{color:scope.row.engineer_status.acw_color}">
            {{ scope.row.engineer_status.acw_time }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        v-if="!statuType"
        prop="engineer_status.acw_avg_time"
        class-name="fiveCol"
        label="平均案面时长"
        width="100"
      />
      <el-table-column
        v-if="!statuType"
        prop="engineer_status.hold_time"
        class-name="fiveCol"
        label="hold总时长"
        width="100"
      >
        <template slot-scope="scope">
          <span :style="{color:scope.row.engineer_status.hold_color}">
            {{ scope.row.engineer_status.hold_time }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        v-if="statuType"
        prop="engineer_status.hangup_time"
        class-name="fiveCol"
        label="挂起总时长"
        width="100"
      >
        <template slot-scope="scope">
          <span :style="{color:scope.row.engineer_status.hangup_color}">
            {{ scope.row.engineer_status.hangup_time }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        prop="engineer_status.rest_time"
        label="小休总时长"
        class-name="fiveCol"
        width="100"
      >
        <template slot-scope="scope">
          <span :style="{color:scope.row.engineer_status.rset_color}">
            {{ scope.row.engineer_status.rest_time }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        prop="engineer_status.rest_num"
        label="小休次数"
        class-name="fiveCol"
        width="100"
      />
      <el-table-column
        prop="engineer_status.rest_rate"
        label="小休比例"
        class-name="fiveCol"
        width="100"
      />
      <el-table-column
        v-if="!statuType"
        prop="engineer_status.call_time"
        class-name="fiveCol"
        label="通话总时长"
        width="100"
      >
        <template slot-scope="scope">
          <span :style="{color:scope.row.engineer_status.call_color}">
            {{ scope.row.engineer_status.call_time }}
          </span>
        </template>
      </el-table-column>
      <el-table-column
        prop="engineer_status.login_time"
        label="登录总时长"
        class-name="fiveCol"
        width="100"
      />
      <el-table-column
        prop="engineer_status.first_login_at"
        label="首次登录时间"
        class-name="fiveCol"
        width="180"
      />
      <el-table-column
        prop="engineer_status.first_offline_at"
        label="首次离线时间"
        class-name="fiveCol"
        width="180"
      />
      <el-table-column
        prop="engineer_status.last_offline_at"
        label="最后离线时间"
        class-name="fiveCol"
        width="180"
      />
    </el-table>
  </div>
</template>
<script>
  export default {
    name: 'my-table-list',
    props: {
      sortChange: {
        type: Array,
        default: () => []
      },
      sortKey: {
        type: Number,
        default: 0
      },
      statuType: {
        type: Number,
        default: 0
      }
    },
    data() {
      return {
      }
    },
    mounted() {
    // console.log(this.statuType)
    },
    methods: {
      handleSort({ column, prop, order }) {
        // console.log({ column, prop, order })
        this.$emit('sortchange', [this.sortKey, { column, prop, order }])
      },
      closed(e) {
        e.currentTarget.parentElement.style.display = 'none'
      }
    }

  }
</script>
<style scoped>
.icoRight {
  position: absolute;
  right: 3px;
  top: 3px;
  cursor: pointer;
  z-index: 33;
}
.checkbox {
  color: #3e8ddd;
}
</style>
