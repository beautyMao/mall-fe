<template>
  <el-dialog
    ref="my-dialog"
    v-loading="dialogLoading"
    :title="title"
    custom-class="el-dialog-aside"
    :visible.sync="dialogTableVisible"
    :before-close="() => void $emit('close')"
  >
    <el-tabs v-model="activeName" type="card">

      <el-tab-pane label="直接添加" name="addById">
        <el-autocomplete
          v-model.trim="searchEngineersText"
          class="inline-input"
          :fetch-suggestions="querySearch"
          placeholder="请输入员工姓名、员工编号"
          :trigger-on-focus="false"
          :style="{width: '80%'}"
          popper-class="select-option"
          @keyup.enter.native="onSearchEngineers"
          @select="handleSelectEngineers"
        >
          <template slot-scope="{ item }">
            <div popper-class="name">{{ item.name }}，{{ item.code }}，{{ item.businesses }}</div>
          </template>
        </el-autocomplete>

        <el-button :disabled="searchEngineersCode ? false : true " @click="onSearchEngineers">添加</el-button>

      </el-tab-pane>
      <!-------------------通过业务添加 tab------------------------>
      <el-tab-pane label="通过业务添加" name="addByQueueId">
        <el-select
          v-model="business_id"
          filterable
          placeholder="请选择业务线"
          :style="{width: '100%'}"
          @change="handleBusinessChange"
        >
          <el-option
            v-for="(item, index) in businessList"
            :key="index"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
        <h4 v-show="business_id">请选择您要添加的客服</h4>
        <el-table
          v-show="business_id"
          ref="engineersTable"
          v-loading="engineersByQueueLoading"
          :data="engineersByQueueTableDate"
          tooltip-effect="dark"
          max-height="260"
          :header-cell-style="{background: 'white'}"
          style="width: 100%;"
          @select="handleengineersByQueueSelect"
          @select-all="handleengineersByQueueSelect"
        >
          <el-table-column label="客服列表" align="center">
            <el-table-column label="全部">
              <template slot-scope="scope">
                <span>{{ `${scope.row.name},   ${scope.row.code}` }}</span>
              </template>
            </el-table-column>
            <el-table-column
              type="selection"
              width="80"
            />
          </el-table-column>
        </el-table>
      </el-tab-pane>
    </el-tabs>
    <div style="overflow: hidden">
      <h4 class="fl">客服选择列表</h4>
      <h4 class="fr" style="color: #3E8DDD;" @click="clearEngineersData">清空列表</h4>
    </div>

    <el-table
      :data="engineersRows"
      style="width: 100%;border:1px solid rgba(220,223,230,1);"
      max-height="260"
    >
      <el-table-column
        prop="name"
        label="客服姓名"
      />
      <el-table-column
        prop="code"
        label="编号"
      />
      <el-table-column
        prop="roles"
        label="角色"
      />
      <el-table-column
        prop="businesses"
        label="业务"
      />
      <el-table-column
        label="操作"
      >
        <template slot-scope="scope">
          <el-button
            type="text"
            size="small"
            @click.native.prevent="deleteRow(scope.$index,scope)"
          >
            移除
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <div slot="footer" class="dialog-footer">
      <el-button @click="$emit('close')">取 消</el-button>
      <el-button type="primary" @click="onData">提 交</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import { searchApiWbStructureBusiness, searchApiWbEngineersByBusiness, postApiWbQueuesAddEngineers, getAccountSearch } from '@/api/skill-group-management'

  export default {
    name: 'skill-engineers-dialog',
    props: {
      visible: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        title: '添加客服',
        activeName: 'addById',
        dialogTableVisible: true,
        businessList: [],
        business_id: '',
        dialogLoading: false,
        engineersByQueueLoading: false,
        searchEngineersText: '',
        searchEngineersCode: '',
        engineersByQueueTableDate: [],
        engineersByQueueTableSelection: [],
        engineersRows: [],
        queueId: this.$route.query.eid,
        selectEngineers: [],
        restaurants: []
      }
    },
    mounted() {
      this.fetchDialogData()
    },
    methods: {
      fetchDialogData() {
        // 获取 业务 列表
        searchApiWbStructureBusiness().then(response => {
          this.businessList = response.data
        }).catch(this.$message.error)
      },
      async onData() {
        if (this.engineersRows.length === 0) {
          this.$message({
            message: '请选择添加客服',
            type: 'error'
          })
          return
        }

        const engineerArr = this.engineersRows.map(item => {
          return {
            engineer_code: item.code,
            queue_level: 3
          }
        })
        const data = { queue_id: this.queueId, engineer: engineerArr }
        await postApiWbQueuesAddEngineers(data).then(response => {
          this.$message({
            message: '客服数据添加成功',
            type: 'success'
          })
          this.$emit('close')
        }).catch(this.$message.error)
      },
      handleSelectionChange(val) { // 查询结果选择框
        this.engineersByQueueTableSelection = val
      },
      async handleBusinessChange(val) {
        await searchApiWbEngineersByBusiness({ business_id: val }).then(response => {
          if (Array.isArray(response.data)) {
            this.engineersByQueueTableDate = response.data
          } else {
            this.engineersByQueueTableDate = []
          }
        }).catch(this.$message.error)
      },
      handleengineersByQueueSelect(rows) {
        this.engineersRows = this.combineArray(rows, this.selectEngineers)
      },
      deleteRow(index, rows) {
        this.engineersRows.splice(index, 1)
        this.selectEngineers.forEach((item, index) => {
          if (item.code === rows.row.code) {
            this.selectEngineers.splice(index, 1)
          }
        })
        this.engineersByQueueTableDate.forEach(item => {
          if (item.code === rows.row.code) {
            this.$refs.engineersTable.toggleRowSelection(rows.row)
          }
        })
      },
      clearEngineersData() {
        this.engineersRows = []
        this.selectEngineers = []
        this.engineersByQueueTableDate = []
        this.business_id = ''
      },
      onSearchEngineers() {
        if (this.searchEngineersCode === '') {
          this.$message({
            message: '没有此客服，请确认信息后在进行查询。',
            type: 'error'
          })
          return
        }
        const data = this.searchEngineersCode
        getAccountSearch({ input: data }).then(response => {
          if (response.data.length === 0) {
            this.$message({
              message: '没有此客服，请确认信息后在进行查询。',
              type: 'warning'
            })
          } else {
            this.searchEngineersText = ''
            const resdata = response.data
            this.searchEngineersCode = ''
            // 跟插入的数组进行查重 如果不重复就插入
            resdata.forEach(item => {
              if (JSON.stringify(this.selectEngineers).indexOf(JSON.stringify(item)) === -1) {
                this.selectEngineers.push(item)
              }
            })
            this.engineersRows = this.combineArray(this.selectEngineers, this.engineersRows)
          }
        }).catch(this.$message.error)
      },
      combineArray(newArr, oldArr) {
        const codeValues = oldArr.map(item => item.code)
        const noRepeatArray = [...oldArr]
        newArr.forEach((obj) => {
          if (!codeValues.includes(obj.code)) {
            noRepeatArray.push(obj)
          }
        })
        return noRepeatArray
      },
      querySearch(queryString, cb) {
        getAccountSearch({ input: queryString }).then(response => {
          if (response.data.length === 0) this.searchEngineersCode = ''
          cb(response.data)
        }).catch(this.$message.error)
      },
      handleSelectEngineers(item) {
        this.searchEngineersText = `${item.name}，${item.code}，${item.businesses}`
        this.searchEngineersCode = item.code
      }
    }
  }
</script>

<style lang="scss">
.select-option{
  .el-scrollbar__wrap{
    overflow-x: scroll;
    .el-scrollbar__view{
      min-width: 450px!important;
    }
  }
}
</style>
