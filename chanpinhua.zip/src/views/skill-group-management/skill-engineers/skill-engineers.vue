<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div id="organizational-structure" class="app-container">
    <header>
      <h1>管理客服 <small>当前技能组：{{ name }}</small></h1>
      <div class="flex-wrp">
        <el-button type="primary" plain @click="addVisible = true">新增客服</el-button>
        <el-input
          v-model.trim="searchText"
          placeholder="输入编号或姓名搜索客服"
          prefix-icon="el-icon-search"
          @keyup.enter.native="onSearch(searchText)"
        />
      </div>
    </header>

    <EngineersViewTable
      :list-data="tableDataList"
      :data="localTableData"
      @change="handleCurrentChange"
      @handleSizeChange="handleSizeChange"
      @delete="handleDelete"
      @goEditEngineers="itemRedact"
    />

    <PublicViewDialog v-if="addVisible" title="新增客服" @close="dialogClose" />
    <v-dialog v-if="createEditorInfo.createEditor" v-bind="createEditorInfo" @closeDialog="closeDialog" />
  </div>
</template>

<script>
  import {
    postApiSkillEngineers,
    delApiWbQueueEngineerId
  } from '@/api/skill-group-management'
  import EngineersViewTable from '@/views/skill-group-management/skill-engineers/skill-engineers-table'
  import PublicViewDialog from '@/views/skill-group-management/skill-engineers/skill-engineers-dialog'
  import vDialog from '@/views/queue-management/account/components/v-dialog'

  export default {
    name: 'skill-engineers',
    components: { EngineersViewTable, PublicViewDialog, vDialog },
    data() {
      return {
        name: this.$route.query.ename,
        queue_id: this.$route.query.eid,
        engId: this.$store.getters.allInfo.code, // 客服id
        searchText: '',
        addVisible: false,
        tableDataList: {
          case_list: [],
          current_page: 1,
          size: 10,
          total: 0
        },
        currentData: {
          page: 1,
          pageSize: 10
        },
        localTableData: [],
        createEditorInfo: {
          createEditor: false,
          title: '创建账户',
          code: ''
        }
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        const sendData = {
          queue_id: this.queue_id,
          engineer_code: this.engId,
          code: this.searchText,
          ...this.currentData
        }
        postApiSkillEngineers(sendData).then(this.renderTable).catch(this.$message.error)
      },
      renderTable(res) {
        this.tableDataList = res.data
        this.currentData.page = res.data.current_page
        this.currentData.pageSize = res.data.per_page
      },
      onSearch() {
        this.fetchData()
      },
      handleCurrentChange(page) {
        this.currentData.page = page
        const sendData = {
          queue_id: this.queue_id,
          engineer_code: this.engId,
          code: this.searchText,
          ...this.currentData
        }
        postApiSkillEngineers(sendData).then(this.renderTable).catch(this.$message.error)
      },
      dialogClose() {
        this.addVisible = false
        this.fetchData()
      },
      handleSizeChange(size) {
        this.currentData.pageSize = size
        this.currentData.page = 1
        const sendData = {
          queue_id: this.queue_id,
          engineer_code: this.engId,
          code: this.searchText,
          ...this.currentData
        }
        postApiSkillEngineers(sendData).then(this.renderTable).catch(this.$message.error)
      },
      closeDialog(val) {
        if (val) {
          this.fetchData()
        }
        this.createEditorInfo.createEditor = false
      },
      itemRedact(index, row) {
        this.createEditorInfo.title = '编辑账户'
        this.createEditorInfo.code = row.code
        this.createEditorInfo.createEditor = true
      },
      handleDelete(index, row) {
        const data = {
          engineer_code: row.code,
          queue_id: this.queue_id
        }
        this.$confirm(`确定删除【${row.name}】客服吗?此操作无法撤销！`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          delApiWbQueueEngineerId(data).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
          }).catch(this.$message.error)
        }).catch(() => {})
      }
    }
  }
</script>
<style lang="scss" scoped>
.l30{
  line-height: 30px;
  margin: 0;
}

.input {
    width: 360px;
    height: 40px;
    & /deep/ .el-input__inner {
      height: 40px;
      line-height: 40px;
    }
  }

</style>
