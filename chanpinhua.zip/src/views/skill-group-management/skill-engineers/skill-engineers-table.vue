<template>
  <el-card>
    <el-table
      ref="my-table"
      :data="listData.data"
      style="width: 100%"
    >
      <el-table-column
        type="index"
        :index="indexMethod"
      />
      <el-table-column
        label="客服姓名"
        width="200"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.is_edit === 0">{{ scope.row.name }}</span>
          <span v-else class="blue" @click="goEditEngineers(scope.$index, scope.row)">{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="客服编号"
        width="160"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.code }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="所属二级业务部门"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.business_name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="客服所在其他技能组"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.queue_name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="text"
            class="el-del"
            @click="handleDelete(scope.$index, scope.row)"
          >移除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      :current-page="listData.current_page"
      :page-size="listData.size"
      :page-sizes="[10, 15, 20, 25]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="listData.total"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </el-card>
</template>

<script>
  export default {
    name: 'skill-engineers-table',
    props: {
      listData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {}
    },
    methods: {
      indexMethod(index) {
        return index + 1
      },
      handleEdit(index, row) {
        this.$emit('edit', index, row)
      },
      handleDelete(index, row) {
        this.$emit('delete', index, row)
      },
      goEditEngineers(index, row) {
        this.$emit('goEditEngineers', index, row)
      },
      currentChange(val) {
        this.$emit('change', val)
      },
      handleSizeChange(val) {
        this.$emit('handleSizeChange', val)
      }
    }
  }
</script>

<style lang="scss" scoped>
.blue{
  color: #3E8DDD;
}
</style>
