<template>
  <el-card>
    <el-table
      ref="my-table"
      :data="data"
    >
      <el-table-column
        type="index"
        :index="indexMethod"
      />
      <el-table-column
        label="编号"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.code }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="名称"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="建立时间"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.created_at }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="工作时间"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.work_start_at }}-{{ scope.row.work_end_at }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="所属业务"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.business_name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="创建人"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.engineer_name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="全部客服数"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.customer_number }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="通路"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.access_name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="排队规则"
        width="150"
      >
        <template slot-scope="scope">
          <el-popover trigger="hover" placement="top">
            <p>{{ scope.row.transfer===1?`转接至本组`:'拒绝转接至本组' }}，{{ scope.row.pick===1?`点选客服`:'拒绝点选客服' }}，{{
              scope.row.visible===1?`C端可见`:'C端不可见' }}，{{ scope.row.transfer===1?`接受转接，排队上限 ${scope.row.time_limit}
              分钟`:'拒绝转接' }}</p>
            <div slot="reference" class="name-wrapper">
              {{ scope.row.transfer===1?`转接至本组`:'拒绝转接至本组' }}，{{ scope.row.pick===1?`点选客`:'拒绝点' }}…
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="150">
        <template slot-scope="scope">
          <el-button
            type="text"
            :disabled="!permission.edit"
            @click="handleEdit(scope.$index, scope.row)"
          >编辑
          </el-button>
          <el-button
            type="text"
            @click="handleEditEngineers(scope.$index, scope.row)"
          >管理客服
          </el-button>
          <el-button
            type="text"
            class="el-del"
            :disabled="!permission.delete"
            @click="handleDelete(scope.$index, scope.row)"
          >删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      :current-page="myPagination.current_page"
      :page-size="myPagination.datanum"
      :page-sizes="[10, 15, 20, 25]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="myPagination.total"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </el-card>
</template>

<script>
  export default {
    name: 'public-view-table',
    props: {
      data: {
        type: Array,
        required: true
      },
      myPagination: {
        type: Object,
        required: true
      },
      permission: {
        type: Object,
        required: true
      }
    },
    data() {
      return {}
    },
    methods: {
      indexMethod(index) {
        return index + 1
      },
      handleEdit(index, row) {
        this.$emit('edit', index, row)
      },
      handleEditEngineers(index, row) {
        this.$emit('editEngineers', index, row)
      },
      handleDelete(index, row) {
        this.$emit('delete', index, row)
      },
      currentChange(val) {
        this.$emit('change', val)
      },
      handleSizeChange(val) {
        this.$emit('size-change', val)
      }
    }
  }
</script>
