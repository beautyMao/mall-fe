<template>
  <div id="jnz-dialog" class="my-dialog">
    <!-- Form -->
    <el-dialog
      ref="my-dialog"
      :title="title"
      custom-class="pr30 el-dialog-aside"
      :visible.sync="visible"
      :before-close="() => void $emit('close')"
    >
      <el-form
        ref="form"
        :model="data"
        :rules="rules"
        @submit.native.prevent
      >
        <el-form-item
          label="技能组名称"
          prop="name"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="data.name"
            placeholder="仅支持中英文和数字的组合，30字符内"
            type="text"
            auto-complete="off"
          />
        </el-form-item>
        <el-form-item
          label="服务方式"
          prop="type"
          :label-width="formLabelWidth"
        >
          <el-radio-group v-model="data.type">
            <el-radio :label="1">文本</el-radio>
          </el-radio-group>
        </el-form-item>
        <el-form-item
          label="业务选择"
          prop="business_id"
          class="form-item1"
          placeholder="请选择业务"
          :label-width="formLabelWidth"
        >
          <el-cascader
            v-model="data.business_id"
            :show-all-levels="false"
            :options="business"
            :props="cascaderAlias"
            change-on-select
          />
        </el-form-item>
        <el-form-item label="通路" prop="access_id" :label-width="formLabelWidth">
          <el-select
            v-model="data.access_id"
            filterable
            placeholder="请选择通路"
            :style="{width: '100%'}"
          >
            <el-option v-for="(item, index) in selectData.roadList" :key="index" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="排队时间上限" prop="time_limit" :label-width="formLabelWidth">
          <el-input-number
            v-model="data.time_limit"
            controls-position="right"
            :min="1"
            :max="120"
            :style="{width: '84%'}"
          />
          分钟
        </el-form-item>
        <el-form-item label="服务时间" :label-width="formLabelWidth">
          <el-col :span="24" style="margin-bottom: 10px;">
            <el-select v-model="data.workday" value="" multiple collapse-tags placeholder="请选择">
              <el-option
                v-for="item in options"
                :key="item.value"
                :label="item.label"
                :value="item.value"
              />
            </el-select>
          </el-col>
          <el-col :span="11">
            <el-form-item prop="work_start_at">
              <el-time-select
                :key="Math.round()"
                v-model="data.work_start_at"
                value-format="HH:mm"
                :style="{width: '100%'}"
                placeholder="起始时间"
                :picker-options="{
                  start: '00:00',
                  step: '00:30',
                  end: '24:00',
                  format: 'HH:mm'
                }"
                @change="() => $refs.form.validate(valid => valid)"
              />
            </el-form-item>
          </el-col>
          <el-col class="line" :span="2">-</el-col>
          <el-col :span="11">
            <el-form-item prop="work_end_at">
              <el-time-select
                :key="Math.round()"
                v-model="data.work_end_at"
                value-format="HH:mm"
                :style="{width: '100%'}"
                placeholder="结束时间"
                :picker-options="{
                  start: '00:00',
                  step: '00:30',
                  end: '24:00',
                  format: 'HH:mm',
                  minTime: data.work_start_at
                }"
                @change="() => $refs.form.validate(valid => valid)"
              />
            </el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item
          label="队列图标"
          prop="icon_url"
          :label-width="formLabelWidth"
        >
          <el-upload
            class="avatar-uploader"
            :action="`${upLoadImg}?token=${getToken()}`"
            :show-file-list="false"
            :on-success="onUpLoadImg"
            :before-upload="beforeUpload"
            :on-change="() => $refs.form.validate(valid => valid)"
          >
            <img v-if="data.icon_url" :src="data.icon_url" class="avatar">
            <i v-else class="el-icon-plus avatar-uploader-icon" />
          </el-upload>
        </el-form-item>
        <div class="flex-wrp flex-between flex-wrap">
          <el-form-item label="转接至本组" :style="{width: '50%'}" :label-width="formLabelWidth">
            <el-switch
              v-model="data.transfer"
              class="el-switch--mark"
              :active-value="1"
              :inactive-value="2"
            />
          </el-form-item>
          <el-form-item label="点选客服" :style="{width: '50%'}" :label-width="formLabelWidth">
            <el-switch
              v-model="data.pick"
              class="el-switch--mark"
              :active-value="1"
              :inactive-value="2"
            />
          </el-form-item>
          <el-form-item label="C端可见" :style="{width: '50%'}" :label-width="formLabelWidth">
            <el-switch
              v-model="data.visible"
              class="el-switch--mark"
              :active-value="1"
              :inactive-value="2"
            />
          </el-form-item>
          <!--  <el-form-item label="坐席全忙时使用机器人" :label-width="formLabelWidth">
            <el-switch
              v-model="data.busy_to_robot"
              :active-value="1"
              :inactive-value="2"
            />
          </el-form-item> -->
          <el-form-item label="是否支持点评" :style="{width: '50%'}" :label-width="formLabelWidth">
            <el-switch
              v-model="data.comment"
              class="el-switch--mark"
              :active-value="1"
              :inactive-value="2"
            />
          </el-form-item>
        </div>
        <el-form-item label="欢迎语" prop="welcome_words" :label-width="formLabelWidth">
          <el-input v-model="data.welcome_words" type="textarea" placeholder="请输入内容（限 300 字）" maxlength="300" />
        </el-form-item>
        <el-form-item label="结束语" prop="end_words" :label-width="formLabelWidth">
          <el-input v-model="data.end_words" type="textarea" placeholder="请输入内容（限 300 字）" maxlength="300" />
        </el-form-item>
        <p v-pre style="margin-left: 120px;;margin-top: -10px;">
          注：<br>1.最多不超过300个字符；<br>2.如输入{{queueName}}则显示技能组名称，{{serviceName}}显示当前客服姓名，{{serviceCode}}显示客服工号。
        </p>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="$emit('close')">取 消</el-button>
        <el-button class="submit" type="primary" @click="onData">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { getToken } from '@/utils/auth'
  import { upLoadImg } from '@/api/public'
  import { getAllAccess, getStructureBusiness } from '@/api/skill-group-management'
  import myAccessDialog from '@/views/queue-management/components/myAccessDialog'

  export default {
    name: 'skill-group-management-dialog',
    components: { myAccessDialog },
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      myData: {
        type: Object,
        default() {
          return {
            business_id: [],
            business_name: '',
            channel_id: '',
            access_id: '',
            type: 1,
            name: '',
            workday: [],
            work_start_at: '09:00',
            work_end_at: '18:00',
            callback: 1,
            time_limit: 60,
            big_customer: 2,
            consult: 1,
            pick: 2,
            transfer: 1,
            visible: 1,
            icon_url: '',
            busy_to_robot: 2,
            comment: 1,
            welcome_words: '您好！您已进入{{queueName}}组，客服{{serviceName}}（工号{{serviceCode}}）很荣幸为您服务！',
            end_words: '您已结束当前会话，再次感谢您的咨询，祝您生活愉快！'
          }
        }
      },
      title: {
        type: String,
        default: ''
      }
    },
    data() {
      const validate_time_limit = (rule, value, callback) => {
        if (this.data.transfer === 1 && value <= 0) {
          callback(new Error('排队时间上限不能小于等于 0'))
        } else {
          callback()
        }
      }

      return {
        data: JSON.parse(JSON.stringify(this.myData)),
        formLabelWidth: '120px',
        selectData: {
          roadList: [],
          businessList: []
        },
        dialogBusinessFormVisible: false,
        dialogBusinessForm: {
          name: ''
        },
        getToken,
        upLoadImg,
        businessLoading: false,
        business: [], // 业务
        business_id: [],
        business_name: '',
        type: '',
        cascaderAlias: {
          checkStrictly: true,
          value: 'id',
          label: 'name',
          children: 'childs'
        },
        rules: {
          type: [{ required: true, trigger: 'change', message: '请选择服务方式' }],
          name: [{ required: true, trigger: 'blur', message: '请选择技能组名称' }],
          business_id: [{ required: true, trigger: 'change', message: '请选择业务' }],
          access_id: [{ required: true, trigger: 'change', message: '请选择通路' }],
          work_start_at: [{ trigger: 'change', message: '请选择服务开始时间' }],
          work_end_at: [{ trigger: 'change', message: '请选择服务结束时间' }],
          time_limit: [{ validator: validate_time_limit, trigger: 'change' }],
          icon_url: [{ trigger: 'blur', message: '请上传队列图标' }],
          end_words: [{ required: true, trigger: 'change', message: '请输入结束语' }],
          welcome_words: [{ required: true, trigger: 'change', message: '请输入欢迎语' }]
        },
        options: [
          { value: '0', label: '周日' },
          { value: '1', label: '周一' },
          { value: '2', label: '周二' },
          { value: '3', label: '周三' },
          { value: '4', label: '周四' },
          { value: '5', label: '周五' },
          { value: '6', label: '周六' }
        ]
      }
    },
    watch: {
      visible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
        })
      },
      myData: {
        handler(newVal, oldVal) {
          this.data = JSON.parse(JSON.stringify(newVal))
          this.data.business_id = this.data.business_id.map(item => parseInt(item))
        },
        deep: true
      }
    },
    mounted() {
      this.fetchDialogData()
    },
    methods: {
      fetchDialogData() {
        // 获取 业务 列表
        getStructureBusiness().then(res => { // 获取业务列表-组织结构
          this.business = this.getTreeData(res.data)
        })
        // 获取 通路 列表
        getAllAccess().then(response => {
          this.$set(this.selectData, 'roadList', response.data)
        }).catch(this.$message.error)
      },
      onUpLoadImg(res, file) {
        this.$set(this.data, 'icon_url', URL.createObjectURL(file.raw))
      },
      beforeUpload(file) {
        const isImg = ['image/jpeg', 'image/png'].some(item => file.type === item)
        const isLt2M = file.size / 1024 / 1024 < 2

        if (!isImg) {
          this.$message.error('上传头像图片只能是 JPG/PNG 格式!')
        }
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!')
        }
        console.log(isImg, '222')
        return isImg && isLt2M
      },
      getTreeData(data) {
        // 循环遍历json数据
        for (var i = 0; i < data.length; i++) {
          if (data[i].childs.length < 1) {
            // children若为空数组，则将children设为undefined
            data[i].childs = undefined
          } else {
            // children若不为空数组，则继续 递归调用 本方法
            this.getTreeData(data[i].childs)
          }
        }
        return data
      },
      onData() {
        this.$refs.form.validate(valid => {
          if (valid) {
            this.$emit('change', this.data)
          } else {
            return false
          }
        })
      }
    }
  }
</script>
<style scoped lang="scss">
#jnz-dialog /deep/ {
  .el-textarea__inner{
      border: 1px solid #d9d9d9 !important;
  }
}
.my-dialog /deep/  {
    // 上传图片样式
    .avatar-uploader .el-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }

    .avatar-uploader .el-upload:hover {
      border-color: #409EFF;
    }

    .avatar-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      width: 100px;
      height: 100px;
      line-height: 100px;
      text-align: center;
    }

    .avatar {
      width: 100px;
      height: 100px;
      display: block;
    }

    .line {
      text-align: center;
    }
  }

  .form-item1 {
    .el-select {
      width: 100%;
    }
    .el-input-number--mini {
      width: 180px;
    }
    .el-cascader--mini{
      width: 180px;
    }
    .el-cascader--small{
      width: 100%;
    }
    /deep/ .el-input__inner {
      text-align: left;
      width: 100%;
    }
  }

</style>

