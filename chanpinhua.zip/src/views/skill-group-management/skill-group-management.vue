<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div class="app-container">
    <header>
      <h1>现有技能组共{{ totalNum }}个</h1>
      <div class="flex-wrp">
        <el-button type="primary" :disabled="!permission.create" plain @click="addVisible = true">新增技能组</el-button>
        <el-input
          v-model.trim="searchText"
          prefix-icon="el-icon-search"
          placeholder="输入编号或关键词搜索技能组"
          @keyup.enter.native="onSearch(searchText)"
        />
      </div>
    </header>
    <PublicViewDialog
      title="新增技能组"
      :visible="addVisible"
      @change="onDialogData"
      @close="addVisible = false"
    />

    <PublicViewTable
      :data="localTableData"
      :permission="permission"
      :my-pagination="myPagination"
      @change="handleCurrentChange"
      @size-change="handleSizeChange"
      @edit="handleEdit"
      @editEngineers="handleEditEngineers"
      @delete="handleDelete"
    />
    <PublicViewDialog
      :mode-disabled="true"
      title="编辑"
      :my-data="tableData"
      :visible="editVisible"
      @change="onTableData"
      @close="editVisible = false"
    />
  </div>
</template>

<script>
  import {
    delApiWbQueueId,
    getApiWbQueue,
    getApiWbQueueId,
    getApiWbQueueSearch,
    postApiWbQueue,
    putApiWbQueueId
  } from '@/api/skill-group-management'
  import PublicViewDialog from '@/views/skill-group-management/skill-group-management-dialog'
  import PublicViewTable from '@/views/skill-group-management/skill-group-management-table'

  export default {
    name: 'skill-management',
    components: { PublicViewDialog, PublicViewTable },
    data() {
      return {
        searchText: '',
        addVisible: false,
        tableDataList: [],
        tableData: {},
        editVisible: false,
        localTableData: [],
        totalNum: 0,
        myPagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        },
        permission: {
          create: false,
          delete: false,
          look: false,
          edit: false
        },
        queueRows: []
      }
    },
    mounted() {
      this.fetchData()
      this.init()
    },
    methods: {
      init() {
        for (const i of this.$store.getters.user.buttonPermission) {
          switch (i.keyword) {
          case 'queueCreate':
            this.permission.create = true
            break
          case 'queueDelete':
            this.permission.delete = true
            break
          case 'queueLook':
            this.permission.look = true
            break
          case 'queueEdit':
            this.permission.edit = true
            break
          }
        }
      },
      fetchData() {
        getApiWbQueue().then(response => {
          this.tableDataList = response.data
          this.myPagination.current_page = this.myPagination.current_page || 1
          this.totalNum = response.data.length
          this.localPagination()
        }).catch(this.$message.error)
      },
      onDialogData(data) {
        data.business_id = data.business_id[data.business_id.length - 1]
        postApiWbQueue(data).then(response => {
          this.fetchData()
          this.addVisible = false
        }).catch(this.$message.error)
      },
      onTableData(data) {
        data.business_id = data.business_id[data.business_id.length - 1]
        putApiWbQueueId(data.id, data).then(response => {
          this.fetchData()
          this.editVisible = false
        }).catch(this.$message.error)
      },
      onSearch(text) {
        getApiWbQueueSearch(text).then(response => {
          this.tableDataList = response.data
          this.myPagination.current_page = 1
          this.localPagination()
        }).catch(this.$message.error)
      },
      handleEdit(index, row) {
        this.editVisible = true
        getApiWbQueueId(row.id).then(response => {
          this.tableData = [response.data].map(item => {
            if (item.workday === '*') {
              item.workday = ['0', '1', '2', '3', '4', '5', '6']
            } else {
              item.workday = item.workday.split(',')
            }
            item.business_id = item.business_id === 0 ? '' : item.business_id
            item.channel_id = item.channel_id === 0 ? '' : item.channel_id
            item.access_id = item.access_id === 0 ? '' : item.access_id
            if (!item.business_id) {
              item.channel_id = ''
            }
            return item
          })[0]
        }).catch(this.$message.error)
      },
      handleEditEngineers(index, row) {
        this.$router.push({
          path: `/spot/skill-group-management/engineers`,
          query: {
            eid: row.id,
            ename: row.name
          }
        })
      },
      handleDelete(index, row) {
        this.$confirm(`确定删除【${row.name}】技能组吗？此操作无法撤销！`, '提示', {
          confirmButtonText: '确定删除',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          delApiWbQueueId(row.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      handleCurrentChange(val) {
        this.myPagination.current_page = val
        this.localPagination()
      },
      localPagination() {
        // 本地分页
        const number = (this.myPagination.current_page - 1) * this.myPagination.datanum
        this.localTableData = this.tableDataList.slice(number, number + this.myPagination.datanum)
        this.myPagination.total = this.tableDataList.length
      },
      handleSizeChange(val) {
        this.myPagination.datanum = val
        this.localPagination()
      }
    }
  }
</script>
