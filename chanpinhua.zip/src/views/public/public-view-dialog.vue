<template>
  <el-dialog
    ref="my-dialog"
    :title="title"
    custom-class="el-dialog-aside my-dialog"
    :visible.sync="visible"
    :before-close="() => void $emit('close')"
  >
    <el-form
      ref="form"
      :model="data"
      :rules="rules"
      @submit.native.prevent
    >
      <el-form-item
        label="业务选择"
        prop="business_id"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="data.business_id"
          filterable
          placeholder="请选择业务"
          :style="{width: '200px'}"
          :disabled="data.type == 2"
        >
          <el-option
            v-for="(item, index) in selectData.businessList"
            :key="index"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item v-show="!modeAllShow" label="通路选择" prop="access_id" :label-width="formLabelWidth">
        <el-select
          v-model="data.access_id"
          filterable
          placeholder="请选择通路"
          :style="{width: '200px'}"
          :disabled="data.type == 2"
        >
          <el-option v-for="(item, index) in selectData.roadList" :key="index" :label="item.name" :value="item.id" />
        </el-select>
      </el-form-item>
      <el-form-item v-show="!modeAllShow" label="队列名称" prop="name" :label-width="formLabelWidth">
        <el-input
          v-model.trim="data.name"
          placeholder="请输入队列名称"
          type="text"
          auto-complete="off"
          :disabled="data.type ==2"
        />
      </el-form-item>
      <el-form-item label="服务时间" :label-width="formLabelWidth" required>
        <el-col :span="11">
          <el-form-item prop="work_start_at">
            <el-time-select
              :key="Math.round()"
              v-model="data.work_start_at"
              value-format="HH:mm"
              :style="{width: '100%'}"
              placeholder="起始时间"
              :picker-options="{
                  start: '00:00',
                  step: '00:30',
                  end: '24:00',
                  format: 'HH:mm'
                }"
              @change="() => $refs.form.validate(valid => valid)"
            />
          </el-form-item>
        </el-col>
        <el-col class="line" :span="2">-</el-col>
        <el-col :span="11">
          <el-form-item prop="work_end_at">
            <el-time-select
              :key="Math.round()"
              v-model="data.work_end_at"
              value-format="HH:mm"
              :style="{width: '100%'}"
              placeholder="结束时间"
              :picker-options="{
                  start: '00:00',
                  step: '00:30',
                  end: '24:00',
                  format: 'HH:mm',
                  minTime: data.work_start_at
                }"
              @change="() => $refs.form.validate(valid => valid)"
            />
          </el-form-item>
        </el-col>
      </el-form-item>
      <div class="flex-wrp flex-between flex-wrap">
        <el-form-item v-if="data.type===1" label="是否C端可见" :label-width="formLabelWidth">
          <el-switch
            class="el-switch--mark"
            v-model="data.visible"
            :active-value="1"
            :inactive-value="2"
          />
        </el-form-item>
        <el-form-item v-if="data.type===1" label="点选" :label-width="formLabelWidth">
          <el-switch
            class="el-switch--mark"
            v-model="data.pick"
            :active-value="1"
            :inactive-value="2"
          />
        </el-form-item>
        <el-form-item label="转接至本队列" :label-width="formLabelWidth">
          <el-switch
            class="el-switch--mark"
            v-model="data.transfer"
            :active-value="1"
            :inactive-value="2"
          />
        </el-form-item>
      </div>
      <el-form-item v-show="data.transfer===1" label="排队时间上限" prop="time_limit" :label-width="formLabelWidth">
        <el-input-number
          v-model="data.time_limit"
          controls-position="right"
          :min="1"
          :max="120"
          :disabled="data.type === 2"
        />
        分钟
      </el-form-item>
      <el-form-item
        v-show="!modeAllShow"
        v-if="data.type===1"
        label="队列图标"
        prop="icon_url"
        :label-width="formLabelWidth"
      >
        <el-upload
          class="avatar-uploader"
          :action="`${upLoadImg}?token=${getToken()}`"
          :show-file-list="false"
          :on-success="onUpLoadImg"
          :before-upload="beforeUpload"
          :on-change="() => $refs.form.validate(valid => valid)"
        >
          <img v-if="data.icon_url" :src="data.icon_url" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon" />
        </el-upload>
      </el-form-item>
      <el-form-item v-if="data.type===1" label="欢迎语" prop="welcome_words" :label-width="formLabelWidth">
        <el-input v-model="data.welcome_words" type="textarea" :rows="4" placeholder="请输入内容（限 50 字）" maxlength="50" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="$emit('close')">取 消</el-button>
      <el-button class="submit" type="primary" @click="onData">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import { getToken } from '@/utils/auth'
  import { upLoadImg } from '@/api/public'
  import { getApiWbAccessAccessesByTypeType, postApiWbAccess } from '@/api/queue-management/access'
  import { getApiWbBusiness, postApiWbBusiness } from '@/api/queue-management/business'
  import myAccessDialog from '@/views/queue-management/components/myAccessDialog'

  export default {
    name: 'PublicViewDialog',
    components: { myAccessDialog },
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      myData: {
        type: Object,
        default() {
          return {
            type: 1,
            business_id: '',
            channel_id: '',
            access_id: '',
            name: '',
            work_start_at: '',
            work_end_at: '',
            callback: 1,
            pick: 2,
            transfer: 1,
            big_customer: 2,
            consult: 1,
            time_limit: 1,
            icon_url: '',
            visible: 2,
            welcome_words: ''
          }
        }
      },
      title: {
        type: String,
        default: ''
      },
      modeDisabled: {
        type: Boolean,
        default: false
      },
      modeAllShow: {
        type: Boolean,
        default: false
      },
      type: {
        type: Number,
        default: 1
      }
    },
    data() {
      const validate_time_limit = (rule, value, callback) => {
        if (this.data.transfer === 1 && value <= 0) {
          callback(new Error('排队时间上限不能小于等于 0'))
        } else {
          callback()
        }
      }

      return {
        data: JSON.parse(JSON.stringify(this.myData)),
        flexWidth: '60px',
        formLabelWidth: '120px',
        getToken,
        upLoadImg,
        selectData: {
          roadList: [],
          businessList: []
        },
        dialogBusinessFormVisible: false,
        dialogBusinessForm: {
          name: ''
        },
        businessLoading: false,
        rules: {
          type: [{ required: true, trigger: 'change', message: '请选择业务' }],
          business_id: [{ required: true, trigger: 'change', message: '请选择业务' }],
          access_id: [{ required: true, trigger: 'change', message: '请选择通路' }],
          name: [{ required: true, trigger: 'blur', message: '请输入队列名称' }],
          work_start_at: [{ required: true, trigger: 'change', message: '请选择服务开始时间' }],
          work_end_at: [{ required: true, trigger: 'change', message: '请选择服务结束时间' }],
          time_limit: [{ validator: validate_time_limit, trigger: 'change' }],
          icon_url: [{ required: true, trigger: 'blur', message: '请上传队列图标' }],
          welcome_words: [{ required: true, trigger: 'change', message: '请输入欢迎语' }]
        }
      }
    },
    watch: {
      visible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
        })
      },
      'data.type'(type) {
        // 获取 通路 列表
        this.visible && getApiWbAccessAccessesByTypeType(type).then(response => {
          this.$set(this.selectData, 'roadList', response.data)
        }).catch(this.$message.error)
      },
      'selectData.roadList'(roadList) {
        this.visible && this.type === 1 && this.$set(this.data, 'access_id', '')
      },
      myData: {
        handler(newVal, oldVal) {
          this.data = JSON.parse(JSON.stringify(newVal))
        },
        deep: true
      }
    },
    mounted() {
      this.fetchDialogData()
    },
    methods: {
      fetchDialogData() {
        // 获取 业务 列表
        getApiWbBusiness().then(response => {
          this.$set(this.selectData, 'businessList', response.data)
        }).catch(this.$message.error)
      },
      onUpLoadImg(res, file) {
        this.$set(this.data, 'icon_url', res.data.picUrl)
      },
      beforeUpload(file) {
        const isImg = ['image/jpeg', 'image/png'].some(item => file.type === item)
        const isLt2M = file.size / 1024 / 1024 < 2

        if (!isImg) {
          this.$message.error('上传头像图片只能是 JPG/PNG 格式!')
        }
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!')
        }
        return isImg && isLt2M
      },
      onData() {
        this.$refs.form.validate(valid => {
          if (valid) {
            this.$emit('change', this.data)
          } else {
            return false
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .my-dialog /deep/ {
    // 上传图片样式
    .avatar-uploader .el-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }

    .avatar-uploader .el-upload:hover {
      border-color: #409EFF;
    }

    .avatar-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      width: 178px;
      height: 178px;
      line-height: 178px;
      text-align: center;
    }

    .avatar {
      width: 178px;
      height: 178px;
      display: block;
    }

    .line {
      text-align: center;
    }
  }
</style>
