<template>
  <div class="app-container">
    <el-tabs tab-position="left" value="first">
      <!-- 示例1 -->
      <el-tab-pane label="标题和操作" name="first">
        <header>
          <h1>这里是标题，也可以是总数</h1>
          <div class="flex-wrp">
            <el-button type="primary" plain>新增</el-button>
            <el-button type="primary" plain @click="dialogFormVisible = true">打开侧边栏</el-button>
            <el-button type="primary" plain disabled>plain不能用</el-button>
            <el-button type="primary" disabled>不能用</el-button>
          </div>
        </header>

        <el-card>
          <demo-table></demo-table>

          <el-pagination background
                         layout="prev, pager, next"
                         :total="50">
          </el-pagination>
        </el-card>
      </el-tab-pane>

      <!-- 示例2 -->
      <el-tab-pane label="操作和简单查询" name="second">
        <header>
          <div class="flex-wrp">
            <el-button type="primary" plain>新增</el-button>
            <el-button type="primary" plain @click="dialogFormVisible = true">打开侧边栏</el-button>
          </div>
          <el-input
            placeholder="请输入队列编号、队列名称">
            <el-button slot="append" icon="el-icon-search"/>
          </el-input>
        </header>

        <el-card>
          <demo-table></demo-table>

          <el-pagination background
                         layout="prev, pager, next"
                         :total="50">
          </el-pagination>
        </el-card>
      </el-tab-pane>

      <!-- 示例3 -->
      <el-tab-pane label="标题和复杂查询" name="third">
        <header>
          <h1>服务记录详情</h1>

          <el-form :inline="true">
            <el-button type="primary" plain>新增</el-button>
            <el-button type="primary" plain @click="dialogFormVisible = true">打开侧边栏</el-button>
            <el-form-item label="是否开启">
              <el-switch class="el-switch--mark" v-model="switchValue"></el-switch>
            </el-form-item>
          </el-form>
        </header>
        <el-card>
          <section>
            <h2>精确查询</h2>
            <el-form :inline="true">
              <el-form-item>
                <el-input placeholder="请输入 CASE ID"></el-input>
              </el-form-item>
              <el-button type="primary" plain>查询</el-button>
            </el-form>

            <h2>条件查询</h2>
            <el-form :inline="true">
              <el-form-item class="required">
                <el-input placeholder="请输入 CASE ID"></el-input>
              </el-form-item>
              <el-form-item>
                <el-select placeholder="placeholder"></el-select>
              </el-form-item>
              <el-form-item>
                <el-cascader
                  placeholder="问题类型"
                  :options="[]"
                  clearable
                />
              </el-form-item>
              <el-form-item required>
                <ext-date-picker
                  size="large"
                  ref="times"
                  type="daterange"
                  placehoder="选择时间"
                  range-separator="至"
                  start-placeholder="开始日期"
                  end-placeholder="结束日期"
                  v-model="dateRange"
                  format="yyyy 年 MM 月 dd 日"
                  value-format="yyyy-MM-dd"
                  :span="5"
                  @range-error="rangeError"
                />
              </el-form-item>
            </el-form>

            <div class="text-right">
              <el-button type="primary" plain>新增</el-button>
              <el-button type="primary" plain @click="dialogFormVisible = true">打开侧边栏</el-button>
            </div>
          </section>

          <section>
            <h2>查询结果</h2>
            <demo-table></demo-table>

            <el-pagination background
                           layout="total, sizes, prev, pager, next, jumper"
                           :total="50">
            </el-pagination>
          </section>

          <footer>
            <h2>查询说明</h2>
            <ol>
              <li>创建时间段为必填字段，不限制整体时间跨度；</li>
              <li>创建时间段默认为从今日开始往前推7日的时间段；</li>
              <li>关闭时间段的起始时间不能早于创建时间段的起始时间；</li>
              <li>条件查询中的各个查询条件之间是“与”的关系，即输入信息越多，结果越准确；</li>
              <li>点击“重置”按钮，会重置所有输入框的状态。</li>
            </ol>
          </footer>
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="详情页" name="forth">
        <header>
          <h1>服务记录详情</h1>

          <el-form :inline="true">
            <el-button type="primary" plain @click="dialogFormVisible = true">某操作</el-button>
          </el-form>
        </header>
        <el-card>
          <section>
            <h2>记录详情</h2>
            <ul class="detail-list">
              <li v-for="i in 9">
                <span>属性名字</span> 长长的属性值，第{{i}}项
              </li>
            </ul>
          </section>

          <section>
            <h2>工单信息</h2>
            <ul class="detail-list">
              <li v-for="i in 5">
                <span>属性名字</span> 长长的属性值，第{{i}}项
              </li>
            </ul>
          </section>

          <section>
            <h2>故障信息</h2>
            <el-form label-width="100px">
              <el-form-item label="建议解决方案">
                <el-input rows="5" type="textarea"></el-input>
              </el-form-item>
              <el-form-item label="上传文件">
                <el-upload
                  action="https://www.demo.com/posts/"
                  :on-preview="handleUpload"
                  :on-remove="handleUpload"
                  :before-remove="handleUpload">
                  <el-button type="primary" plain>点击上传</el-button>
                  <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
                </el-upload>
              </el-form-item>
            </el-form>
          </section>

          <footer class="text-center">
            <el-button plain type="primary">取消</el-button>
            <el-button type="primary">确认</el-button>
          </footer>
        </el-card>
      </el-tab-pane>

      <el-tab-pane label="页面表单" name="fifth">
        <header>
          <h1>新建工单</h1>
          <el-button type="primary" plain @click="dialogFormVisible = true">某操作</el-button>
        </header>
        <el-card>
          <section>
            <h2>
              客户信息
              <el-button type="text" @click="dialogWideFormVisible = true">选择客户</el-button>
            </h2>
            <el-form :inline="true" label-width="100px">
              <el-form-item required label="客户ID">
                <el-input placeholder="客户ID"></el-input>
              </el-form-item>
              <el-form-item label="客户姓名">
                <el-input placeholder="客户姓名"></el-input>
              </el-form-item>
              <el-form-item label="客户手机号">
                <el-input placeholder="客户手机号"></el-input>
              </el-form-item>
              <el-form-item label="客户邮箱">
                <el-input placeholder="客户邮箱"></el-input>
              </el-form-item>
            </el-form>
          </section>

          <section>
            <h2>工单信息</h2>
            <el-form label-width="100px">
              <el-form-item label="特殊资源" required>
                <el-radio-group>
                  <el-radio label="高"></el-radio>
                  <el-radio label="中"></el-radio>
                  <el-radio label="低"></el-radio>
                </el-radio-group>
              </el-form-item>
              <el-form-item label="期望回复时间">
                <el-date-picker type="date" placeholder="选择日期"></el-date-picker>
              </el-form-item>
              <el-form-item label="备注">
                <el-input rows="5" type="textarea"></el-input>
              </el-form-item>
            </el-form>
          </section>

          <section>
            <h2>故障信息</h2>
            <el-form label-width="100px">
              <el-form-item label="服务记录ID">
                <el-input></el-input>
              </el-form-item>
              <el-form-item label="故障类型">
                <el-select placeholder="请选择故障类型">
                  <el-option label="区域一" value="shanghai"></el-option>
                  <el-option label="区域二" value="beijing"></el-option>
                </el-select>
              </el-form-item>
              <el-form-item label="故障描述" required>
                <el-input rows="5" type="textarea"></el-input>
              </el-form-item>
              <el-form-item label="建议解决方案">
                <el-input rows="5" type="textarea"></el-input>
              </el-form-item>
              <el-form-item label="上传文件">
                <el-upload
                  action="https://www.demo.com/posts/"
                  :on-preview="handleUpload"
                  :on-remove="handleUpload"
                  :before-remove="handleUpload">
                  <el-button type="primary" plain>点击上传</el-button>
                  <div slot="tip" class="el-upload__tip">只能上传jpg/png文件，且不超过500kb</div>
                </el-upload>
              </el-form-item>
            </el-form>
          </section>

          <footer class="text-center">
            <el-button type="primary">提交</el-button>
          </footer>
        </el-card>
      </el-tab-pane>
    </el-tabs>

    <!-- 添加关键样式 el-dialog-aside -->
    <el-dialog custom-class="el-dialog-aside" title="收货地址" :visible.sync="dialogFormVisible">
      <el-form label-width="100px">
        <el-form-item label="活动名称" required>
          <el-input auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="活动区域" required>
          <el-select placeholder="请选择活动区域">
            <el-option label="区域一" value="shanghai"></el-option>
            <el-option label="区域二" value="beijing"></el-option>
          </el-select>
        </el-form-item>
        <el-form-item label="问题分类">
          <el-input auto-complete="off"></el-input>
        </el-form-item>
        <el-form-item label="问题描述">
          <el-input
            maxlength="500"
            show-word-limit
            type="textarea"
            rows="10"
            placeholder="请填写问题描述，最多500字"></el-input>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
      </div>
    </el-dialog>

    <el-dialog custom-class="el-dialog-aside el-dialog-aside__large" :visible.sync="dialogWideFormVisible">
      <h2>查询用户</h2>
      <el-form inline>
        <el-form-item required>
          <el-input placeholder="人员ID"></el-input>
        </el-form-item>
        <el-form-item required>
          <el-input placeholder="姓名"></el-input>
        </el-form-item>
        <el-form-item required>
          <el-input placeholder="邮箱"></el-input>
        </el-form-item>
      </el-form>
      <div class="text-right">
        <el-button plain type="primary">注册新用户</el-button>
        <el-button plain type="primary">查询用户</el-button>
        <el-button plain>重置</el-button>
      </div>

      <h2>查询结果</h2>
      <demo-table></demo-table>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogWideFormVisible = false">取 消</el-button>
        <el-button type="primary" @click="dialogWideFormVisible = false">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script type="text/ecmascript-6">
  import DemoTable from './components/demo-table'
  import ExtDatePicker from '@/components/ExtDatePicker'

  export default {
    components: { DemoTable, ExtDatePicker },
    data() {
      return {
        dialogFormVisible: false,
        dialogWideFormVisible: false,
        switchValue: false,
        dateRange: null
      }
    },
    methods: {
      deleteRow() {},
      handleUpload() {},
      rangeError(span) {
        this.$message.error('超出了时间范围为' + span)
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>

</style>
