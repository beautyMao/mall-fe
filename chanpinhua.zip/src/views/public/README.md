# 魔方产品化开发规范 范本

只在开发环境下会触发此 范本

1. 范本依据 队里管理 -> 队列池 改造而来，接口数据为真实的后台数据，请谨慎 CURD 操作
2. 开发新项目时，请参考 范本 [风格指南](https://cn.vuejs.org/v2/style-guide/)

更多信息请参考 [风格指南](https://cn.vuejs.org/v2/style-guide/)
