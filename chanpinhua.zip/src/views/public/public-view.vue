<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div class="app-container">

    <!-- 头部标题和主要操作栏 使用header -->
    <header>
      <div class="flex-wrp">
        <el-button type="primary" plain @click="addVisible = true">新增</el-button>
      </div>

      <el-input
        v-model.trim="searchText"
        placeholder="请输入队列编号、队列名称"
        @keyup.enter.native="onSearch(searchText)"
      >
        <el-button slot="append" icon="el-icon-search" @click="onSearch(searchText)" />
      </el-input>
    </header>

    <!-- 内容区，使用el-card，这里的el card 在组件内部 -->
    <public-view-table
      :data="localTableData"
      :my-pagination="myPagination"
      @change="handleCurrentChange"
      @size-change="handleSizeChange"
      @edit="handleEdit"
      @delete="handleDelete"
      @select="tableSelect"
    />

    <!-- type@Number; info: 1 => 新增; 2 => 编辑; 3 => 批量修改;  // default => 1 -->
    <public-view-dialog title="新增" :visible="addVisible" @change="onDialogData" @close="addVisible = false" />

    <public-view-dialog
      :mode-disabled="true"
      title="编辑"
      :type="2"
      :my-data="tableData"
      :visible="editVisible"
      @change="onTableData"
      @close="editVisible = false"
    />
  </div>
</template>

<script>
  import {
    delApiWbQueueId,
    getApiWbQueue,
    getApiWbQueueId,
    getApiWbQueueSearch,
    postApiWbQueue,
    putApiWbQueueId
  } from '@/api/queue-management/pond'
  import { getApiWbQueueIdEngineers } from '@/api/queue-management/account'
  import PublicViewDialog from '@/views/public/public-view-dialog'
  import PublicViewTable from '@/views/public/public-view-table'

  export default {
    name: 'PublicView',
    components: { PublicViewDialog, PublicViewTable },
    data() {
      return {
        searchText: '',
        addVisible: false,
        tableDataList: [],
        tableData: {},
        editVisible: false,
        localTableData: [],
        myPagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        },
        queueRows: []
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        getApiWbQueue().then(response => {
          this.tableDataList = response.data
          this.myPagination.current_page = 1
          this.localPagination()
        }).catch(this.$message.error)
      },
      onDialogData(data) {
        postApiWbQueue(data).then(response => {
          this.fetchData()
          this.addVisible = false
        }).catch(this.$message.error)
      },
      onTableData(data) {
        putApiWbQueueId(data.id, data).then(response => {
          this.fetchData()
          this.editVisible = false
        }).catch(this.$message.error)
      },
      onSearch(text) {
        getApiWbQueueSearch(text).then(response => {
          this.tableDataList = response.data
          this.myPagination.current_page = 1
          this.localPagination()
        }).catch(this.$message.error)
      },
      handleEdit(index, row) {
        this.editVisible = true
        getApiWbQueueId(row.id).then(response => {
          this.tableData = [response.data].map(item => {
            item.business_id = item.business_id === 0 ? '' : item.business_id
            item.channel_id = item.channel_id === 0 ? '' : item.channel_id
            item.access_id = item.access_id === 0 ? '' : item.access_id
            if (!item.business_id) {
              item.channel_id = ''
            }
            return item
          })[0]
        }).catch(this.$message.error)
      },
      handleDelete(index, row) {
        this.$confirm('此操作将永久删除该队列, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          delApiWbQueueId(row.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      handleCurrentChange(val) {
        this.myPagination.current_page = val
        this.localPagination()
      },
      localPagination() {
        // 本地分页
        const number = (this.myPagination.current_page - 1) * this.myPagination.datanum
        this.localTableData = this.tableDataList.slice(number, number + this.myPagination.datanum)
        this.myPagination.total = this.tableDataList.length
      },
      handleSizeChange(val) {
        this.myPagination.datanum = val
        this.localPagination()
      },
      tableSelect(rows) {
        this.queueRows = JSON.parse(JSON.stringify(rows))
      }
    }
  }
</script>

