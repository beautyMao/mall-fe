<template>
  <div class="login-container flex-wrp flex-center">
    <!-- 轮播图 -->
    <div id="banner" class="banner">
      <div class="logo">
        <img src="./imgs/lenovo.png" alt="logo">
      </div>
      <ul>
        <li class="bg0">
          <div class="banner-con flex-center">
            <div class="font">
              <p class="title">全渠道接入客户 多样化沟通</p>
              <p class="explain">
                公众号/小程序/Web/Wap/H5/IOS/Andriod/Hot line
              </p>
            </div>
            <div class="photo photo0"><img src="./imgs/one.png"></div>
          </div>
        </li>
        <li class="bg1">
          <div class="banner-con flex-center">
            <div class="font">
              <p class="title">智能化交付 高效流转 跨部门协作</p>
              <p class="explain">
                在线、呼叫、客户等多场景实时创建工单 / 一键流转，方便跨部门协同
              </p>
            </div>
            <div class="photo photo1"><img src="./imgs/two.png"></div>
          </div>
        </li>
        <li class="bg2">
          <div class="banner-con flex-center">
            <div class="font">
              <p class="title">八大产品板块 全面提升服务品质</p>
              <p class="explain">
                全渠道接入/智能路由/用户识别/诊断机器人/智能交付/工单管理/智能运营/智能全量质检
              </p>
            </div>
            <div class="photo photo2"><img src="./imgs/three.png"></div>
          </div>
        </li>
      </ul>
      <div id="btn">
        <div id="btnCon" class="btn-con">
          <a href="##" class="active" />
          <a href="##" />
          <a href="##" />
        </div>
        <div class="copy-right">© 2019 Lenovo. All rights reserved</div>
      </div>
    </div>
    <div class="login-con flex-align-center flex-between bg-white">
      <el-form
        ref="loginForm"
        class="login-form"
        auto-complete="on"
        :model="loginForm"
        :rules="loginRules"
        label-position="left"
      >
        <div class="title-container flex-wrp flex-center">
          <div class="login-title">
            <svg-icon icon-class="logo" />
            <p class="first-title">魔方</p>
            <p class="second-title">{{ VERSION }}</p>
          </div>
        </div>
        <el-form-item prop="username">
          <span class="svg-container svg-container_login">
            <svg-icon icon-class="user" />
          </span>
          <!--<el-input name="username" type="text" v-model="loginForm.username" autoComplete="on" placeholder="请输入账号"/>-->
          <el-input v-model="usernameComputed" name="username" type="text" auto-complete="on" placeholder="请输入账号" />
        </el-form-item>

        <el-form-item prop="password">
          <span class="svg-container">
            <svg-icon icon-class="password" />
          </span>
          <el-input
            v-model="loginForm.password"
            name="password"
            :type="passwordType"
            auto-complete="on"
            placeholder="请输入密码"
            @keyup.enter.native="handleLogin"
          />
          <span class="show-pwd" @click="showPwd">
            <svg-icon icon-class="eye" />
          </span>
        </el-form-item>

        <div class="verificationCodeWrap">
          <el-form-item prop="captcha" class="captcha">
            <el-input v-model="loginForm.captcha" name="text" placeholder="请输入验证码" @keyup.enter.native="handleLogin" />
          </el-form-item>
          <img
            alt="验证码 captcha"
            :src="'/api/captcha?' + salt"
            style="width: 120px; height: 47px"
            @click="handleCode"
          >
        </div>
        <el-button type="primary" class="login-btn" :loading="loading" @click.native.prevent="handleLogin">登 录
        </el-button>
        <a class="reset" @click="reset">忘记密码</a>
      </el-form>
    </div>
  </div>
</template>

<script>
  const validataPassword = (rule, value, callback) => {
    if (value.length < 6) {
      callback(new Error('密码不能少于6位数'))
    } else {
      callback()
    }
  }

  export default {
    name: 'login',
    data() {
      return {
        // defined in webpack git plugin
        VERSION: process.env.VUE_APP_VERSION.split('-')[0],
        loginForm: {
          username: '',
          password: '',
          captcha: ''
        },
        loginRules: {
          username: [{ required: true, trigger: 'blur', message: '必填项' }],
          password: [{ required: true, trigger: 'blur', validator: validataPassword }],
          captcha: [{ required: true, trigger: 'blur', message: '验证码为必填项' }]
        },
        passwordType: 'password',
        loading: false,
        captcha: null,
        salt: +new Date(),
        publicity: true,

        timer: null
      }
    },
    computed: {
      usernameComputed: {
        get: function() {
          return this.loginForm.username
        },
        set: function(val) {
          this.loginForm.username = val.toUpperCase()
        }
      }
    },
    mounted() {
      this.carousel()
    },
    destroyed() {
      this.timer && clearInterval(this.timer)
    },
    methods: {
      showPwd() {
        if (this.passwordType === 'password') {
          this.passwordType = ''
        } else {
          this.passwordType = 'password'
        }
      },
      handleCode() {
        this.salt = +new Date()
      },
      handleLogin() {
        this.$refs.loginForm.validate(valid => {
          if (valid) {
            this.loading = true
            this.$store.dispatch('Login', this.loginForm).then(() => {
              this.$router.push({ path: '/' })
            }).catch((e) => {
              this.salt = +new Date()
              this.$message.error('登录失败：' + (e.captcha || e))
            }).finally(() => {
              this.loading = false
            })
          } else {
            return false
          }
        })
      },
      reset() {
        this.$router.push({
          path: '/reset',
          query: {
            id: 1
          }
        })
      },
      carousel() {
        // 运动轨迹
        function move(obj, json, fn) {
          clearInterval(obj.timer)
          obj.timer = setInterval(function() {
            let bStop = true
            for (const attr in json) {
              // 先判断是否是透明度
              let iCur
              if (attr === 'opacity') {
                iCur = parseInt(obj.style.opacity * 100)
              } else {
                iCur = parseInt(obj.style.opacity)
              }
              // 算速度
              let speed = (json[attr] - iCur) / 8
              speed = speed > 0 ? Math.ceil(speed) : Math.floor(speed)

              if (json[attr] !== iCur) {
                bStop = false
              }
              if (attr === 'opacity') {
                obj.style.opacity = (iCur + speed) / 100
                obj.style.filter = 'alpha(opacity:' + (iCur + speed) + ')'
              } else {
                obj.style[attr] = iCur + speed + 'px'
              }
            }
            if (bStop) {
              clearInterval(obj.timer)
              fn && fn()
            }
          }, 30)
        }

        // var banner = document.getElementById('banner')
        const aLi = document.querySelectorAll('#banner>ul>li')
        const aBtn = document.querySelectorAll('#btnCon>a')
        let iNow = 0
        let Next = 0
        // let timer = null

        for (let i = 0; i < aBtn.length; i++) {
          aBtn[i].index = i
          aBtn[i].onmouseover = function() {
            for (let j = 0; j < aBtn.length; j++) {
              aBtn[j].className = ''
              move(aLi[j], { opacity: 0 })
            }
            this.className = 'active'
            // 移入的时候让当前这个li显示
            move(aLi[this.index], { opacity: 100 })
            // 因为next与this.index不是同一个东西 因此需要他们两个同步
            Next = this.index
            iNow = Next
          }
        }

        this.timer = autoPlay()

        // 自动轮播
        function autoPlay() {
          return setInterval(function() {
            if (Next === aLi.length - 1) {
              Next = 0
            } else {
              Next++
            }
            toImg()
          }, 4000)
        }

        // 运动原理
        function toImg() {
          move(aLi[iNow], { opacity: 0 })
          move(aLi[Next], { opacity: 100 })
          iNow = Next
          for (let i = 0; i < aBtn.length; i++) {
            aBtn[i].className = ''
          }
          aBtn[Next].className = 'active'
        }
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss">
  /* 修复input 背景不协调 和光标变色 */
  /* Detail see https://github.com/PanJiaChen/vue-element-admin/pull/927 */

  $bg: #fff;
  $light_gray: #000;
  $cursor: #000;

  @supports (-webkit-mask: none) and (not (cater-color: $cursor)) {
    .login-container .el-input input {
      color: $cursor;

      &::first-line {
        color: $light_gray;
      }
    }
  }

  /* reset element-ui css */
  .login-container {
    .el-input {
      display: inline-block;
      height: 47px;
      width: 85%;

      input {
        background: transparent;
        border: 0px;
        -webkit-appearance: none;
        border-radius: 0px;
        padding: 12px 5px 12px 15px;
        color: $light_gray;
        height: 47px;
        caret-color: $cursor;

        &:-webkit-autofill {
          -webkit-box-shadow: 0 0 0px 1000px $bg inset !important;
          -webkit-text-fill-color: $cursor !important;
        }
      }
    }

    .el-form-item {
      border: 1px solid #ccc;
      // background: rgba(0, 0, 0, 0.1);
      border-radius: 5px;
      color: #454545;
      margin-bottom: 30px;

      .el-form-item__error {
        padding-top: 5px;
      }
    }
  }

  .verificationCodeWrap {
    display: flex;
    justify-content: space-between;

    .captcha {
      margin-right: 20px;
      flex: 1;
    }
  }
</style>

<style rel="stylesheet/scss" lang="scss" scoped>
  $bg: #eef2fa;
  $dark_gray: #889aa4;
  $light_gray: #eee;
  $white: #fff;

  .login-container {
    position: fixed;
    height: 100%;
    width: 100%;
    background-color: $bg;

    .banner {
      width: 100vw;
      height: 100vh;
      position: relative;

      .logo {
        width: 200px;
        height: 38px;
        position: absolute;
        top: 20px;
        left: 20px;
        z-index: 10;
      }

      ul {
        width: 100vw;
        height: 100vh;

        li {
          width: 100%;
          height: 100%;
          position: absolute;
          opacity: 0;
          filter: alpha(opacify=0);
        }

        li:first-child {
          opacity: 1;
          filter: alpha(opacify=1);
        }

        .banner-con {
          width: calc(100vw - 450px);
          position: absolute;
          top: 50%;
          left: 0;
          text-align: center;
          color: $white;
          line-height: 1;
          height: 280px;
          margin: -140px 0 0;

          .title {
            font-size: 48px;
          }

          .explain {
            font-size: 24px;
            margin: -30px 0 0;
            line-height: 1.25;
          }

          .font {
            animation: fadeShow 3s;
            position: absolute;
            top: 0;
            width: 100%;
            left: 0;
            z-index: 5;
          }

          .photo {
            position: absolute;
            bottom: 0;
            width: 100%;
            left: 0;
            text-align: center;
            z-index: 1;

            img {
              width: 70%;
            }
          }

          .photo0 {
            animation: fadeIn 0.5s;
            bottom: 50px;
          }

          .photo1 {
            img {
              width: 40%;
              animation: rotate 3s;
            }
          }

          .photo2 {
            bottom: 30px;

            img {
              width: 70%;
              animation: beat 1s ease-in 4s;
            }
          }

          @-webkit-keyframes fadeIn {
            0% {
              left: -100%;
            }
            50% {
              left: -50%;
            }
            100% {
              left: 0;
            }
          }
          @-webkit-keyframes rotate {
            0% {
              transform: rotate(0deg) scale(0)
            }
            25% {
              transform: rotate(90deg) scale(0.25)
            }
            50% {
              transform: rotate(180deg) scale(0.5)
            }
            75% {
              transform: rotate(270deg) scale(0.75)
            }
            100% {
              transform: rotate(360deg) scale(1)
            }
          }
          @-webkit-keyframes beat {
            0% {
              transform: translate(0, 0);
            }
            25% {
              transform: translate(0, 10px);
            }
            50% {
              transform: translate(0, 0);
            }
            75% {
              transform: translate(0, 10px);
            }
            100% {
              transform: translate(0, 0);
            }
          }
          @-webkit-keyframes fadeShow {
            0% {
              opacity: 0; /*初始状态 透明度为0*/
            }
            50% {
              opacity: 0.5; /*中间状态 透明度为0*/
            }
            100% {
              opacity: 1; /*结尾状态 透明度为1*/
            }
          }
        }

        .bg0 {
          background: url('./imgs/login-bg0.png') no-repeat;
          background-size: auto 120%;
          animation: play 20s linear infinite;
        }

        .bg1 {
          background: url('./imgs/login-bg1.png') no-repeat;
          background-size: auto 120%;
          animation: play 20s linear infinite;
        }

        .bg2 {
          background: url('./imgs/login-bg2.png') no-repeat;
          background-size: auto 120%;
          animation: play 20s linear infinite;
        }

        @keyframes play {
          /*from {
            background-size: auto 100%;
            background-position: center center;
          }
          to {
            background-size: auto 120%;
            background-position: center center;
          }*/
          0% {
            background-size: auto 100%;
          }
          25% {
            background-size: auto 105%;
          }
          50% {
            background-size: auto 110%;
          }
          75% {
            background-size: auto 115%;
          }
          100% {
            background-size: auto 120%;
          }
        }
      }

      #btn {
        position: fixed;
        width: calc(100vw - 450px);
        bottom: 0;
        left: 0;

        .btn-con {
          text-align: center;
        }

        .copy-right {
          width: 100%;
          height: 40px;
          line-height: 40px;
          background-color: #000;
          padding-left: 10px;
          color: #fff;
          font-size: 12px;
          margin: 30px 0 0;
        }

        a {
          /*float: left;*/
          display: inline-block;
          margin-left: 10px;
          width: 30px;
          height: 4px;
          background: rgba(255, 255, 255, 0.3);
        }

        .active {
          background: rgba(255, 255, 255, 1);
        }
      }
    }

    .login-con {
      position: fixed;
      right: 0;
      top: 0;
      width: 450px;
      height: 100vw;

      .login-form {
        position: fixed;
        width: 355px;
        right: 45px;
        top: 40%;
        margin-top: -260px;
        .reset {
          display: block;
          width: 200px;
          margin: 20px auto 0;
          font-size: 14px;
          text-align: center;
          color: #337CE8;
        }
        .login-title {
          text-align: center;
          line-height: 1;

          svg {
            font-size: 64px;
          }

          .first-title {
            font-size: 30px;
            margin-top: 20px;
          }

          .second-title {
            font-size: 23px;
            color: #949494;
            margin: -20px 0 40px 0;
          }
        }
      }

      .tips {
        font-size: 14px;
        color: #000;
        margin-bottom: 10px;

        span {
          &:first-of-type {
            margin-right: 16px;
          }
        }
      }

      .svg-container {
        padding: 6px 5px 6px 15px;
        color: $dark_gray;
        vertical-align: middle;
        width: 30px;
        display: inline-block;

        &_login {
          font-size: 20px;
        }
      }

      .title-container {
        margin-bottom: 50px;

        .title {
          color: #3E8DDD;
          font-size: 34px;
          font-weight: bold;
        }
      }

      .show-pwd {
        position: absolute;
        right: 10px;
        top: 10px;
        font-size: 16px;
        color: $dark_gray;
        cursor: pointer;
        user-select: none;
        z-index: 9999;
      }

      .thirdparty-button {
        position: absolute;
        right: 35px;
        bottom: 28px;
      }
    }
  }

  .login-btn {
    width: 100%;
    height: 59px;
    background-color: #337CE8;
    cursor: pointer;
    color: #fff;
    text-align: center;
    font-size: 24px;
  }

  .login-btn:hover {
    background-color: #518FEB;
  }
</style>
