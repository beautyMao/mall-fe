<template>
  <div class="Wrap">
    BlackList
  </div>
</template>

<script>
  export default {
    name: 'black-list',
    data() {
      return {}
    },
    methods: {}
  }
</script>

<style scoped lang="scss">

</style>
