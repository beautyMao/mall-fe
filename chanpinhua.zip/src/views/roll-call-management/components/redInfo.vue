<template>
  <div ref="ele" class="Warp">
    <p class="title">查询结果</p>
    <el-table :data="listData" style="width: 100%" tooltip-effect="light" :header-cell-style="getRowClass" class="tab">
      <el-table-column type="selection" width="50" />
      <el-table-column prop="client_type" label="姓名" />
      <el-table-column prop="direction" label="手机号" />
      <el-table-column prop="direction" label="openID" />
      <el-table-column prop="direction" label="通路" />
      <el-table-column prop="direction" label="队列" />
      <el-table-column prop="start_talking_at" label="创建时间" min-width="106" />
      <el-table-column prop="direction" label="添加账户" />
      <el-table-column prop="direction" label="状态" />
      <el-table-column prop="" label="操作">
        <template slot-scope="scope">
          <el-button class="btn" @click="itemRedact(scope.row)">编辑</el-button>
          <el-button class="btn" @click="itemDelete(scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
  </div>
</template>

<script>
  export default {
    props: {
      listData: {
        type: Array,
        default: function() {
          return []
        }
      }
    },
    data() {
      return {
        IRTypeID: ''
      }
    },
    mounted() {
      if (window.screen.width >= 1920) {
        this.$refs.ele.children[1].style = 'font-size: 14px !important'
      }
      document.documentElement.scrollTop = window.pageYOffset = document.body.scrollTop = this.$refs.ele.offsetTop + 70
    },
    methods: {
      getRowClass({ row, column, rowIndex, columnIndex }) { // 设置table 标题背景色
        if (rowIndex === 0) { return 'background:#F0F4FB' } else { return '' }
      },
      itemRedact() {},
      handleEdit(index, row) { // 获取详情信息
        this.$router.push({
          path: `touch/particulars`,
          query: {
            id: row.id,
            type: row.client_type
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .Warp /deep/ .el-table__header tr th:first-child .cell {
    padding-left: 28px;
  }
  /*.Warp /deep/ .el-table__header tr th:last-child .cell {
    padding-right: 28px;
  }*/
  .Warp /deep/ .el-table__body tr td:first-child .cell {
    padding-left: 28px;
  }
  .Warp /deep/ .el-table__body tr td:last-child .cell {
    padding-right: 28px;
  }
  .Warp /deep/ .el-table thead {
    color: #666;
  }
  .Warp {
    position: relative;
    .title {
      padding-left: 20px;
      font-weight: 700;
    }
    .el-table__row:hover .el-button {
      background: #F5F7FA;
      color: #606266;
    }
    .tab /deep/ tr {
      height: 50px;
      th {
        padding: 0;
      }
    }
    .tab /deep/ .el-table__row {
      height: 50px;
      .cell {
        overflow: hidden;
        max-height: 70px;
        .el-button {
          border: none;
          padding: 0;
          line-height: 24px;
        }
      }
      span button {
        font-family: PingFangSC-Regular;
        line-height: 22px;
        border: 0;
        overflow: hidden;
        white-space: pre-wrap;
      }
    }
  }

</style>
