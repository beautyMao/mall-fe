<template>
  <div class="condition">
    <el-scrollbar>
      <p class="title">条件查询</p>
      <el-form ref="ruleForm" :model="ruleForm" label-width="100px" :inline="true" class="from">
        <el-form-item label="" prop="a" class="inputWrap">
          <el-select
            v-model="ruleForm.a"
            filterable
            remote
            clearable
            reserve-keyword
            placeholder="姓名"
            :remote-method="remoteMethod"
            :loading="loading"
            @click.native="handleUserClick"
          >
            <el-option
              v-for="item in a"
              :key="item.code"
              :label="item.label"
              :value="item.value"
            />
          </el-select>
        </el-form-item>

        <el-form-item label="" prop="a" class="inputWrap">
          <el-input v-model="ruleForm.a" clearable placeholder="电话号码" class="input" />
        </el-form-item>
        <el-form-item label="" prop="a" class="inputWrap">
          <el-input v-model="ruleForm.a" clearable placeholder="open Id" class="input" />
        </el-form-item>
        <el-form-item label="" prop="a" class="inputWrap">
          <el-select v-model="ruleForm.a" value="" clearable placeholder="通路">
            <el-option
              v-for="item in a"
              :key="item.ParaValue"
              :label="item.ParaValue"
              :value="item.ParaCode"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="" prop="a" class="inputWrap">
          <el-select v-model="ruleForm.a" value="" clearable placeholder="队列">
            <el-option
              v-for="item in a"
              :key="item.ParaValue"
              :label="item.ParaValue"
              :value="item.ParaCode"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="" prop="a" class="inputWrap">
          <el-select v-model="ruleForm.a" value="" clearable placeholder="添加账户">
            <el-option
              v-for="item in a"
              :key="item.ParaValue"
              :label="item.ParaValue"
              :value="item.ParaCode"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="" prop="value1" class="timeWrap">
          <el-date-picker
            ref="time"
            v-model="value1"
            type="daterange"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            :picker-options="pickerOptions2"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
            class="time"
            @change="hanleTiemScope"
            @focus="handleBorderColorChange"
            @blur="handleBorderColorRestore"
          />
        </el-form-item>
        <el-form-item class="btnWrap">
          <el-button type="primary" class="btn" @click="submitConditionForm(ruleForm)">查询</el-button>
          <el-button class="btn" style="background: #fff" @click="resetConditionForm('ruleForm')">重置</el-button>
        </el-form-item>
      </el-form>
    </el-scrollbar>
  </div>
</template>

<script>
  import { getIRContactType, getSearchEngineer } from '@/api/touch'
  export default {
    data() {
      return {
        ruleForm: {
          a: ''
        },
        debounceQuery: null,
        loading: false,
        a: [],
        value1: null,
        pickerOptions2: { // 禁止选择未来时间
          disabledDate(time) {
            return time.getTime() > Date.now()
          }
        },
        input: /^[A-Za-z0-9\-_]+$/
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      submitConditionForm(formName) { // 获取列表数据
        // this.ruleForm.begin_time = this.value1[0]
        // this.ruleForm.end_time = this.value1[1]
        // this.$emit('ruleForm', Object.assign({}, this.ruleForm))
      },
      resetConditionForm(formName) { // 重置数据
        this.$refs[formName].resetFields()
        this.defaultTime(30)
      },
      hanleTiemScope() { // 设置时间跨度
        if (this.value1 === null) return
        let a = this.value1[0]
        let b = this.value1[1]
        a = new Date(a.replace(/-/g, '/')).getTime()
        b = new Date(b.replace(/-/g, '/')).getTime()
        if (b - a > 2592000000) {
          this.$message({
            message: '整体时间跨度不超过31天',
            type: 'warning'
          })
          this.value1 = null
          this.ruleForm.begin_time = ''
          this.ruleForm.end_time = ''
          this.defaultTime(30)
        }
      },
      // 默认时间
      defaultTime(val) {
        const now = new Date()
        const start = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() - val)).toISOString().slice(0, 10)
        const end = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10)
        this.value1 = [start, end]
      },
      handleUserClick() {
        this.a = []
      },
      remoteMethod(query) { // 模糊查询 客服
        this.ruleForm.a = query
        this.loading = true
        this.fuzzyEngineerSearch(query)
      },
      fuzzyEngineerSearch(query) {
        if (query !== '') {
          getSearchEngineer(query).then((res) => {
            var data = []
            for (const i in res.data) {
              data.push(res.data[i])
            }
            this.user = data.map(item => {
              return {
                value: item.code,
                label: item.code + ' / ' + item.name
              }
            })
            this.loading = false
          }).catch(() => {
            this.user = []
            this.loading = false
          })
        }
      },
      init() {
        getIRContactType().then(res => { this.IRType = res.data }) // 接触方式
        this.defaultTime(30) // IR开始时间初始默认时间段
        this.$refs.time.$el.children[0].innerHTML = '创建时间'
        this.$refs.time.$el.children[0].className = 'times'
      },
      handleBorderColorChange() {
        this.$refs.time.$el.children[0].style = 'border-color: #409EFF'
      },
      handleBorderColorRestore() {
        this.$refs.time.$el.children[0].style = 'border-color: #dcdfe6'
      }
    }
  }
</script>

<style lang="scss" scoped>
  .from /deep/ .el-form-item__content{
    width: 100%;
    //max-width: 260px;
    .el-input__inner {
      min-width: 186px;
      //max-width: 260px;
      height: 40px;
    }
    .el-select {
      width: 100%;
    }
  }
  .from1 {
    justify-content: flex-start!important;
  }
  .condition /deep/ .el-scrollbar {
    border-bottom: 1px solid #E4E7ED;
  }
  .from{
    display: flex;
    flex-wrap: wrap;
    //justify-content: space-around;
    min-width: 1048px;
    overflow: hidden;
    padding-left: 15px;
    .inputWrap {
      width: 18%;
      margin-right: 2%;
      margin-bottom: 2%;
    }
    .timeWrap /deep/ .el-form-item__content {
      //max-width: 550px;
    }
    .timeWrap {
      position: relative;
      width: 38%;
      margin-right: 2%;
      margin-bottom: 2%;
      .time {
        width: 100%;
        min-width: 390px !important;
        //max-width: 550px !important;
        height: 40px;
      }
      .time /deep/ .el-icon-date:before {
        content: ''
      }
      .time /deep/ .el-range-separator {
        color: #DCDFE4;
        line-height: 32px;
      }
      .time /deep/ .times {
        width: 100px;
        height: 40px;
        padding: 0 10px;
        margin-left: -11px;
        border: 1px solid #dcdfe6;
        border-right: none;
        border-top-left-radius: 5px;
        border-bottom-left-radius: 5px;
        font-size: 12px;
        text-align: center;
        font-style: normal;
        color: #909399;
        background: #F5F7FA;
      }
    }
    .btnWrap1 {
      width: auto !important;
    }

    .btnWrap /deep/ .el-form-item__content {
      max-width: none;
    }
    .btnWrap {
      width: 100%;
      text-align: right;
      margin-right: 2%;
      .btn {
        width: 150px;
        height: 40px;
        border: 1px solid #3E8DDD;
        color: #3E8DDD;
        background: #E5F2FF;
      }
      .border{
        border: none;
        color: #3E8DDD;
        background: #fff;
      }
      .btn_margin{
        margin-right: 200px;
      }
    }
  }
  .precise {
    padding: 0 20px;
    overflow: hidden;
    .title {
      font-weight: 700;
    }
  }
  .condition {
    padding: 0 20px;
    .title {
      font-weight: 700;
    }
  }
  .Icon {
    position: absolute;
    left: -15px;
    font-size: 10px;
    line-height: 40px;
    color: red;
  }
</style>
