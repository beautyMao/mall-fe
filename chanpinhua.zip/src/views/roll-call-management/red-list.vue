<template>
  <div class="RedList">
    <header>
      <div>
        <el-button type="primary" plain>新增</el-button>
        <el-button type="primary" plain>批量删除</el-button>
        <el-button type="primary" plain>批量导入</el-button>
      </div>
      <div class="btnBox">
        <span class="name">是否启用</span>
        <el-switch
          v-model="value"
          class="el-switch--mark"
          active-color="#409eff"
          inactive-color="#dcdfe6"
        />
      </div>
    </header>
    <div class="main">
      <condition-query />
      <div>
        <red-info />
        <div class="pageW">
          <el-pagination
            class="page"
            background
            :page-sizes="[10, 20, 30]"
            :current-page="list.page_index"
            :page-size="list.page_size"
            layout="total, sizes, prev, pager, next, jumper"
            :total="TotalNumber"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          />
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import conditionQuery from './components/conditionQuery'
  import redInfo from './components/redInfo'
  export default {
    name: 'red-list',
    components: {
      conditionQuery,
      redInfo
    },
    data() {
      return {
        list: {},
        value: false,
        TotalNumber: 0
      }
    },
    methods: {
      handleSizeChange(val) { // 条数切换
        this.list.page_size = val
        this.list.page_index = 1
        this.data = null
        if (this.IRID) {
          // getListInfo(this.IRID).then(this.submitSucc).catch(this.error)
        } else {
          // getListInfo1(this.list).then(this.submitSucc).catch(this.error)
        }
      },
      handleCurrentChange(val) { // 分页切换
        this.list.page_index = val
        this.data = null
        if (this.IRID) {
          // getListInfo(this.IRID).then(this.submitSucc).catch(this.error)
        } else {
          // getListInfo1(this.list).then(this.submitSucc).catch(this.error)
        }
      }
    }
  }
</script>
<style scoped lang="scss">
  .RedList {
    padding: 20px;
    header {
      display: flex;
      justify-content: space-between;
      margin-bottom: 20px;
      .btnBox {
        line-height: 32px;
      }
      .name {
        margin-right: 10px;
        font-size: 14px;
        color: #999;
      }
    }
    .main {
      overflow: hidden;
      box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
      background: #fff;
      .pageW {
        float: right;
        margin: 20px;
      }
    }
  }
</style>
