<template>
  <div class="Label">
    <span class="el-icon-plus icon leftIcon" @click="handleAddClick" />
    <el-cascader
      v-model="value1"
      :options="data"
      :props="cascaderAlias"
      :show-all-levels="true"
      clearable
      popper-class="cascaderPopper"
      filterable
      class="cascader"
      @change="handleCascaderChange"
    />
    <span class="el-icon-minus icon rightIcon" @click="handleDelClick" />
  </div>
</template>

<script>
  export default {
    name: 'add-del-label',
    props: {
      data: {
        type: Array,
        default: function() {
          return []
        }
      },
      info: {
        type: Object,
        default: function() {
          return {}
        }
      },
      location: {
        type: Number,
        default: 0
      },
      location1: {
        type: Number,
        default: 0
      },
      type: {
        type: String,
        default: ''
      }
    },
    data() {
      return {
        cascaderSet: [],
        value1: [],
        cascaderAlias: {
          value: 'id',
          label: this.type,
          children: 'children'
        },
        returnedItem: []
      }
    },
    watch: {
      info() {
        if (this.type === 'customer_label_name') {
          this.value1 = this.info.pivot.customer_label_id
        }
        if (this.type === 'servicer_label_name') {
          this.value1 = this.info.pivot.servicer_label_id
        }
      }
    },
    mounted() {
      let labelId = null
      if (this.type === 'customer_label_name') {
        labelId = this.info.pivot.customer_label_id
      }
      if (this.type === 'servicer_label_name') {
        labelId = this.info.pivot.servicer_label_id
      }
      this.reverseSearch(this.data, labelId)
      const idx = this.cascaderSet.indexOf(labelId)
      if (idx > -1) {
        this.value1 = this.cascaderSet.slice(0, idx + 1)
      } else {
        this.value1 = []
      }
    },
    methods: {
      reverseSearch(tree, targetId) {
        for (const elem of tree) {
          if (elem.parent_id === null) {
            this.cascaderSet.length = 0
          }
          if (elem.children === undefined) {
            if (elem.id === targetId) {
              this.cascaderSet.push(elem.id)
              return elem
            }
          } else {
            this.cascaderSet.push(elem.id)
            const found = this.reverseSearch(elem.children, targetId)
            if (found !== undefined) {
              this.cascaderSet.push(found.id)
              return found
            }
          }
        }
      },
      handleAddClick() {
        this.$emit('addItem', [this.info, this.location])
      },
      handleDelClick() {
        this.$emit('delItem')
      },
      handleCascaderChange() {
        this.$emit('cascaderChange', [this.value1, this.type, this.location, this.location1, this.info])
      }
    }
  }
</script>

<style scoped lang="scss">
  .Label {
    display: flex;
    justify-content: center;
    align-items: center;
    padding: 10px 0;
    color: #909399;
    .cascader {
      width: 280px;
      height: 40px;
      line-height: 40px;
      & /deep/ .el-input__inner {
        height: 40px;
        border-radius: 0;
      }
    }
    .icon {
      display: inline-block;
      width: 40px;
      height: 40px;
      line-height: 40px;
      border: 1px solid #CCC;
      background: #F5F7FA;
    }
    .leftIcon {
      border-right: 0;
      border-radius:4px 0 0 4px;
    }
    .rightIcon {
      border-left: 0;
      border-radius:0 4px 4px 0;
    }
  }
</style>
<style lang="scss">
  /*.cascaderPopper {*/
    /*width: 280px;*/
    /*.el-cascader-menu {*/
      /*width: 280px;*/
    /*}*/
  /*}*/
</style>

