<template>
  <div class="Recommend">
    <div class="title">
      <h4>分配规则</h4>
      <div class="switch">
        <el-button type="primary" plain class="button" @click="handleAddListClick">新建</el-button>
        <span class="name">是否启用</span>
        <el-switch
          v-model="isSwitch"
          class="el-switch--mark"
          active-color="#4AC0E0"
          inactive-color="#dcdfe6"
          @change="handleSwitchChange"
        />
      </div>
    </div>
    <div class="main">
      <div class="header">
        <h5>说明</h5>
        <div class="create">
          <span>1.点击新建可创建新的标签对应关系</span>
          <span>2.点击删除可分别删除标签对应关系</span>
          <span>3.可拖动顺序，调整匹配优先级</span>
        </div>
      </div>
      <draggable v-model="myArray" group="people" class="draggable" @start="drag=true" @end="drag=false" @change="handleUpdate">
        <div v-for="(myItem, idx) in myArray" :key="idx" class="item">
          <div class="label">
            <span class="tit">客服标签</span>
            <add-del-label
              v-for="(item, index) in myItem.matching_rule_servicer_label"
              v-if="ServicerLabel.length"
              :key="item.id"
              :location="idx"
              :location1="index"
              :info="item"
              :type="'servicer_label_name'"
              :data="ServicerLabel"
              @cascaderChange="cascaderChange"
              @addItem="addEngineerItem"
              @delItem="delEngineerItem(item, idx, myItem, myArray, index)"
            />
          </div>
          <div class="label labelbor">
            <span class="tit">客户标签</span>
            <add-del-label
              v-for="(item, index) in myItem.matching_rule_customer_label"
              v-if="CustomerLabel.length"
              :key="item.id"
              :location="idx"
              :location1="index"
              :info="item"
              :type="'customer_label_name'"
              :data="CustomerLabel"
              @cascaderChange="cascaderChange"
              @addItem="addClientItem"
              @delItem="delClientItem(item, idx, myItem, myArray, index)"
            />
          </div>
          <div class="close-rank">
            <el-button type="primary" class="button" @click="submitForm(idx)">保存</el-button>
            <div @click="handleDeleteItem(idx)">
              <svg-icon icon-class="delete" class="close" />
            </div>
            <svg-icon icon-class="move" class="close" />
          </div>
        </div>
      </draggable>
    </div>

    <!--<div class="bottom">
      <el-button class="button">取消</el-button>
      <el-button type="primary" class="button" @click="submitForm">保存</el-button>
    </div>-->
  </div>
</template>

<script>
  import addDelLabel from './component/add-del-label'
  import draggable from 'vuedraggable'
  import {
    getSwitch, // 获取开关
    getSwitchChange, // 设置开关
    getMove, // 移动
    getMatchingLabelRule, // 列表展示
    getBatchMatchingLabelRule, // 批量创建
    getCustomerLabel,
    getServicerLabel,
    getBatchChange, // 批量修改
    getBatchDelete
  } from '@/api/rule-management/recommend'
  export default {
    name: 'tag-rule',
    components: {
      draggable,
      addDelLabel
    },
    data() {
      return {
        isSwitch: true,
        isCreate: true,
        myArray: [],
        ServicerLabel: [],
        CustomerLabel: [],
        changeMyArray: []
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      init() {
        getSwitch('matchingLabelRule').then(res => {
          const isSwitch = true
          this.isSwitch = res.data.int_value ? isSwitch : !isSwitch
        })
        getMatchingLabelRule().then(res => { // 获取已有数据
          this.myArray = res.data
          for (const item in this.myArray) {
            if (!this.myArray[item].matching_rule_servicer_label.length) {
              const data = {
                pivot: {
                  matching_rule_label_id: this.myArray[item].id,
                  servicer_label_id: ''
                }
              }
              this.myArray[item].matching_rule_servicer_label.push(data)
            }
            if (!this.myArray[item].matching_rule_customer_label.length) {
              const data = {
                pivot: {
                  matching_rule_label_id: item.id,
                  customer_label_id: ''
                }
              }
              this.myArray[item].matching_rule_customer_label.push(data)
            }
          }
        })
        getCustomerLabel().then(res => { // 客户列表数据
          this.CustomerLabel = this.getTreeData(res.data)
        })
        getServicerLabel().then(res => { // 客服列表数据
          this.ServicerLabel = this.getTreeData(res.data)
        })
      },
      handleSwitchChange() { // 是否启用
        const data = {
          key_name: 'matchingLabelRule',
          int_value: this.isSwitch ? 1 : 0
        }
        getSwitchChange(data).then()
      },
      getTreeData(data) { // 去除空children
        for (var i = 0; i < data.length; i++) {
          if (data[i].children.length < 1) {
            // children若为空数组，则将children设为undefined
            data[i].children = undefined
          } else {
            // children若不为空数组，则继续 递归调用 本方法
            this.getTreeData(data[i].children)
          }
        }
        return data
      },
      handleAddListClick() { // 新建
        if (!this.isCreate) {
          this.$message({
            message: '请先保存新增的标签',
            type: 'warning'
          })
          return
        }
        const data = {
          matching_rule_customer_label: [
            {
              pivot: {
                matching_rule_label_id: '',
                customer_label_id: ''
              }
            }
          ],
          matching_rule_servicer_label: [
            {
              pivot: {
                matching_rule_label_id: '',
                servicer_label_id: ''
              }
            }
          ]
        }
        this.myArray.push(data)
        this.isCreate = false
      },
      addEngineerItem(val) { // 添加客服item
        for (const myItem of this.myArray) {
          if (myItem.id === val[0].pivot.matching_rule_label_id) {
            const data = {
              pivot: {
                matching_rule_label_id: myItem.id,
                servicer_label_id: ''
              }
            }
            myItem.matching_rule_servicer_label.push(data)
          }
        }
      },
      delEngineerItem(item, idx, myItem, myArray, index) { // 删除客服item
        console.log(item)
        if (myItem.matching_rule_servicer_label.length > 1) {
          myArray[idx].matching_rule_servicer_label.splice(index, 1)
        }
      },
      addClientItem(val) { // 添加客户item
        for (const myItem of this.myArray) {
          if (myItem.id === val[0].pivot.matching_rule_label_id) {
            const data = {
              pivot: {
                matching_rule_label_id: myItem.id,
                customer_label_id: ''
              }
            }
            myItem.matching_rule_customer_label.push(data)
          }
        }
      },
      delClientItem(item, idx, myItem, myArray, index) { // 删除客户item
        if (myItem.matching_rule_customer_label.length > 1) {
          myArray[idx].matching_rule_customer_label.splice(index, 1)
        }
      },
      cascaderChange(val) { // 每条item改变触发
        // getCustomerLabel().then(res => { // 客户列表数据
        //   this.CustomerLabel = this.getTreeData(res.data)
        // })
        // getServicerLabel().then(res => { // 客服列表数据
        //   this.ServicerLabel = this.getTreeData(res.data)
        // })
        const newArr = this.myArray
        if (val[1] === 'servicer_label_name') {
          const data = {
            pivot: {
              matching_rule_label_id: newArr[val[2]].id,
              servicer_label_id: val[0]
            }
          }
          newArr[val[2]].matching_rule_servicer_label[val[3]] = data
          this.myArray = [...newArr]
        }
        if (val[1] === 'customer_label_name') {
          const data = {
            pivot: {
              matching_rule_label_id: newArr[val[2]].id,
              customer_label_id: val[0]
            }
          }
          newArr[val[2]].matching_rule_customer_label[val[3]] = data
          this.myArray = [...newArr]
        }
      },
      // changeInfo(index) { // 去重
      //   if (this.changeMyArray.length) {
      //     let notFound = true
      //     for (const i in this.changeMyArray) {
      //       if (this.changeMyArray[i].id === this.myArray[index].id) {
      //         this.changeMyArray[i] = this.myArray[index]
      //         notFound = false
      //       }
      //     }
      //     if (notFound) {
      //       this.changeMyArray.push(this.myArray[index])
      //     }
      //   } else {
      //     this.changeMyArray.push(this.myArray[index])
      //   }
      // },
      handleDeleteItem(idx) { // 删除一条数据
        this.$confirm('是否删除当前匹配规则?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          if (!this.myArray[idx].id) {
            this.isCreate = true
            this.myArray.splice(idx, 1)
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            return
          }
          const data = {
            matching_label_rule_id: [this.myArray[idx].id]
          }
          getBatchDelete(data).then()
          this.myArray.splice(idx, 1)
          this.$message({
            type: 'success',
            message: '删除成功!'
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      submitForm(idx) { // 保存数据
        if (!this.myArray[idx].id) { // 新建
          const data = {
            customer_label_id: [],
            servicer_label_id: []
          }
          for (const item of this.myArray[idx].matching_rule_servicer_label) {
            if (!item.pivot.servicer_label_id) continue
            let label_id = item.pivot.servicer_label_id
            label_id = item.pivot.servicer_label_id instanceof Array ? item.pivot.servicer_label_id.slice(-1)[0] : item.pivot.servicer_label_id
            data.servicer_label_id.push(label_id)
          }
          if (this.deweight(data.servicer_label_id, '客服标签重复')) return
          for (const item of this.myArray[idx].matching_rule_customer_label) {
            if (!item.pivot.customer_label_id) continue
            let label_id = item.pivot.customer_label_id
            label_id = item.pivot.customer_label_id instanceof Array ? item.pivot.customer_label_id.slice(-1)[0] : item.pivot.customer_label_id
            data.customer_label_id.push(label_id)
          }
          if (this.deweight(data.customer_label_id, '客户标签重复')) return
          data.servicer_label_id = data.servicer_label_id[0] ? data.servicer_label_id : []
          data.customer_label_id = data.customer_label_id[0] ? data.customer_label_id : []
          if (!(data.servicer_label_id.length && data.customer_label_id.length)) {
            this.$message({
              message: '请设置匹配标签',
              type: 'warning'
            })
            return
          }
          getBatchMatchingLabelRule([data]).then(() => {
            this.isCreate = true
            this.init()
            this.$message({
              message: '保存成功',
              type: 'success'
            })
          })
        } else {
          const data = {
            customer_label_id: [],
            servicer_label_id: []
          }
          for (const item of this.myArray[idx].matching_rule_servicer_label) {
            if (!item.pivot.servicer_label_id) continue
            data.id = this.myArray[idx].id
            let label_id = item.pivot.servicer_label_id
            label_id = item.pivot.servicer_label_id instanceof Array ? item.pivot.servicer_label_id.slice(-1)[0] : item.pivot.servicer_label_id
            data.servicer_label_id.push(label_id)
          }
          if (this.deweight(data.servicer_label_id, '客服标签重复')) return
          for (const item of this.myArray[idx].matching_rule_customer_label) {
            if (!item.pivot.customer_label_id) continue
            data.id = this.myArray[idx].id
            let label_id = item.pivot.customer_label_id
            label_id = item.pivot.customer_label_id instanceof Array ? item.pivot.customer_label_id.slice(-1)[0] : item.pivot.customer_label_id
            data.customer_label_id.push(label_id)
          }

          if (this.deweight(data.customer_label_id, '客户标签重复')) return
          data.servicer_label_id = data.servicer_label_id[0] ? data.servicer_label_id : []
          data.customer_label_id = data.customer_label_id[0] ? data.customer_label_id : []
          if (!(data.servicer_label_id.length && data.customer_label_id.length)) {
            this.$message({
              message: '请设置匹配标签',
              type: 'warning'
            })
            return
          }
          getBatchChange([data]).then(() => {
            this.init()
            this.$message({
              message: '保存成功',
              type: 'success'
            })
          })
        }
      },
      deweight(data, name) {
        const nary1 = data.sort()
        for (let i = 0; i < nary1.length - 1; i++) {
          if (nary1[i] === nary1[i + 1]) {
            this.$message({
              message: name,
              type: 'warning'
            })
            return true
          }
        }
      },
      handleUpdate(a) { // 移动
        let data = null
        if (a.moved.newIndex === 0) {
          data = { pre_id: 0 }
        } else {
          data = { pre_id: this.myArray[a.moved.newIndex - 1].id }
        }
        getMove(this.myArray[a.moved.newIndex].id, data).then()
      }
    }
  }
</script>

<style scoped lang="scss">
  .Recommend {
    position: relative;
    padding: 0 20px 60px;
    .title {
      display: flex;
      justify-content: space-between;
      align-items: center;
      .button {
        width: 150px;
        height: 40px;
        margin-right: 30px;
      }
      .name {
        margin-right: 5px;
        color: #606266;
        font-size: 14px;
      }
    }
    .main {
      padding: 28px 30px 0;
      box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
      background: #fff;
      .header {
        height: 158px;
        border-bottom: 1px solid #E4E7ED;
        h5 {
          margin: 0;
          font-size: 16px;
        }
        .create {
          display: flex;
          flex-direction: column;
          margin-top: 10px;
          line-height: 26px;
          color: #909399;
          font-size: 14px;
        }
      }
      .draggable {
        flex: 1;
        .item {
          position: relative;
          display: flex;
          justify-content: space-between;
          padding: 40px 20px 20px;
          border-bottom: 1px solid #E4E7ED;
          text-align: center;
          min-height: 150px;
          .labelbor {
            border-left: 1px solid #ccc;
            border-right: 1px solid #ccc;
          }
          .label {
            flex: 1;
            text-align: center;
            .tit {
              position: absolute;
              top: 5px;
              margin-left: 20px;
              display: block;
              height: 32px;
              line-height: 32px;
              font-size: 13px;
              font-weight: 700;
              color: #303133;
            }
          }
          .close-rank {
            display: flex;
            justify-content: flex-end;
            align-items: center;
            width: 280px;
            color: #909399;
            .close {
              margin: 0 15px;
              font-size:28px;
            }
            .button {
              margin: 0 15px;
            }
            .rank {
              font-size: 24px;
              margin-left: 20px;
            }
          }
        }
        .sortable-ghost {
          background: #909399;
        }
        .item:last-child {
          border-bottom: 0;
        }
      }
    }
    .bottom {
      position: fixed;
      left: 0;
      right: 0;
      bottom: 0;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      height: 64px;
      box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
      background: #fff;
      .button {
        width: 150px;
        height: 40px;
        margin-right: 20px;
      }
    }
  }
</style>
