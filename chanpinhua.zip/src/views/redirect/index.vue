<script>
  import { mapGetters } from 'vuex'

  // 旧版使用的是 beforeCreate，但在这个生命周期里，无法使用vuex
  // 目前为了让刷新功能能够正确的获取route 存储的params ，使用了created
  // 引发的问题是，浏览器刷新页面后造成page component 重复init, 并且在首次init 时没有获取到自定义的params
  // 解决方案转移到 route index.js 中，建立一个router before each
  export default {
    computed: {
      ...mapGetters('tagsView', ['visitedViews'])
    },
    created() {
      const { params, query } = this.$route
      const { path } = params
      const view = this.visitedViews.find(v => v.path === '/' + path)
      this.$router.replace(view || { path: '/' + path, query })
    },
    render: function(h) {
      return h() // avoid warning message
    }
  }
</script>
