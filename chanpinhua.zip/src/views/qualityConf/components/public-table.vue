<template>
  <el-card>
    <el-table
      ref="multipleTable"
      :data="tableData.data"
      tooltip-effect="dark"
      @select="handleSelectionChange"
      @select-all="handleSelectionChange"
    >
      <el-table-column
        type="index"
        :index="indexMethod"
      />
      <el-table-column
        width="200"
        label="名称"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="服务方式"
        width="200"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.mode == 0">文本</span>
          <span v-if="scope.row.mode !== 0">电话</span>
        </template>
      </el-table-column>
      <el-table-column
        label="描述"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.description }}</span>
        </template>
      </el-table-column>
      <el-table-column label="是否启用">
        <template slot-scope="scope">
          <el-switch
            v-model="scope.row.is_use"
            @change="handleQiyong(scope.row)"
          />
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="handleEdit(scope.$index, scope.row)"
          >编辑
          </el-button>
          <el-button
            type="text"
            class="el-del"
            @click="handleDelete(scope.$index, scope.row)"
          >删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      :current-page="listData.current_page"
      :page-size="listData.size"
      :page-sizes="[5, 10, 20]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="listData.total"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </el-card>
</template>

<script>
  export default {
    name: 'public-table',
    props: {
      type: {
        type: String,
        required: true
      },
      listData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        isArt: this.type === 'article',
        tableData: [],
        multipleSelection: []
      }
    },
    watch: {
      listData: {
        handler(newVal, oldVal) {
          this.tableData = Object.assign({}, newVal)
          this.multipleSelection = []
        },
        deep: true
      }
    },
    mounted() {
      // console.log(this.isArt)
    },
    methods: {
      indexMethod(index) {
        return index + 1
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
      handleEdit(index, row) {
        this.$emit('edit', index, row)
      },
      handleDelete(index, row) {
        this.$emit('delete', index, row)
      },
      currentChange(val) {
        this.$emit('change', val)
      },
      handleSizeChange(val) {
        this.$emit('handleSizeChange', val)
      },
      handleQiyong(index, row) {
        this.$emit('qiyong', index, row)
      }
    }
  }
</script>
<style scoped lang="scss">
</style>
