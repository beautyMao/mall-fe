<template>
  <el-dialog
    ref="my-dialog"
    v-loading="dialogLoading"
    :title="title"
    custom-class="el-dialog-aside"
    :visible.sync="visible"
    :before-close="() => void $emit('close')"
  >
    <el-form
      ref="form"
      :model="data"
      :rules="rules"
      @submit.native.prevent
    >
      <el-form-item
        label="规则名称"
        prop="name"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="data.name"
          placeholder="仅支持中英文和数字的组合，10字符内"
          type="text"
          auto-complete="off"
        />
      </el-form-item>
      <el-form-item
        label="服务方式"
        prop="mode"
        :label-width="formLabelWidth"
      >
        <el-select
          v-model="data.mode"
          filterable
          placeholder="请选择服务方式"
        >
          <el-option
            v-for="(item, index) in modeList"
            :key="index"
            :label="item.name"
            :value="item.id"
          />
        </el-select>
      </el-form-item>
      <el-form-item
        label="是否启用"
        prop="is_use"
        :label-width="formLabelWidth"
      >
        <el-switch
          v-model="data.is_use"
        />
      </el-form-item>
      <el-form-item
        label="描述"
        prop="description"
        :label-width="formLabelWidth"
      >
        <el-input v-model="data.description" type="textarea" placeholder="请输入内容" maxlength="200" show-word-limit :autosize="{minRows: 3,maxRows: 6}" resize="none" />
      </el-form-item>
      <!------content-title---------->
      <div class="content-title">
        <h3 class="title fl">致命性设置</h3>
        <div class="fr" style="margin-top: 16px;">
          <div class="fl" style="margin-right: 8px;"><i class="el-icon-circle-plus" style="color: #1890FF" /> &nbsp;&nbsp;新增</div>
          <el-checkbox v-model="checkedQuan" class="fl">权重</el-checkbox>
        </div>
      </div>
      <!------bg-grey---------->
      <div v-for="(item, index) in data.fatal_options" class="bg-grey">
        <div v-if="index != 0" class="close">×</div>
        <el-form-item
          label="致命项名称"
          :prop="item.name"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="item.name"
            placeholder="请填写致命项名称"
            type="text"
          />
        </el-form-item>
        <el-form-item
          label="权重值"
          :prop="item.score"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="item.score"
            placeholder="请填写致命项名称"
            type="text"
          />
        </el-form-item>
        <el-form-item
          label="致命项说明"
          :prop="item.description"
          :label-width="formLabelWidth"
        >
          <el-input v-model="item.description" type="textarea" placeholder="请输入内容" maxlength="500" show-word-limit :autosize="{minRows: 3,maxRows: 6}" resize="none" />
        </el-form-item>
      </div>
      <div>
        <p>当前总分 {{ fatal_options_num }}</p>
      </div>
      <!------content-title---------->
      <div class="content-title">
        <h3 class="title fl">非致命性设置</h3>
        <div class="fr" style="margin-top: 16px;">
          <div class="fl" style="margin-right: 8px;"><i class="el-icon-circle-plus" style="color: #1890FF" /> &nbsp;&nbsp;新增</div>
        </div>
      </div>
      <!------bg-no---------->
      <div v-for="(item, index) in data.ordinary_options" class="bg-no">
        <el-form-item
          label="非致命项名称"
          :prop="item.name"
          :label-width="formLabelWidth"
          style="width: 94%;display: inline-block;"
        >
          <el-input
            v-model="item.name"
            placeholder="请填写致命项名称"
            type="text"
          />
        </el-form-item>
        <i class="el-icon-remove" style="color: #1890FF" />
      </div>

    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="$emit('close')">取 消</el-button>
      <el-button type="primary" @click="onData">提 交</el-button>
    </div>
  </el-dialog>
</template>

<script>

  export default {
    name: 'public-dialog',
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      title: {
        type: String,
        default: ''
      },
      nameVal: {
        type: String,
        default: ''
      },
      myData: {
        type: Object,
        default() {
          return {
            name: '',
            mode: 0,
            is_use: 1,
            description: '',
            fatal_options: [{
              name: '',
              score: '',
              description: ''
            }],
            ordinary_options: [{ name: '' }]
          }
        }
      }
    },
    data() {
      const validateName = (rule, value, callback) => {
        const reg = /^[A-Za-z0-9-\(\)\u4e00-\u9fa5]{1,10}$/
        if (!reg.test(this.data.name)) {
          callback(new Error('仅支持中英文和数字的组合，10字符内'))
        } else {
          callback()
        }
      }
      return {
        dialogLoading: false,
        dialogTableVisible: true,
        data: Object.assign({}, this.myData),
        formLabelWidth: '120px',
        modeList: [{ id: 0, name: '文本' }, { id: 1, name: '电话' }],
        checkedQuan: false,
        fatal_options_num: 99,
        rules: {
          name: [{ required: true, validator: validateName, trigger: 'blur' }],
          mode: [{ required: true, message: '请选择质检方式', trigger: 'blur' }],
          is_use: [{ required: true, message: '请选择是否启用', trigger: 'blur' }]
        }
      }
    },
    watch: {
      visible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
        })
      },
      nameVal: {
        handler(newVal, oldVal) {
          this.data.name = newVal
        }
      },
      myData: {
        handler(newVal, oldVal) {
          this.data = Object.assign({}, newVal)
        },
        deep: true
      }
    },
    methods: {
      onData() {
        this.$refs.form.validate(valid => {
          if (valid) {
            this.$emit('submitData', this.data)
          }
        })
      }
    }
  }
</script>
<style scoped lang="scss">
.content-title{
  overflow: hidden;
}
.title{
  color: #303133;
  font-size: 16px;
}
.fl{ float: left; }
.fr{ float: right; }
.title:before {
    content: '*';
    color: #F37261;
    margin-right: 4px;
}
.bg-grey{
  background:rgba(240,242,245,1);
  padding: 34px;
  margin: 10px -10px;
  position: relative;
  .close{
    position: absolute;
    top: 10px;
    right: 10px;
    color: #909399;
    font-size: 20px;
  }
}
</style>
