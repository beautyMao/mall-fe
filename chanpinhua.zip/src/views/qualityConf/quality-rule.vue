<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div class="app-container">
    <header>
      <h1>质检规则</h1>
      <div class="flex-wrp">
        <el-button type="primary" plain @click="addVisible = true">新增质检规则</el-button>
      </div>
    </header>
    <PublickTable
      type="type"
      :list-data="tableDataList"
      @change="handleCurrentChange"
      @handleSizeChange="handleSizeChange"
      @delete="handleDelete"
      @edit="handleEdit"
      @qiyong="handleQiyong"
    />
    <PublickDialog
      :visible="addVisible"
      title="新增质检规则"
      @close="addVisible = false"
      @submitData="handleSubmitData"
    />

    <PublickDialog
      :visible="editVisible"
      title="修改文章分类"
      :name-val="nameVal"
      @close="editVisible = false"
      @submitData="handleSubmitData"
    />
  </div>
</template>

<script>
  import {
    getQualityTestingRules,
    configQualityTestingRulesRestApi,
    getTriggerIsUse
  } from '@/api/quality-conf'
  import PublickTable from './components/public-table'
  import PublickDialog from './components/public-dialog'

  export default {
    name: 'quality-rule',
    components: { PublickTable, PublickDialog },
    data() {
      return {
        addVisible: true,
        editVisible: false,
        nameVal: '',
        tableDataList: {
          case_list: [],
          current_page: 1,
          size: 10,
          total: 0
        },
        currentData: {
          page: 1,
          pageSize: 10
        }
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        const param = {
          mode: 0,
          ...this.currentData
        }
        getQualityTestingRules(param).then(this.renderTable).catch(this.$message.error)
      },
      handleDelete(index, row) {
        // this.$confirm(`确定删除【${row.name}】文章分类吗？此操作无法撤销！`, '提示', {
        //   confirmButtonText: '确定删除',
        //   cancelButtonText: '取消',
        //   type: 'warning'
        // }).then(() => {
        //   configQualityTestingRulesRestApi.delete(row.id).then(response => {
        //     this.$message({
        //       type: 'success',
        //       message: '删除成功!'
        //     })
        //     this.fetchData()
        //   }).catch(this.$message.error)
        // }).catch(() => {})
      },
      handleEdit(index, row) {
        this.nameVal = row.name
        this.editVisible = true
      },
      handleSubmitData(data) {
        console.log(data)
        // configQualityTestingRulesRestApi.post(data).then(response => {
        //   this.fetchData()
        //   this.addVisible = false
        // }).catch(this.$message.error)
      },
      handleCurrentChange(page) {
        this.currentData.page = page
        // searchApiWbClassifiedKnowledge(this.currentData).then(this.renderTable).catch(this.$message.error)
      },
      handleSizeChange(size) {
        this.currentData.pageSize = size
        this.currentData.page = 1
        // searchApiWbClassifiedKnowledge(this.currentData).then(this.renderTable).catch(this.$message.error)
      },
      renderTable(res) {
        this.tableDataList = res.data
        this.currentData.page = res.data.current_page
        this.currentData.pageSize = res.data.per_page
      },
      handleQiyong(row) {
        getTriggerIsUse(row.id).then(res => this.fetchData()).catch(this.$message.error)
      }
    }
  }
</script>

