<template>
  <el-card>
    <el-table
      :data="data"
      style="width: 100%"
    >
      <el-table-column
        type="index"
        :index="indexMethod"
      />
      <el-table-column
        label="通路名称"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="通路标识"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <el-popover v-if="scope.row.en_name === 'wechat' && scope.row.appid" placement="bottom" title="公众号Appid:" trigger="hover" popper-class="accountPopover">
            <div>{{ scope.row.appid }}</div>
            <span slot="reference" type="text">{{ scope.row.en_name }}</span>
          </el-popover>
          <span v-else>{{ scope.row.en_name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="handleEdit(scope.$index, scope.row)"
          >编辑
          </el-button>
          <el-button
            type="text"
            class="el-del"
            @click="handleDelete(scope.$index, scope.row)"
          >删除
          </el-button>
          <el-button
            v-if="scope.row.en_name === 'wechat' && (scope.row.en_name === 'wechat' && !scope.row.appid && scope.row.type === 1)"
            type="text"
            @click="handleVerify(scope.$index, scope.row)"
          >
            <el-popover placement="bottom" title="请选择必要的权限:" trigger="hover" popper-class="accountPopover">
              <div>{{ '消息管理权限' }}</div>
              <div>{{ '用户管理权限' }}</div>
              <div>{{ '素材管理权限' }}</div>
              <span slot="reference" type="text">微信公众号授权</span>
            </el-popover>
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      :current-page="mypagination.current_page"
      :page-size="mypagination.datanum"
      :page-sizes="[10, 15, 20, 25]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="mypagination.total"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </el-card>
</template>

<script>
  export default {
    props: {
      data: {
        type: Array,
        required: true
      },
      mypagination: {
        type: Object,
        required: true
      }
    },
    data() {
      return {}
    },
    methods: {
      indexMethod(index) {
        return index + 1
      },
      handleEdit(index, row) {
        this.$emit('handleEdit', index, row)
      },
      handleDelete(index, row) {
        this.$emit('handleDelete', index, row)
      },
      handleVerify(index, row) {
        this.$emit('handleVerify', index, row)
      },
      currentChange(val) {
        this.$emit('currentChange', val)
      },
      handleSizeChange(val) {
        this.$emit('handleSizeChange', val)
      }
    }
  }
</script>
<style>
  .accountPopover /deep/ .el-popover__title{
    font-weight: 700;
    font-size: 14px;
  }
</style>
