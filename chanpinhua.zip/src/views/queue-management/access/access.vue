<template>
  <div class="app-container">
    <header>
      <h1>通路管理</h1>
      <div class="flex-wrp">
        <el-button type="primary" plain @click="dialogFormVisible = true">新增</el-button>
        <el-input
          v-model.trim="searchText"
          prefix-icon="el-icon-search"
          placeholder="请输入通路名称、通路标识"
          @keyup.enter.native="onSearch(searchText)"
        />
      </div>
    </header>

    <my-dialog title="新增" :mydata="dialogForm" :visible="dialogFormVisible" @on-data="onDialogData" @on-close="dialogFormVisible = false" />
    <my-dialog title="编辑" :mydata="tableForm" :visible="tableFormVisible" @on-data="onTableData" @on-close="tableFormVisible = false" />

    <my-table
      :data="localTableData"
      :mypagination="mypagination"
      @currentChange="handleCurrentChange"
      @handleEdit="handleEdit"
      @handleDelete="handleDelete"
      @handleVerify="handleVerify"
      @handleSizeChange="handleSizeChange"
    />
  </div>
</template>

<script>
  import {
    delApiWbAccessId,
    getApiWbAccess,
    getApiWbAccessSearch,
    postApiWbAccess,
    putApiWbAccessId,
    getAuthUrl
  } from '@/api/queue-management/access'
  import myDialog from '@/views/queue-management/components/myAccessDialog'
  import myTable from '@/views/queue-management/access/components/myTable'

  export default {
    components: { myDialog, myTable },
    data() {
      return {
        searchText: '',
        dialogForm: {
          type: 1,
          name: '',
          en_name: '',
          icon_url: ''
        },
        dialogFormVisible: false,
        tableData: [],
        tableForm: {},
        tableFormVisible: false,
        localTableData: [],
        mypagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        },
        timer: null
      }
    },
    mounted() {
      this.fetchData()
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    methods: {
      fetchData() {
        getApiWbAccess().then(response => {
          this.tableData = response.data
          this.mypagination.current_page = 1
          this.localPagination()
        }).catch(this.$message.error)
      },
      onDialogData(data) {
        postApiWbAccess(data).then(response => {
          this.fetchData()
          this.dialogFormVisible = false
        }).catch(this.$message.error)
      },
      onTableData(data) {
        putApiWbAccessId(data.id, data).then(response => {
          this.fetchData()
          this.tableFormVisible = false
        }).catch(this.$message.error)
      },
      onSearch(text) {
        getApiWbAccessSearch(text).then(response => {
          this.tableData = response.data
          this.mypagination.current_page = 1
          this.localPagination()
        }).catch(this.$message.error)
      },
      handleEdit(index, row) {
        this.tableFormVisible = true
        this.$nextTick(() => {
          this.tableForm = Object.assign({}, row)
        })
      },
      handleDelete(index, row) {
        this.$confirm('此操作将永久删除该通路, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          delApiWbAccessId(row.id).then(response => {
            this.$message.success('删除成功')
            this.fetchData()
          }).catch(this.$message.error)
        })
      },
      openWindow(url, name, iWidth, iHeight) {
        const iTop = (window.screen.availHeight - 30 - iHeight) / 2 // 获得窗口的垂直位置;
        const iLeft = (window.screen.availWidth - 10 - iWidth) / 2 // 获得窗口的水平位置;
        window.open(url, name, `height=${iHeight}, innerHeight=${iHeight}, width=${iWidth}, innerWidth=${iWidth}, top=${iTop}, left=${iLeft}, toolbar=no, menubar=no, scrollbars=auto, resizeable=no, location=no, status=no`)
      },
      handleVerify(index, row) {
        clearInterval(this.timer)
        getAuthUrl(row.id).then(res => {
          this.openWindow(res.data.url, 'a.html', 1000, 600)
          this.timer = setInterval(() => {
            this.fetchData()
          }, 1000 * 5)
        })
      },
      handleCurrentChange(val) {
        this.mypagination.current_page = val
        this.localPagination()
      },
      localPagination() {
        const number = (this.mypagination.current_page - 1) * this.mypagination.datanum
        this.localTableData = this.tableData.slice(number, number + this.mypagination.datanum)
        this.mypagination.total = this.tableData.length
      },
      handleSizeChange(val) {
        this.mypagination.datanum = val
        this.localPagination()
      }
    }
  }
</script>
