<template>
  <el-card>
    <el-table :data="data">
      <el-table-column type="index" :index="indexMethod" />
      <el-table-column label="工程师账号" width="width: 100%">
        <template slot-scope="scope">
          <span>{{ scope.row.engineer_code }}</span>
        </template>
      </el-table-column>
      <el-table-column label="姓名" width="width: 100%">
        <template slot-scope="scope">
          <span>{{ scope.row.engineer_name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="现场通路" width="width: 100%">
        <template slot-scope="scope">
          <span>{{ scope.row.access }}</span>
        </template>
      </el-table-column>
      <el-table-column label="所属业务" width="width: 100%">
        <template slot-scope="scope">
          <span>{{ scope.row.business }}</span>
        </template>
      </el-table-column>
      <el-table-column label="现场业务" width="width: 100%">
        <template slot-scope="scope">
          <span>{{ scope.row.locale_business }}</span>
        </template>
      </el-table-column>
      <el-table-column label="权限" width="width: 100%">
        <template slot-scope="scope">
          <span>{{ scope.row.permission }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="handleEdit(scope.$index, scope.row)"
          >编辑</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      background
      :current-page="mypagination.current_page"
      :page-size="mypagination.datanum"
      :page-sizes="[10, 15, 20, 25]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="mypagination.total"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </el-card>
</template>

<script>
  export default {
    name: 'my-table',
    props: {
      data: {
        type: Array,
        default: () => []
      },
      mypagination: {
        type: Object,
        required: true
      }
    },
    // ['data', 'mypagination'],
    methods: {
      indexMethod(index) {
        return index + 1
      },
      handleEdit(index, row) {
        this.$emit('handleEdit', index, row)
      },
      currentChange(val) {
        this.$emit('currentChange', val)
      },
      handleSizeChange(val) {
        this.$emit('handleSizeChange', val)
      }
    }
  }
</script>

<style scoped>

</style>
