<template>
  <el-dialog ref="my-dialog" :title="title" custom-class="el-dialog-aside" :visible.sync="visible" :before-close="()=>{ onData(false) }">
    <el-form ref="form" :model="data" :rules="rules" @submit.native.prevent>
      <h4>账号信息</h4>
      <el-form-item label="工程师账号" prop="code" :label-width="formLabelWidth">
        <el-input v-model.trim="data.code" placeholder="请输入工程师账号" type="text" auto-complete="off" :disabled="title==='编辑'" @blur="getEngineerInfo" @keyup.enter.native="getEngineerInfo" />
      </el-form-item>
      <el-form-item label="姓名" prop="name" :label-width="formLabelWidth" :disabled="true">
        <el-input v-model.trim="data.name" placeholder="请输入姓名" type="text" auto-complete="off" :disabled="true" />
      </el-form-item>
    </el-form>
    <el-form ref="addForm" :model="addFormItem" :rules="addFormRules">
      <h4>权限信息</h4>
      <el-form-item label="业务" :label-width="formLabelWidth" prop="business">
        <el-select v-model="addFormItem.business" filterable placeholder="请选择业务" value-key="id" :style="{width: '100%'}">
          <el-option v-for="item in businessList" :key="item.id" :label="item.name" :value="item" />
        </el-select>
      </el-form-item>
      <el-form-item label="通路" :label-width="formLabelWidth" prop="access">
        <el-select v-model="addFormItem.access" filterable placeholder="请选择通路" value-key="id" :style="{width: '100%'}">
          <el-option v-for="item in accessList" :key="item.id" :label="item.name" :value="item" />
        </el-select>
      </el-form-item>
      <el-form-item label="权限" :label-width="formLabelWidth" prop="permission">
        <el-radio v-model="addFormItem.permission" label="1">可读</el-radio>
        <el-radio v-model="addFormItem.permission" label="2">可操作</el-radio>
        <el-button type="text" class="ml15" @click="()=>{ onAddForm(addFormItem, 'addForm') }">添加</el-button>
      </el-form-item>
    </el-form>

    <!--<el-form ref="copyEngineerForm" :model="copyEngineerForm" :rules="copyEngineerFormRules">-->
    <!--<h4>复用工程师</h4>-->
    <!--<el-form-item label="工程师" prop="select" :label-width="formLabelWidth">-->
    <!--<el-select v-model="copyEngineerForm.select" placeholder="请选择工程师" value-key="code" :style="{width: '200px'}">-->
    <!--<el-option v-for="(item, index) in selectTableData" :key="index" :label="`${item.name} - ${item.code}`" :value="item" :disabled="item.code===data.code">-->
    <!--<span style="float: left">{{ `${item.code===data.code?'(当前)':''}${item.name}` }}</span>-->
    <!--<span style="float: right; color: #8492a6; font-size: 13px">{{ item.code }}</span>-->
    <!--</el-option>-->
    <!--</el-select>-->
    <!--<el-button type="text" class="ml15" @click="copyOnData(copyEngineerForm, 'copyEngineerForm')">添加</el-button>-->
    <!--</el-form-item>-->
    <!--</el-form>-->

    <div class="flex-wrp flex-between">
      <h4>权限列表</h4>
      <el-button type="text" @click="permissionList=[]">清空队列</el-button>
    </div>
    <el-table
      :data="permissionList"
      max-height="260"
      style="width: 100%"
    >
      <el-table-column
        align="center"
        prop="business_name"
        label="业务"
      />
      <el-table-column
        align="center"
        prop="access_name"
        label="通路"
      />
      <el-table-column
        align="center"
        prop="permissionName"
        label="权限"
      />
      <el-table-column align="center" label="操作">
        <template slot-scope="scope">
          <el-button
            type="text"
            class="el-del"
            @click="handleDelete(scope.$index, scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <div slot="footer" class="dialog-footer">
      <el-button @click="()=>{ onData(false) }">取 消</el-button>
      <el-button class="submit" type="primary" @click="()=>{ onData(true, data) }">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import { getToken } from '@/utils/auth'
  import { getApiWbEngineerSearchInfo, getApiWbEngineerSearch } from '@/api/queue-management/permission'
  export default {
    name: 'my-permission-dialog',
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      mydata: {
        type: Object,
        required: true
      },
      accessList: {
        type: Array,
        default: () => []
      },
      businessList: {
        type: Array,
        default: () => []
      },
      tablePermissionList: {
        type: Array,
        default: () => []
      },
      modeDisabled: {
        type: Boolean,
        default: false
      },
      title: {
        type: String,
        default: ''
      },
      type: {
        type: String,
        default: ''
      }
    },
    // ['visible', 'mydata', 'title', 'modeDisabled', 'modeAllShow', 'type', 'accessList', 'businessList', 'tableData', 'tablePermissionList'],
    data() {
      const isNullStr = (name) => (rule, value, callback) => {
        if (!value) {
          callback(name)
        } else {
          callback()
        }
      }
      return {
        data: JSON.parse(JSON.stringify(this.mydata)),
        getToken,
        selectTableData: [],
        formLabelWidth: '120px',
        selectData: {
          queueList: [],
          accessList: [],
          businessList: []
        },
        rules: {
          code: [{ required: true, trigger: 'blur', message: '必填项' }],
          name: [{ required: true, trigger: 'blur', message: '必填项' }]
        },
        addForm: {
          business: '',
          access: '',
          permission: ''
        },
        permissionList: [], // 权限列表
        addFormItem: { // 用来暂时保存选中的业务通路权限对象
          access: '',
          business: '',
          permission: ''
        },
        addFormRules: {
          queue_level: [{ trigger: 'blur', message: '必填项', validator: isNullStr('请完整配置技能设置') }],
          access_id: [],
          business_id: []
        },
        copyEngineerForm: {
          select: ''
        },
        copyEngineerFormRules: {
          select: [{ trigger: 'blur', message: '必填项', validator: isNullStr('请选择工程师') }]
        }
      }
    },
    watch: {
      visible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
          this.$refs['addForm'].resetFields()
          console.log(11111111)
          this.permissionList = []
        })
      },
      mydata: {
        handler(newName, oldName) {
          this.data = newName
        },
        deep: true
      },
      tablePermissionList: {
        handler(newName, oldName) {
          this.permissionList = newName
        },
        deep: true
      }
    },
    mounted() {
      console.log('this.mydata', this.mydata)
      if (this.type === 'edit') {
        this.permissionList = []
        this.permissionList = this.tablePermissionList
      } else if (this.type === 'add') {
        this.permissionList = []
      }
      console.log('this.permissionList', this.permissionList)
    },
    methods: {
      onData(status, tmp) {
        if (status) {
          this.$refs['form'].validate((valid) => {
            if (valid) {
              const data = JSON.parse(JSON.stringify(tmp))
              const params = {
                'engineer_code': data.code,
                'locales': []
              }
              for (let i = 0; i < this.permissionList.length; i++) {
                console.log(222)
                const item = {
                  'access_id': this.permissionList[i].access_id,
                  'business_id': this.permissionList[i].business_id,
                  'permission': this.permissionList[i].permission
                }
                params.locales.push({ ...item })
              }
              console.log(params)
              this.$emit('onData', status, { ...params })
            }
          })
        } else {
          this.$emit('onData', status)
        }
      },
      onAddForm(addFormItem, cName) {
        console.log(this.data)
        if (addFormItem.business === '' && addFormItem.access === '' || addFormItem.permission === '') {
          this.$message({
            type: 'warning',
            message: `请重新配置权限信息`
          })
          return false
        } else {
          this.addForm.business_id = this.addFormItem.business.id
          this.addForm.access_id = this.addFormItem.access.id
          this.addForm.business_name = this.addFormItem.business.name
          this.addForm.access_name = this.addFormItem.access.name
          this.addForm.permission = this.addFormItem.permission
          if (this.addForm.permission === '1') {
            this.addForm.permissionName = '可读'
          } else {
            this.addForm.permissionName = '可操作'
          }

          if (this.permissionList.length === 0) {
            this.permissionList.push({ ...this.addForm })
          } else {
            for (let i = 0; i < this.permissionList.length; i++) {
              if (this.addForm.business_id === this.permissionList[i].business_id && this.addForm.access_id === this.permissionList[i].access_id) {
                this.$message({
                  type: 'warning',
                  message: '该工程师下队列已存在，请重新选择'
                })
                return false
              }
            }
            this.permissionList.push({ ...this.addForm })
          }
          console.log('this.permissionList', this.permissionList)
        }
      },
      copyOnData(data, formName) {
        this.$refs[formName].validate((valid) => {
          if (valid) {
            console.log(valid)
          } else {
            this.$message({
              type: 'warning',
              message: `请选择工程师`
            })
            return false
          }
        })
      },
      handleDelete(index, row) {
        this.permissionList.splice(index, 1)
      },
      getEngineerInfo() {
        setTimeout(() => {
          console.log('this.visible', this.visible)
          if (this.visible) {
            getApiWbEngineerSearchInfo(this.data.code).then(res => {
              if (res.data.name === null || res.data.name === '') {
                this.$message('未找到该用户')
              } else {
                this.data.name = res.data.name
                getApiWbEngineerSearch(this.data.name).then(response => {
                  if (!this.permissionList.length) {
                    // permissionList
                    for (let i = 0; i < response.data.length; i++) {
                      let permission
                      if (response.data[i].permission === '可读') {
                        permission = 1
                      } else {
                        permission = 2
                      }
                      const item = {
                        'access_id': response.data[i].access_id,
                        'access_name': response.data[i].access,
                        'business_name': response.data[i].locale_business,
                        'business_id': response.data[i].business_id,
                        'permissionName': response.data[i].permission,
                        'permission': permission
                      }
                      this.permissionList.push({ ...item })
                    }
                  } else {
                    return this.permissionList
                  }
                })
              }
            })
          }
        }, 500)
        this.$emit('handleGetEngineerInfo', 1)
      }
    }
  }
</script>
