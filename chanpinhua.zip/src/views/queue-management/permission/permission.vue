<template>
  <div class="app-container">
    <header>
      <h1>{{ $route.meta.title }}</h1>
      <div class="flex-wrap">
        <el-button type="primary" plain @click="addDialogForm">新增</el-button>
        <el-input v-model.trim="searchText" placeholder="请输入工程师账号、姓名" @keyup.enter.native="onSearch(searchText)">
          <el-button slot="append" icon="el-icon-search" @click="onSearch(searchText)" />
        </el-input>
      </div>
    </header>

    <my-permission-dialog
      type="add"
      :business-list="businessList"
      :access-list="accessList"
      :mydata="dialogForm"
      :table-data="tableData"
      title="新增"
      :visible="dialogFormVisible"
      class="modification"
      @onData="onDialogData"
      @handleGetEngineerInfo="handleGetEngineerInfo"
    />

    <my-table
      :data="localTableData"
      :mypagination="mypagination"
      @currentChange="handleCurrentChange"
      @handleEdit="handleEdit"
      @handleSizeChange="handleSizeChange"
    />

    <my-permission-dialog
      type="edit"
      :table-permission-list="permissionList"
      :business-list="businessList"
      :access-list="accessList"
      :mydata="tableForm"
      title="编辑"
      :visible="tableFormVisible"
      class="modification"
      @onData="onTableData"
    />
  </div>

</template>
<script>
  import { getApiWbEngineerLocale, getApiWbEngineerSearch, postApiWbEngineerLocale } from '@/api/queue-management/permission'
  // import { getApiWbBusiness } from '@/api/queue-management/business'
  import { getApiWbBusiness } from '@/api/ccp/index'
  import { getApiWbAccess } from '@/api/queue-management/access'
  import myTable from '@/views/queue-management/permission/components/myTable'
  import myPermissionDialog from '@/views/queue-management/permission/components/myPermissionDialog'

  export default {
    name: 'ccp-management',
    components: { myTable, myPermissionDialog },
    data() {
      return {
        searchText: '',
        tableData: [],
        tableForm: {
          name: '',
          code: ''
        },
        tableFormVisible: false,
        localTableData: [],
        permissionList: [],
        mypagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        },
        dialogForm: {
          name: '',
          code: ''
        },
        dialogFormVisible: false,
        businessList: [],
        accessList: [],
        oldVal: false
      }
    },
    computed: {},
    watch: {},
    mounted() {
      this.fetchData()
      this.fetchDialogData()
    },
    methods: {
      addDialogForm() {
        console.log(111)
        this.dialogFormVisible = true
        this.dialogForm = {
          type: 2,
          business_id: '',
          channel_id: '',
          access_id: '',
          name: '',
          work_start_at: '',
          work_end_at: '',
          callback: 1,
          pick: 2,
          transfer: 1,
          consult: 1,
          time_limit: 1,
          icon_url: '',
          visible: 2,
          welcome_words: ''
        }
      },
      fetchData() {
        getApiWbEngineerLocale().then(response => {
          this.tableData = response.data
          this.mypagination.current_page = 1
          this.localPagination()
        })
      },
      onDialogData(status, data) {
        if (status) {
          postApiWbEngineerLocale(data).then(res => {
            console.log('res', res)
          })
        }
        if (status) {
          getApiWbEngineerLocale().then(response => {
            setTimeout(() => {
              this.fetchData()
            }, 1000)
            this.dialogFormVisible = false
          }).catch(err => {
            console.log(err)
          })
        } else {
          this.dialogFormVisible = false
        }
      },
      onTableData(status, data) {
        this.permissionList = []
        if (status) {
          postApiWbEngineerLocale(data).then(res => {
            console.log('res', res)
          })
        }
        if (status) {
          getApiWbEngineerLocale().then(response => {
            setTimeout(() => {
              this.fetchData()
            }, 1000)
            this.tableFormVisible = false
          }).catch(err => {
            console.log(err)
          })
        } else {
          this.tableFormVisible = false
        }
      },
      onSearch(text) {
        getApiWbEngineerSearch(text).then(response => {
          this.tableData = response.data
          this.mypagination.current_page = 1
          this.localPagination()
        })
      },
      localPagination() {
        const number = (this.mypagination.current_page - 1) * this.mypagination.datanum // num
        console.log('number', number)
        console.log('datanum', this.mypagination.datanum)
        this.localTableData = this.tableData.slice(number, number + this.mypagination.datanum)
        this.mypagination.total = this.tableData.length
      },
      fetchDialogData() {
        // 获取 业务 列表
        getApiWbBusiness().then(response => {
          this.businessList = response.data
          console.log('this.businessList', this.businessList)
        })
        // 获取 通路 列表
        getApiWbAccess().then(response => {
          this.accessList = response.data
          console.log('this.accessList', this.accessList)
        })
      },
      handleEdit(index, row) {
        console.log('row', row)
        this.tableFormVisible = true
        this.tableForm = {
          name: row.engineer_name,
          code: row.engineer_code
        }
        console.log('tableForm', this.tableForm)
        getApiWbEngineerSearch(row.engineer_code).then(response => {
          console.log('response', response)
          // permissionList
          for (let i = 0; i < response.data.length; i++) {
            let permission
            if (response.data[i].permission === '可读') {
              permission = 1
            } else {
              permission = 2
            }
            const item = {
              'access_id': response.data[i].access_id,
              'access_name': response.data[i].access,
              'business_name': response.data[i].locale_business,
              'business_id': response.data[i].business_id,
              'permissionName': response.data[i].permission,
              'permission': permission
            }
            console.log(111, item)
            this.permissionList.push({ ...item })
          }
        })
      },
      handleGetEngineerInfo(val) {
      },
      handleCurrentChange(val) {
        this.mypagination.current_page = val
        this.localPagination()
      },
      handleSizeChange(val) { // 改变每页条数
        this.mypagination.datanum = val
        this.localPagination()
      }
    }
  }
</script>

