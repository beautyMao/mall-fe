<template>
  <div class="app-container">
    <header>
      <h1>{{ $route.meta.title }}</h1>
      <div class="flex-wrap">
        <el-button type="primary" plain :disabled="!buttonPermission('accountRegiest')" @click="createEngineer">创建客服</el-button>
        <el-button type="primary" plain :disabled="!(buttonPermission('accountDelete') && pitchOn.length)" @click="batchDelete">批量删除</el-button>
        <el-input v-model="input" placeholder="请输入客服账号或姓名" class="input" @keyup.enter.native="searchInfo" @blur="searchInfo">
          <i slot="prefix" class="el-input__icon el-icon-search" />
        </el-input>
      </div>
    </header>
    <el-card class="box-card">
      <el-table :data="engineerInfo" tooltip-effect="light" class="tab" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="42" />
        <el-table-column type="index" width="40" />
        <el-table-column prop="code" label="客服账号" width="100" />
        <el-table-column prop="name" label="客服姓名" />
        <el-table-column prop="nickname" label="昵称" />
        <el-table-column prop="businesses" label="所属业务" />
        <el-table-column prop="roles" label="账号角色">
          <template slot-scope="scope">
            <el-popover v-if="scope.row.roles.length" placement="bottom" title="账号角色:" trigger="hover" popper-class="accountPopover">
              <div v-for="item in scope.row.roles" :key="item" class="popoverHeight">{{ item }}</div>
              <span slot="reference" type="text">{{ scope.row.roles[0] }}</span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column prop="labels" label="客服标签">
          <template slot-scope="scope">
            <el-popover v-if="scope.row.labels.length" placement="bottom" title="客服标签:" trigger="hover" popper-class="accountPopover">
              <div v-for="item in scope.row.labels" :key="item.id" class="popoverHeight">{{ item.name }}</div>
              <span slot="reference" type="text">{{ scope.row.labels[0].name }}</span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column prop="chat_limit" label="会话上限" width="80" />
        <el-table-column prop="queue_limit" label="排队上限" width="80" />
        <el-table-column prop="menu_permissions.name" label="技能组" width="120">
          <template slot-scope="scope">
            <el-popover v-if="scope.row.queues.length" placement="bottom" title="技能组:" trigger="hover" popper-class="accountPopover">
              <div v-for="item in scope.row.queues" :key="item.id" class="popoverHeight">{{ item.name }}</div>
              <span slot="reference" style="color:#606266">
                {{ scope.row.queues[0].name.length > 7 ? scope.row.queues[0].name.substring(0, 7) + '...' : scope.row.queues[0].name }}
              </span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column prop="" label="操作" width="140px">
          <template slot-scope="scope">
            <el-button :disabled="!buttonPermission('accountInfo')" type="text" @click="itemExamine(scope.row)">查看</el-button>
            <el-button :disabled="!buttonPermission('accountEdit')" type="text" @click="itemRedact(scope.row)">编辑</el-button>
            <el-button :disabled="!buttonPermission('accountDelete')" type="text" @click="itemDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>

      <el-pagination
        background
        :page-sizes="[10, 15, 20, 25]"
        :current-page="data.page"
        :page-size="data.per_page"
        :total="data.total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>
    <v-dialog v-if="createEditorInfo.createEditor" v-bind="createEditorInfo" @closeDialog="closeDialog" />
  </div>
</template>

<script>
  import { getAccountSearch, getAccountDelete } from '@/api/account-info'
  import vDialog from './components/v-dialog'
  import { mapGetters } from 'vuex'
  // import vDialog from '@/views/queue-management/account/components/v-dialog'
  export default {
    components: { vDialog },
    data() {
      return {
        input: '',
        engineerInfo: [],
        pitchOn: '',
        data: {
          is_page: true,
          page: 1,
          per_page: 10,
          total: 0
        },
        createEditorInfo: {
          createEditor: false,
          title: '创建账户',
          code: '',
          boo: 1
        }
      }
    },
    computed: {
      ...mapGetters([
        'buttonPermission'
      ])
    },
    mounted() {
      this.init()
    },
    methods: {
      init() {
        getAccountSearch(this.data).then(res => {
          this.engineerInfo = res.data.data
          this.data.total = res.data.total
          for (const i in this.engineerInfo) {
            this.engineerInfo[i].roles = this.engineerInfo[i].roles.split(',')
          }
        })
      },
      closeDialog(val) {
        if (val) {
          this.init()
        }
        this.createEditorInfo.createEditor = false
      },
      handleSelectionChange(val) { // 获取批量数据
        this.pitchOn = val
      },
      batchDelete() { // 批量删除
        var codes = []
        if (!this.pitchOn.length) {
          this.$message({
            message: '请选择客服',
            type: 'warning'
          })
          return
        }
        for (const item of this.pitchOn) {
          codes.push(item.code)
        }
        const list = { codes }
        this.$confirm('是否永久删除这些账号？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          getAccountDelete(list).then(res => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.data.input = ''
            this.init()
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      itemDelete(row) {
        var codes = []
        codes.push(row.code)
        const list = { codes }
        this.$confirm(`此操作将删除 ${row.code}/${row.name} 且无法撤销，是否继续？`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          getAccountDelete(list).then(res => {
            this.$message({
              type: 'success',
              message: `已删除 ${row.code}/${row.name} !`
            })
            this.data.input = ''
            this.init()
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      itemExamine(row) {
        this.createEditorInfo.title = '查看账号'
        this.createEditorInfo.code = row.code
        this.createEditorInfo.createEditor = true
      },
      itemRedact(row) {
        this.createEditorInfo.title = '编辑账号'
        this.createEditorInfo.code = row.code
        this.createEditorInfo.createEditor = true
      },
      createEngineer() {
        this.createEditorInfo.title = '创建账号'
        this.createEditorInfo.code = ''
        this.createEditorInfo.createEditor = true
      },
      searchInfo() { // 查询客服
        this.data.input = this.input
        this.data.page = 1
        this.data.per_page = 10
        this.init()
      },
      handleSizeChange(val) { // 每页条数
        this.data.per_page = val
        this.init()
      },
      handleCurrentChange(val) { // 第几页
        this.data.page = val
        this.init()
      }
    }
  }
</script>

<style>
  .accountPopover /deep/ .el-popover__title{
    font-weight: 700;
    font-size: 14px;
  }
</style>
