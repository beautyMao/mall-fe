<template>
  <div class="create-account">
    <el-form
      ref="ruleForm"
      size="medium"
      :model="ruleForm"
      :rules="rules"
      label-width="110px"
      :disabled="title === '查看账号'"
    >
      <el-form-item label="姓名" prop="name">
        <el-input v-model="ruleForm.name" placeholder="请输入姓名" />
      </el-form-item>
      <el-form-item label="昵称" prop="nickname">
        <el-input v-model="ruleForm.nickname" placeholder="请输入昵称" />
      </el-form-item>
      <el-form-item label="性别" prop="sex" :rules="[{ required: true, message: ' '}]">
        <el-radio v-model="ruleForm.sex" label="男">男</el-radio>
        <el-radio v-model="ruleForm.sex" label="女">女</el-radio>
      </el-form-item>
      <el-form-item v-if="code" label="客服账号" prop="code">
        <span>{{ code }}</span>
      </el-form-item>
      <el-form-item class="upload" label="头像">
        <el-upload class="avatar-uploader" :action="uploadUrl()" :show-file-list="false" :before-upload="beforeAvatarUpload" :on-success="handleAvatarSuccess">
          <img v-if="imageUrl" :src="imageUrl" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon" />
          <div slot="tip" class="el-upload__tip">(建议上传60*60px，大小不超过2M的jpg、png格式）</div>
        </el-upload>
      </el-form-item>
      <el-form-item label="手机号" prop="phone">
        <el-input v-model="ruleForm.phone	" placeholder="请输入手机号" />
      </el-form-item>
      <el-form-item label="邮箱" prop="email">
        <el-input v-model="ruleForm.email	" placeholder="请输入邮箱" />
      </el-form-item>
      <el-form-item label="角色" prop="roles">
        <el-select v-model="ruleForm.roles" multiple collapse-tags placeholder="请选择">
          <el-option v-for="item in role" :key="item.id" :label="item.name" :value="item.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="所属业务" prop="businesses">
        <el-cascader v-model="ruleForm.businesses" :show-all-levels="false" :options="business" :props="cascaderAlias" />
      </el-form-item>
      <el-form-item label="个人会话上限" prop="chat_limit">
        <el-input-number v-model="ruleForm.chat_limit" controls-position="right" :min="0" placeholder="0" />
      </el-form-item>
      <el-form-item label="个人排队上限" prop="queue_limit">
        <el-input-number v-model="ruleForm.queue_limit" controls-position="right" :min="0" placeholder="0" />
      </el-form-item>
      <h3>客服标签匹配</h3>
      <el-form-item label="客服标签" prop="labels">
        <el-popover
          placement="bottom"
          width="200"
          class="labels-btn"
          trigger="click"
        >
          <el-cascader
            ref="cascader"
            v-model="labels"
            :show-all-levels="false"
            :options="servicerList"
            :props="cascaderAlias1"
            clearable
            popper-class="cascaderPopper"
            filterable
            class="cascader"
            @change="handleCascaderChange"
          />
          <el-button slot="reference" icon="el-icon-plus" type="primary" circle size="medium" />
        </el-popover>
        <el-tag
          v-for="item in labels1"
          :key="item.id"
          effect="plain"
          :closable="title !== '查看账号'"
          :disable-transitions="false"
          class="tag"
          @close="handleClose(item)"
        >
          {{ item.name }}
        </el-tag>
      </el-form-item>
      <h3>技能组配置</h3>
      <el-form-item label="所属业务">
        <el-cascader v-model="business1" :show-all-levels="false" :options="business" :props="cascaderAlias" @change="handleChange" />
      </el-form-item>
      <el-form-item label="所属通路">
        <el-select ref="access" v-model="access1" placeholder="请选择" @change="handleChange">
          <el-option v-for="item in access" :key="item.id" :label="item.name" :value="item.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="技能组" prop="id">
        <el-select v-model="name" placeholder="请选择" @focus="handleBusinessesFocus">
          <el-option v-for="item in skillsetList" :key="item.id" :label="item.label" :value="item.value" />
        </el-select>
      </el-form-item>
      <el-form-item label="优先级" prop="queue_level">
        <el-select v-model="queue_level" placeholder="请选择">
          <el-option v-for="item in queue_level_list" :key="item" :label="item" :value="item" />
        </el-select>
      </el-form-item>
      <el-form-item>
        <el-button type="primary" plain @click="addSkillset">添加</el-button>
      </el-form-item>

      <h3 class="clearfix">
        技能组列表
        <el-button class="fr" type="text" @click="clearSkillset">清空技能组</el-button>
      </h3>
      <div class="border">
        <el-table :data="tableData">
          <el-table-column prop="name" label="技能组名称" />
          <el-table-column prop="queue_level" label="优先级" width="60" />
          <el-table-column prop="bussiness" label="业务" />
          <el-table-column prop="access" label="通路" />
          <el-table-column width="50" label="操作">
            <template slot-scope="scope">
              <el-button type="text" :class="{btn:(title !== '查看账户')}" @click="deleteTableItem(scope.$index)">删除</el-button>
            </template>
          </el-table-column>
        </el-table>
      </div>
    </el-form>
  </div>
</template>

<script>
  import { QINIU_ACTION } from '@/api/qiniu'

  const manAvatar = 'https://cube-resources.lenovo.com.cn//cube/6c40feb2a676d779e1ca0c114da97926.png'
  const womanAvatar = 'https://cube-resources.lenovo.com.cn//cube/0431b3d48df26937385fd1e906ed2ad8.png'
  import {
    getAccountCreate,
    getRoleLists,
    getStructureBusiness,
    getStructureAccess,
    getBusinessQueues,
    getAccountInfo,
    getAccountInfo1,
    getAccountEdit
  } from '@/api/account-info'
  import { getToken } from '@/utils/auth'
  import { getServicerLabel } from '@/api/rule-management/recommend'
  export default {
    name: 'create-account',
    props: {
      code: {
        type: String,
        default: ''
      },
      title: {
        type: String,
        default: ''
      },
      boo: {
        type: Number,
        default: 0
      }
    },
    data() {
      const checkName = (rule, value, callback) => {
        if (value) {
          const reg = /^[\w\u4E00-\u9FA5]{2,10}$/
          if (reg.test(value)) {
            callback()
          } else {
            return callback(new Error('请输入10位以内中英文字符'))
          }
        }
      }
      const checkNickname = (rule, value, callback) => {
        if (value) {
          const reg = /^[\w\u4E00-\u9FA5]{2,10}$/
          if (reg.test(value)) {
            callback()
          } else {
            return callback(new Error('请输入10位以内中英文字符'))
          }
        }
      }
      const checkBus = (rule, value, callback) => {
        if (value.length) {
          callback()
        } else {
          return callback(new Error('请选择客服所属业务'))
        }
      }
      return {
        ruleForm: {
          name: '',
          sex: '女',
          nickname: '',
          avatar: '',
          phone: '',
          email: '',
          roles: [],
          businesses: [],
          chat_limit: '5',
          queue_limit: '5',
          queues: [],
          labels: []
        },
        rules: {
          name: [
            { required: true, message: '请填写姓名' },
            { validator: checkName, trigger: 'blur' }
          ],
          nickname: [{ validator: checkNickname, trigger: 'blur' }],
          phone: [
            { required: true, message: '请输入手机号' },
            { min: 11, max: 11, message: '手机号格式不正确', trigger: 'blur' }
          ],
          email: [
            { required: true, message: '请输入邮箱', trigger: 'blur' },
            { type: 'email', message: '邮箱格式不正确', trigger: 'blur' }
          ],
          roles: [{ required: true, message: '请选择客服角色' }],
          businesses: [{ required: true, validator: checkBus, trigger: 'blur' }]
        },
        role: [], // 角色列表
        business: [], // 业务
        business1: [],
        access: [], // 通路
        access1: '',
        name: '', // 技能组
        queue_level_list: [1, 2, 3, 4, 5, 6, 7, 8, 9],
        queue_level: '', // 优先级
        skillsetList: [], // 技能组列表
        cascaderAlias: {
          value: 'id',
          label: 'name',
          children: 'childs',
          checkStrictly: true
        },
        imageUrl: '',
        tableData: [], // 技能组列表
        servicerList: [],
        labels: [],
        labels1: [],
        cascaderAlias1: {
          value: 'id',
          label: 'servicer_label_name',
          children: 'children'
        }
      }
    },
    watch: {
      'ruleForm.sex'() {
        if (this.ruleForm.avatar === womanAvatar) {
          if (this.ruleForm.sex === '男') {
            this.ruleForm.avatar = manAvatar
            this.imageUrl = manAvatar
          }
        } else if (this.ruleForm.avatar === manAvatar) {
          if (this.ruleForm.sex === '女') {
            this.ruleForm.avatar = womanAvatar
            this.imageUrl = womanAvatar
          }
        }
      }
    },
    mounted() {
      this.init()
      this.imageUrl = womanAvatar
      this.ruleForm.avatar = womanAvatar
    },
    methods: {
      init() {
        getServicerLabel().then(res => {
          this.servicerList = this.getTreeData1(res.data)
        })
        if (this.boo === 1) {
          this.ruleForm.source = 'accountEdit'
        }
        getStructureBusiness(this.boo).then(res => { // 获取业务列表
          this.business = this.getTreeData(res.data)
          if (this.code) { // 编辑页面push数据
            getAccountInfo(this.code).then(res => {
              this.ruleForm.name = res.data.name
              this.ruleForm.sex = res.data.sex
              this.ruleForm.nickname = res.data.nickname
              this.ruleForm.avatar = res.data.avatar
              if (res.data.avatar) {
                this.imageUrl = res.data.avatar
              } else {
                if (res.data.sex === '女') {
                  this.imageUrl = womanAvatar
                  this.ruleForm.avatar = womanAvatar
                } else {
                  this.imageUrl = manAvatar
                  this.ruleForm.avatar = manAvatar
                }
              }
              this.ruleForm.phone = res.data.phone
              this.ruleForm.email = res.data.email
              for (const item of res.data.roles) {
                this.ruleForm.roles.push(item.id)
              }
              for (const item of res.data.businesses) {
                this.ruleForm.businesses = item.ids
                if (this.boo === 0) {
                  getAccountInfo1().then(res => {
                    this.ids = res.data.businesses[0].ids.pop()
                    this.setBusinessList()
                  })
                }
              }
              this.ruleForm.queues = res.data.queues
              this.tableData = [...res.data.queues]
              this.ruleForm.chat_limit = res.data.chat_limit
              this.ruleForm.queue_limit = res.data.queue_limit
              this.labels1 = res.data.labels
            })
          } else {
            if (this.boo === 0) {
              getAccountInfo1().then(res => {
                this.ids = res.data.businesses[0].ids.pop()
                this.setBusinessList()
              })
            }
          }
        })
        getStructureAccess().then(res => { // 获取通路列表
          this.access = res.data
        })
        getRoleLists().then(res => { // 获取角色列表
          this.role = res.data
        })
      },
      getTreeData1(data) { // 去除空children
        for (var i = 0; i < data.length; i++) {
          if (data[i].children.length < 1) {
            // children若为空数组，则将children设为undefined
            data[i].children = undefined
          } else {
            // children若不为空数组，则继续 递归调用 本方法
            this.getTreeData1(data[i].children)
          }
        }
        return data
      },
      uploadUrl() { // 上传图片地址
        return `${QINIU_ACTION}?token=${getToken()}`
      },
      handleClose(tag) {
        this.labels1.splice(this.labels1.indexOf(tag), 1)
      },
      handleCascaderChange(e) {
        const data = this.reverseSearch(this.servicerList, e.pop())
        for (const i in this.labels1) {
          if (this.labels1[i].id === data.id) {
            this.labels1.splice(i, 1)
          }
        }
        this.labels1.push({
          id: data.id,
          name: data.servicer_label_name
        })
        this.labels = []
      },
      reverseSearch(tree, targetId) {
        for (const elem of tree) {
          if (elem.children === undefined) {
            if (elem.id === targetId) {
              return elem
            }
          } else {
            const found = this.reverseSearch(elem.children, targetId)
            if (found !== undefined) {
              return found
            }
          }
        }
        getServicerLabel().then(res => {
          this.servicerList = this.getTreeData1(res.data)
        })
      },
      handleAvatarSuccess(res, file) {
        this.imageUrl = URL.createObjectURL(file.raw)
        this.ruleForm.avatar = res.data.picUrl
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg' || file.type === 'image/png'
        const isLt2M = file.size / 1024 / 1024 < 2

        if (!isJPG) {
          this.$message.error('上传头像图片只能是 JPG或PNG 格式!')
        }
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!')
        }
        return isJPG && isLt2M
      },
      handleChange() {
        this.name = ''
        this.skillsetList = []
      },
      handleBusinessesFocus() { // 获取技能组码表
        if (!this.access1 || !this.business1.length) {
          this.$message({
            message: '请选择业务通路',
            type: 'warning'
          })
          return
        }
        const data = {
          access_id: this.access1,
          business_id: this.business1[this.business1.length - 1]
        }
        getBusinessQueues(data).then(res => { // 清空技能组列表
          this.skillsetList = []
          for (var item of res.data) {
            this.skillsetList.push({
              value: [item.id, item.name],
              label: item.name
            })
          }
        })
      },
      getCascaderObj(val, business) {
        return val.map((value, index, array) => {
          for (var itm of business) {
            if (itm.id === value) { business = itm.childs; return itm }
          }
          return null
        })
      },
      setBusinessList() { // 设置所属业务为当前人员可操作业务
        if (this.business[0].id !== this.ids) {
          this.handleBusinessChange(this.business[0].childs)
        }
      },
      handleBusinessChange(data) {
        for (const item of data) {
          if (item.id !== this.ids) {
            this.handleBusinessChange(item.childs)
          } else {
            this.business = [item]
          }
        }
      },
      getTreeData(data) {
        // 循环遍历json数据
        for (var i = 0; i < data.length; i++) {
          if (data[i].childs.length < 1) {
            // children若为空数组，则将children设为undefined
            data[i].childs = undefined
          } else {
            // children若不为空数组，则继续 递归调用 本方法
            this.getTreeData(data[i].childs)
          }
        }
        return data
      },
      addSkillset() {
        if (!this.name) {
          this.$message({
            message: '请填写技能组',
            type: 'warning'
          })
          return
        }
        if (!this.queue_level) {
          this.$message({
            message: '请填写优先级',
            type: 'warning'
          })
          return
        }
        for (const item of this.tableData) {
          if (item.id === this.name[0]) {
            this.$message({
              message: '技能组不能重复添加',
              type: 'warning'
            })
            return
          }
        }
        const data = this.getCascaderObj(this.business1, this.business)
        var business = ''
        for (var item of data) {
          business += item.name + '/'
        }
        business = business.substring(0, business.length - 1)
        this.ruleForm.queues.push({
          id: this.name[0],
          bussiness: this.business1,
          queue_level: this.queue_level
        })
        this.tableData.push({
          id: this.name[0],
          name: this.name[1],
          queue_level: this.queue_level,
          bussiness: business,
          access: this.$refs.access.selectedLabel
        })
        this.name = ''
        this.queue_level = ''
        this.access1 = ''
        this.skillsetList = []
        this.business1 = []
      },
      deleteTableItem(index) {
        this.tableData.splice(index, 1)
        this.ruleForm.queues.splice(index, 1)
      },
      clearSkillset() {
        this.ruleForm.queues = []
        this.tableData = []
      },
      submitForm() {
        const reg = /^[\w\u4E00-\u9FA5]{2,20}$/
        const reg1 = /^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,})$/
        const valid = reg.test(this.ruleForm.name) && (this.ruleForm.sex === '女' || this.ruleForm.sex === '男') && this.ruleForm.phone.length === 11 && reg1.test(this.ruleForm.email) && this.ruleForm.roles.length && this.ruleForm.businesses.length
        if (this.ruleForm.businesses.length) {
          this.ruleForm.businesses = [this.ruleForm.businesses.pop()]
        }
        this.$refs.ruleForm.validate((valid) => {})
        if (this.labels1.length) {
          for (const i in this.labels1) {
            this.ruleForm.labels.push(this.labels1[i].id)
          }
        }
        if (valid) {
          if (this.code) {
            this.ruleForm.code = this.code
            getAccountEdit(this.ruleForm).then(res => {
              this.$emit('operateSucc', true)
              this.$message({
                message: '编辑员工成功',
                type: 'warning'
              })
            }).catch((err) => {
              this.$message({
                message: err,
                type: 'warning'
              })
            })
          } else {
            getAccountCreate(this.ruleForm).then(res => {
              this.$emit('operateSucc', true)
              this.$message({
                message: '新增员工成功',
                type: 'warning'
              })
            }).catch((err) => {
              this.$message({
                message: err,
                type: 'warning'
              })
            })
          }
        } else {
          this.$emit('operateSucc', false)
          // this.$message({
          //   message: '请填写必填项',
          //   type: 'warning'
          // })
          return false
        }
      }
    }
  }
</script>

<style scoped lang="scss">
  h3 {
    margin-top: 25px;
  }
  .el-button--medium.is-circle {
    padding: 4px;
    font-size: 12px;
  }
  .tag {
    margin: 5px;
  }
  .avatar {
    width: 60px;
    height: 60px;
    display: block;
  }
</style>
<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
</style>

