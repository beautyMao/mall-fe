<template>
  <div class="my-dialog">
    <!-- Form -->
    <el-dialog
      :title="title"
      custom-class=""
      width="460px"
      :visible.sync="visible"
      :before-close="() => void $emit('on-close')"
    >
      <el-form ref="form" :model="data" :rules="rules" @submit.native.prevent>
        <h4>账号信息</h4>
        <el-form-item label="客服账号" prop="code" :label-width="formLabelWidth">
          <el-input
            v-model.trim="data.code"
            placeholder="请输入客服账号"
            type="text"
            auto-complete="off"
            :disabled="title==='编辑'"
          />
        </el-form-item>
        <el-form-item label="角色" prop="role_id" :label-width="formLabelWidth">
          <el-input
            v-model.trim="data.role_name"
            placeholder="客服角色"
            type="text"
            auto-complete="off"
            :disabled="title==='编辑'"
          />
          <!--<el-select v-model="data.role_id" filterable placeholder="请选择角色" :disabled="title==='编辑'" :style="{width: '100%'}">-->
          <!--<el-option v-for="(item, index) in roleList" :key="index" :label="item.name" :value="item.id" ></el-option>-->
          <!--</el-select>-->
        </el-form-item>
        <h4>角色信息</h4>
        <el-form-item label="姓名" prop="name" :label-width="formLabelWidth">
          <el-input
            v-model.trim="data.name"
            placeholder="请输入姓名"
            type="text"
            auto-complete="off"
            :disabled="title==='编辑'"
          />
        </el-form-item>
        <el-form-item label="所属业务" prop="business_id" :label-width="formLabelWidth">
          <el-select
            v-model="data.business_id"
            filterable
            placeholder="请选择业务"
            :disabled="title==='编辑'"
            :style="{width: '100%'}"
          >
            <el-option v-for="(item, index) in businessList" :key="index" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="文本会话上限" prop="chat_limit" :label-width="formLabelWidth">
          <el-input-number v-model="data.chat_limit" controls-position="right" :min="0" :max="120" />
        </el-form-item>
        <el-form-item label="个人队列上限" prop="queue_limit" :label-width="formLabelWidth">
          <el-input-number v-model="data.queue_limit" controls-position="right" :min="0" :max="120" />
        </el-form-item>
      </el-form>
      <el-form ref="addForm" :model="addForm" :rules="addFormRules">
        <h4>技能设置</h4>
        <el-form-item label="选择通路" prop="access_id" :label-width="formLabelWidth">
          <el-select
            v-model="addForm.access_id"
            filterable
            clearable
            placeholder="请选择通路"
            :style="{width: '100%'}"
          >
            <el-option v-for="(item, index) in selectData.accessList" :key="index" :label="item.name" :value="item.id" />
          </el-select>
        </el-form-item>
        <el-form-item label="选择业务" prop="business_id" :label-width="formLabelWidth">
          <el-select
            v-model="addForm.business_id"
            filterable
            clearable
            placeholder="请选择业务"
            :style="{width: '100%'}"
          >
            <el-option
              v-for="(item, index) in selectData.businessList"
              :key="index"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <el-form-item label="队列" prop="data" :label-width="formLabelWidth">
          <el-select
            v-model="addForm.data"
            value-key="id"
            multiple
            filterable
            allow-create
            default-first-option
            placeholder="请选择队列"
            :style="{width: '100%'}"
          >
            <el-option v-for="(item, index) in selectData.queueList" :key="index" :label="item.name" :value="item" />
          </el-select>
        </el-form-item>
        <el-form-item label="优先级" prop="queue_level" :label-width="formLabelWidth">
          <el-select v-model="addForm.queue_level" filterable placeholder="请选择优先级" :style="{width: '200px'}">
            <el-option v-for="(item, index) in priority" :key="index" :label="item" :value="item" />
          </el-select>
          <el-button type="text" class="ml15" @click="()=>{ onAddForm(addForm, 'addForm') }">添加</el-button>
        </el-form-item>
      </el-form>
      <el-form ref="copyEngineerForm" :model="copyEngineerForm" :rules="copyEngineerFormRules">
        <h4>复用客服</h4>
        <el-form-item label="客服" prop="select" :label-width="formLabelWidth">
          <el-select v-model="copyEngineerForm.select" placeholder="请选择客服" value-key="code" :style="{width: '200px'}">
            <el-option
              v-for="(item, index) in selectTableData"
              :key="index"
              :label="`${item.name} - ${item.code}`"
              :value="item"
              :disabled="item.code===data.code"
            >
              <span style="float: left">{{ `${item.code===data.code?'(当前)':''}${item.name}` }}</span>
              <span style="float: right; color: #8492a6; font-size: 13px">{{ item.code }}</span>
            </el-option>
          </el-select>
          <el-button type="text" class="ml15" @click="copyOnData(copyEngineerForm, 'copyEngineerForm')">添加</el-button>
        </el-form-item>
      </el-form>
      <div class="flex-wrp flex-between">
        <h4>队列列表</h4>
        <el-button type="text" @click="data.queues=[]">清空队列</el-button>
      </div>
      <el-table
        :data="data.queues"
        max-height="260"
        style="width: 100%"
      >
        <el-table-column
          align="center"
          prop="name"
          label="队列"
        />
        <el-table-column
          align="center"
          prop="queue_level"
          label="优先级"
        />
        <el-table-column
          align="center"
          prop="access_name"
          label="通路"
        />
        <el-table-column
          align="center"
          prop="business_name"
          label="业务"
        />
        <el-table-column align="center" label="操作">
          <template slot-scope="scope">
            <el-button
              type="text"
              class="el-del"
              @click="handleDelete(scope.$index, scope.row)"
            >删除
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <div slot="footer" class="dialog-footer">
        <el-button @click="$emit('on-close')">取 消</el-button>
        <el-button class="submit" type="primary" @click="onData(data)">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { getToken } from '@/utils/auth'
  import { getApiWbQueue, postApiWbQueueAccessBusinessQueues } from '@/api/queue-management/pond'
  import { getApiWbEngineerCodeQueues } from '@/api/queue-management/account'
  import { getApiWbAccess } from '@/api/queue-management/access'
  import { getApiWbBusiness } from '@/api/queue-management/business'

  export default {
    props: {
      visible: {
        type: Boolean,
        required: true
      },
      mydata: {
        type: Object,
        required: true
      },
      title: {
        type: String,
        required: true
      },
      roleList: {
        type: Array,
        required: true
      },
      businessList: {
        type: Array,
        required: true
      },
      tableData: {
        type: Array,
        required: true
      }
    },
    data() {
      // const selectTableData = JSON.parse(JSON.stringify(this.tableData)).filter((item) => {
      //   return this.mydata.business_id === item.business_id
      // })
      const isNullStr = (name) => (rule, value, callback) => {
        if (!value) {
          callback(new Error(name))
        } else {
          callback()
        }
      }
      // const isNullArr = (name) => (rule, value, callback) => {
      //   if (!value.length) {
      //     callback(name)
      //   } else {
      //     callback()
      //   }
      // }
      return {
        selectTableData: [],
        data: JSON.parse(JSON.stringify(this.mydata)),
        formLabelWidth: '120px',
        getToken,
        priority: [0, 1, 2, 3, 4, 5, 6, 7, 8, 9],
        selectData: {
          queueList: [],
          accessList: [],
          businessList: []
        },
        rules: {
          code: [],
          business_id: [],
          role_id: [],
          access_id: [{ required: true, trigger: 'change', message: '必填项' }],
          name: [{ required: true, trigger: 'change', message: '必填项' }],
          chat_limit: [{ required: true, trigger: 'change', message: '必填项' }],
          queue_limit: [{ required: true, trigger: 'change', message: '必填项' }],
          queue_level: [{ required: true, trigger: 'change', message: '必填项' }]
        },
        addForm: {
          access_id: '',
          business_id: '',
          data: '',
          queue_level: 0
        },
        addFormRules: {
          data: [],
          queue_level: [{ trigger: 'change', message: '必填项', validator: isNullStr('请完整配置技能设置') }],
          access_id: [],
          business_id: []
        },
        copyEngineerForm: {
          select: null
        },
        copyEngineerFormRules: {
          select: [{ trigger: 'change', validator: isNullStr('请选择客服') }]
        }
      }
    },
    watch: {
      visible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
          this.$refs['addForm'].resetFields()
          this.$refs['copyEngineerForm'].resetFields()
        })

        status && getApiWbAccess().then((response) => {
          this.$set(this.selectData, 'accessList', response.data)
        })
        status && getApiWbBusiness().then((response) => {
          this.$set(this.selectData, 'businessList', response.data)
        })
        status && getApiWbQueue().then((response) => {
          this.$set(this.selectData, 'queueList', response.data)
        })
      },
      'data.business_id': {
        handler(id, oldVal) {
          // 过滤客服
          this.selectTableData = JSON.parse(JSON.stringify(this.tableData)).filter(item => {
            return id === item.business_id
          })

          this.$refs['addForm'].resetFields()
          this.$refs['copyEngineerForm'].resetFields()
        }
      },
      'addForm.access_id'(access_id) {
        postApiWbQueueAccessBusinessQueues({
          access_id: access_id || 0,
          business_id: this.addForm.business_id || 0
        }).then((response) => {
          this.$set(this.selectData, 'queueList', response.data)
          this.$set(this.addForm, 'data', [])
        })
      },
      'addForm.business_id'(business_id) {
        postApiWbQueueAccessBusinessQueues({
          business_id: business_id || 0,
          access_id: this.addForm.access_id || 0
        }).then((response) => {
          this.$set(this.selectData, 'queueList', response.data)
          this.$set(this.addForm, 'data', [])
        })
      },
      mydata: {
        handler(newName, oldName) {
          this.data = JSON.parse(JSON.stringify(newName))
        },
        deep: true
      }
    },
    methods: {
      onData(tmp) {
        this.$refs['form'].validate(valid => {
          if (valid) {
            const data = JSON.parse(JSON.stringify(tmp))
            console.log('tmp', tmp)
            delete data.avatar
            delete data.role_name
            delete data.business_name
            delete data.role_name
            const _data = data.queues.map(data => ({ id: data.id, queue_level: data.queue_level }))
            this.$emit('on-data', { ...data, queues: _data })
          } else {
            return false
          }
        })
      },
      onAddForm(data, cName) {
        this.$refs[cName].validate(valid => {
          if (valid) {
            let that_data
            if (!data.data.length) {
              that_data = this.selectData.queueList
            } else {
              that_data = data.data
            }
            const _data = JSON.parse(JSON.stringify(that_data)).map(item => ({
              queue_level: data.queue_level,
              name: item.name,
              id: item.id,
              code: item.code,
              access_id: item.access_id,
              access_name: item.access_name,
              business_id: item.business_id,
              business_name: item.business_name
            })).filter(item => !this.data.queues.some(tt => item.code === tt.code))
            if (_data.length) {
              this.data.queues = this.data.queues.concat(_data)
              this.$message({
                type: 'success',
                message: `已过滤重复队列`
              })
              this.$refs[cName].resetFields()
            } else {
              this.$message({
                type: 'warning',
                message: `队列已存在或队列为空，请重新选择队列`
              })
              this.$refs[cName].resetFields()
            }
          } else {
            this.$message({
              type: 'warning',
              message: `请完整配置技能设置`
            })
            return false
          }
        })
      },
      handleDelete(index, row) {
        this.data.queues.splice(index, 1)
      },
      copyOnData(data, formName) {
        this.$refs[formName].validate(valid => {
          if (valid) {
            getApiWbEngineerCodeQueues(data.select.code).then(response => { // 获取客服下所有队列并filter
              if (Array.isArray(response.data) && response.data.length) {
                // const _data = JSON.parse(JSON.stringify(response.data)).map(item => ({ queue_level: item.queue_level, name: item.name, id: item.id, code: item.code, access_id: item.access_id, access_name: item.access_name, business_id: item.business_id, business_name: item.business_name })).filter(item => !this.data.queues.some(tt => item.code === tt.code))
                const _data = JSON.parse(JSON.stringify(response.data)).map(item => ({
                  queue_level: item.queue_level,
                  name: item.name,
                  id: item.id,
                  code: item.code,
                  access_id: item.access_id,
                  access_name: item.access_name,
                  business_id: item.business_id,
                  business_name: item.business_name
                }))
                if (_data.length) {
                  const tmpQueues = this.data.queues.filter(item => !_data.some(tmp => item.code === tmp.code))
                  this.data.queues = tmpQueues.concat(_data)
                  this.$message({
                    type: 'success',
                    message: `已合并该客服下重复队列`
                  })
                  this.$refs[formName].resetFields()
                } else {
                  this.$message({
                    type: 'warning',
                    message: `该客服下队列已存在，请重新选择客服`
                  })
                  this.$refs[formName].resetFields()
                }
              } else {
                this.$message({
                  type: 'warning',
                  message: `该客服下没有队列，请重新选择客服`
                })
                this.$refs[formName].resetFields()
              }
            }).catch(this.$message.error)
          } else {
            this.$message({
              type: 'warning',
              message: `请选择客服`
            })
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .my-dialog /deep/ {
    .dialog {
      width: 440px;
    }

    .avatar-uploader .el-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }

    .avatar-uploader .el-upload:hover {
      border-color: #409EFF;
    }

    .avatar-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      width: 178px;
      height: 178px;
      line-height: 178px;
      text-align: center;
    }

    .avatar {
      width: 178px;
      height: 178px;
      display: block;
    }

    .line {
      text-align: center;
    }
  }
</style>
