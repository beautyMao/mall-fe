<template>
  <el-dialog
    :title="`${title} 组织信息`"
    :visible.sync="visible"
    class="btn"
    fullscreen
    :before-close="() => onData(false)"
  >
    <div>
      <el-table
        :data="data"
        height="calc(100vh - 206px)"
        style="width: 100%"
      >
        <el-table-column
          type="index"
          :index="indexMethod"
        />
        <el-table-column
          label="账号"
          width="width: 100%"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.code }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="姓名"
          width="width: 100%"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.name }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="业务(哪一级别)"
          width="width: 100%"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.business }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="小组"
          width="width: 100%"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.group }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="角色"
          width="width: 100%"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.role }}</span>
          </template>
        </el-table-column>
        <el-table-column
          label="工作地点"
          width="width: 100%"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.address }}</span>
          </template>
        </el-table-column>
      </el-table>

    </div>
    <div slot="footer" class="dialog-footer">
      <div class="pagination-container">
        <el-pagination
          background
          :current-page="mypagination.current_page"
          :page-size="mypagination.datanum"
          :page-sizes="[10, 15, 20, 25]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="mypagination.total"
          @size-change="handleSizeChange"
          @current-change="currentChange"
        />
        <el-button class="ml40 cancel-btn" @click="onData(false)">取消</el-button>
      </div>
    </div>
  </el-dialog>
</template>

<script>
  export default {
    props: {
      data: {
        type: Array,
        required: true
      },
      mypagination: {
        type: Object,
        required: true
      },
      visible: {
        type: Boolean,
        required: true
      },
      title: {
        type: String,
        required: true
      }
    },
    methods: {
      indexMethod(index) {
        return index + 1
      },
      onData(status) {
        this.$emit('onData', status)
      },
      currentChange(val) {
        this.$emit('currentChange', val)
      },
      handleSizeChange(val) {
        this.$emit('handleSizeChange', val)
      }
    }
  }
</script>

<style lang="scss">
  .btn {
    .is-fullscreen {
      .el-dialog__header {
        .el-dialog__headerbtn {
          .el-icon-close {
            color: #000000 !important;
            font-size: 20px;
            font-weight: bolder;
          }
        }
      }

      .el-dialog__footer {
        .dialog-footer {
          .pagination-container {
            .cancel-btn {
              width: 100px;
              background-color: #ecf5ff;
            }
          }
        }
      }
    }
  }
</style>
