<template>

  <div class="app-container">
    <div class="flex-wrp flex-between">
      <div class="flex-wrp">
        <el-button type="primary" plain @click="addDialogForm">新增</el-button>
        <my-pond-dialog title="新增" :mydata="dialogForm" :visible="dialogFormVisible" @on-data="onDialogData" @on-close="dialogFormVisible = false" />

        <el-button class="ml20" type="primary" plain @click="allEditQueue">批量修改</el-button>

        <!-- type@Number; info: 1 => 新增; 2 => 编辑; 3 => 批量修改;  // default => 1 -->
        <my-pond-dialog
          :mode-disabled="true"
          :mode-all-show="true"
          :type="3"
          title="批量修改"
          :mydata="queueForm"
          :visible="queueFormVisible"
          @on-data="onQueueData"
          @on-close="queueFormVisible = false"
        />

        <!-- <el-button class="ml20" @click="switchMode">{{mode?'文本全选':'电话全选'}}</el-button> -->
      </div>

      <el-input
        v-model.trim="searchText"
        placeholder="请输入队列编号、队列名称"
        :style="{width: '300px'}"
        @keyup.enter.native="onSearch(searchText)"
      >
        <el-button slot="append" icon="el-icon-search" @click="onSearch(searchText)" />
      </el-input>
    </div>

    <div class="pt20">
      <my-table
        ref="my-table"
        :data="localTableData"
        :mypagination="mypagination"
        @currentChange="handleCurrentChange"
        @handleSizeChange="handleSizeChange"
        @handleEdit="handleEdit"
        @handleDelete="handleDelete"
        @handleSee="tableHandleSee"
        @select="tableSelect"
      />
      <my-see
        :mypagination="seemypagination"
        :data="seeData"
        :visible="tableSeeVisible"
        :title="seeTitle"
        @currentChange="seeHandleCurrentChange"
        @handleSizeChange="seeHandleSizeChange"
        @onData="onSeeData"
      />
      <my-pond-dialog
        :mode-disabled="true"
        title="编辑"
        :type="2"
        :mydata="tableForm"
        :visible="tableFormVisible"
        @on-data="onTableData"
        @on-close="tableFormVisible = false"
      />
    </div>

  </div>

</template>

<script>
  import {
    delApiWbQueueId,
    getApiWbQueue,
    getApiWbQueueId,
    getApiWbQueueSearch,
    postApiWbQueue,
    putApiWbQueueBatchUpdate,
    putApiWbQueueId
  } from '@/api/queue-management/pond'
  import { getApiWbQueueIdEngineers } from '@/api/queue-management/account'
  import myPondDialog from '@/views/queue-management/components/myPondDialog'
  import myAccessDialog from '@/views/queue-management/components/myAccessDialog'
  import myTable from '@/views/queue-management/pond/components/myTable'
  import mySee from '@/views/queue-management/pond/components/mySee'

  export default {
    name: 'pond',
    components: { myPondDialog, myAccessDialog, myTable, mySee },
    data() {
      return {
        searchText: '',
        dialogForm: {},
        dialogFormVisible: false,
        tableData: [],
        tableForm: {},
        tableFormVisible: false,
        localTableData: [],
        suList: [],
        mypagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        },
        seemypagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        },
        tableSeeVisible: false,
        seeTableData: [],
        seeData: [],
        seeTitle: '',
        queueFormVisible: false,
        queueForm: {},
        queueRows: [],
        mode: true,
        dialogBusinessFormVisible: false,
        dialogBusinessForm: {
          name: ''
        }
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        getApiWbQueue().then(response => {
          this.tableData = response.data
          this.mypagination.current_page = 1
          this.localPagination()
        }).catch(this.$message.error)
      },
      onDialogData(data) {
        postApiWbQueue(data).then(response => {
          this.fetchData()
          this.dialogFormVisible = false
        }).catch(this.$message.error)
      },
      onTableData(data) {
        putApiWbQueueId(data.id, data).then(response => {
          this.fetchData()
          this.tableFormVisible = false
        }).catch(this.$message.error)
      },
      onSearch(text) {
        getApiWbQueueSearch(text).then(response => {
          this.tableData = response.data
          this.mypagination.current_page = 1
          this.localPagination()
        }).catch(this.$message.error)
      },
      handleEdit(index, row) {
        this.tableFormVisible = true
        getApiWbQueueId(row.id).then((response) => {
          this.tableForm = [response.data].map((item) => {
            item.business_id = item.business_id === 0 ? '' : item.business_id
            item.channel_id = item.channel_id === 0 ? '' : item.channel_id
            item.access_id = item.access_id === 0 ? '' : item.access_id
            if (!item.business_id) {
              item.channel_id = ''
            }
            if (item.busy_to_robot === undefined) {
              item.busy_to_robot = 2
            }
            return item
          })[0]
        }).catch(this.$message.error)
      },
      handleDelete(index, row) {
        this.$confirm('此操作将永久删除该队列, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          delApiWbQueueId(row.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
          }).catch(this.$message.error)
        })
      },
      handleCurrentChange(val) {
        this.mypagination.current_page = val
        this.localPagination()
      },
      localPagination() {
        const number = (this.mypagination.current_page - 1) * this.mypagination.datanum
        this.localTableData = this.tableData.slice(number, number + this.mypagination.datanum)
        this.mypagination.total = this.tableData.length
      },
      handleSizeChange(val) {
        this.mypagination.datanum = val
        this.localPagination()
      },
      tableHandleSee(index, row) {
        this.tableSeeVisible = true
        getApiWbQueueIdEngineers(row.id).then((response) => {
          this.seeTableData = response.data
          this.seeTitle = row.name
          this.seeLocalPagination()
        }).catch(this.$message.error)
      },
      onSeeData(status) {
        this.tableSeeVisible = status
        this.seeTableData = []
        this.seeData = []
        Object.assign(this.seemypagination, this.$options.data().seemypagination)
      },
      seeLocalPagination() {
        const number = (this.seemypagination.current_page - 1) * this.seemypagination.datanum
        this.seeData = this.seeTableData.slice(number, number + this.seemypagination.datanum)
        this.seemypagination.total = this.seeTableData.length
      },
      seeHandleCurrentChange(val) {
        this.seemypagination.current_page = val
        this.seeLocalPagination()
      },
      seeHandleSizeChange(val) {
        this.seemypagination.datanum = val
        this.seeLocalPagination()
      },
      allEditQueue() {
        if (this.queueRows.length) {
          const equals = this.queueRows.some((item) => {
            return this.queueRows[0].type !== item.type
          })
          if (equals) {
            this.$message({
              type: 'warning',
              message: '服务方式不能相同,请重新选择要修改的业务'
            })
          } else {
            this.queueFormVisible = true
            this.queueForm = {
              type: this.queueRows[0].type,
              business_id: '',
              work_start_at: '',
              work_end_at: '',
              visible: 2,
              callback: 1,
              pick: 2,
              consult: 1,
              transfer: 1,
              time_limit: 1,
              busy_to_robot: 2
            }
          }
        } else {
          this.$message({
            type: 'warning',
            message: '请选择要修改的业务'
          })
        }
      },
      onQueueData(data) {
        this.queueRows = this.queueRows.map(item => {
          if (item.type === 1) {
            return {
              id: item.id,
              channel_id: item.channel_id,
              business_id: data.business_id,
              work_start_at: data.work_start_at,
              work_end_at: data.work_end_at,
              pick: data.pick,
              transfer: data.transfer,
              callback: data.callback,
              consult: data.consult,
              time_limit: data.time_limit,
              visible: data.visible,
              type: data.type,
              busy_to_robot: data.busy_to_robot
            }
          } else {
            return {
              id: item.id,
              channel_id: item.channel_id,
              type: data.type,
              business_id: data.business_id,
              work_start_at: data.work_start_at,
              work_end_at: data.work_end_at,
              transfer: data.transfer,
              callback: data.callback,
              time_limit: data.time_limit,
              busy_to_robot: data.busy_to_robot
            }
          }
        })
        putApiWbQueueBatchUpdate(this.queueRows).then(response => {
          this.fetchData()
          this.queueFormVisible = false
          this.queueRows = []
        }).catch(this.$message.error)
      },
      tableSelect(rows) {
        this.queueRows = JSON.parse(JSON.stringify(rows))
      },
      switchMode() {
        const mode = this.mode ? 1 : 2
        this.localTableData.forEach(row => {
          if (row.type === mode) {
            this.$refs['my-table'].$refs['my-table'].toggleRowSelection(row, true)
          } else {
            this.$refs['my-table'].$refs['my-table'].toggleRowSelection(row, false)
          }
        })
        const queueRows = this.localTableData.filter((item) => {
          return item.type === mode
        })
        this.queueRows = JSON.parse(JSON.stringify(queueRows))
        this.mode = !this.mode
      },
      addDialogForm() {
        this.dialogFormVisible = true
        this.dialogForm = {
          type: 1,
          business_id: '',
          channel_id: '',
          access_id: '',
          name: '',
          work_start_at: '',
          work_end_at: '',
          callback: 1,
          pick: 2,
          transfer: 1,
          consult: 1,
          time_limit: 1,
          visible: 2,
          busy_to_robot: 2
        }
      }
    }
  }
</script>

