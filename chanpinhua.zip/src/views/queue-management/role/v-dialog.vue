<template>
  <el-dialog :title="title" :visible.sync="show" width="600px" custom-class="el-dialog-aside el-dialog-aside__wide">
    <create-role ref="createRole" :title="title" :code="id" @operateSucc="operateSucc" />
    <div slot="footer">
      <el-button @click="show = false">取 消</el-button>
      <el-button v-if="title !== '查看角色'" type="primary" @click="submitForm">提 交</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import createRole from './create-role'
  export default {
    components: { createRole },
    props: {
      createEditor: {
        type: Boolean,
        default: false
      },
      title: {
        type: String,
        default: '创建角色'
      },
      id: {
        type: String,
        default: ''
      }
    },
    data() {
      return {
        show: this.createEditor,
        isSubmit: false
      }
    },
    watch: {
      show() {
        if (!this.show) {
          this.$emit('closeDialog')
        }
      }
    },
    methods: {
      operateSucc(val) {
        if (val) {
          this.show = false
          this.$emit('closeDialog', true)
        } else {
          this.isSubmit = false
        }
      },
      submitForm() {
        this.isSubmit = true
        this.$refs.createRole.submitForm()
      }
    }
  }
</script>
