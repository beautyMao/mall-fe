<template>
  <div class="app-container">
    <header>
      <h1>{{ $route.meta.title }}</h1>
      <div class="flex-wrap">
        <el-button type="primary" plain :disabled="!buttonPermission('roleCreate')" @click="createEngineer">创建角色</el-button>
        <el-button type="primary" plain :disabled="!(buttonPermission('roleDelete') && pitchOn.length)" @click="batchDelete">批量删除</el-button>
        <el-input v-model="input" prefix-icon="el-icon-search" placeholder="请输入角色名称" @keyup.enter.native="searchInfo" @blur="searchInfo" />
      </div>
    </header>

    <el-card>

      <el-table :data="engineerInfo" tooltip-effect="light" class="tab" @selection-change="handleSelectionChange">
        <el-table-column type="selection" width="55" />
        <el-table-column type="index" width="50" />
        <el-table-column prop="name" label="角色名称" />
        <el-table-column prop="desc" label="角色描述" />
        <el-table-column prop="menu_permissions.name" label="菜单权限">
          <template slot-scope="scope">
            <el-popover v-if="scope.row.menu_permissions.length" placement="bottom" title="操作权限:" trigger="hover" popper-class="accountPopover">
              <div v-for="item in scope.row.menu_permissions" :key="item.id" class="popoverHeight">{{ item.name }}</div>
              <span slot="reference" type="text">{{ scope.row.menu_permissions[0].name }}</span>
            </el-popover>
          </template>
        </el-table-column>
        <!--<el-table-column prop="api_permissions.name" label="操作权限">-->
        <!--<template slot-scope="scope">-->
        <!--<el-popover v-if="scope.row.api_permissions.length" placement="bottom" title="操作权限:" trigger="hover" popper-class="accountPopover">-->
        <!--<div v-for="item in scope.row.api_permissions" :key="item.id" class="popoverHeight">{{ item.name }}</div>-->
        <!--<el-button slot="reference" type=text>{{ scope.row.api_permissions[0].name }}</el-button>-->
        <!--</el-popover>-->
        <!--</template>-->
        <!--</el-table-column>-->
        <el-table-column prop="button_permissions.name" label="按钮权限">
          <template slot-scope="scope">
            <el-popover v-if="scope.row.button_permissions.length" placement="bottom" title="操作权限:" trigger="hover" popper-class="accountPopover">
              <div v-for="item in scope.row.button_permissions" :key="item.id" class="popoverHeight">{{ item.name }}</div>
              <span slot="reference" type="text">{{ scope.row.button_permissions[0].name }}</span>
            </el-popover>
          </template>
        </el-table-column>
        <el-table-column prop="created_at" label="创建时间" />
        <el-table-column prop="updated_at" label="最后修改时间" />
        <el-table-column label="操作" width="150px">
          <template slot-scope="scope">
            <el-button :disabled="!buttonPermission('roleInfo')" type="text" @click="itemExamine(scope.row)">查看</el-button>
            <el-button :disabled="!buttonPermission('roleEdit')" type="text" @click="itemRedact(scope.row)">编辑</el-button>
            <el-button :disabled="!buttonPermission('roleDelete')" type="text" @click="itemDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        class="page"
        background
        :page-sizes="[10, 15, 20, 25]"
        :current-page="data.page"
        :page-size="data.per_page"
        :total="data.total"
        layout="total, sizes, prev, pager, next, jumper"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>
    <v-dialog v-if="createEditorInfo.createEditor" v-bind="createEditorInfo" @closeDialog="closeDialog" />
  </div>
</template>

<script>
  import { getRoleList, getRoleDelete } from '@/api/role-info'
  import vDialog from './v-dialog'
  import { mapGetters } from 'vuex'
  export default {
    components: { vDialog },
    data() {
      return {
        input: '',
        engineerInfo: [],
        pitchOn: '',
        data: {
          is_page: true,
          page: 1,
          per_page: 10,
          total: 0
        },
        createEditorInfo: {
          createEditor: false,
          title: '创建角色',
          id: ''
        }
      }
    },
    computed: {
      ...mapGetters([
        'buttonPermission'
      ])
    },
    mounted() {
      this.init()
    },
    methods: {
      init() {
        const data = `is_page=true&page=1&per_page=10&input=${this.input}`
        getRoleList(data).then(res => {
          this.engineerInfo = res.data.data
          this.data.total = res.data.total
        })
      },
      closeDialog(val) {
        if (val) {
          this.init()
        }
        this.createEditorInfo.createEditor = false
      },
      handleSelectionChange(val) { // 获取批量数据
        this.pitchOn = val
      },
      batchDelete() { // 批量删除
        var codes = []
        if (!this.pitchOn.length) {
          this.$message({
            message: '请选择角色',
            type: 'warning'
          })
          return
        }
        for (const item of this.pitchOn) {
          codes.push(item.id)
        }
        const list = { roles: codes }
        this.$confirm('是否永久删除这些账号？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          getRoleDelete(list).then(res => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.data.input = ''
            this.init()
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      itemDelete(row) {
        const codes = []
        codes.push(row.id)
        const list = { roles: codes }
        this.$confirm('是否永久删除该账号？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          getRoleDelete(list).then(res => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.data.input = ''
            this.init()
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      },
      itemExamine(row) {
        this.createEditorInfo.title = '查看角色'
        this.createEditorInfo.id = '' + row.id
        this.createEditorInfo.createEditor = true
      },
      itemRedact(row) {
        this.createEditorInfo.title = '编辑角色'
        this.createEditorInfo.id = '' + row.id
        this.createEditorInfo.createEditor = true
      },
      createEngineer() {
        this.createEditorInfo.title = '创建角色'
        this.createEditorInfo.id = ''
        this.createEditorInfo.createEditor = true
      },
      searchInfo() { // 查询客服
        this.init()
      },
      handleSizeChange(val) { // 每页条数
        this.data.per_page = val
        this.init()
      },
      handleCurrentChange(val) { // 第几页
        this.data.page = val
        this.init()
      }
    }
  }
</script>

<style lang="scss">
  .el-popover {
    .popoverHeight {
      line-height: 26px;
    }
  }

</style>
