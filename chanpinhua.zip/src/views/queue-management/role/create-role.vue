<template>
  <div class="CreateRole">
    <div class="box">
      <el-form ref="ruleForm" :model="ruleForm" :rules="rules" label-width="100px" class="ruleForm" :disabled="title === '查看角色'">
        <el-form-item label="角色姓名" prop="name" class="form-item">
          <el-input v-model="ruleForm.name" placeholder="请输入角色名称" />
        </el-form-item>
        <el-form-item label="角色描述" prop="desc" class="form-item">
          <el-input v-model="ruleForm.desc" placeholder="请输入角色描述" />
        </el-form-item>
        <p class="title">权限配置范围</p>
        <el-form-item label="菜单权限" prop="activeName" class="form-item">
          <el-cascader
            ref="cascader"
            v-model="cascadeSet"
            :show-all-levels="false"
            :options="servicerList"
            :props="cascaderAlias"
            clearable
            popper-class="cascaderPopper"
            filterable
            collapse-tags
            placeholder="请输入角色描述"
            class="cascader"
            @change="handleCascaderChange"
          />
        </el-form-item>
        <el-tabs v-model="activeName" type="card" class="tabs" @tab-click="handleClick">
          <!--<el-tab-pane label="菜单权限" name="first">
            <el-checkbox v-if="original[currentTab].length > 0" v-model="checkAll" :indeterminate="isIndeterminate" class="all" @change="handleAllChange">全选</el-checkbox>
            <div v-for="(item, index) in checkboxList" class="list">
              <span class="title">{{ item.group }}:</span>
              <el-checkbox v-model="item.checkAll" :indeterminate="isIndeterminate" class="listAll" @change="handleListAll($event, index)">全选</el-checkbox>
              <el-checkbox-group v-model="item.checked" class="checkbox-group" @change="handleItemChange($event, index)">
                <el-checkbox v-for="i in item.cities" :key="i" :label="i">{{ i }}</el-checkbox>
              </el-checkbox-group>
            </div>
          </el-tab-pane>
          <el-tab-pane label="操作权限" name="second">
            <el-checkbox v-if="original[currentTab].length > 0" v-model="checkAll" :indeterminate="isIndeterminate" class="all" @change="handleAllChange">全选</el-checkbox>
            <div v-for="(item, index) in checkboxList" class="list">
              <span class="title">{{ item.group }}:</span>
              <el-checkbox v-model="item.checkAll" :indeterminate="isIndeterminate" class="listAll" @change="handleListAll($event, index)">全选</el-checkbox>
              <el-checkbox-group v-model="item.checked" class="checkbox-group" @change="handleItemChange($event, index)">
                <el-checkbox v-for="i in item.cities" :key="i" :label="i">{{ i }}</el-checkbox>
              </el-checkbox-group>
            </div>
          </el-tab-pane>-->
          <el-tab-pane label="按钮权限" name="third">
            <el-checkbox v-if="original[currentTab].length > 0" v-model="checkAll" :indeterminate="isIndeterminate" class="all" @change="handleAllChange">全选</el-checkbox>
            <div v-for="(item, index) in checkboxList" class="list">
              <span class="title">{{ item.group }}:</span>
              <el-checkbox v-model="item.checkAll" :indeterminate="isIndeterminate" class="listAll" @change="handleListAll($event, index)">全选</el-checkbox>
              <el-checkbox-group v-model="item.checked" class="checkbox-group" @change="handleItemChange($event, index)">
                <el-checkbox v-for="i in item.cities" :key="i" :label="i">{{ i }}</el-checkbox>
              </el-checkbox-group>
            </div>
          </el-tab-pane>
        </el-tabs>
      </el-form>
      <!--<div class="btn">
        &lt;!&ndash;<el-button @click="resetForm('numberValidateForm')">取消</el-button>&ndash;&gt;
        <el-button type="primary" @click="submitForm">提交</el-button>
      </div>-->
    </div>
  </div>
</template>

<script>
  const TAB_API = 'apis'
  const TAB_MENU = 'menus'
  const TAB_BUTTONS = 'buttons'
  const PERMISSION_API = 'api_permissions'
  const PERMISSION_MENU = 'menu_permissions'
  const PERMISSION_BTN = 'button_permissions'
  const TAB_API_MAP = {}
  TAB_API_MAP[TAB_API] = PERMISSION_API
  TAB_API_MAP[TAB_MENU] = PERMISSION_MENU
  TAB_API_MAP[TAB_BUTTONS] = PERMISSION_BTN
  import {
    getLimitsList,
    getCreateRole,
    getRoleDetail,
    getRoleEdit
  } from '@/api/role-info.js'
  export default {
    name: 'create-role',
    props: {
      code: {
        type: String,
        default: ''
      },
      title: {
        type: String,
        default: ''
      }
    },
    data() {
      var checkName = (rule, value, callback) => {
        if (value) {
          const reg = /^[\w\s\u4E00-\u9FA5]{1,50}$/
          if (reg.test(value)) {
            callback()
          } else {
            return callback(new Error('请输入50位以内中英文字符'))
          }
        }
      }
      var checkDesc = (rule, value, callback) => {
        if (value) {
          const reg = /^[\w\s\u4E00-\u9FA5]{1,50}$/
          if (reg.test(value)) {
            callback()
          } else {
            return callback(new Error('请输入50位以内中英文字符'))
          }
        }
      }
      return {
        ruleForm: {
          name: '',
          desc: ''
        },
        rules: {
          name: [
            { required: true, message: '请填写姓名' },
            { validator: checkName, trigger: 'blur' }
          ],
          desc: [
            { required: true, message: '请填写角色描述' },
            { validator: checkDesc, trigger: 'blur' }
          ]
        },
        id: this.code,
        role: null,
        permissions: null,
        activeName: 'third',
        checkAll: false,
        isIndeterminate: false,
        menus: '',
        original: {
          apis: [],
          menus: [],
          buttons: []
        },
        checkboxList: [],
        currentTab: TAB_BUTTONS,
        changedCache: {
          apis: [],
          menus: [],
          buttons: []
        },
        cascadeSet: [],
        servicerList: [],
        cascaderAlias: {
          value: 'id',
          label: 'name',
          children: 'childs',
          multiple: true
        }
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      isAllChecked() { // 是否全选
        for (const index in this.checkboxList) {
          if (!this.checkboxList[index].checkAll) {
            return false
          }
        }
        return true
      },
      handleListAll(event, index) { // 每个list全选
        this.checkboxList[index].checked = event ? this.checkboxList[index].cities : []
        this.checkboxList[index].isIndeterminate = false
        this.checkAll = this.isAllChecked()
        this.saveCheckedState()
      },
      handleItemChange(event, index) { // 每个按钮
        if (event.indexOf('角色编辑') !== -1) {
          this.checkboxList[index].checked.push('角色详情')
        }
        this.checkboxList[index].checked = [...new Set(this.checkboxList[index].checked)]
        // const checkedCount = event.length
        const checkedCount = this.checkboxList[index].checked.length
        this.checkboxList[index].checkAll = checkedCount === this.checkboxList[index].cities.length
        this.checkboxList[index].isIndeterminate = checkedCount > 0 && checkedCount < this.checkboxList[index].cities.length
        this.checkAll = this.isAllChecked()
        this.saveCheckedState()
      },
      handleAllChange() { // 全选事件
        for (const index in this.checkboxList) {
          this.checkboxList[index].checkAll = this.checkAll
          this.checkboxList[index].checked = this.checkAll ? this.checkboxList[index].cities : []
        }
        this.saveCheckedState()
      },
      matchChecked(idx, tab) {
        const checked = this.checkboxList[idx].checked
        const original = this.original[tab][idx]
        const filtered = original.filter((item) => {
          const found = checked.find((checkItem) => {
            return checkItem === item.name
          })
          return found
        })
        return filtered
      },
      saveCheckedState() {
        for (const i in this.original[this.currentTab]) {
          const original = this.original[this.currentTab][i]
          this.changedCache[this.currentTab][i] = {
            group: original[0].group,
            checked: []
          }
          const checkGroup = this.changedCache[this.currentTab][i]
          for (const item of this.matchChecked(i, this.currentTab)) {
            checkGroup.checked.push(item)
          }
        }
      },
      reverseSearch(sibling, data) {
        for (const idx in data) {
          if (data[idx].childs.length === 0) {
            this.cascadeSet.push([].concat(sibling, data[idx].id))
          } else {
            this.reverseSearch([].concat(sibling, data[idx].id), data[idx].childs)
          }
        }
      },
      handleCascaderChange() {
      },
      submitForm() {
        const permissions = []
        const data = []
        for (const i in this.cascadeSet) {
          if (this.cascadeSet[i].length) {
            data.push(...this.cascadeSet[i])
          }
        }
        const val = [...new Set(data)]
        permissions.push(...val)
        // for (const checkGroup of this.changedCache[TAB_MENU]) {
        //   permissions.push(checkGroup.pop())
        // }
        // for (const checkGroup of this.changedCache[TAB_API]) {
        //   checkGroup.checked.map((item) => {
        //     permissions.push(item.id)
        //   })
        // }
        for (const checkGroup of this.changedCache[TAB_BUTTONS]) {
          checkGroup.checked.map((item) => {
            permissions.push(item.id)
          })
        }
        const reg = /^[\w\u4E00-\u9FA5]{2,20}$/
        const reg1 = /^[\w\u4E00-\u9FA5]{1,50}$/
        const valid = reg.test(this.ruleForm.name) && reg1.test(this.ruleForm.desc)
        this.$refs.ruleForm.validate((valid) => {})
        if (valid) {
          if (this.id) {
            const data = {
              id: this.id,
              name: this.ruleForm.name,
              desc: this.ruleForm.desc,
              permissions: permissions
            }
            getRoleEdit(data).then(res => {
              this.$emit('operateSucc', true)
              this.$message({
                message: '编辑成功',
                type: 'warning'
              })
            }).catch((err) => {
              this.$message({
                message: err,
                type: 'warning'
              })
            })
          } else {
            const data = {
              name: this.ruleForm.name,
              desc: this.ruleForm.desc,
              permissions: permissions
            }
            getCreateRole(data).then(res => {
              this.$emit('operateSucc', true)
              this.$message({
                message: '创建成功',
                type: 'warning'
              })
            }).catch((err) => {
              this.$message({
                message: err,
                type: 'warning'
              })
            })
          }
        } else {
          this.$emit('operateSucc', false)
          this.$message({
            message: '请填写必填项',
            type: 'warning'
          })
          return false
        }
      },
      // handleAllroleManagement(val) {
      //   this.roleManagement.checked = val ? roleManagement : []
      //   this.roleManagement.isIndeterminate = false
      //   this.checkAll = this.watchAll()
      // },
      // handleroleManagement(event, index) {
      //   const checkedCount = event.length
      //   this.checkboxList[index].checkAll = checkedCount === this.checkboxList[index].cities.length
      //   this.checkboxList[index].isIndeterminate = checkedCount > 0 && checkedCount < this.checkboxList[index].cities.length
      // },
      // handleAllaccessMabels(val) {
      //   this.accessMabels.checked = val ? accessMabels : []
      //   this.accessMabels.isIndeterminate = false
      //   this.checkAll = this.watchAll()
      // },
      // handleaccessMabels(value) {
      //   const checkedCount = value.length
      //   this.accessMabels.checkAll = checkedCount === this.accessMabels.cities.length
      //   this.accessMabels.isIndeterminate = checkedCount > 0 && checkedCount < this.accessMabels.cities.length
      // },
      // handleAllqueryData(val) {
      //   this.queryData.checked = val ? queryData : []
      //   this.queryData.isIndeterminate = false
      //   this.checkAll = this.watchAll()
      // },
      // handlequeryData(value) {
      //   const checkedCount = value.length
      //   this.queryData.checkAll = checkedCount === this.queryData.cities.length
      //   this.queryData.isIndeterminate = checkedCount > 0 && checkedCount < this.queryData.cities.length
      // },
      // handleAllconfigureBack(val) {
      //   this.configureBack.checked = val ? configureBack : []
      //   this.configureBack.isIndeterminate = false
      //   this.checkAll = this.watchAll()
      // },
      // handleconfigureBack(value) {
      //   const checkedCount = value.length
      //   this.configureBack.checkAll = checkedCount === this.configureBack.cities.length
      //   this.configureBack.isIndeterminate = checkedCount > 0 && checkedCount < this.configureBack.cities.length
      // },
      // handleAllverbalTrick(val) {
      //   this.verbalTrick.checked = val ? verbalTrick : []
      //   this.verbalTrick.isIndeterminate = false
      //   this.checkAll = this.watchAll()
      // },
      // handleverbalTrick(value) {
      //   const checkedCount = value.length
      //   this.verbalTrick.checkAll = checkedCount === this.verbalTrick.cities.length
      //   this.verbalTrick.isIndeterminate = checkedCount > 0 && checkedCount < this.verbalTrick.cities.length
      // },
      // handleAllproductsSale(val) {
      //   this.productsSale.checked = val ? productsSale : []
      //   this.productsSale.isIndeterminate = false
      //   this.checkAll = this.watchAll()
      // },
      // handleproductsSale(value) {
      //   const checkedCount = value.length
      //   this.productsSale.checkAll = checkedCount === this.productsSale.cities.length
      //   this.productsSale.isIndeterminate = checkedCount > 0 && checkedCount < this.productsSale.cities.length
      // },
      // handleAllclientManagement(val) {
      //   this.clientManagement.checked = val ? clientManagement : []
      //   this.clientManagement.isIndeterminate = false
      //   this.checkAll = this.watchAll()
      // },
      // handleclientManagement(value) {
      //   const checkedCount = value.length
      //   this.clientManagement.checkAll = checkedCount === this.clientManagement.cities.length
      //   this.clientManagement.isIndeterminate = checkedCount > 0 && checkedCount < this.clientManagement.cities.length
      // },
      init() {
        getLimitsList().then(res => {
          this.servicerList = this.getTreeData(res.data.menus)
          this.role = res.data
          const tabs = [TAB_API, TAB_MENU, TAB_BUTTONS]
          tabs.map((item) => {
            for (const i in this.role[item]) {
              const original = this.role[item][i]
              this.changedCache[item][i] = {
                group: original.group,
                checked: []
              }
            }
          })
          this.initMenus(this.currentTab)
        })
      },
      getTreeData(data) {
        // 循环遍历json数据
        for (var i = 0; i < data.length; i++) {
          if (data[i].childs.length < 1) {
            // children若为空数组，则将children设为undefined
            data[i].childs = undefined
          } else {
            // children若不为空数组，则继续 递归调用 本方法
            this.getTreeData(data[i].childs)
          }
        }
        return data
      },
      initMenus(tab) {
        this.checkboxList.length = 0
        this.original[tab].length = 0
        const data = this.role[tab]
        for (const idx in data) {
          this.checkboxList.push(
            {
              group: data[idx].group,
              cities: [],
              checkAll: false,
              checked: [],
              isIndeterminate: false
            }
          )
          const groups = data[idx].groups
          const checkGroup = this.checkboxList[idx]
          groups.forEach((element) => {
            checkGroup.cities.push(element.name)
          })
          this.original[tab].push(groups)
        }
        if (this.id) {
          if (this.permissions === null) {
            getRoleDetail(this.id).then(res => {
              this.permissions = res.data
              // 初始化 Cascade 菜单
              const data = this.permissions[PERMISSION_MENU]
              this.cascadeSet = []
              for (const idx in data) {
                if (data[idx].childs.length === 0) {
                  this.cascadeSet.push([data[idx].id])
                } else {
                  this.reverseSearch([data[idx].id], data[idx].childs)
                }
              }
              // 初始化 Checkbox
              this.ruleForm.name = res.data.name
              this.ruleForm.desc = res.data.desc
              const tabs = [TAB_API, TAB_MENU, TAB_BUTTONS]
              tabs.map((item) => {
                for (const i in this.role[item]) {
                  const checkGroup = this.changedCache[item][i]
                  for (const selected of this.permissions[TAB_API_MAP[item]]) {
                    if (selected.group === checkGroup.group) {
                      checkGroup.checked.push(selected)
                    }
                  }
                }
              })
              if (tab === TAB_MENU) {
                this.checkedChange(PERMISSION_MENU)
              } else if (tab === TAB_API) {
                this.checkedChange(PERMISSION_API)
              } else {
                this.checkedChange(PERMISSION_BTN)
              }
            })
            return
          }
        }
        if (tab === TAB_API) {
          this.checkedChange(PERMISSION_API)
        } else if (tab === TAB_MENU) {
          this.checkedChange(PERMISSION_MENU)
        } else {
          this.checkedChange(PERMISSION_BTN)
        }
      },
      checkedChange(pkey) {
        if (this.id) {
          for (const i in this.checkboxList) {
            const checkGroup = this.checkboxList[i]
            let data
            if (this.changedCache[this.currentTab].length > 0) {
              data = this.changedCache[this.currentTab][i].checked
            } else {
              data = this.permissions[pkey]
            }
            for (const selected of data) {
              if (checkGroup.group === selected.group) {
                checkGroup.checked.push(selected.name)
              }
            }
            if (checkGroup.checked.length === checkGroup.cities.length) {
              checkGroup.checkAll = true
            }
          }
        } else {
          if (this.changedCache[this.currentTab].length > 0) {
            for (const i in this.checkboxList) {
              const checkGroup = this.checkboxList[i]
              const data = this.changedCache[this.currentTab][i].checked

              for (const selected of data) {
                if (checkGroup.group === selected.group) {
                  checkGroup.checked.push(selected.name)
                }
              }
              if (checkGroup.checked.length === checkGroup.cities.length) {
                checkGroup.checkAll = true
              }
            }
          }
        }
        this.checkAll = this.isAllChecked()
        this.saveCheckedState()
      },
      handleClick(tab, event) {
        if (tab.label === '操作权限') {
          this.currentTab = TAB_API
        } else if (tab.label === '菜单权限') {
          this.currentTab = TAB_MENU
        } else {
          this.currentTab = TAB_BUTTONS
        }
        this.initMenus(this.currentTab)
      }
    }
  }
</script>

<style scoped lang="scss">
 .CreateRole {
   .title {
     font-weight: 700;
   }
   .ruleForm {
     position: relative;
     margin-top: 20px;
     .cascader {
       width: 360px;
       height: 40px;
       line-height: 40px;
       & /deep/ .el-input__inner {
         width: 360px!important;
         height: 40px!important;
         line-height: 40px!important;
       }
       & /deep/ .el-tag--mini {
         height: 30px;
         line-height: 30px;
       }
     }
     .form-item {
       & /deep/ .el-form-item__label{
         height: 40px;
         line-height: 40px;
       }
       .el-input {
         width: 360px;
         & /deep/ .el-input__inner {
           height: 40px;
           line-height: 40px;
         }
       }
     }
   }
   .tabs {
     margin-top: 20px;
     margin-left: 25px;
     .all {
       margin: 10px 0;
     }
     .list {
       display: flex;
       .title {
         width: 100px;
         height: 28px;
         line-height: 28px;
         margin-left: 0;
         margin-right: 10px;
         font-weight: 700;
         font-size: 12px;
       }
       .listAll {
         width: 55px;
         height: 28px;
         line-height: 28px;
         margin-right: 10px;
       }
     }
     .checkbox-group {
       flex: 1;
       .el-checkbox {
         width: 150px;
         height: 28px;
         line-height: 28px;
         margin: 0;
         font-size: 12px;
         & /deep/ .el-checkbox__label {
           font-size: 12px;
         }
       }
     }
   }
   .btn {
     position: absolute;
     left: 0;
     right: 0;
     bottom: 20px;
     text-align: center;
   }
 }
</style>
