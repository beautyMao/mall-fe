<template>
  <div class="my-dialog">
    <!-- Form -->
    <el-dialog
      ref="my-dialog"
      :title="title"
      custom-class="pr30"
      width="440px"
      :visible.sync="visible"
      :before-close="() => void $emit('on-close')"
    >
      <el-form ref="form" :model="data" :rules="rules" @submit.native.prevent>
        <!-- <el-form-item label="服务方式" prop="type" :label-width="formLabelWidth">
          <el-radio-group v-model="data.type" :disabled="modeDisabled">
            <el-radio v-if="title != '新增'" :label="2">电话</el-radio>
            <el-radio :label="1">文本</el-radio>
          </el-radio-group>
        </el-form-item> -->
        <el-form-item v-show="!modeAllShow" label="技能组名称" prop="name" :label-width="formLabelWidth">
          <el-input
            v-model.trim="data.name"
            placeholder="请输入技能组名称"
            type="text"
            auto-complete="off"
            :disabled="data.type ==2"
          />
        </el-form-item>
        <!-- :show-message="rulesMessage.business_id ? true : false" -->
        <el-form-item label="业务选择" prop="business_id" :label-width="formLabelWidth">
          <el-select
            v-model="data.business_id"
            filterable
            placeholder="请选择业务"
            :style="{width: '200px'}"
            :disabled="data.type == 2"
          >
            <el-option
              v-for="(item, index) in selectData.businessList"
              :key="index"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>
        <!-- <el-form-item v-show="!modeAllShow" label="SU选择" prop="channel_id" :label-width="formLabelWidth">
          <el-select
            v-model="data.channel_id"
            filterable
            placeholder="请选择 SU"
            :style="{width: '200px'}"
            :disabled="data.type == 2"
          >
            <el-option v-for="(item, index) in selectData.suList" :key="index" :label="item.name" :value="item.id" />
          </el-select>
          <el-button v-if="data.type != 2" type="text" class="ml10" @click="addDialogSuForm">新增</el-button>
          <my-su-dialog
            ref="my-su-dialog"
            append-to-body
            :select-list="selectData"
            title="新增"
            :mydata="dialogSuForm"
            :visible="dialogSuFormVisible"
            @onData="onDialogSuData"
          />
        </el-form-item> -->
        <el-form-item v-show="!modeAllShow" label="客户渠道" prop="access_id" :label-width="formLabelWidth">
          <el-select
            v-model="data.access_id"
            filterable
            placeholder="请选择客户渠道"
            :style="{width: '200px'}"
            :disabled="data.type == 2"
          >
            <el-option v-for="(item, index) in selectData.roadList" :key="index" :label="item.name" :value="item.id" />
          </el-select>
          <el-button v-show="data.type != 2" type="text" class="ml10" @click="addDialogAccessForm">新增</el-button>
          <my-access-dialog
            ref="my-access-dialog"
            append-to-body
            title="新增"
            :mydata="dialogAccessForm"
            :visible="dialogAccessFormVisible"
            @on-data="onDialogAccessData"
            @on-close="dialogAccessFormVisible = false"
          />
        </el-form-item>
        <el-form-item label="服务时间" :label-width="formLabelWidth" required>
          <el-col :span="11">
            <el-form-item prop="work_start_at">
              <el-time-select
                :key="Math.round()"
                v-model="data.work_start_at"
                value-format="HH:mm"
                :style="{width: '100%'}"
                placeholder="起始时间"
                :picker-options="{
                  start: '00:00',
                  step: '00:30',
                  end: '24:00',
                  format: 'HH:mm'
                }"
                @change="() => $refs.form.validate(valid => valid)"
              />
            </el-form-item>
          </el-col>
          <el-col class="line" :span="2">-</el-col>
          <el-col :span="11">
            <el-form-item prop="work_end_at">
              <el-time-select
                :key="Math.round()"
                v-model="data.work_end_at"
                value-format="HH:mm"
                :style="{width: '100%'}"
                placeholder="结束时间"
                :picker-options="{
                  start: '00:00',
                  step: '00:30',
                  end: '24:00',
                  format: 'HH:mm',
                  minTime: data.work_start_at
                }"
                @change="() => $refs.form.validate(valid => valid)"
              />
            </el-form-item>
          </el-col>
        </el-form-item>
        <el-form-item v-show="data.transfer===1" label="排队时间上限" prop="time_limit" :label-width="formLabelWidth">
          <el-input-number
            v-model="data.time_limit"
            controls-position="right"
            :min="1"
            :max="120"
            :disabled="data.type === 2"
          />
          分钟
        </el-form-item>
        <div class="flex-wrp flex-between flex-wrap">
          <el-form-item v-if="data.type===1" label="是否C端可见" :label-width="formLabelWidth">
            <el-switch
              v-model="data.visible"
              class="el-switch--mark"
              :active-value="1"
              :inactive-value="2"
            />
          </el-form-item>
          <el-form-item v-if="data.type===1" label="坐席全忙时使用机器人" :label-width="formLabelWidth">
            <el-switch
              v-model="data.busy_to_robot"
              class="el-switch--mark"
              :active-value="1"
              :inactive-value="2"
            />
          </el-form-item>
          <el-form-item v-if="data.type===1" label="点选" :label-width="formLabelWidth">
            <el-switch
              v-model="data.pick"
              class="el-switch--mark"
              :active-value="1"
              :inactive-value="2"
            />
          </el-form-item>
          <el-form-item label="支持转接" :label-width="formLabelWidth">
            <el-switch
              v-model="data.transfer"
              class="el-switch--mark"
              :active-value="1"
              :inactive-value="2"
            />
          </el-form-item>
        </div>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="$emit('on-close')">取 消</el-button>
        <el-button class="submit" type="primary" @click="onData(data)">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { getToken } from '@/utils/auth'
  import { upLoadImg } from '@/api/public'
  import { getApiWbAccessAccessesByTypeType, postApiWbAccess } from '@/api/queue-management/access'
  import { getApiWbBusiness, postApiWbBusiness } from '@/api/queue-management/business'
  import myAccessDialog from '@/views/queue-management/components/myAccessDialog'

  export default {
    components: { myAccessDialog },
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      mydata: {
        type: Object,
        default() {
          return {}
        }
      },
      title: {
        type: String,
        default: ''
      },
      modeDisabled: {
        type: Boolean,
        default: false
      },
      modeAllShow: {
        type: Boolean,
        default: false
      },
      type: {
        type: Number,
        default: 1
      }
    },
    data() {
      const validate_time_limit = (rule, value, callback) => {
        if (this.data.transfer === 1 && value <= 0) {
          callback(new Error('排队时间上限不能小于等于 0'))
        } else {
          callback()
        }
      }

      return {
        data: JSON.parse(JSON.stringify(this.mydata)),
        flexWidth: '60px',
        formLabelWidth: '120px',
        getToken,
        upLoadImg,
        selectData: {
          roadList: [],
          businessList: []
        },
        dialogBusinessFormVisible: false,
        dialogBusinessForm: {
          name: ''
        },
        businessLoading: false,
        dialogAccessForm: {},
        dialogAccessFormVisible: false,
        rules: {
          type: [{ required: true, trigger: 'change', message: '请选择业务' }],
          business_id: [{ required: true, trigger: 'change', message: '请选择业务' }],
          access_id: [{ required: true, trigger: 'change', message: '请选择通路' }],
          name: [{ required: true, trigger: 'blur', message: '请输入队列名称' }],
          work_start_at: [{ required: true, trigger: 'change', message: '请选择服务开始时间' }],
          work_end_at: [{ required: true, trigger: 'change', message: '请选择服务结束时间' }],
          time_limit: [{ validator: validate_time_limit, trigger: 'change' }]
        }
      }
    },
    watch: {
      visible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
        })
      },
      'data.type'(type) {
        // 获取 通路 列表
        this.visible && getApiWbAccessAccessesByTypeType(type).then(response => {
          this.$set(this.selectData, 'roadList', response.data)
        }).catch(this.$message.error)
      },
      'selectData.roadList'(roadList) {
        this.visible && this.type === 1 && this.$set(this.data, 'access_id', '')
      },
      mydata: {
        handler(newVal, oldVal) {
          this.data = JSON.parse(JSON.stringify(newVal))
        },
        deep: true
      }
    },
    mounted() {
      this.fetchDialogData()
    },
    methods: {
      fetchDialogData() {
        // 获取 业务 列表
        getApiWbBusiness().then(response => {
          this.$set(this.selectData, 'businessList', response.data)
        }).catch(this.$message.error)
      },
      onData(data) {
        // 批量修改
        if (this.type === 3) {
          this.$refs.form.validate((valid, vdata) => {
            if (!['business_id', 'work_start_at', 'work_end_at'].some(item => Object.keys(vdata).some(tt => tt === item))) {
              this.$emit('on-data', data)
            } else {
              return false
            }
          })
          return
        }

        // 新增 or 编辑
        this.$refs.form.validate(valid => {
          if (valid) {
            this.$emit('on-data', data)
          } else {
            return false
          }
        })
      },
      onDialogBusinessData(data) {
        postApiWbBusiness(data).then(response => getApiWbBusiness()).then((response) => {
          this.$set(this.selectData, 'businessList', response.data)
          this.dialogBusinessFormVisible = false
        }).catch(this.$message.error)
      },
      onDialogAccessData(data) {
        postApiWbAccess(data).then(response => {
          this.data.type && getApiWbAccessAccessesByTypeType(this.data.type).then(response => {
            this.$set(this.selectData, 'roadList', response.data)
            this.dialogAccessFormVisible = false
          })
        }).catch(this.$message.error)
      },
      addDialogAccessForm() {
        this.dialogAccessFormVisible = true
        this.dialogAccessForm = {
          type: this.data.type,
          name: '',
          en_name: ''
        }
      }
    }
  }
</script>

<style lang="scss" scoped>
  .my-dialog /deep/ {
    .avatar-uploader .el-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }

    .avatar-uploader .el-upload:hover {
      border-color: #409EFF;
    }

    .avatar-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      width: 178px;
      height: 178px;
      line-height: 178px;
      text-align: center;
    }

    .avatar {
      width: 178px;
      height: 178px;
      display: block;
    }

    .line {
      text-align: center;
    }
  }
</style>
