<template>
  <el-dialog
    ref="my-dialog"
    center
    width="440px"
    :title="title"
    :append-to-body="appendToBody"
    :visible.sync="visible"
    :before-close="() => void $emit('on-close')"
  >
    <el-form ref="form" :model="data" :rules="rules" @submit.native.prevent>
      <el-form-item label="通路名称" prop="name" :label-width="formLabelWidth">
        <el-input v-model.trim="data.name" placeholder="请输入通路名称" auto-complete="off" />
      </el-form-item>
      <el-form-item label="通路标识" prop="en_name" :label-width="formLabelWidth">
        <el-select v-model="data.en_name" filterable placeholder="请选择通路标识">
          <el-option
            v-for="item in options"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="通路图标" prop="icon_url" :label-width="formLabelWidth">
        <el-upload
          class="avatar-uploader"
          :action="`${upLoadImg}?token=${getToken()}`"
          :show-file-list="false"
          :on-success="onUpLoadImg"
          :before-upload="beforeUpload"
          :on-change="() => $refs.form.validate(valid => valid)"
        >
          <img v-if="data.icon_url" :src="data.icon_url" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon" />
        </el-upload>
      </el-form-item>
    </el-form>

    <div slot="footer" class="dialog-footer">
      <el-button @click="$emit('on-close')">取 消</el-button>
      <el-button type="primary" @click="onData(data)">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import { getToken } from '@/utils/auth'
  import { upLoadImg } from '@/api/public'
  import { CUBE } from '@/configuration.js'
  export default {
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      mydata: {
        type: Object,
        required: true
      },
      title: {
        type: String,
        default: ''
      },
      appendToBody: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        data: { ...this.mydata },
        formLabelWidth: '120px',
        getToken,
        upLoadImg,
        options: [
          {
            value: 'wechat',
            label: 'wechat'
          },
          {
            value: 'webchat',
            label: 'webchat'
          },
          {
            value: 'app',
            label: 'app'
          }
        ],
        rules: {
          en_name: [{ required: true, trigger: 'change', message: '请输入通路标识' }],
          name: [{ required: true, trigger: 'change', message: '请输入通路名称' }],
          icon_url: [{ required: true, trigger: 'change', message: '请上传通路图标' }]
        }
      }
    },
    // CUBE.permission.wechat.official_accounts
    watch: {
      visible(status) {
        !status &&
          this.$nextTick(() => {
            this.$refs['form'].resetFields()
          })
      },
      mydata: {
        handler(newVal, oldVal) {
          this.data = { ...newVal }
        },
        deep: true
      }
    },
    mounted() {
      if (this.title === '新增') {
        if (!CUBE.permission.wechat.official_accounts) {
          this.options.shift()
        }
      } else {
        if (this.data.en_name !== 'wechat' && !CUBE.permission.wechat.official_accounts) {
          this.options.shift()
        }
      }
    },
    methods: {
      onData(data) {
        this.$refs.form.validate(valid => {
          if (valid) {
            this.$emit('on-data', data)
          } else {
            return false
          }
        })
      },
      onUpLoadImg(res, file) {
        // this.imageUrl = URL.createObjectURL(file.raw)
        this.$set(this.data, 'icon_url', res.data.picUrl)
      },
      beforeUpload(file) {
        const isImg = ['image/jpeg', 'image/png'].some(item => file.type === item)
        const isLt2M = file.size / 1024 / 1024 < 2

        if (!isImg) {
          this.$message.error('上传通路图标只能是 JPG/PNG 格式!')
        }
        if (!isLt2M) {
          this.$message.error('上传通路图标大小不能超过 2MB!')
        }
        return isImg && isLt2M
      }
    }
  }
</script>

<style lang="scss" scoped>
  .avatar-uploader /deep/ {
    .el-upload {
      border: 1px dashed #d9d9d9;
      border-radius: 6px;
      cursor: pointer;
      position: relative;
      overflow: hidden;
    }
    .el-upload:hover {
      border-color: #409eff;
    }
    .avatar-uploader-icon {
      font-size: 28px;
      color: #8c939d;
      width: 178px;
      height: 178px;
      line-height: 178px;
      text-align: center;
    }
    .avatar {
      width: 178px;
      height: 178px;
      display: block;
    }
  }
</style>
