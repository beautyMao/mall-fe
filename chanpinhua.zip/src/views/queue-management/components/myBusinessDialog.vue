<template>
  <div class="my-dialog">
    <!-- Form -->
    <el-dialog ref="my-dialog" :append-to-body="appendToBody" :title="title" custom-class="pr30" width="440px" :visible.sync="visible" :before-close="() => void $emit('on-close')">
      <el-form ref="form" :model="data" :rules="rules" @submit.native.prevent>
        <el-form-item label="业务名称" prop="name" :label-width="formLabelWidth">
          <el-input v-model.trim="data.name" placeholder="请输入业务名称" auto-complete="off" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="$emit('on-close')">取 消</el-button>
        <el-button type="primary" @click="onData(data)">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { getToken } from '@/utils/auth'
  import { upLoadImg } from '@/api/public'
  export default {
    props: {
      visible: {
        type: Boolean,
        required: true
      },
      mydata: {
        type: Object,
        required: true
      },
      title: {
        type: String,
        required: true
      },
      appendToBody: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        data: { ...this.mydata },
        formLabelWidth: '120px',
        getToken,
        upLoadImg,
        rules: {
          name: [{ required: true, trigger: 'change', message: '请输入业务名称' }]
        }
      }
    },
    watch: {
      visible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
        })
      },
      mydata: {
        handler(newVal) {
          this.data = { ...newVal }
        },
        deep: true
      }
    },
    methods: {
      onData(data) {
        this.$refs.form.validate(valid => {
          if (valid) {
            this.$emit('on-data', data)
          } else {
            return false
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
.my-dialog /deep/ {
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 178px;
    height: 178px;
    display: block;
  }
}
</style>
