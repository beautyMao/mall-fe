<template>
  <div class="app-container">
    <div class="flex-wrp flex-between">
      <el-button type="primary" plain @click="dialogFormVisible = true">新增</el-button>
      <my-dialog
        title="新增"
        :mydata="dialogForm"
        :visible="dialogFormVisible"
        @on-data="onDialogData"
        @on-close="dialogFormVisible = false"
      />

      <el-input
        v-model.trim="searchText"
        placeholder="请输入业务名称"
        :style="{width: '300px'}"
        @keyup.enter.native="onSearch(searchText)"
      >
        <el-button slot="append" icon="el-icon-search" @click="onSearch(searchText)" />
      </el-input>
    </div>

    <div class="pt20">
      <my-table
        :data="localTableData"
        :mypagination="mypagination"
        @currentChange="handleCurrentChange"
        @handleEdit="handleEdit"
        @handleDelete="handleDelete"
        @handleSizeChange="handleSizeChange"
      />
      <my-dialog title="编辑" :mydata="tableForm" :visible="tableFormVisible" @on-data="onTableData" @on-close="tableFormVisible = false" />
    </div>
  </div>
</template>

<script>
  import {
    getApiWbBusiness,
    postApiWbBusiness,
    putApiWbBusinessId,
    delApiWbBusinessId,
    getApiWbBusinessSearch
  } from '@/api/queue-management/business'
  import myDialog from '@/views/queue-management/components/myBusinessDialog'
  import myTable from '@/views/queue-management/business/components/myTable'
  import { getToken } from '@/utils/auth'

  export default {
    components: { myDialog, myTable },
    data() {
      return {
        searchText: '',
        dialogForm: {
          name: ''
        },
        getToken,
        dialogFormVisible: false,
        tableData: [],
        tableForm: {},
        tableFormVisible: false,
        localTableData: [],
        mypagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        },
        excelForm: {
          fileList: []
        },
        formLabelWidth: '120px',
        dialogExcelFormVisible: false,
        excelFormRules: {
          fileList: [{ required: true, trigger: 'blur', message: '必填项' }]
        }
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        getApiWbBusiness().then(response => {
          this.tableData = response.data
          this.mypagination.current_page = 1
          this.localPagination()
        }).catch(this.$message.error)
      },
      onDialogData(data) {
        postApiWbBusiness(data).then(response => {
          this.fetchData()
          this.dialogFormVisible = false
        }).catch(this.$message.error)
      },
      onTableData(data) {
        putApiWbBusinessId(data.id, data).then(response => {
          this.fetchData()
          this.tableFormVisible = false
        }).catch(this.$message.error)
      },
      onSearch(text) {
        getApiWbBusinessSearch(text).then(response => {
          this.tableData = response.data
          this.mypagination.current_page = 1
          this.localPagination()
        }).catch(this.$message.error)
      },
      handleEdit(index, row) {
        console.log(index, row)
        this.tableFormVisible = true
        this.$nextTick(() => {
          this.tableForm = Object.assign({}, row)
        })
      },
      handleDelete(index, row) {
        this.$confirm('此操作将永久删除该业务, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          delApiWbBusinessId(row.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
          }).catch(this.$message.error)
        })
      },
      handleCurrentChange(val) {
        this.mypagination.current_page = val
        this.localPagination()
      },
      localPagination() {
        const number =
          (this.mypagination.current_page - 1) * this.mypagination.datanum
        this.localTableData = this.tableData.slice(
          number,
          number + this.mypagination.datanum
        )
        this.mypagination.total = this.tableData.length
      },
      handleSizeChange(val) {
        this.mypagination.datanum = val
        this.localPagination()
      },
      beforeUpload(file) {
        const isImg = ['image/jpeg', 'image/png'].some(item => file.type === item)
        const isLt2M = file.size / 1024 / 1024 < 2

        if (!isImg) {
          this.$message.error('上传头像图片只能是 JPG/PNG 格式!')
        }
        if (!isLt2M) {
          this.$message.error('上传头像图片大小不能超过 2MB!')
        }
        return isImg && isLt2M
      }
    }
  }
</script>
