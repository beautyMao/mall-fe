<template>
  <el-card>
    <el-table :data="data" style="width: 100%">
      <el-table-column type="index" :index="indexMethod" />
      <el-table-column label="业务名称" width="width: 100%">
        <template slot-scope="scope">
          <span>{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button type="text" @click="handleEdit(scope.$index, scope.row)">编辑</el-button>
          <el-button type="text" class="el-del" @click="handleDelete(scope.$index, scope.row)">删除</el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="pagination-container">
      <el-pagination
        background
        :current-page="mypagination.current_page"
        :page-size="mypagination.datanum"
        :page-sizes="[10, 15, 20, 25]"
        layout="total, sizes, prev, pager, next, jumper"
        :total="mypagination.total"
        @size-change="handleSizeChange"
        @current-change="currentChange"
      />
    </div>
  </el-card>
</template>

<script>
  export default {
    props: {
      data: {
        type: Array,
        required: true
      },
      mypagination: {
        type: Object,
        required: true
      }
    },
    data() {
      return {}
    },
    methods: {
      indexMethod(index) {
        return index + 1
      },
      handleEdit(index, row) {
        this.$emit('handleEdit', index, row)
      },
      handleDelete(index, row) {
        this.$emit('handleDelete', index, row)
      },
      currentChange(val) {
        this.$emit('currentChange', val)
      },
      handleSizeChange(val) {
        this.$emit('handleSizeChange', val)
      }
    }
  }
</script>
