<template>
  <div class="app-container">
    <header>
      <h1>{{ page.title }}</h1>
      <el-button type="primary" plain @click="addVisible = true">{{ page.addBtnName }}</el-button>
    </header>

    <myDialog
      v-if="addVisible"
      :dialog-visible="addVisible2"
      :title="page.newRuleDialogTitle"
      @change="onDialogData"
      @close="addVisible = false"
    />

    <my-table
      :list-data="tableDataList"
      @handleEdit="handleEdit"
      @handleDelete="handleDelete"
      @currentChange="handleCurrentChange"
      @handleSizeChange="handleSizeChange"
    />
    <myDialog
      :title="page.editRuleDialogTitle"
      :render-data="rowData"
      :dialog-visible="editVisible"
      @change="onTableData"
      @close="editVisible = false"
    />
  </div>
</template>

<script>
  import myTable from '../components/my-table'
  import myDialog from '../components/my-dialog'
  import { getConfigTimeoutSpeech, getConfigSilentSpeech, configTimeoutSpeechRestApi, configSilentSpeechRestApi } from '@/api/chat-conf'

  export default {
    components: { myTable, myDialog },
    data() {
      return {
        page: {
          name: '',
          title: '',
          addBtnName: '',
          newRuleDialogTitle: '',
          editRuleDialogTitle: ''
        },
        addVisible: false,
        addVisible2: true,
        editVisible: false,
        tableDataList: {
          case_list: [],
          current_page: 1,
          size: 10,
          total: 0
        },
        currentData: {
          page: 1,
          pageSize: 10
        },
        rowData: {},
        tableData: []
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      init() {
        this.page.name = this.$route.name
        if (this.page.name === 'timeout-chat-management') {
          this.page.title = '超时话术配置'
          this.page.addBtnName = '新建文本超时话术规则'
          this.page.newRuleDialogTitle = '创建超时话术规则'
          this.page.editRuleDialogTitle = '编辑超时话术规则'

          getConfigTimeoutSpeech(this.currentData).then(this.renderTable).catch(this.$message.error)
        } else if (this.page.name === 'empty-chat-management') {
          this.page.title = '空框话术配置'
          this.page.addBtnName = '新建文本空框话术规则'
          this.page.newRuleDialogTitle = '创建空框话术规则'
          this.page.editRuleDialogTitle = '编辑空框话术规则'

          getConfigSilentSpeech(this.currentData).then(this.renderTable).catch(this.$message.error)
        }
      },
      renderTable(res) {
        let _data = res.data.data
        this.tableDataList = res.data
        if (this.page.name === 'empty-chat-management') {
          _data = _data.map(item => ({
            id: item.id,
            timeout_name: item.silent_name,
            timeout_time_first: item.silent_time_first,
            timeout_time_second: item.silent_time_second,
            timeout_time_all: item.silent_time_all,
            timeout_content_first: item.silent_content_first,
            timeout_content_second: item.silent_content_second,
            businesses: item.businesses,
            queues: item.queues
          }))
          this.tableDataList.data = _data
        }
        if (!res.data.total) this.$message.warning('查询不到数据')
        this.currentData.page = res.data.current_page
        this.currentData.pageSize = res.data.per_page
      },
      handleEdit(index, row) {
        this.rowData = JSON.parse(JSON.stringify(row))
        this.editVisible = true
      },
      onDialogData(data) {
        if (this.page.name === 'timeout-chat-management') {
          configTimeoutSpeechRestApi.post(data).then(response => {
            this.init()
            this.addVisible = false
          }).catch(this.$message.error)
        } else if (this.page.name === 'empty-chat-management') {
          const parm = {
            silent_name: data.timeout_name,
            silent_time_first: data.timeout_time_first,
            silent_time_second: data.timeout_time_second,
            silent_time_all: data.timeout_time_all,
            silent_content_first: data.timeout_content_first,
            silent_content_second: data.timeout_content_second,
            queues: data.queues
          }
          configSilentSpeechRestApi.post(parm).then(response => {
            this.init()
            this.addVisible = false
          }).catch(this.$message.error)
        }
      },
      onTableData(data) {
        if (typeof data.queues[0] !== 'number') {
          data.queues = []
        }
        if (this.page.name === 'timeout-chat-management') {
          configTimeoutSpeechRestApi.update(data.id, data).then(response => {
            this.init()
            this.editVisible = false
          }).catch(this.$message.error)
        } else if (this.page.name === 'empty-chat-management') {
          const parm = {
            silent_name: data.timeout_name,
            silent_time_first: data.timeout_time_first,
            silent_time_second: data.timeout_time_second,
            silent_time_all: data.timeout_time_all,
            silent_content_first: data.timeout_content_first,
            silent_content_second: data.timeout_content_second,
            queues: data.queues
          }
          configSilentSpeechRestApi.update(data.id, parm).then(response => {
            this.init()
            this.editVisible = false
          }).catch(this.$message.error)
        }
      },
      handleDelete(index, row) {
        this.$confirm('您将要删除此规则，删除后，已经配置此规则的队列将恢复为默认规则，是否仍要继续删除?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          if (this.page.name === 'timeout-chat-management') {
            configTimeoutSpeechRestApi.delete(row.id).then(this.handleSuccessInit)
          } else if (this.page.name === 'empty-chat-management') {
            configSilentSpeechRestApi.delete(row.id).then(this.handleSuccessInit)
          }
        })
      },
      handleSuccessInit() {
        this.$message({
          type: 'success',
          message: '删除成功!'
        })
        this.init()
      },
      handleCurrentChange(page) {
        this.currentData.page = page
        if (this.page.name === 'timeout-chat-management') {
          getConfigTimeoutSpeech(this.currentData).then(this.renderTable).catch(this.$message.error)
        } else if (this.page.name === 'empty-chat-management') {
          getConfigSilentSpeech(this.currentData).then(this.renderTable).catch(this.$message.error)
        }
      },
      handleSizeChange(size) {
        this.currentData.pageSize = size
        this.currentData.page = 1
        if (this.page.name === 'timeout-chat-management') {
          getConfigTimeoutSpeech(this.currentData).then(this.renderTable).catch(this.$message.error)
        } else if (this.page.name === 'empty-chat-management') {
          getConfigSilentSpeech(this.currentData).then(this.renderTable).catch(this.$message.error)
        }
      }
    }
  }
</script>
