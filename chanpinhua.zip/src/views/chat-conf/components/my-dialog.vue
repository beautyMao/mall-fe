<template>
  <div class="my-dialog">
    <!-- Form -->
    <el-dialog
      ref="my-dialog"
      :title="title"
      custom-class="pr30 el-dialog-aside"
      :visible.sync="dialogVisible"
      :before-close="() => void $emit('close')"
    >
      <el-form ref="form" :model="formData" :rules="rules">
        <el-form-item
          label="规则名称"
          prop="timeout_name"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="formData.timeout_name"
            placeholder="请输入规则名称，限制20个字符"
            type="text"
            auto-complete="off"
            maxlength="20"
          />
        </el-form-item>

        <h3>{{ pageTitle }}话术配置</h3>

        <el-form-item :label="`${pageTitle}时间总长`" prop="timeout_time_all" :label-width="formLabelWidth">
          <el-input-number
            v-model="formData.timeout_time_all"
            controls-position="right"
            :style="{width: '84%'}"
            :precision="0"
            :min="3"
            :max="20"
            placeholder="在此设置会话超时总时长"
          />
          分钟
        </el-form-item>

        <el-form-item label="第1次话术触发时间" prop="timeout_time_first" :label-width="formLabelWidth">
          <el-input-number
            v-model="formData.timeout_time_first"
            controls-position="right"
            :precision="0"
            :style="{width: '84%'}"
            :min="1"
            :max="20"
            placeholder="在此设置第1次话术触发时间"
          />
          分钟
        </el-form-item>

        <el-form-item label="触发话术" prop="timeout_content_first" :label-width="formLabelWidth">
          <el-input v-model="formData.timeout_content_first" type="textarea" :rows="4" placeholder="在此输入第1次话术内容，字数不超过300字" maxlength="300" />
        </el-form-item>

        <el-form-item label="第2次话术触发时间" prop="timeout_time_second" :label-width="formLabelWidth">
          <el-input-number
            v-model="formData.timeout_time_second"
            controls-position="right"
            :min="2"
            :precision="0"
            :style="{width: '84%'}"
            :max="20"
            placeholder="在此设置第2次话术触发时间"
          />
          分钟
        </el-form-item>

        <el-form-item label="触发话术" prop="timeout_content_second" :label-width="formLabelWidth">
          <el-input v-model="formData.timeout_content_second" type="textarea" :rows="4" placeholder="在此输入第2次话术内容，字数不超过300字" maxlength="300" />
        </el-form-item>

        <h3>应用到技能组</h3>

        <el-form-item
          label="业务选择"
          prop="business_id"
          class="form-item1"
          placeholder="请选择业务"
          :label-width="formLabelWidth"
        >
          <el-cascader
            v-model="formData.business_id"
            :show-all-levels="false"
            :options="business"
            :props="cascaderAlias"
            change-on-select
            @change="handleBusinessChange"
          />
        </el-form-item>
        <el-form-item
          label="技能组"
          prop="queues"
          placeholder="请选择技能组"
          :label-width="formLabelWidth"
        >
          <el-table
            ref="queueTable"
            :data="queuesByQueueTableDate"
            tooltip-effect="dark"
            max-height="260"
            :header-cell-style="{background: 'white'}"
            style="width: 100%;border:1px solid #C0C4CC;"
            @select="handlequeueByQueueSelect"
            @select-all="handlequeueByQueueSelect"
          >
            <el-table-column label="全部">
              <template slot-scope="scope">
                <span>{{ `${scope.row.name}` }}</span>
              </template>
            </el-table-column>
            <el-table-column
              type="selection"
              width="80"
            />
          </el-table>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="$emit('close')">取 消</el-button>
        <el-button class="submit" type="primary" @click="onData">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { getStructureBusiness } from '@/api/skill-group-management'
  import { searchApiWbQueuesByBusiness } from '@/api/chat-conf'
  import { deepClone } from '@/utils'

  export default {
    name: 'my-dialog',
    props: {
      title: {
        type: String,
        default: ''
      },
      dialogVisible: {
        type: Boolean,
        default: false
      },
      renderData: {
        type: Object,
        default() {
          return {
            id: '',
            businesses: [],
            queues: [],
            timeout_content_first: '',
            timeout_content_second: '',
            timeout_name: '',
            timeout_time_all: '',
            timeout_time_first: '',
            timeout_time_second: ''
          }
        }
      }
    },
    data() {
      const validatePassAll = (rule, value, callback) => {
        if (this.formData.timeout_time_first >= this.formData.timeout_time_all) {
          callback(new Error('会话超时总时长必须大于第1次话术触发时间！'))
        } else if (this.formData.timeout_time_second >= this.formData.timeout_time_all) {
          callback(new Error('会话超时总时长必须大于第2次话术触发时间！'))
        } else {
          callback()
        }
      }
      const validatePassFirst = (rule, value, callback) => {
        if (this.formData.timeout_time_first >= this.formData.timeout_time_all) {
          callback(new Error('第1次话术触发时间必须小于会话超时总时长！'))
        } else if (this.formData.timeout_time_first >= this.formData.timeout_time_second) {
          callback(new Error('第1次话术触发时间必须小于第2次话术触发时间！'))
        } else {
          callback()
        }
      }
      const validatePassSecond = (rule, value, callback) => {
        if (this.formData.timeout_time_second >= this.formData.timeout_time_all) {
          callback(new Error('第2次话术触发时间必须小于会话超时总时长！'))
        } else if (this.formData.timeout_time_first >= this.formData.timeout_time_second) {
          callback(new Error('第2次话术触发时间必须大于第1次话术触发时间！'))
        } else {
          callback()
        }
      }
      return {
        activeName: 'addById',
        formLabelWidth: '160px',
        formLabelWidthMax: '120px',
        formData: deepClone(this.renderData),
        queues_id: '',
        business: [],
        queuesByQueueTableDate: [],
        cascaderAlias: {
          checkStrictly: true,
          value: 'id',
          label: 'name',
          children: 'childs'
        },
        pageTitle: '超时',
        rules: {
          timeout_name: [
            { required: true, message: '请输入规则名称', trigger: 'blur' },
            { min: 0, max: 20, message: '长度在20个字符以内', trigger: 'blur' }
          ],
          timeout_time_all: [{ required: true, validator: validatePassAll, trigger: 'change' }],
          timeout_time_first: [{ required: true, trigger: 'change', validator: validatePassFirst }],
          timeout_time_second: [{ required: true, validator: validatePassSecond, trigger: 'change' }],
          timeout_content_first: [{ required: true, message: '请输入第1次话术触发内容', trigger: 'blur' },
                                  { required: true, message: '请输入第1次话术触发内容', trigger: 'change' }],
          timeout_content_second: [{ required: true, message: '请输入第2次话术触发内容', trigger: 'blur' },
                                   { required: true, message: '请输入第2次话术触发内容', trigger: 'change' }]
        }
      }
    },
    watch: {
      dialogVisible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
        })
      },
      renderData: {
        handler(newVal, oldVal) {
          this.formData = deepClone(newVal)
          if (this.formData.businesses && this.formData.businesses.length !== 0) {
            this.formData.business_id = this.formData.businesses.map(item => parseInt(item.pivot.business_id))
            this.formData.queues = this.formData.queues.map(item => parseInt(item.pivot.queue_id))
            this.renderQueueTable(this.formData.business_id)
          }
        },
        deep: true
      }
    },
    mounted() {
      this.fetchDialogData()
      this.initTitle()
    },
    methods: {
      initTitle() {
        const pageName = this.$route.name
        if (pageName === 'empty-chat-management') {
          this.pageTitle = '空框'
        }
      },
      fetchDialogData() {
        // 获取 业务 列表
        getStructureBusiness({ search: true }).then(res => { // 获取业务列表-组织结构
          this.business = this.getTreeData(res.data)
        })
      },
      async onData() {
        this.$refs.form.validate(valid => {
          if (valid) {
            this.$emit('change', this.formData)
          } else {
            return false
          }
        })
      },
      getTreeData(data) {
        // 循环遍历json数据
        for (var i = 0; i < data.length; i++) {
          if (data[i].childs.length < 1) {
            // children若为空数组，则将children设为undefined
            data[i].childs = undefined
          } else {
            // children若不为空数组，则继续 递归调用 本方法
            this.getTreeData(data[i].childs)
          }
        }
        return data
      },
      async renderQueueTable(val) {
        const sentData = {
          business_id: val[val.length - 1],
          access_id: 0
        }
        await searchApiWbQueuesByBusiness(sentData).then(response => {
          if (Array.isArray(response.data)) {
            this.queuesByQueueTableDate = response.data
            if (this.formData.queues && this.formData.queues.length !== 0) {
              this.formData.queues.forEach(id => {
                this.queuesByQueueTableDate.forEach(item => {
                  if (item.id === id) {
                    this.$nextTick(() => {
                      this.$refs.queueTable.toggleRowSelection(item)
                    })
                  }
                })
              })
            }
          } else {
            this.queuesByQueueTableDate = []
          }
        }).catch(this.$message.error)
      },
      async handleBusinessChange(val) {
        if (val === undefined) {
          this.queuesByQueueTableDate = []
          return false
        }
        const sentData = {
          business_id: val[val.length - 1],
          access_id: 0
        }
        await searchApiWbQueuesByBusiness(sentData).then(response => {
          if (Array.isArray(response.data)) {
            this.queuesByQueueTableDate = response.data
          } else {
            this.queuesByQueueTableDate = []
          }
        }).catch(this.$message.error)
      },
      handlequeueByQueueSelect(val) {
        this.formData.queues = val.map(item => item.id)
      }
    }
  }
</script>

<style lang="scss" scoped>
 .form-item1 {
    .el-select {
      width: 100%;
    }
    .el-input-number--mini {
      width: 180px;
    }
    .el-cascader--mini{
      width: 180px;
    }
    .el-cascader--small{
      width: 100%;
    }
    /deep/ .el-input__inner {
      text-align: left;
      width: 100%;
    }
  }
</style>
