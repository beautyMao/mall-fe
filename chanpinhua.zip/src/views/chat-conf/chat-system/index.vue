<template>
  <div class="app-container">
    <header>
      <h1>系统话术配置</h1>
      <el-button type="primary" plain @click="addVisible = true">新建文本系统话术规则</el-button>
    </header>

    <myDialog
      v-if="addVisible"
      :dialog-visible="addVisible2"
      title="创建系统话术规则"
      @change="onDialogData"
      @close="addVisible = false"
    />

    <my-table
      :list-data="tableDataList"
      @handleEdit="handleEdit"
      @handleDelete="handleDelete"
      @currentChange="handleCurrentChange"
      @handleSizeChange="handleSizeChange"
    />
    <myDialog
      title="编辑系统话术规则"
      :render-data="rowData"
      :dialog-visible="editVisible"
      @change="onTableData"
      @close="editVisible = false"
    />
  </div>
</template>

<script>
  import myTable from './components/my-table'
  import myDialog from './components/my-dialog'
  import { getConfigSystemSpeech, configSystemSpeechRestApi } from '@/api/chat-conf'

  const applicationArr = ['客服接起话术', '进入队列排队', '网络异常', '网络断开重连', '排队中，用户发送任意字符', '超时未被接起']

  export default {
    name: 'system-chat-management',
    components: { myTable, myDialog },
    data() {
      return {
        addVisible: false,
        editVisible: false,
        addVisible2: true,
        rowData: {},
        tableDataList: {
          case_list: [],
          current_page: 1,
          size: 10,
          total: 0
        },
        currentData: {
          page: 1,
          pageSize: 10
        },
        source: 'chatConf'
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      init() { // 获取超时列表
        getConfigSystemSpeech(this.currentData).then(this.renderTable).catch(this.$message.error)
      },
      renderTable(res) {
        this.tableDataList = res.data
        this.tableDataList.data.forEach(item => {
          item.application_scenarios_val = applicationArr[item.application_scenarios]
        })
        if (!res.data.total) this.$message.warning('查询不到数据')
        this.currentData.page = res.data.current_page
        this.currentData.pageSize = res.data.per_page
      },
      handleEdit(index, row) {
        this.rowData = JSON.parse(JSON.stringify(row))
        this.editVisible = true
      },
      onDialogData(data) {
        configSystemSpeechRestApi.post(data).then(response => {
          this.init()
          this.addVisible = false
        }).catch(this.$message.error)
      },
      onTableData(data) {
        if (typeof data.queues[0] !== 'number') {
          data.queues = []
        }
        configSystemSpeechRestApi.update(data.id, data).then(response => {
          this.init()
          this.editVisible = false
        }).catch(this.$message.error)
      },
      handleDelete(index, row) {
        this.$confirm('您将要删除此规则，删除后，已经配置此规则的队列将恢复为默认规则，是否仍要继续删除?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          configSystemSpeechRestApi.delete(row.id).then(() => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.init()
          })
        })
      },
      handleCurrentChange(page) {
        this.currentData.page = page
        getConfigSystemSpeech(this.currentData).then(this.renderTable).catch(this.$message.error)
      },
      handleSizeChange(size) {
        this.currentData.pageSize = size
        this.currentData.page = 1
        getConfigSystemSpeech(this.currentData).then(this.renderTable).catch(this.$message.error)
      }
    }
  }
</script>
