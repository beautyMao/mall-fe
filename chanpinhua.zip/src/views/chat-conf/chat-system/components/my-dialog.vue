<template>
  <div class="my-dialog">
    <el-dialog
      ref="my-dialog"
      :title="title"
      custom-class="pr30 el-dialog-aside"
      :visible.sync="dialogVisible"
      :before-close="() => void $emit('close')"
    >
      <el-form ref="formData" :model="formData" :rules="rules">
        <el-form-item
          label="规则名称"
          prop="system_name"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="formData.system_name"
            placeholder="请输入规则名称，限制20个字符"
            type="text"
            auto-complete="off"
            maxlength="20"
          />
        </el-form-item>
        <el-form-item
          label="应用场景"
          prop="application_scenarios"
          :label-width="formLabelWidth"
        >
          <el-select v-model="formData.application_scenarios" :style="{width: '100%'}" placeholder="请选择" disabled @change="changeApplicationScenarios">
            <el-option
              v-for="(item, index) in application_scenarios_arr"
              :key="index"
              :label="item"
              :value="index"
            />
          </el-select>
        </el-form-item>
        <el-form-item
          v-if="formData.application_scenarios === 5"
          label="超时时间设置"
          prop="timout_time"
          :label-width="formLabelWidth"
        >
          <el-input-number
            v-model="formData.timout_time"
            controls-position="right"
            :min="10"
            :max="50"
            :style="{width: '84%'}"
          />
          分钟
        </el-form-item>
        <el-form-item
          label="推送话术"
          prop="system_content"
          :label-width="formLabelWidth"
        >
          <el-input
            v-model="formData.system_content"
            type="textarea"
            placeholder="在此输入内容，字数不超过300"
            maxlength="300"
          />
        </el-form-item>
        <p v-pre style="margin-left: 120px;;margin-top: -10px;">
          注：<br>1.最多不超过300个字符；<br>2.如输入“{{linUp}}”可获取当前用户排队位置；
        </p>

        <h3>应用到业务及技能组</h3>

        <el-form-item
          label="业务选择"
          prop="business_id"
          class="form-item1"
          placeholder="请选择业务"
          :label-width="formLabelWidth"
        >
          <el-cascader
            v-model="formData.business_id"
            :show-all-levels="false"
            :options="business"
            :props="cascaderAlias"
            change-on-select
            :style="{width: '100%'}"
            @change="handleBusinessChange"
          />
        </el-form-item>
        <el-form-item
          label="技能组"
          prop="queues"
          placeholder="请选择技能组"
          :label-width="formLabelWidth"
        >
          <el-table
            ref="queueTable"
            :data="queuesByQueueTableDate"
            tooltip-effect="dark"
            max-height="260"
            :header-cell-style="{background: 'white'}"
            style="width: 100%;border:1px solid #C0C4CC;"
            @select="handlequeueByQueueSelect"
            @select-all="handlequeueByQueueSelect"
          >
            <el-table-column label="全部">
              <template slot-scope="scope">
                <span>{{ `${scope.row.name}` }}</span>
              </template>
            </el-table-column>
            <el-table-column
              type="selection"
              width="80"
            />
          </el-table>
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="$emit('close')">取 消</el-button>
        <el-button class="submit" type="primary" @click="onData">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { getStructureBusiness } from '@/api/skill-group-management'
  import { searchApiWbQueuesByBusiness } from '@/api/chat-conf'
  const application_scenarios_msg = ['您好，客服{{ servicrName }}，为您服务，请问有什么可以帮助您？', '您好，您当前在队列第{{ linUp }}位，请您耐心等待，客服马上就来！', '当前网络异常，请检查网络环境~', '网络已恢复，请继续沟通~', '您当前排在第{{linUp}}位，请不要离开哦，客服马上就来！', '当前业务繁忙，建议您稍后咨询！']

  export default {
    name: 'my-dialog',
    props: {
      title: {
        type: String,
        default: ''
      },
      dialogVisible: {
        type: Boolean,
        default: false
      },
      renderData: {
        type: Object,
        default() {
          return {
            id: '',
            timout_time: 30,
            system_name: '',
            businesses: [],
            queues: [],
            application_scenarios: 4,
            system_content: '您当前排在第{{linUp}}位，请不要离开哦，客服马上就来！'
          }
        }
      }
    },
    data() {
      return {
        formLabelWidth: '120px',
        formData: JSON.parse(JSON.stringify(this.renderData)),
        queues_id: '',
        addNewPage: true,
        business: [],
        application_scenarios_arr: ['客服接起话术', '进入队列排队', '网络异常', '网络断开重连', '排队中，用户发送任意字符', '超时未被接起'],
        application_scenarios_pleah: '',
        queuesByQueueTableDate: [],
        cascaderAlias: {
          checkStrictly: true,
          value: 'id',
          label: 'name',
          children: 'childs'
        },
        rules: {
          system_name: [
            { required: true, message: '请输入规则名称', trigger: 'blur' },
            { min: 0, max: 20, message: '长度在20个字符以内', trigger: 'blur' }
          ],
          timout_time: [{ required: true, message: '请输入超时时间', trigger: 'change' }],
          application_scenarios: [{ required: true, message: '请输入应用场景', trigger: 'change' }],
          system_content: [{ required: true, trigger: 'blur', message: '请输入推送话术' }]
        }
      }
    },
    watch: {
      dialogVisible(status) {
        !status && this.$nextTick(() => {
          this.$refs['formData'].resetFields()
        })
      },
      renderData: {
        handler(newVal, oldVal) {
          this.formData = JSON.parse(JSON.stringify(newVal))
          this.addNewPage = false
          if (this.formData.businesses && this.formData.businesses.length !== 0) {
            this.formData.business_id = this.formData.businesses.map(item => parseInt(item.pivot.business_id))
            this.formData.queues = this.formData.queues.map(item => parseInt(item.pivot.queue_id))
            this.renderQueueTable(this.formData.business_id)
          }
        },
        deep: true
      }
    },
    mounted() {
      this.fetchDialogData()
    },
    methods: {
      fetchDialogData() {
        // 获取 业务 列表
        getStructureBusiness({ search: true }).then(res => { // 获取业务列表-组织结构
          this.business = this.getTreeData(res.data)
        })
      },
      async onData() {
        this.$refs.formData.validate(valid => {
          if (valid) {
            this.$emit('change', this.formData)
          } else {
            return false
          }
        })
      },
      getTreeData(data) {
        // 循环遍历json数据
        for (var i = 0; i < data.length; i++) {
          if (data[i].childs.length < 1) {
            // children若为空数组，则将children设为undefined
            data[i].childs = undefined
          } else {
            // children若不为空数组，则继续 递归调用 本方法
            this.getTreeData(data[i].childs)
          }
        }
        return data
      },
      async renderQueueTable(val) {
        const sentData = {
          business_id: val[val.length - 1],
          access_id: 0
        }
        await searchApiWbQueuesByBusiness(sentData).then(response => {
          if (Array.isArray(response.data)) {
            this.queuesByQueueTableDate = response.data
            if (this.formData.queues && this.formData.queues.length !== 0) {
              this.formData.queues.forEach(id => {
                this.queuesByQueueTableDate.forEach(item => {
                  if (item.id === id) {
                    this.$nextTick(() => {
                      this.$refs.queueTable.toggleRowSelection(item)
                    })
                  }
                })
              })
            }
          } else {
            this.queuesByQueueTableDate = []
          }
        }).catch(this.$message.error)
      },
      async handleBusinessChange(val) {
        if (val === undefined) {
          this.queuesByQueueTableDate = []
          return false
        }
        const sentData = {
          business_id: val[val.length - 1],
          access_id: 0
        }
        await searchApiWbQueuesByBusiness(sentData).then(response => {
          if (Array.isArray(response.data)) {
            this.queuesByQueueTableDate = response.data
          } else {
            this.queuesByQueueTableDate = []
          }
        }).catch(this.$message.error)
      },
      handlequeueByQueueSelect(val) {
        this.formData.queues = val.map(item => item.id)
      },
      changeApplicationScenarios() {
        if (this.addNewPage) this.formData.system_content = application_scenarios_msg[this.formData.application_scenarios]
      }
    }
  }
</script>

<style lang="scss" scoped>
 .form-item1 {
    .el-select {
      width: 180px;
    }
    .el-input-number--mini {
      width: 180px;
    }
    .el-cascader--mini{
      width: 180px;
    }
    /deep/ .el-input__inner {
      text-align: left;
    }
  }
</style>
