<template>
  <el-card>
    <el-table
      :data="listData.data"
      style="width: 100%"
    >
      <el-table-column
        align="center"
        label="#"
        type="index"
        :index="indexMethod"
      />
      <el-table-column
        align="center"
        label="规则名称"
        prop="system_name"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.system_name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        label="推送话术"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.system_content.length<=4">{{ scope.row.system_content }}</span>
          <el-popover v-if="scope.row.system_content.length>4" trigger="hover" placement="top">
            <p :style="{'max-width': '400px!important'}">{{ scope.row.system_content }}</p>
            <div slot="reference" class="name-wrapper">
              <span>{{ scope.row.system_content }}</span>
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        label="应用场景"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.application_scenarios_val }}</span>
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        label="应用业务"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.businesses_name.length<=10">{{ scope.row.businesses_name }}</span>
          <el-popover v-if="scope.row.businesses_name.length>10" trigger="hover" placement="top">
            <p :style="{'max-width': '400px!important'}">
              <span v-for="(item, index) in scope.row.businesses" v-if="index!==scope.row.businesses.length-1" :key="index">{{ item.name }}/</span>
              <span v-for="(item, index) in scope.row.businesses" v-if="index===scope.row.businesses.length-1" :key="index">{{ item.name }}</span>
            </p>
            <div slot="reference" class="name-wrapper">
              <span v-for="(item, index) in scope.row.businesses" v-if="index!==scope.row.businesses.length-1" :key="index">{{ item.name }}/</span>
              <span v-for="(item, index) in scope.row.businesses" v-if="index===scope.row.businesses.length-1" :key="index">{{ item.name }}</span>
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        label="应用技能组"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span v-if="scope.row.queues_name.length<=10">{{ scope.row.queues_name }}</span>
          <el-popover v-if="scope.row.queues_name.length>10" trigger="hover" placement="top">
            <p :style="{'max-width': '400px!important'}">
              <span v-for="(item, index) in scope.row.queues" v-if="index!==scope.row.queues.length-1" :key="index">{{ item.name }}/</span>
              <span v-for="(item, index) in scope.row.queues" v-if="index===scope.row.queues.length-1" :key="index">{{ item.name }}</span>
            </p>
            <div slot="reference" class="name-wrapper">
              <span v-for="(item, index) in scope.row.queues" v-if="index!==scope.row.queues.length-1" :key="index">{{ item.name }}/</span>
              <span v-for="(item, index) in scope.row.queues" v-if="index===scope.row.queues.length-1" :key="index">{{ item.name }}</span>
            </div>
          </el-popover>
        </template>
      </el-table-column>
      <el-table-column
        align="center"
        label="操作"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="handleEdit(scope.$index, scope.row)"
          >编辑</el-button>
          <el-button
            type="text"
            class="el-del"
            @click="handleDelete(scope.$index, scope.row)"
          >删除</el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      background
      :current-page="listData.current_page"
      :page-size="listData.size"
      :page-sizes="[5, 10, 20]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="listData.total"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </el-card>
</template>

<script>
  export default {
    name: 'my-table',
    props: {
      listData: {
        type: Object,
        required: true
      }
    },
    watch: {
      listData: {
        handler(newVal, oldVal) {
          const data = this.listData.data
          data.forEach((item, index) => {
            const businesses_name = []
            const queues_name = []
            if (item.businesses && item.businesses.length !== 0) {
              item.businesses.forEach((b_item, b_index) => {
                if (b_index === item.businesses.length - 1) {
                  businesses_name.push(b_item.name)
                } else {
                  businesses_name.push(b_item.name + '/')
                }
              })
            }
            if (item.queues && item.queues.length !== 0) {
              item.queues.forEach((q_item, q_index) => {
                if (q_index === item.queues.length - 1) {
                  queues_name.push(q_item.name)
                } else {
                  queues_name.push(q_item.name + '/')
                }
              })
            }
            data[index].businesses_name = businesses_name.join('')
            data[index].queues_name = queues_name.join('')
          })
        },
        deep: true
      }
    },
    methods: {
      indexMethod(index) {
        return index + 1
      },
      handleEdit(index, row) {
        this.$emit('handleEdit', index, row)
      },
      handleDelete(index, row) {
        this.$emit('handleDelete', index, row)
      },
      currentChange(val) {
        this.$emit('currentChange', val)
      },
      handleSizeChange(val) {
        this.$emit('handleSizeChange', val)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .el-tag {
    width: 95%;
    overflow: hidden;
    text-overflow: ellipsis;
    white-space: nowrap;
    padding: 0 5px;
  }
  .name-wrapper{
    overflow: hidden;
    text-overflow:ellipsis;
    white-space: nowrap;

  }
</style>
