<template>
  <div>
    <div v-if="pwd" class="newpwdWrapper">
      <p class="list-title">设置新密码</p>
      <div class="title">注册邮箱：{{ email }}</div>
      <div class="pwdWrapper">
        <div class="pos">
          <el-input
            v-model="input"
            placeholder="请输入新密码"
            :type="passwordType1"
            class="password"
            @change="handlePwdChange"
          />
          <span class="show-pwd" @click="showPwd1">
            <svg-icon v-if="eye1" icon-class="eye" />
            <svg-icon v-else icon-class="eyeOpen" />
          </span>
          <span class="info" :class="{ info1: infoShow }">{{ info }}</span>
        </div>
        <div class="pos">
          <el-input
            v-model="input1"
            placeholder="请再次确认密码"
            :type="passwordType2"
            class="password"
            @change="handlePwdChange1"
          />
          <span class="show-pwd" @click="showPwd2">
            <svg-icon v-if="eye2" icon-class="eye" />
            <svg-icon v-else icon-class="eyeOpen" />
          </span>
          <span v-if="infoShow1" class="info1">两次密码输入不一致</span>
        </div>
        <el-button
          type="primary"
          class="button"
          @click="handleBtnClick"
        >提交
        </el-button>
      </div>
    </div>
    <div v-if="err" class="err">
      <svg-icon icon-class="lose" class="icon" />
      <p class="info">该链接已失效，<span class="num">{{ num }}</span> 秒后页面跳转</p>
    </div>
  </div>
</template>

<script>
  import { getPasswordInfo } from '@/api/account-info'
  export default {
    data() {
      return {
        pwd: false,
        err: false,
        email: '',
        input: '',
        input1: '',
        info: '密码为8-20位数字、字母组合',
        infoShow: false,
        infoShow1: false,
        passwordType1: 'password',
        passwordType2: 'password',
        eye1: true,
        eye2: true,
        token: '',
        num: 5,
        reg: /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z._!@#$%]{8,20}$/
      }
    },
    mounted() {
      getPasswordInfo(this.$route.query.token).then(res => {
        this.pwd = true
        const reg = /(.{2}).+(.{2}@.+)/g
        this.email = res.data.email.replace(reg, '$1****$2')
      }).catch(err => {
        if (err === '该链接已失效') {
          this.err = true
          setInterval(this.numChange, 1000)
          setTimeout(this.routerChange, 5000)
        }
      })
    },
    methods: {
      numChange() {
        return this.num--
      },
      routerChange() {
        this.$router.push({ path: '/login' })
      },
      handlePwdChange() {
        if (!this.reg.test(this.input)) {
          this.infoShow = true
          this.info = '请输入8-20位数字、字母组合'
        } else {
          this.infoShow = false
        }
      },
      showPwd1() {
        if (this.passwordType1 === 'password') {
          this.eye1 = false
          this.passwordType1 = ''
        } else {
          this.eye1 = true
          this.passwordType1 = 'password'
        }
      },
      showPwd2() {
        if (this.passwordType2 === 'password') {
          this.eye2 = false
          this.passwordType2 = ''
        } else {
          this.eye2 = true
          this.passwordType2 = 'password'
        }
      },
      handlePwdChange1() {
        if (this.input !== this.input1) {
          this.infoShow1 = true
        } else {
          this.infoShow1 = false
        }
      },
      handleBtnClick() {
        const data = {
          token: this.$route.query.token,
          password: this.input,
          password_confirmation: this.input1
        }
        this.$emit('submitChange', data)
      }
    }
  }
</script>

<style scoped lang="scss">
  .newpwdWrapper {
    padding-top: 80px;
    margin: 0 140px;
    color: #0B0B0B;
    .pos {
      position: relative;
      margin-bottom: 34px;
      .show-pwd {
        position: absolute;
        right: 30px;
        top: 16px;
        color: #889aa4;
        font-size: 14px;
        cursor: pointer;
        user-select: none;
        z-index: 9999;
      }
    }
    .list-title {
      margin: 0;
      margin-bottom: 12px;
      font-size: 34px;
      text-align: center;
    }
    .title {
      margin-bottom: 30px;
      font-size: 18px;
      text-align: center;
      color: #909399;
    }
    .password {
      width: 400px;
      height: 48px;
      & /deep/.el-input__inner {
        height: 100%;
      }
    }
    .info {
      position: absolute;
      left: 0;
      bottom: -25px;
      font-size: 13px;
      color: #93969C;
    }
    .info1 {
      position: absolute;
      left: 0;
      bottom: -25px;
      font-size: 13px;
      color: #F37261;
    }
    .button {
      width: 400px;
      height: 60px;
      font-size: 24px;
    }
  }
  .err {
    padding-top: 200px;
    text-align: center;
    .icon {
      display: block;
      width: 80px;
      height: 60px;
      margin: 0 auto;
    }
    .info {
      margin-top: 30px;
      color: #0B0B0B;
      .num {
        color: #1890FF;
      }
    }
  }
  /*.newpwdWrapper {*/
    /*position: relative;*/
    /*width: 550px;*/
    /*margin: 0 auto;*/
    /*font-size: 14px;*/
    /*.list-title {*/
      /*text-align: center;*/
      /*font-size: 20px;*/
    /*}*/
    /*.title {*/
      /*text-align: center;*/
      /*font-size: 14px;*/
      /*color: #666;*/
    /*}*/
    /*.pwdWrapper {*/
      /*position: relative;*/
      /*width: 300px;*/
      /*margin: 0 auto;*/
      /*.password {*/
        /*padding: 10px 0;*/
        /*text-align: center;*/
      /*}*/
      /*.password /deep/ .el-input__inner {*/
        /*height: 40px;*/
        /*line-height: 40px;*/
      /*}*/
      /*.info {*/
        /*font-size: 12px;*/
        /*color: #555;*/
      /*}*/
      /*.info1 {*/
        /*font-size: 12px;*/
        /*color: #ff0000;*/
      /*}*/
      /*.button {*/
        /*width: 100%;*/
        /*height: 40px;*/
        /*margin: 10px 0;*/
      /*}*/
    /*}*/

  /*}*/
</style>
