<template>
  <div class="resetWrapper">
    <p class="list-title">重置密码</p>
    <div class="title">请输入注册账号的邮箱</div>
    <el-input
      v-model="input"
      placeholder="请输入邮箱"
      class="input"
      clearable
      @change="handleInputChange"
    />
    <span
      v-if="show"
      class="warn"
    >{{ value }}
    </span>
    <el-button
      type="primary"
      class="button"
      @click="handleNextClick"
    >下一步
    </el-button>
  </div>
</template>

<script>
  import { getAccountSearch1 } from '@/api/account-info.js'
  export default {
    props: {
      codeList: {
        type: Array,
        default() {
          return []
        }
      }
    },
    data() {
      return {
        input: '',
        show: false,
        value: '邮箱格式不正确'
      }
    },
    methods: {
      handleInputChange() {
        const reg = new RegExp('^[a-z0-9]+([._\\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$')
        this.show = !reg.test(this.input)
      },
      handleNextClick() {
        if (this.show || !this.input) return
        const data = {
          email: this.input
        }
        getAccountSearch1(data).then(res => {
          if (res.data.length === 0) {
            this.show = true
            this.value = '该邮箱尚未注册'
            return
          }
          this.$emit('changeResetShow', [this.input, res.data])
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  .resetWrapper {
    padding-top: 80px;
    margin: 0 140px;
    color: #0B0B0B;
    .list-title {
      margin: 0;
      margin-bottom: 60px;
      font-size: 34px;
      text-align: center;
    }
    .title {
      margin-bottom: 10px;
      font-size: 20px;
    }
    .input {
      width: 400px;
      height: 48px;
      & /deep/.el-input__inner {
        height: 100%;
      }
    }
    .warn {
      display: inline-block;
      margin-top: 6px;
      font-size: 16px;
      color: #F37261;
    }
    .button {
      width: 400px;
      height: 60px;
      margin-top: 30px;
      font-size: 24px;
    }
  }
</style>
