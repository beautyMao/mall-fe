<template>
  <div class="successWrapper">
    <p class="list-title">密码重置成功</p>
    <div class="succ">
      <img
        src="../images/succ.png"
        alt=""
        class="img"
      >
      <el-button
        type="primary"
        class="button"
        @click="handleBtnClick"
      >去登陆
      </el-button>
    </div>
  </div>
</template>

<script>
  export default {
    data() {
      return {}
    },
    methods: {
      handleBtnClick() {
        this.$router.push({ path: '/' })
      }
    }
  }
</script>

<style scoped lang="scss">
  .successWrapper {
    padding-top: 80px;
    margin: 0 140px;
    color: #0B0B0B;
    .list-title {
      margin: 0;
      margin-bottom: 12px;
      font-size: 34px;
      text-align: center;
    }
    .succ {
      text-align: center;
      .img {
        width: 120px;
        height: 120px;
        margin: 50px 0;
      }
    }
    .button {
      width: 400px;
      height: 60px;
      font-size: 24px;
    }
  }
</style>
