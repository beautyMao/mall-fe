<template>
  <div class="authWrapper">
    <p class="list-title">验证身份</p>
    <div class="content">
      为保证账号的安全，需要发送验证身份链接至您的邮箱，
      <br>
      点击立即发送按钮，将会发送一封身份验证邮件至邮箱{{ value }},请注意查收
    </div>
    <el-select v-model="optionsVal" placeholder="请选择工号" class="select">
      <el-option
        v-for="item in codeList"
        :key="item.code"
        :label="item.code"
        :value="item.code"
      />
    </el-select>
    <el-button
      ref="send"
      type="primary"
      class="button"
      :disabled="send"
      @click="handleSendClick"
    >立即发送
    </el-button>
    <div
      v-if="send"
      class="hint"
    >{{ data }}
      <a
        class="resend"
        @click="handleResendClick"
      >{{ resendInfo }}
      </a>
    </div>
  </div>
</template>

<script>
  export default {
    props: {
      email: {
        type: String,
        default: ''
      },
      codeList: {
        type: Array,
        default() {
          return []
        }
      }
    },
    data() {
      return {
        value: '',
        data: '未收到邮件？',
        resendInfo: '重新发送',
        send: false,
        optionsVal: ''
      }
    },
    mounted() {
      var reg = /(.{2}).+(.{2}@.+)/g
      this.value = this.email.replace(reg, '$1****$2')
    },
    methods: {
      handleSendClick() {
        if (!this.optionsVal) {
          this.$message({
            message: '请填写工号',
            type: 'warning'
          })
          return
        }
        this.send = true
        this.$refs.send.$el.style.backgroundColor = '#BDC6DF'
        this.$emit('sendEmail', this.optionsVal)
      },
      handleResendClick() {
        this.$emit('sendEmail', this.optionsVal)
        let n = 20
        const timer = setInterval(() => {
          this.resendInfo = '已发送' + n-- + 's'
          if (n === -1) {
            clearInterval(timer)
            this.data = '还未收到邮件？'
            this.resendInfo = '重新发送'
          }
        }, 1000)
      }
    }
  }
</script>

<style scoped lang="scss">
  .authWrapper {
    padding-top: 80px;
    margin: 0 40px;
    color: #0B0B0B;
    .list-title {
      margin: 0;
      margin-bottom: 60px;
      font-size: 34px;
      text-align: center;
    }
    .content {
      line-height: 30px;
      font-size: 18px;
      text-align: center;
    }
    .select {
      display: block;
      width: 400px;
      height: 48px;
      margin: 10px auto 30px;
      & /deep/ .el-input {
        width: 100%;
        height: 100%;
        .el-input__inner {
          height: 100%;
        }
      }
    }
    .button {
      display: block;
      width: 400px;
      height: 60px;
      margin: 30px auto 0;
      font-size: 24px;
    }
    .hint {
      margin-top: 20px;
      font-size: 18px;
      text-align: center;
      .resend {
        color: #337CE8;
      }
    }
  }

</style>
