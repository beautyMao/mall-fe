<template>
  <div class="Wrap">
    <header>
      <div class="logo">
        <svg-icon icon-class="logo" />
        <span class="first-title">魔方</span>
      </div>
    </header>
    <div class="box">
      <div v-if="reset_page">
        <v-reset v-if="v_reset" ref="reset" @changeResetShow="changeResetShow" />
        <v-authentication v-if="v_auth" :email="email" :code-list="codeList" @sendEmail="sendEmail" />
      </div>
      <div v-if="reset_page1">
        <v-newpwd v-if="v_newpwd" @submitChange="submitChange" />
        <v-amendsucc v-if="v_amendsucc" />
      </div>
    </div>
  </div>
</template>

<script>
  import vReset from './components/reset-passwords'
  import vAuthentication from './components/authentication'
  import vNewpwd from './components/new-password'
  import vAmendsucc from './components/amend-success'
  import {
    getAccountForgetPassword,
    getPasswordChange
  } from '@/api/account-info.js'
  import { CUBE } from '@/configuration'
  export default {
    name: 'reset',
    components: {
      vReset,
      vAuthentication,
      vNewpwd,
      vAmendsucc
    },
    data() {
      return {
        reset_page: '',
        reset_page1: '',
        v_reset: true,
        v_auth: false,
        v_newpwd: true,
        v_amendsucc: false,
        email: '',
        code: '',
        codeList: []
      }
    },
    mounted() {
      if (('' + this.$route.query.id) === '1') {
        this.reset_page = true
        this.reset_page1 = false
      } else if (('' + this.$route.query.id) === '2') {
        this.reset_page = false
        this.reset_page1 = true
      }
    },
    methods: {
      changeResetShow(val) {
        this.v_reset = false
        this.v_auth = true
        this.email = val[0]
        this.codeList = val[1]
      },
      sendEmail(val) {
        this.code = val
        const data = {
          code: val,
          email: this.email,
          rest_url: `${CUBE.api.domain}/#/reset?id=2`
        }
        getAccountForgetPassword(data).then(res => {})
      },
      submitChange(val) {
        getPasswordChange(val).then(res => {
          this.v_newpwd = false
          this.v_amendsucc = true
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  .Wrap {
    position: fixed;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    background: #F5F7FA;
    header {
      position: absolute;
      left: 0;
      top: 0;
      right: 0;
      height: 74px;
      background: #fff;
      .logo {
        width: 250px;
        margin: 12px 0 0 30px;
        font-size: 44px;
        .first-title {
          font-size: 22px;
          color: #646464;
        }
      }
    }
    .box {
      width: 680px;
      height: 480px;
      margin: 164px auto;
      background: #fff;
    }
  }
</style>
