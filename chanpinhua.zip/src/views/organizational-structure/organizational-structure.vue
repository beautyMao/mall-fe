<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div id="organizational-structure" class="app-container">
    <div class="flex-wrp flex-between">
      <div class="mr15">
        <div @contextmenu="openMenu($event, 1)">
          <el-card>
            <div slot="header" class="flex-wrp flex-between flex-align-center">
              <div class="color2 bold size16 flex-wrp lh200 ptb5" :style="{width: '106px'}">
                组织关系</div>
              <div @contextmenu="stopDefault($event)"><el-button icon="el-icon-plus" size="mini" circle @click.stop="addMenuRoot($event)" /></div>
            </div>
            <div :style="{width: '250px'}">
              <el-tree
                ref="tree"
                :data="thatDataComputed"
                children="childs"
                node-key="id"
                :props="defaultProps"
                :auto-expand-parent="false"
                :default-expanded-keys="showMenus"
                :check-on-click-node="true"
                :highlight-current="true"
                :expand-on-click-node="false"
                @node-contextmenu="($event, data) => openMenu($event, data.id === 0 ? 1 : 2, data)"
                @node-click="() => { closeMenu(); closeMenuEdit() }"
                @node-expand="nodeExpand"
                @node-collapse="nodeCollapse"
                @current-change="setCurrentTarget"
              >
                <!-- @contextmenu="openMenu($event, data.id === 0 ? 1 : 2, data)" -->
                <div slot-scope="{ node, data }" class="custom-tree-node" @dblclick="menuEdit($event, data)">
                  <el-input
                    v-if="data.id === hoverMenu.id && hoverMenu.edit"
                    :ref="`menuText${data.id}`"
                    v-model="hoverMenu.name"
                    size="mini"
                    class="menu-text"
                    @contextmenu.native="stopDefault($event)"
                    @dblclick.native="stopDefault($event)"
                    @click.native="stopDefault($event)"
                    @keyup.enter.native="successEditMenu($event)"
                    @keyup.esc.native="closeMenuEdit($event)"
                  >
                    <div slot="suffix" class="flex-wrp flex-center talk" @click="successEditMenu($event)">
                      <svg-icon icon-class="duigou" class="talk-icon" />
                    </div>
                  </el-input>
                  <div v-else class="color4" @selectstart="stopDefault($event)">{{ data.name }}</div>
                </div>
              </el-tree>
            </div>
          </el-card>
        </div>
        <ul v-show="visible" class="contextmenu" :style="{left:left+'px',top:top+'px'}">
          <div v-show="hoverMenu.menuType === 1">
            <li class="pointer" @click="addMenu($event, 1)">增加根目录</li>
          </div>
          <div v-show="hoverMenu.menuType === 2">
            <li class="pointer" @click="menuEdit($event)">重命名</li>
            <li class="pointer" @click="delEditMenu($event)">删除</li>
            <li class="pointer" @click="addMenu($event, 2)">增加子业务</li>
          </div>
        </ul>
      </div>
      <div :style="{ flex: 1 }">
        <header>
          <h1 v-if="!selectInfo.input">所有（ {{ tableDataList.total }} ）人</h1>
          <h1 v-else>搜索结果（ {{ tableDataList.total }} ）人</h1>
          <div class="flex-wrp">
            <el-button :disabled="!buttonPermission('accountRegiest') || (selectInfo.business_id === 0)" type="primary" plain @click="add">新增</el-button>
            <el-button :disabled="!buttonPermission('accountDelete') || !codeAll.length" type="primary" plain @click="allDet">批量删除</el-button>
            <el-button :disabled="!codeAll.length" type="primary" plain @click="handleDownloadClick">导出 Excel</el-button>
          </div>
        </header>

        <public-view-table
          :data="tableDataList"
          :select-all="selectInfo.input ? true : false"
          @change="handleCurrentChange"
          @size-change="handleSizeChange"
          @edit="edit"
          @delete="det"
          @select="tableSelect"
        >
          <div class="flex-wrp pd15">
            <el-select
              v-model="selectInfo.role_id"
              class="mr15"
              :style="{width: '240px'}"
              :clearable="true"
              filterable
              placeholder="角色"
            >
              <el-option v-for="(item, index) in roleList" :key="index" :label="item.name" :value="item.id" />
            </el-select>

            <!-- <el-input
                v-model.trim="selectInfo.input"
                placeholder="姓名、邮箱、手机号、工号"
                :style="{width: '300px'}"
              /> -->
            <el-input
              v-model.trim="searchText"
              placeholder="姓名、邮箱、手机号、工号"
              :style="{width: '240px'}"
              @blur="onBlurText"
              @keyup.enter.native="onSearch"
            >
              <i slot="prefix" class="el-input__icon el-icon-search" @click="onSearch" />
            </el-input>
          </div>
        </public-view-table>

        <v-dialog v-if="createEditorInfo.createEditor" v-bind="createEditorInfo" @closeDialog="closeDialog" />
      </div>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { getApiWbStructureBusiness, postApiWbStructureBusiness, putApiWbStructureBusiness, delApiWbStructureBusiness, getApiWbEngineerList, getApiCubeEngineerRoleLists, postApiWbEngineerExport, postApiCubeEngineerAccountDelete } from '@/api/organizational-structure'
  import PublicViewTable from '@/views/organizational-structure/organizational-structure-table'
  import vDialog from '@/views/queue-management/account/components/v-dialog'
  import { deepClone, uuid } from '@/utils'

  const ORGANIZATIONAL_STRUCTURE = 'ORGANIZATIONAL_STRUCTURE'

  export default {
    name: 'organizational-structure',
    components: { PublicViewTable, vDialog },
    data() {
      return {
        tableDataList: {
          data: [],
          current_page: 1,
          per_page: 20,
          total: 0
        },
        localTableData: [],
        myPagination: {
          current_page: 1,
          per_page: 20,
          total: 1
        },
        thatData: [],
        visible: false,
        left: 0,
        top: 0,
        hoverMenu: {},
        showMenus: [],
        selectInfo: {
          business_id: '',
          input: '',
          role_id: ''
        },
        defaultProps: {
          children: 'childs',
          label: 'name'
        },
        roleList: [],
        role: '',
        codeAll: [],
        searchText: '',
        createEditorInfo: {
          createEditor: false,
          title: '创建账户',
          code: ''
        }
      }
    },
    computed: {
      ...mapGetters([
        'buttonPermission',
        'engineerCode'
      ]),
      paging() {
        return {
          page: this.tableDataList.current_page,
          size: this.tableDataList.per_page
        }
      },
      thatDataComputed() {
        // const tmp = [{
        //   name: '全部',
        //   id: 0,
        //   childs: []
        // }]
        // tmp[0].childs= this.thatData
        // return tmp
        return Array.prototype.concat.apply({
          name: '全部',
          id: 0
        }, this.thatData)
      }
    },
    watch: {
      visible(value) {
        if (value) {
          document.body.addEventListener('click', this.closeMenu)
        } else {
          document.body.removeEventListener('click', this.closeMenu)
        }
      },
      hoverMenu: {
        handler({ edit }) {
          if (edit !== void 0) {
            if (edit) {
              document.body.addEventListener('click', this.closeMenuEdit)
            } else {
              document.body.removeEventListener('click', this.closeMenuEdit)
            }
          }
        },
        deep: true
      },
      selectInfo: {
        handler(data) {
          this.fetchDataTabel({ ...data, engineer_code: this.engineerCode })
        },
        deep: true
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      onBlurText() {
        if (!this.searchText) {
          this.onSearch()
        }
      },
      onSearch() {
        this.$set(this.selectInfo, 'input', this.searchText)
      },
      fetchData() {
        getApiWbStructureBusiness({ search: true }).then(response => {
          // 必须放在头部
          // 做了删除操作
          // 做了编辑操作
          // 可以做成自动选择临近业务
          const steamrollerData = this.steamroller(response.data)
          const tGetCurrentData = this.$refs.tree.getCurrentNode()
          let newCurrentData = null
          if (response.data.length && !!tGetCurrentData && this.hoverMenu.del) {
            const tGetCurrentNode = this.$refs.tree.getNode(tGetCurrentData)
            if (!!tGetCurrentNode && !!tGetCurrentNode.parent.parent) {
              const data = tGetCurrentNode.parent.data
              const ii = steamrollerData.find(dd => data.childs.some(({ id }) => dd === id))
              const tt = steamrollerData.find(dd => data.id === dd)
              if (steamrollerData.some(id => id === tGetCurrentData.id)) {
                newCurrentData = { ...tGetCurrentData }
              } else if (ii) {
                newCurrentData = data.childs.find(({ id }) => id === ii)
              } else if (tt) {
                newCurrentData = data
              }
            }
          }

          this.thatData = response.data
          // 取消 目标 对象
          this.hoverMenu = {}
          // 设置默认 选中 业务
          this.$nextTick(() => {
            const current = this.$refs.tree.getCurrentNode()
            if (this.thatData.length) {
              if (!current) {
                this.setCurrentKey(this.thatDataComputed[0])
              } else if (this.steamroller(this.thatData).some(id => id === current.id)) {
                this.setCurrentKey(current)
              } else {
                // 做了删除操作
                // 可以做成自动选择临近业务
                !newCurrentData ? this.setCurrentKey(this.thatDataComputed[0]) : this.setCurrentKey(newCurrentData)
              }
            } else {
              // 没有业务
              !current && this.setCurrentKey(null)
            }
          })
          return response
        }).catch(this.$message.error)

        getApiCubeEngineerRoleLists().then(res => {
          this.roleList = res.data
        }).catch(this.$message.error)
      },
      fetchDataTabel(data = this.selectInfo, paging = {}) {
        const query = {
          ...data,
          engineer_code: this.engineerCode,
          page: this.tableDataList.current_page,
          size: this.tableDataList.per_page,
          ...paging
        }
        return getApiWbEngineerList(query).then(response => {
          response.data = Array.isArray(response.data) ? {
            data: [],
            current_page: 1,
            per_page: 20,
            total: 0
          } : response.data
          this.tableDataList = response.data
          query.input && !response.data.total && this.$message.warning('未查询到结果')
          return response.data
        }).catch(err => {
          this.tableDataList.data = []
          this.$message.error(err)
        })
      },
      handleCurrentChange(page) {
        this.fetchDataTabel(undefined, { page })
      },
      handleSizeChange(size) {
        this.fetchDataTabel(undefined, { size, page: 1 })
      },
      tableSelect(rows) {
        this.codeAll = deepClone(rows)
      },
      openMenu(e, type, data) {
        if (!(data && data.id === this.hoverMenu.id && this.hoverMenu.edit) || data === void 0) {
          // 防止编辑时触发误触
          this.closeMenuEdit()
          // closeMenuEdit 一定要最上方
          const menuMinWidth = 105
          const offsetLeft = this.$el.getBoundingClientRect().left // container margin left
          const offsetWidth = this.$el.offsetWidth // container width
          const maxLeft = offsetWidth - menuMinWidth // left boundary
          const left = e.clientX - offsetLeft + 15 // 15: margin right

          if (left > maxLeft) {
            this.left = maxLeft
          } else {
            this.left = left
          }

          this.top = e.clientY - window.$('#organizational-structure').offset().top
          this.visible = true

          // 右键菜单显示类型
          if (type === 2) {
            this.hoverMenu = deepClone({ ...data, menuType: type, root: this.$refs.tree.getNode(data.id).parent.parent === null })
            // 设置 选中 业务
            this.setCurrentKey(data)
          } else {
            this.hoverMenu = { menuType: type, root: true }
          }
        }
        e.preventDefault()
        e.stopPropagation()
      },
      setCurrentKey(data) {
        // 设置 选中 业务
        this.$refs.tree.setCurrentKey(data.id)
        !!data && this.setCurrentTarget(data)
      },
      setCurrentTarget({ id }) {
        this.selectInfo = {
          ...this.selectInfo,
          business_id: id
        }
      },
      closeMenu(e) {
        this.visible = false
      },
      stopDefault(e) {
        e.preventDefault()
        e.stopPropagation()
        return false
      },
      menuEdit(e, data) {
        if (data && data.id !== 0 || data === void 0) {
          const parent = data ? this.$refs.tree.getNode(data.id).parent.parent : this.$refs.tree.getNode(this.hoverMenu.id).parent.parent
          this.hoverMenu = data ? deepClone({ ...data, edit: true, root: parent === null }) : { ...this.hoverMenu, edit: true, root: parent === null }
          this.$nextTick(() => {
            this.$refs[`menuText${this.hoverMenu.id}`].focus()
          })
          // 手动执行关闭菜单方法
          this.closeMenu()
          // @dblclick 会影响 @contextmenu 所以需要阻止默认事件
          e.preventDefault()
          e.stopPropagation()
          return false
        }
      },
      closeMenuEdit() {
        // 取消编辑 和 添加 or 添加失败 和 编辑失败
        if (this.hoverMenu.edit) {
          if (this.hoverMenu.new) {
            if (!this.hoverMenu.root) {
              const parent = this.$refs.tree.getNode(this.hoverMenu.id).parent
              if (parent !== null && parent.data.childs.length <= 1) {
                // 删除 假数据 下拉状态
                this.showMenus = this.showMenus.filter(item => item !== parent.data.id)
              }
            }
            this.$refs.tree.remove(this.hoverMenu.id)
          }
        }
        // 取消目标元素
        this.hoverMenu = {}
      },
      delEditMenu(e) {
        const { id, root } = this.hoverMenu
        this.$confirm('此操作将删除该业务，是否继续？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.hoverMenu.del = true
          // 后台不支持删除 带有 子业务的目录，所以目前可以不考虑同步 下拉 组
          delApiWbStructureBusiness(id).then(res => {
            const parent = this.$refs.tree.getNode(id).parent
            if (!root && parent.data.childs.length <= 1) {
              // 删除 假数据 下拉状态
              this.showMenus = this.showMenus.filter(item => item !== parent.data.id)
            }
            this.$message.success('已将此业务删除')
            return res
          }).then(res => {
            this.fetchData()
          }).catch(err => {
            this.$message.error(err)
            this.closeMenuEdit()
          })
        }).catch(() => {})
        this.closeMenu()
        // 阻止默认事件
        e.preventDefault()
        e.stopPropagation()
        return false
      },
      successEditMenu(e) {
        if (!this.hoverMenu.name) {
          this.closeMenuEdit()
        } else {
          if (this.hoverMenu.new) {
            const parent_id = this.hoverMenu.root ? 0 : this.$refs.tree.getNode(this.hoverMenu.id).parent.data.id
            postApiWbStructureBusiness({ name: this.hoverMenu.name, parent_id }).then(res => {
              this.fetchData()
              this.$message.success('创建业务成功！')
            }).then(this.filterShowMenus).catch(err => {
              this.$message.error(err)
            })
          } else {
            const parent_id = this.hoverMenu.root ? 0 : this.$refs.tree.getNode(this.hoverMenu.id).parent.data.id
            putApiWbStructureBusiness(this.hoverMenu.id, { name: this.hoverMenu.name, parent_id }).then(res => {
              this.fetchData()
              this.$message.success('业务名称修改成功')
            }).then(this.fetchData).catch(err => {
              this.$message.error(err)
            })
          }
        }
        // 阻止默认事件
        e.preventDefault()
        e.stopPropagation()
        return false
      },
      steamroller(arr) {
        const data = []
        const arrFn = item => {
          item.forEach(it => {
            data.push(it.id)
            Array.isArray(it.childs) && arrFn(it.childs)
          })
        }
        arrFn(arr)
        return data
      },
      filterShowMenus() {
        // 添加新的节点成功后 自动处理 展开项
        this.showMenus.filter(item => this.steamroller(this.thatData).some(t => item.id === t.id))
      },
      nodeExpand(data) {
        this.closeMenu()
        this.closeMenuEdit()
        !this.showMenus.some(item => item === data.id) && this.showMenus.push(data.id)
      },
      nodeCollapse(data) {
        this.closeMenu()
        this.closeMenuEdit()
        this.showMenus = this.showMenus.filter(item => item !== data.id)
      },
      addMenuRoot(e) {
        this.closeMenuEdit()
        // current-node-key
        const data = this.$refs.tree.getCurrentNode()
        if (data === null || !!data && data.id === 0) {
          // (data.id === 0 || data.new) && this.closeMenuEdit()
          // this.closeMenuEdit()
          // this.hoverMenu = { menuType: 1 }
          this.addMenu(e, 1, { menuType: 1 })
        } else {
          // 关闭上次添加
          // this.closeMenuEdit()
          // if (data.childs && data.childs.some(item => item.new)) return
          // this.hoverMenu = deepClone({ ...data, menuType: 2 })
          this.addMenu(e, 2, deepClone({ ...data, menuType: 2 }))
        }
        e.preventDefault()
        e.stopPropagation()
        return false
      },
      addMenu(e, type, data = this.hoverMenu) {
        const newChild = {
          id: uuid(ORGANIZATIONAL_STRUCTURE),
          name: '',
          edit: true,
          new: true
        }

        // type = 1 根节点 type = 2 子节点
        if (type === 2) {
          if (data.depth >= 3) {
            this.$message.error('业务至多只可添加到4级')
            return
          }
          const { id } = data
          // 此处代码顺序非常重要
          // 是否自动展开目录
          !this.showMenus.some(item => item === id) && this.showMenus.push(id)
          this.$nextTick(() => {
            this.hoverMenu = newChild
            this.$refs.tree.append(newChild, id)
            this.$nextTick(() => {
              this.$refs[`menuText${newChild.id}`].focus()
            })
          })
        } else {
          newChild.root = true
          if (this.thatData.length) {
            // 有数据
            const targetDatat = this.thatData[this.thatData.length - 1]
            this.hoverMenu = newChild
            this.$refs.tree.insertAfter(newChild, targetDatat.id)
            this.$nextTick(() => {
              this.$refs[`menuText${newChild.id}`].focus()
            })
          } else {
            // 无数据
            this.thatData = [newChild]
            this.hoverMenu = newChild
            this.$nextTick(() => {
              this.$nextTick(() => {
                this.$refs[`menuText${newChild.id}`].focus()
              })
            })
          }
        }

        this.closeMenu()
        e.preventDefault()
        e.stopPropagation()
        return false
      },
      handleDownloadClick() {
        if (!this.codeAll.length) {
          this.$message.error('导出失败，请选择要导出的条目')
          return
        }
        postApiWbEngineerExport({ engineerCode: this.codeAll.map(item => item.code) }).then(res => {
          this.$message.success('导出成功')
          window.location.href = res.data.download
        }).catch(this.$message.error)
      },
      // nameTypeNumber(arr) {
      //   //角色分组
      //   arr = deepClone(arr)
      //   const map = {}
      //   const dest = []
      //   for (let i = 0; i < arr.length; i++) {
      //     const ai = arr[i]
      //     if (!map[ai.roles]) {
      //       dest.push({
      //         // id: ai.code,
      //         roles: ai.roles,
      //         data: [ai]
      //       })
      //       map[ai.roles] = ai
      //     } else {
      //       for (let j = 0; j < dest.length; j++) {
      //         const dj = dest[j]
      //         if (dj.roles === ai.roles) {
      //           dj.data.push(ai)
      //           break
      //         }
      //       }
      //     }
      //   }
      //   return dest
      // },
      allDet() {
        if (!this.codeAll.length) {
          this.$message.error('批量删除失败，请选择要删除的条目')
          return
        }
        this.$confirm('此操作将永久删除这些账号, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          postApiCubeEngineerAccountDelete({ codes: this.codeAll.map(item => item.code) }).then(() => {
            this.$message.success('批量删除成功')
            this.fetchDataTabel()
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      det({ code, name }) {
        this.$confirm(`此操作将删除 ${name} 员工且无法撤销，是否继续？`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          postApiCubeEngineerAccountDelete({ codes: [code] }).then(() => {
            this.$message.success(`已删除 ${name} 员工`)
            this.fetchDataTabel()
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      closeDialog(val) {
        if (val) {
          setTimeout(this.fetchData, 1000)
        }
        this.createEditorInfo.createEditor = false
      },
      edit({ code }) {
        this.createEditorInfo = {
          createEditor: true,
          title: '编辑账户',
          code
        }
      },
      add() {
        this.createEditorInfo = {
          createEditor: true,
          title: '创建账户',
          code: ''
        }
      }
    }
  }
</script>

<style>
  .custom-tree-node {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 14px;
    padding-right: 8px;
  }
</style>

<style lang="scss" scoped>
.contextmenu {
  width: 106px;
  margin: 0;
  background: #fff;
  z-index: 100;
  position: absolute;
  list-style-type: none;
  padding: 5px 0;
  border-radius: 4px;
  font-size: 12px;
  font-weight: 400;
  color: #333;
  box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, .3);
  li {
    margin: 0;
    padding: 7px 16px;
    cursor: pointer;
    &:hover {
      background: #eee;
    }
  }
}
.menu-text {
  // border-radius: 4px;
  // border: 1px solid #C0C4CC;
  /deep/ .el-input__inner {
    padding: 0 0px 0px 10px;
    height: 22px;
    line-height: 22px;
  }
  .talk {
    position: absolute;
    top: 0;
    right: 0;
    height: 22px;
    .talk-icon {
      font-size: 14px;
      line-height: 14px;
      color: #C0C4CC;
      cursor: pointer;
      border: 1px solid #C0C4CC;
      border-radius: 50%;
      padding: 1px;
      opacity: 0;
      background: #fff;
      transition: all 200ms;
    }
  }
  &:hover{
    /deep/ .el-input__inner {
      padding: 0 22px 0px 10px;
    }
    .talk {
      .talk-icon {
        opacity: 1;
        color: #909399;
        border: 1px solid #C0C4CC;
      }
    }
  }
}
// element ui
/deep/ .el-card__header {
  padding: 3px 20px !important;
  border-bottom: none;
  background:rgba(240,244,251,1);
  /*.el-button--small.is-circle {*/
  /*  padding: 2px !important;*/
  /*  .el-icon-plus {*/
  /*    font-weight: bold;*/
  /*  }*/
  /*}*/
  /*.el-button {*/
  /*  border-width: 2px !important;*/
  /*}*/
}
/deep/ .el-tree--highlight-current .el-tree-node.is-current>.el-tree-node__content {
  background:rgba(245,247,250,1) !important;
}
/deep/ .el-tree-node__content:hover {
  background:rgba(245,247,250,1) !important;
}
</style>

