<template>
  <el-card>
    <slot />
    <el-table
      ref="my-table"
      :data="mydata.data"
      style="width: 100%"
      @select-all="select"
      @select="select"
    >
      <el-table-column
        type="selection"
        width="55"
      />
      <el-table-column
        type="index"
        label="序号"
        :index="indexMethod"
      />
      <el-table-column
        label="工号"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.code }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="姓名"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="所属业务"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.businesses }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="角色"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.roles }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="邮箱"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.email }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="手机"
        width="width: 100%"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.phone }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="text"
            :disabled="!buttonPermission('accountEdit')"
            @click="handleEdit(scope.$index, scope.row)"
          >编辑
          </el-button>
          <el-button
            type="text"
            :disabled="!buttonPermission('accountDelete')"
            @click="handleDelete(scope.$index, scope.row)"
          >删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      :current-page="mydata.current_page"
      :page-size="mydata.per_page"
      :page-sizes="[10, 15, 20, 25]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="mydata.total"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </el-card>
</template>

<script>
  import { deepClone } from '@/utils'
  import { mapGetters } from 'vuex'
  export default {
    name: 'organizational-structure-table',
    props: {
      data: {
        type: Object,
        required: true
      },
      selectAll: {
        type: Boolean,
        required: true
      }
    },
    data() {
      return {
        mydata: this.data
      }
    },
    watch: {
      data: {
        handler(data) {
          this.mydata = deepClone(data)
          this.selectAll && this.$nextTick(() => {
            this.$refs['my-table'].toggleAllSelection()
          })
        },
        deep: true
      }
    },
    computed: {
      ...mapGetters([
        'buttonPermission'
      ])
    },
    methods: {
      indexMethod(index) {
        return index + 1
      },
      handleEdit(index, row) {
        this.$emit('edit', row)
      },
      handleDelete(index, row) {
        this.$emit('delete', row)
      },
      currentChange(val) {
        this.$emit('change', val)
      },
      handleSizeChange(val) {
        this.$emit('size-change', val)
      },
      select(rows) {
        this.$emit('select', rows)
      }
    }
  }
</script>
