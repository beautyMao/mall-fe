<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span class="title">问题分类管理</span>
        <a href="javascript:;" @click="openAll">
          <span class="header-btn">
            <svg-icon icon-class="open-all" />  全部展开</span>
        </a>
        <a href="javascript:;" @click="packAll">
          <span class="header-btn">
            <svg-icon icon-class="pack-all" />  全部收起</span>
        </a>
      </div>
      <div ref="contextMenuTarget" class="body">
        <el-tree
          ref="tree"
          :data="data"
          default-expand-all
          node-key="id"
          :props="{ label: 'name' }"
          draggable
          :allow-drop="allowDrop"
          :allow-drag="allowDrag"
          :expand-on-click-node="false"
          :default-expanded-keys="expandList"
          @node-drag-start="handleDragStart"
          @node-drop="handleDrop"
        >
          <span slot-scope="{ node, data }" class="custom-tree-node" :class="{ 'top-title': node.level === 1 }">
            <span :class="{ 'top-title-text': node.level === 1 }">{{ node.label }}</span>
            <span>
              <el-button
                type="text"
                size="mini"
                @click="() => append(data)"
              >
                编辑
              </el-button>
              <el-button
                type="text"
                size="mini"
                class="delete"
                style="margin-right: 15px"
                @click="() => remove(node, data)"
              >
                删除
              </el-button>
            </span>
          </span>
        </el-tree>
      </div>
    </el-card>

    <add-problem :select-data="data" @addProblem="addProblem" />

    <edit-dialog
      :visible.sync="dialogFormVisible"
      :select-data="data"
      :select-node.sync="selectNode"
      @close="dialogFormVisible = false"
      @getDataList="getDataList"
      @addProblem="addProblem"
    />

  </div>
</template>

<script type="text/jsx">
  import { problemRestApi, putMoveNodeApi } from '@/api/problems'
  import addProblem from './add-problem'
  import editDialog from './edit-dialog'
  // import { cancelMove } from '@/utils/operate-tree'

  // eslint-disable-next-line no-unused-vars
  const convertTreeData = function(data) {
    return data.map(item => {
      item.label = item.name
      if (item.children.length) {
        item.children = convertTreeData(item.children)
      } else {
        delete item.children
      }
      return item
    })
  }

  // 计算节点的最大深度
  // eslint-disable-next-line no-unused-vars
  const computeMaxDeep = function(data, deep = 1) {
    if (!data.children.length) {
      return 1
    }
    return data.children.map(item => computeMaxDeep(item, deep)).sort().reverse()[0] + deep
  }

  export default {
    name: 'problems-management',
    components: { addProblem, editDialog },
    data() {
      return {
        data: [],
        expandList: [],
        dataBeforeMove: '',
        form: {
          name: '',
          pid: []
        },
        draggingNodeLevel: 1,
        dropNodeLevel: 1,
        deepestDraggingNodeLevel: 1,
        deepestDropNodeLevel: 1,
        selectNode: {},
        dialogFormVisible: false,
        formatData: [],
        contextMenuVisible: false,
        contextMenuTarget: null
      }
    },
    mounted() {
      this.getDataList()
    },
    methods: {
      getDataList() {
        problemRestApi.list().then(response => {
          this.data = convertTreeData(response.data)
          this.data = response.data
        })
      },
      handleDragStart(node, ev) {
        this.dataBeforeMove = node
        this.formatData = []
        this.getTargetNodeId(this.data)
      },
      addProblem(val) {
        if (val.parent_id === null) {
          this.data.push(val)
        } else {
          this.getNodeDataById(this.data, val)
        }
        // this.getDataList()
      },
      cancelLastMove(data, draggingNode, dropNode) {
        setTimeout(() => {
          this.getNodeDataById(data, draggingNode.data)
        }, 0)

        const parent = dropNode.parent
        const children = parent.data.children || parent.data
        const index = children.findIndex(d => d.id === draggingNode.data.id)
        children.splice(index, 1)
        this.getDataList()
      },
      getNodeDataById(data, node) { // 查询id节点，并将数据压入
        return data.map(item => {
          if (item.id === node.parent_id) {
            if (item.children) {
              this.$nextTick(() => {
                item.children.push(node)
              })
            } else {
              this.$nextTick(() => {
                this.$set(item, 'children', []) // 同步刷新
                item.children.push(node)
              })
            }
            return
          }
          if (item.children) {
            this.getNodeDataById(item.children, node)
          }
        })
      },
      handleDrop(draggingNode, dropNode, dropType, ev) {
        if (dropType === 'before') { // 放置的节点在目标节点前
          const isTopNode = dropNode.level === 1 // 判断是否移动到最顶层
          console.log('是否移动到最顶部？', isTopNode)
          if (isTopNode) { // 如果在最顶部
            console.log(dropNode.data.label)
            for (let i = 0; i < this.data.length; i++) {
              if (this.data[i].id === dropNode.data.id) {
                console.log(i)
                if (i > 1) {
                  const parm = {
                    parent_id: 0,
                    prev_id: this.data[i - 1].id
                  }
                  putMoveNodeApi(draggingNode.data.id, parm).then(res => {

                  }).catch(err => {
                    this.$message({
                      type: 'warning',
                      message: err
                    })
                    this.cancelLastMove(this.data, draggingNode, dropNode)
                  })
                } else {
                  const parm = {
                    parent_id: 0,
                    prev_id: 0
                  }
                  putMoveNodeApi(draggingNode.data.id, parm).then(res => {

                  }).catch(err => {
                    this.$message({
                      type: 'warning',
                      message: err
                    })
                    this.cancelLastMove(this.data, draggingNode, dropNode)
                  })
                }
              }
            }
          } else {
            for (let i = 0, _sizei = this.formatData.length; i < _sizei; i++) {
              const obj = this.formatData[i]
              if (obj.id === dropNode.data.id) { // 查找移动的节点的ID
                if (i) {
                  if (this.formatData[i - 1].parent_id === dropNode.data.parent_id) {
                    console.log('在当前目录不是第一个元素')
                    const parm = {
                      parent_id: dropNode.data.parent_id,
                      prev_id: this.formatData[i - 1].id
                    }
                    putMoveNodeApi(draggingNode.data.id, parm).then(res => {

                    }).catch(err => {
                      this.$message({
                        type: 'warning',
                        message: err
                      })
                      this.cancelLastMove(this.data, draggingNode, dropNode)
                    })
                  } else {
                    console.log('在当前目录是第一个元素')
                    const parm = {
                      parent_id: this.formatData[i - 1].id,
                      prev_id: 0
                    }
                    putMoveNodeApi(draggingNode.data.id, parm).then(res => {

                    }).catch(err => {
                      this.$message({
                        type: 'warning',
                        message: err
                      })
                      this.cancelLastMove(this.data, draggingNode, dropNode)
                    })
                  }
                }
              }
            }
          }
        } else if (dropType === 'after') { // 放置的节点在目标节点后
          const isTopNode = dropNode.level === 1 // 判断是否移动到最顶层
          console.log('是否移动到最顶部？', isTopNode)
          if (isTopNode) { // 如果在最顶部
            const parm = {
              parent_id: 0,
              prev_id: dropNode.data.id
            }
            putMoveNodeApi(draggingNode.data.id, parm).then(res => {

            }).catch(err => {
              this.$message({
                type: 'warning',
                message: err
              })
              this.cancelLastMove
            })
          } else {
            const parm = {
              parent_id: dropNode.data.parent_id,
              prev_id: dropNode.data.id
            }
            putMoveNodeApi(draggingNode.data.id, parm).then(res => {

            }).catch(err => {
              this.$message({
                type: 'warning',
                message: err
              })
              this.cancelLastMove
            })
          }
        } else if (dropType === 'inner') {
          const parm = {
            parent_id: dropNode.data.id,
            prev_id: 0
          }
          putMoveNodeApi(draggingNode.data.id, parm).then(res => {

          }).catch(err => {
            this.$message({
              type: 'warning',
              message: err
            })
            this.cancelLastMove
          })
        }
        this.$forceUpdate()
      },
      allowDrop(draggingNode, dropNode, type) {
        this.draggingNodeLevel = 1
        this.dropNodeLevel = 1
        this.deepestDraggingNodeLevel = 1
        this.deepestDropNodeLevel = 1
        console.log(draggingNode)
        if (draggingNode.data.children && draggingNode.data.children.length) {
          this.getDragChildrenLevel(draggingNode.data.children, 2)
        } else {
          this.deepestDraggingNodeLevel = 1
        }
        console.log('dropNode.level', dropNode.level)
        console.log('this.deepestDraggingNodeLevel', this.deepestDraggingNodeLevel)
        if ((dropNode.level + this.deepestDraggingNodeLevel) > 4) {
          if (type === 'inner') {
            return false
          } else {
            return true
          }
        } else {
          return true
        }
      },
      getDragChildrenLevel(data, level) { // 将起始层级数传入，由于初始化的时候传入的是children，所以初始化为 2
        let dragLevel = level // 定义一个局部变量，在当前作用域下计数
        data.map(item => { // 遍历元素，map会将每个元素会形成一个新的作用域
          if (item.children && item.children.length) {
            dragLevel = dragLevel + 1 // 进入后由于有下一层级，所以肯定+1
            if (dragLevel > this.deepestDraggingNodeLevel) {
              this.deepestDraggingNodeLevel = dragLevel
            }
            this.getDragChildrenLevel(item.children, dragLevel) // 将新的children传入，同时将当前作用域下的计数传入
          } else { // 如果只有两级的话，children没有值了，就直接赋值为2
            this.deepestDraggingNodeLevel = dragLevel
          }
        })
      },
      allowDrag() {
        return true
      },
      getTargetNodeId(data, dropNode) {
        return data.map(item => {
          this.formatData.push(item)
          if (item.children && item.children.length) {
            item.children = this.getTargetNodeId(item.children, dropNode)
          }
          return item
        })
      },
      append(data, parentNode) {
        this.$nextTick(() => {
          this.dialogFormVisible = true
          this.selectNode = data
        })
      },
      remove(node, data) {
        this.$confirm(`是否删除` + data.name + `？若该节点下包含子节点，则将被全部删除`, '删除问题分类', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          console.log(data)
          problemRestApi.delete(data.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            const parent = node.parent
            const children = parent.data.children || parent.data
            const index = children.findIndex(d => d.id === data.id)
            children.splice(index, 1)
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      openAll() {
        for (let i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
          this.$refs.tree.store._getAllNodes()[i].expanded = true
        }
      },
      packAll() {
        for (let i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
          this.$refs.tree.store._getAllNodes()[i].expanded = false
        }
      }
    }
  }
</script>
<style lang="scss" type="text/scss" scoped>
  /*@import "../../styles/context-menu";*/
  .delete {
    color: #F37261 !important;
  }
  .delete:hover {
    color: #F37261 !important;
  }
  .app-container {
    display: flex;
    justify-content: space-between;
    padding-right: 10px;
    .box-card {
      width: 66%;
      padding-left: 20px;
      padding-right: 5px;
      height: calc(100vh - 140px);
      /deep/ .el-card__body {
        padding-right: 0 !important;
        .body {
          overflow-y: scroll;
          height: calc(100vh - 220px);
          /deep/ .el-tree>.el-tree-node {
            border-bottom: 1px solid #EBEEF5;
            padding-bottom: 5px;
            padding-top: 5px;
            margin-right: 20px;
          }
          /deep/ .el-tree {
            /deep/ .el-tree-node {
              /deep/ .el-tree-node__content{
              }
              .top-title {
                color: #303133;
                .top-title-text {
                  font-weight: 700 !important;
                }
              }
            }
          }
        }
      }
      .clearfix{
        .title {
          font-size: 20px;
          color: #222222;
          font-weight: bolder;
        }
        .header-btn {
          font-size: 14px;
          color: #1890FF;
          font-weight: bolder;
          margin-left: 20px;
        }
      }
    }
  }
  .line {
    width: 100%;
    height: 1px;
    border: 1px solid #9b59b6;
  }
  .custom-tree-node {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 14px;
    padding-right: 8px;
    .edit-icon {
      font-size: 16px;
    }
  }
</style>

