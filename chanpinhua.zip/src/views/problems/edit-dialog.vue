<template>
  <div class="my-dialog">
    <!-- Form -->
    <el-dialog
      ref="my-dialog"
      custom-class="el-dialog-body-center"
      width="440px"
      :visible.sync="visible"
      :before-close="() => void $emit('close')"
      :close-on-click-modal="false"
    >
      <div slot="title" class="dialog-footer el-dialog-body-center">
        编辑问题分类
      </div>
      <el-form ref="form" :model="form" label-position="left" label-width="80px" size="medium">
        <el-form-item label="问题级别" required>
          <el-cascader
            v-model="form.pid"
            :props="{ checkStrictly: true, value: 'id', label: 'name' }"
            placeholder="请选择父级问题类别 "
            filterable
            :show-all-levels="false"
            :options="problemData"
            @focus="getData"
          />
        </el-form-item>
        <el-form-item label="问题名称" required>
          <el-input
            v-model.trim="form.name"
            auto-complete="off"
            placeholder="请输入问题名称，最多20个字符"
            maxlength="20"
          />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="$emit('close')">取 消</el-button>
        <el-button type="primary" @click="submitData">提 交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { problemRestApi } from '@/api/problems'
  export default {
    name: 'edit-dialog',
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      selectData: {
        type: Array
      },
      selectNode: {
        type: Object
      }
    },
    data() {
      return {
        problemData: [{
          id: 0,
          label: '问题一级分类',
          name: '问题一级分类',
          children: []
        }],
        form: {
          name: '',
          pid: []
        },
        choosedNode: {}
      }
    },
    watch: {
      'selectNode': function() {
        if (this.selectNode.parent_id === null) {
          this.selectNode.parent_id = 0
        }
        this.form.pid = []
        this.form.pid.unshift(this.selectNode.parent_id)
        this.form.name = this.selectNode.name
        this.choosedNode = this.selectNode
        this.getData()
        this.checkChoose(this.choosedNode, true)
      },
      'visible': function() {
        if (this.selectNode.parent_id === null) {
          this.selectNode.parent_id = 0
        }
        this.form.pid = []
        this.form.pid.unshift(this.selectNode.parent_id)
        this.form.customer_label_name = this.selectNode.customer_label_name
        this.choosedNode = this.selectNode
        this.getData()
        if (!this.visible) {
          this.checkChoose(this.choosedNode, false)
        }
      }
    },
    methods: {
      checkChoose(selectNode, flag) {
        console.log(selectNode)
        if (flag) {
          selectNode.disabled = flag
          this.$set(selectNode, 'disabled', true)
        } else {
          this.$set(selectNode, 'disabled', false)
          delete selectNode.disabled
        }

        if (selectNode.children) {
          selectNode.children.forEach(item => {
            this.checkChoose(item, flag)
          })
        }
      },
      // formatData(data) {
      //   data.disabled = false
      //   if (data.children) {
      //     data.children.forEach(item => {
      //       this.checkChoose(item)
      //     })
      //   }
      // },
      getData() {
        this.problemData[0].children = this.selectData
        // this.formatData(this.problemData)
      },
      submitData() {
        this.$refs.form.validate(valid => {
          if (valid) {
            if (this.form.pid && this.form.pid.length) {
              // 以下为二级节点，父ID为null
              if (this.form.pid.length === 1 && this.form.pid[0] === null) {
                const parm = {
                  parent_id: 0,
                  name: this.form.name
                }
                problemRestApi.update(this.choosedNode.id, parm).then(res => {
                  if (res.statusCode === 200) {
                    this.$message({
                      type: 'success',
                      message: '修改成功!'
                    })
                    this.$emit('close')
                    this.$emit('getDataList')
                  }
                }).catch(err => {
                  if (err.errorOrRes === '问题分类重复，请重新填写') {
                    this.isDuplicate = true
                  } else {
                    this.$message({
                      message: err,
                      type: 'warning'
                    })
                  }
                })
              } else {
                const index = this.form.pid.length - 1
                const parm = {
                  parent_id: this.form.pid[index],
                  name: this.form.name
                }
                problemRestApi.update(this.choosedNode.id, parm).then(res => {
                  if (res.statusCode === 200) {
                    this.$message({
                      type: 'success',
                      message: '修改成功!'
                    })
                    this.$emit('close')
                    this.$emit('getDataList')
                  }
                }).catch(err => {
                  if (err.errorOrRes === '问题分类重复，请重新填写') {
                    this.isDuplicate = true
                  } else {
                    this.$message({
                      message: err,
                      type: 'warning'
                    })
                  }
                })
              }
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>
