<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span class="title">客服标签管理</span>
        <a href="javascript:;" @click="openAll">
          <span class="header-btn">
            <svg-icon icon-class="open-all" />  全部展开</span>
        </a>
        <a href="javascript:;" @click="packAll">
          <span class="header-btn">
            <svg-icon icon-class="pack-all" />  全部收起</span>
        </a>

        <el-input
          v-model.trim="searchText"
          placeholder="请输入标签名称"
          :style="{width: '300px'}"
          style="float: right"
          @keyup.enter.native="onSearch(searchText)"
        >
          <el-button slot="append" icon="el-icon-search" @click="onSearch(searchText)" />
        </el-input>
        <div class="table-header">
          <ul>
            <li>节点名称</li>
            <li>
              <span style="margin-right: 82px">更新账号</span>
              <span style="margin-right: 75px">最新时间</span>
              <span style="margin-right: 65px">操作</span>
            </li>
          </ul>
        </div>
      </div>
      <div ref="contextMenuTarget" class="body">
        <el-tree
          ref="tree"
          :empty-text="'未检索到相关结果'"
          :data="data"
          default-expand-all
          node-key="id"
          :props="{ label: 'servicer_label_name' }"
          draggable
          :allow-drop="allowDrop"
          :allow-drag="allowDrag"
          :expand-on-click-node="false"
          :filter-node-method="filterNode"
          @node-drag-start="handleDragStart"
          @node-drop="handleDrop"
        >
          <span slot-scope="{ node, data }" class="custom-tree-node" :class="{ 'top-title': node.level === 1 }">
            <span :class="{ 'top-title-text': node.level === 1 }">{{ node.label }}</span>
            <div class="user-info">
              <span style="line-height: 32px; display: flex;">
                <el-tooltip :content="data.operator_name" placement="bottom" effect="light">
                  <span class="editor-name">{{ data.operator_name }}</span>
                </el-tooltip>
                <span>/ {{ data.operator_code }}</span>
              </span>
              <!--<span style="line-height: 28px">{{ data.operator_name + ' / ' + data.operator_code }}</span>-->
              <div>
                <span style="padding-right: 30px">{{ data.updated_at.substr(0, data.updated_at.length - 3) }}</span>
                <el-button
                  type="text"
                  size="mini"
                  @click="() => append(data)"
                >
                  编辑
                </el-button>
                <el-button
                  type="text"
                  size="mini"
                  class="delete"
                  style="margin-right: 15px"
                  @click="() => remove(node, data)"
                >
                  删除
                </el-button>
              </div>
            </div>
          </span>
        </el-tree>
      </div>
    </el-card>

    <add-problem :select-data="data" :is-empty-data="isEmptyData" @addProblem="addProblem" />

    <edit-dialog
      :visible.sync="dialogFormVisible"
      :select-data="data"
      :select-node.sync="selectNode"
      @close="dialogFormVisible = false"
      @getDataList="getDataList"
      @addProblem="addProblem"
    />

  </div>
</template>

<script type="text/jsx">
  import { serviceTagRestApi, putServiceMoveNodeApi } from '@/api/tag-configuration'
  import addProblem from './components/add-problem'
  import editDialog from './components/edit-dialog'

  // eslint-disable-next-line no-unused-vars
  const convertTreeData = function(data) {
    return data.map(item => {
      item.label = item.servicer_label_name
      if (item.children.length) {
        item.children = convertTreeData(item.children)
      } else {
        delete item.children
      }
      return item
    })
  }

  // 计算节点的最大深度
  // eslint-disable-next-line no-unused-vars
  const computeMaxDeep = function(data, deep = 1) {
    if (!data.children.length) {
      return 1
    }
    return data.children.map(item => computeMaxDeep(item, deep)).sort().reverse()[0] + deep
  }

  export default {
    name: 'engineer-tag',
    components: { addProblem, editDialog },
    data() {
      return {
        data: [],
        form: {
          name: '',
          pid: []
        },
        searchText: '',
        draggingNodeLevel: 1,
        dropNodeLevel: 1,
        deepestDraggingNodeLevel: 1,
        deepestDropNodeLevel: 1,
        selectNode: {},
        dialogFormVisible: false,
        formatData: [],
        contextMenuVisible: false,
        contextMenuTarget: null,
        isEmptyData: true
      }
    },
    watch: {
      searchText(val) {
        this.$refs.tree.filter(val)
      }
    },
    mounted() {
      this.getDataList()
    },
    methods: {
      getDataList() {
        serviceTagRestApi.list().then(response => {
          this.data = convertTreeData(response.data)
          this.isEmptyData = !response.data.length
          this.data = response.data
        })
      },
      handleDragStart(node, ev) {
        this.formatData = []
        this.getTargetNodeId(this.data)
      },
      filterNode(value, data) {
        if (!value) return true
        return data.label.indexOf(value) !== -1
      },
      addProblem(val) {
        console.log(val)
        if (val.parent_id === null) {
          this.data.push(val)
        } else {
          this.getNodeDataById(this.data, val)
        }
        // this.getDataList()
      },
      getNodeDataById(data, node) { // 查询id节点，并将数据压入
        return data.map(item => {
          if (item.id === node.parent_id) {
            if (item.children) {
              item.children.push(node)
            } else {
              this.$nextTick(() => {
                this.$set(item, 'children', []) // 同步刷新
                item.children.push(node)
              })
            }
            return
          }
          if (item.children) {
            this.getNodeDataById(item.children, node)
          }
        })
      },
      handleDrop(draggingNode, dropNode, dropType, ev) {
        if (dropType === 'before') { // 放置的节点在目标节点前
          const isTopNode = dropNode.level === 1 // 判断是否移动到最顶层
          console.log('是否移动到最顶部？', isTopNode)
          if (isTopNode) { // 如果在最顶部
            console.log(dropNode.data.label)
            for (let i = 0; i < this.data.length; i++) {
              if (this.data[i].id === dropNode.data.id) {
                console.log(i)
                if (i > 1) {
                  const parm = {
                    parent_id: 0,
                    prev_id: this.data[i - 1].id
                  }
                  putServiceMoveNodeApi(draggingNode.data.id, parm).then(res => {

                  }).catch(err => {
                    this.$message({
                      type: 'warning',
                      message: err
                    })
                    this.getDataList()
                  })
                } else {
                  const parm = {
                    parent_id: 0,
                    prev_id: 0
                  }
                  putServiceMoveNodeApi(draggingNode.data.id, parm).then(res => {

                  }).catch(err => {
                    this.$message({
                      type: 'warning',
                      message: err
                    })
                    this.getDataList()
                  })
                }
              }
            }
          } else {
            for (let i = 0, _sizei = this.formatData.length; i < _sizei; i++) {
              const obj = this.formatData[i]
              if (obj.id === dropNode.data.id) { // 查找移动的节点的ID
                if (i) {
                  if (this.formatData[i - 1].parent_id === dropNode.data.parent_id) {
                    console.log('在当前目录不是第一个元素')
                    const parm = {
                      parent_id: dropNode.data.parent_id,
                      prev_id: this.formatData[i - 1].id
                    }
                    putServiceMoveNodeApi(draggingNode.data.id, parm).then(res => {

                    }).catch(err => {
                      this.$message({
                        type: 'warning',
                        message: err
                      })
                      this.getDataList()
                    })
                  } else {
                    console.log('在当前目录是第一个元素')
                    const parm = {
                      parent_id: this.formatData[i - 1].id,
                      prev_id: 0
                    }
                    putServiceMoveNodeApi(draggingNode.data.id, parm).then(res => {

                    }).catch(err => {
                      this.$message({
                        type: 'warning',
                        message: err
                      })
                      this.getDataList()
                    })
                  }
                }
              }
            }
          }
        } else if (dropType === 'after') { // 放置的节点在目标节点后
          const isTopNode = dropNode.level === 1 // 判断是否移动到最顶层
          console.log('是否移动到最顶部？', isTopNode)
          if (isTopNode) { // 如果在最顶部
            const parm = {
              parent_id: 0,
              prev_id: dropNode.data.id
            }
            putServiceMoveNodeApi(draggingNode.data.id, parm).then(res => {

            }).catch(err => {
              this.$message({
                type: 'warning',
                message: err
              })
              this.getDataList()
            })
          } else {
            const parm = {
              parent_id: dropNode.data.parent_id,
              prev_id: dropNode.data.id
            }
            putServiceMoveNodeApi(draggingNode.data.id, parm).then(res => {

            }).catch(err => {
              this.$message({
                type: 'warning',
                message: err
              })
              this.getDataList()
            })
          }
        } else if (dropType === 'inner') {
          const parm = {
            parent_id: dropNode.data.id,
            prev_id: 0
          }
          putServiceMoveNodeApi(draggingNode.data.id, parm).then(res => {

          }).catch(err => {
            this.$message({
              type: 'warning',
              message: err
            })
            this.getDataList()
          })
        }
      },
      allowDrop(draggingNode, dropNode, type) {
        this.draggingNodeLevel = 1
        this.dropNodeLevel = 1
        this.deepestDraggingNodeLevel = 1
        this.deepestDropNodeLevel = 1
        console.log(draggingNode)
        if (draggingNode.data.children && draggingNode.data.children.length) {
          this.getDragChildrenLevel(draggingNode.data.children, 2)
        } else {
          this.deepestDraggingNodeLevel = 1
        }
        console.log('dropNode.level', dropNode.level)
        console.log('this.deepestDraggingNodeLevel', this.deepestDraggingNodeLevel)
        if ((dropNode.level + this.deepestDraggingNodeLevel) > 4) {
          if (type === 'inner') {
            return false
          } else {
            return true
          }
        } else {
          return true
        }
      },
      getDragChildrenLevel(data, level) { // 将起始层级数传入，由于初始化的时候传入的是children，所以初始化为 2
        let dragLevel = level // 定义一个局部变量，在当前作用域下计数
        data.map(item => { // 遍历元素，map会将每个元素会形成一个新的作用域
          if (item.children && item.children.length) {
            dragLevel = dragLevel + 1 // 进入后由于有下一层级，所以肯定+1
            if (dragLevel > this.deepestDraggingNodeLevel) {
              this.deepestDraggingNodeLevel = dragLevel
            }
            this.getDragChildrenLevel(item.children, dragLevel) // 将新的children传入，同时将当前作用域下的计数传入
          } else { // 如果只有两级的话，children没有值了，就直接赋值为2
            this.deepestDraggingNodeLevel = dragLevel
          }
        })
      },
      allowDrag() {
        return true
      },
      getTargetNodeId(data, dropNode) {
        return data.map(item => {
          this.formatData.push(item)
          if (item.children && item.children.length) {
            item.children = this.getTargetNodeId(item.children, dropNode)
          }
          return item
        })
      },
      append(data, parentNode) {
        this.$nextTick(() => {
          this.dialogFormVisible = true
          this.selectNode = data
        })
      },
      remove(node, data) {
        console.log(data)
        this.$confirm(`是否删除` + data.servicer_label_name + `？若该节点下包含子节点，则将被全部删除`, '删除客服标签', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          console.log(data)
          serviceTagRestApi.delete(data.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            const parent = node.parent
            const children = parent.data.children || parent.data
            const index = children.findIndex(d => d.id === data.id)
            children.splice(index, 1)
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      openAll() {
        for (let i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
          this.$refs.tree.store._getAllNodes()[i].expanded = true
        }
      },
      packAll() {
        for (let i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
          this.$refs.tree.store._getAllNodes()[i].expanded = false
        }
      },
      onSearch() {
        console.log('search')
      }
    }
  }
</script>
<style lang="scss" type="text/scss" scoped>
  /*@import "../../styles/context-menu";*/
  .delete {
    color: #F37261 !important;
  }
  .delete:hover {
    color: #F37261 !important;
  }
  .app-container {
    display: flex;
    justify-content: space-between;
    padding-right: 10px;
    .box-card {
      width: 66%;
      padding-left: 20px;
      padding-right: 5px;
      height: calc(100vh - 140px);
      /deep/ .el-card__header {
        padding-bottom: 0 !important;
      }
      /deep/ .el-card__body {
        padding-top: 10px;
        padding-right: 0 !important;
        overflow-y: hidden;
        .body {
          overflow-y: scroll;
          height: calc(100vh - 260px);
          /deep/ .el-tree>.el-tree-node {
            border-bottom: 1px solid #EBEEF5;
            padding-bottom: 5px;
            padding-top: 5px;
            margin-right: 20px;
          }
          /deep/ .el-tree {
            /deep/ .el-tree-node {
              /deep/ .el-tree-node__content{
              }
              .top-title {
                color: #303133;
                .top-title-text {
                  font-weight: 700 !important;
                }
              }
            }
          }
        }
      }
      .clearfix{
        .title {
          font-size: 20px;
          color: #222222;
          font-weight: bolder;
        }
        .header-btn {
          font-size: 14px;
          color: #1890FF;
          font-weight: bolder;
          margin-left: 20px;
        }
      }
      .table-header {
        height: 30px;
        width: 100%;
        margin-top: 30px;
        font-weight: 500 !important;
        ul {
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 30px;
          width: 100%;
          li {
            font-size: 16px;
            font-weight: 700 !important;
            line-height: 16px;
          }
        }
       }

    }
  }
  .custom-tree-node {
    .label-text {
      display: block;
      max-width: 280px;
      overflow: hidden;
      text-overflow: ellipsis;
      -o-text-overflow: ellipsis;
      white-space:nowrap;
    }
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 14px;
    padding-right: 8px;
    .edit-icon {
      font-size: 16px;
    }
    .user-info {
      width: 375px;
      display: flex;
      color: #303133;
      justify-content: space-between;
      font-size: 14px;
      line-height: 32px;
      .editor-name {
        max-width: 84px;
        overflow: hidden;
        text-overflow: ellipsis;
        -o-text-overflow: ellipsis;
        white-space:nowrap;
      }
    }
  }
</style>

