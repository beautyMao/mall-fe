<template>
  <div class="flex-wrp flex-between">
    <el-card :style="{width: '180px'}">
      <div class="pd15">
        <div class="color2 bold size18 flex-wrp lh200 pb5">一级话术列表</div>
        <div class="pb5">
          <!-- <div class="pb5" :style="{height: '490px'}"> -->
          <!-- <el-scrollbar :style="{height: '100%'}"> -->
          <div class="flex-wrp flex-cell flex-middle">
            <div v-for="(item, key) in personalSpeechList" :key="item.id">
              <el-popover
                :key="item.id"
                placement="right"
                popper-class="el-popover-talking-skill"
                trigger="hover"
              >
                <div class="flex-wrp flex-align-center flex-between">
                  <div class="mr5" @click.stop="editTitle($event, item)">
                    <el-button type="primary" icon="el-icon-edit" circle size="mini" />
                  </div>
                  <div @click.stop="deleteSpeechList($event, item, key)">
                    <el-button type="primary" icon="el-icon-delete" circle size="mini" />
                  </div>
                </div>
                <el-button
                  slot="reference"
                  type="text"
                  class="size14 color2 mtb5 text-nowrap target_hover_text"
                  :class="{'color5': speechTarget.id === item.id}"
                  :style="{'text-align': 'left', 'font-weight': '400'}"
                  @click="confirmSpeech(item)"
                >{{ item.content }}
                </el-button>
              </el-popover>
            </div>
          </div>
          <!-- </el-scrollbar> -->
        </div>
        <div class="flex-wrp flex-center">
          <div><el-button icon="el-icon-plus" size="mini" circle @click.stop="addTitle($event)" /></div>
        </div>
      </div>
    </el-card>

    <el-dialog
      title="新增话术系列"
      :visible.sync="addSpeechsStatus"
      custom-class="pr30"
      width="440px"
      :before-close="() => { addSpeechsStatus = false }"
    >
      <el-form ref="addForm" :model="addSpeechsData" :rules="rules" @submit.native.prevent @keyup.enter.native="successAdd($event)">
        <el-form-item label="话术系列名称" prop="content" :label-width="formLabelWidth">
          <el-input
            v-model.trim="addSpeechsData.content"
            type="text"
            placeholder="请输入话术系列名称"
            auto-complete="off"
          />
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="addSpeechsStatus = false">取 消</el-button>
        <el-button type="primary" @click="successAdd($event)">确 定</el-button>
      </span>
    </el-dialog>

    <el-dialog
      title="修改话术系列名称"
      :visible.sync="editSpeechsStatus"
      custom-class="pr30"
      width="440px"
      :before-close="() => { editSpeechsStatus = false }"
    >
      <el-form ref="editForm" :model="editSpeechsData" :rules="rules" @submit.native.prevent @keyup.enter.native="successEdit($event)">
        <el-form-item label="话术系列名称" prop="content" :label-width="formLabelWidth">
          <el-input
            v-model.trim="editSpeechsData.content"
            type="text"
            placeholder="请输入话术系列名称"
            auto-complete="off"
          />
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="editSpeechsStatus = false">取 消</el-button>
        <el-button type="primary" @click="successEdit($event)">确 定</el-button>
      </span>
    </el-dialog>

    <div class="pl15" :style="{flex: 1}">
      <header>
        <div class="flex-wrap">
          <el-button type="primary" plain @click="addSpeech">新增话术</el-button>
          <el-button :disabled="chooseDeleteList.length === 0" type="primary" plain @click="batchDelete">批量删除</el-button>
        </div>
      </header>

      <my-dialog
        :type="2"
        :select-list="selectList"
        title="新增话术"
        :mydata="{
          titles: speechTarget.id ? speechTarget : '',
          content: ''
        }"
        :visible="dialogFormVisible"
        @on-data="onDialogData"
        @on-close="dialogFormVisible = false"
      />

      <my-table
        :data="localTableData"
        :type="2"
        :mypagination="mypagination"
        :title="title"
        @handleEdit="handleEdit"
        @handleDelete="handleDelete"
        @currentChange="handleCurrentChange"
        @handleSizeChange="handleSizeChange"
        @handleSelectionChange="handleSelectionChange"
      />
      <my-dialog
        :type="2"
        :select-list="selectList"
        title="编辑话术"
        :mydata="tableForm"
        :visible="tableFormVisible"
        @on-data="onTableData"
        @on-close="tableFormVisible = false"
      />
    </div>
  </div>
</template>

<script>
  import myTable from '@/views/speech/components/myTable'
  import myDialog from '@/views/speech/components/myDialog'
  import {
    delApiWbEngineerSpeech,
    deleteApiWbEngineerBatchDelete,
    getApiWbEngineerPersonalSpeech,
    getApiWbEngineerSpeech,
    postApiWbEngineerSpeech,
    putApiWbEngineerSpeech
  } from '@/api/speech'

  export default {
    name: 'my-personal-speech',
    components: { myTable, myDialog },
    props: {
      type: {
        type: String,
        required: true
      }
    },
    data() {
      return {
        title: '个人话术',
        dialogFormVisible: false,
        tableFormVisible: false,
        selectList: [],
        tableForm: {},
        tableData: [],
        localTableData: [],
        mypagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        },
        chooseDeleteList: [],
        personalSpeechList: [],
        addSpeechsStatus: false,
        addSpeechsData: {},
        editSpeechsStatus: false,
        editSpeechsData: {},
        speechTarget: {},
        formLabelWidth: '120px',
        rules: {
          content: [{ required: true, trigger: 'change', message: '请输入话术系列名称' }]
        }
      }
    },
    watch: {
      addSpeechsStatus(status) {
        !status && this.$nextTick(() => {
          this.$refs.addForm.resetFields()
        })
      },
      editSpeechsStatus(status) {
        !status && this.$nextTick(() => {
          this.$refs.editForm.resetFields()
        })
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        return getApiWbEngineerSpeech().then(res => {
          this.personalSpeechList = res.data.personal
          this.selectList = this.personalSpeechList
          if (this.personalSpeechList.length && !this.speechTarget.id) {
            this.confirmSpeech(this.personalSpeechList[0])
          }
        })
      },
      fetchPersonalList() {
        const { id } = this.speechTarget
        if (id) {
          return getApiWbEngineerPersonalSpeech({ id: id }).then(res => {
            this.tableData = res.data
            this.mypagination.current_page = 1
            this.localPagination()
          })
        } else {
          this.tableData = []
          this.mypagination.current_page = 1
          this.localPagination()
          return Promise.resolve()
        }
      },
      localPagination() { // 分页
        const number = (this.mypagination.current_page - 1) * this.mypagination.datanum // num
        this.localTableData = this.tableData.slice(number, number + this.mypagination.datanum)
        this.mypagination.total = this.tableData.length
      },
      addSpeech: function() {
        this.dialogFormVisible = true
      },
      confirmSpeech: function(item) {
        this.speechTarget = { ...item }
        this.title = item.content
        this.fetchPersonalList()
      },
      addTitle(e, data = { content: '' }) {
        this.addSpeechsStatus = true
        this.addSpeechsData = data
      },
      editTitle(e, data) {
        this.editSpeechsData = { ...data }
        this.$nextTick(() => {
          this.editSpeechsStatus = true
        })
      },
      deleteSpeechList: function(e, item, key) {
        e.stopPropagation()
        this.$confirm('删除话术系列将同时删除该系列下的全部话术内容，确定删除?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          delApiWbEngineerSpeech(item.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            if (this.speechTarget.id === item.id) {
              Promise.all([this.fetchData(), this.fetchPersonalList()]).then(() => {
                if (this.personalSpeechList.length) {
                  this.confirmSpeech(this.personalSpeechList[key - 1] || this.personalSpeechList[0])
                } else {
                  this.speechTarget = {}
                  this.title = '个人话术'
                }
              })
            } else {
              this.fetchData()
              this.fetchPersonalList()
            }
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      batchDelete: function() {
        this.$confirm('此操作将删除所选话术, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          deleteApiWbEngineerBatchDelete({ id: this.chooseDeleteList.map(item => item.id), type: this.speechTarget.type }).then(response => {
            this.fetchPersonalList()
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      handleEdit(row) {
        this.tableFormVisible = true
        this.tableForm = {
          titles: this.speechTarget,
          content: row.content,
          data: { ...row }
        }
      },
      handleCurrentChange(val) {
        this.mypagination.current_page = val
        this.localPagination()
      },
      handleSizeChange(val) { // 改变每页条数
        this.mypagination.datanum = val
        this.localPagination()
      },
      successEdit(e) {
        e.stopPropagation()
        const { id } = this.editSpeechsData
        putApiWbEngineerSpeech(id, {
          'content': this.editSpeechsData.content,
          'type': 1
        }).then(response => {
          this.confirmSpeech(this.editSpeechsData)
          this.fetchData()
          this.editSpeechsStatus = false
        }).catch(this.$message.error)
      },
      successAdd(e) {
        e.stopPropagation()
        postApiWbEngineerSpeech({
          'content': this.addSpeechsData.content,
          'type': 1
        }).then(res => {
          this.addSpeechsStatus = false
          this.fetchData()
        }).catch(this.$message.error)
      },
      onDialogData: function(data) {
        const param = {
          'content': data.content,
          'parent_id': data.titles.id,
          'type': data.titles.type
        }
        postApiWbEngineerSpeech(param).then(response => {
          this.$message('添加成功，请前往相应一级话术下查看')
          this.fetchData()
          this.fetchPersonalList()
          this.dialogFormVisible = false
        }).catch(this.$message.error)
      },
      onTableData(data) {
        const param = {
          'content': data.content,
          'parent_id': data.titles.id,
          'id': data.data.id,
          'type': 1
        }
        putApiWbEngineerSpeech(data.data.id, param).then(response => {
          this.fetchData()
          this.fetchPersonalList()
          this.tableFormVisible = false
        }).catch(this.$message.error)
      },
      handleSelectionChange(val) {
        this.chooseDeleteList = val
      },
      handleDelete(data) {
        this.$confirm('确定删除话术?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          delApiWbEngineerSpeech(data.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
            this.fetchPersonalList()
          }).catch(this.$message.error)
        }).catch(() => {})
      }
    }
  }
</script>

<style lang="scss" scoped>
// /deep/ .el-scrollbar__wrap {
//   overflow-x: hidden !important;
// }
.target_hover_text:hover{
  color: #3e8ddd !important;
}
</style>

