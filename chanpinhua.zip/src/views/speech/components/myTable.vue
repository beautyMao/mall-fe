<template>
  <el-card>
    <el-table
      ref="multipleTable"
      :data="data"
      style="width: 100%"
      @selection-change="handleSelectionChange"
    >
      <el-table-column
        type="selection"
        :selectable="checkSelectable"
        width="55"
      />

      <el-table-column :label="type === 1 ? '公共话术' : title ">
        <template slot-scope="scope">
          <span>{{ scope.row.content }}</span>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="150" align="left">
        <template slot-scope="scope">
          <el-button
            :disabled="type === 1 ? !buttonPermission('updatePublicDiscourse') : !(type === 2)"
            type="text"
            @click="handleEdit(scope.row)"
          >编辑
          </el-button>
          <el-button
            :disabled="type === 1 ? !buttonPermission('deletePublicDiscourse') : !(type === 2)"
            class="el-del"
            type="text"
            @click="handleDelete(scope.row)"
          >删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>

    <el-pagination
      background
      :current-page="mypagination.current_page"
      :page-size="mypagination.datanum"
      :page-sizes="[10, 15, 20, 25]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="mypagination.total"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </el-card>
</template>

<script>
  import { mapGetters } from 'vuex'

  export default {
    name: 'my-table',
    props: {
      data: {
        type: Array,
        required: true
      },
      mypagination: {
        type: Object,
        required: true
      },
      type: {
        type: Number,
        default: 1
      },
      title: {
        type: String,
        default: null
      }
    },
    computed: {
      ...mapGetters([
        'buttonPermission'
      ])
    },
    methods: {
      checkSelectable() {
        return this.buttonPermission('deletePublicDiscourse')
      },
      toggleSelection(rows) {
        if (rows) {
          rows.forEach(row => {
            this.$refs.multipleTable.toggleRowSelection(row)
          })
        } else {
          this.$refs.multipleTable.clearSelection()
        }
      },
      handleSelectionChange(val) {
        this.$emit('handleSelectionChange', val)
      },
      indexMethod(index) {
        return index + 1
      },
      handleEdit(row) {
        this.$emit('handleEdit', row)
      },
      handleDelete(row) {
        this.$emit('handleDelete', row)
      },
      currentChange(val) {
        this.$emit('currentChange', val)
      },
      handleSizeChange(val) {
        this.$emit('handleSizeChange', val)
      }
    }
  }
</script>

