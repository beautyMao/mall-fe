<template>
  <div>
    <header>
      <div class="flex-wrap">
        <el-button :disabled="!buttonPermission('insertPublicDiscourse')" type="primary" plain @click="addSpeech">新增话术</el-button>
        <el-button :disabled="chooseDeleteList.length === 0 || !buttonPermission('deletePublicDiscourse')" type="primary" plain @click="batchDelete">批量删除</el-button>
      </div>
    </header>

    <my-dialog
      :select-list="selectList"
      title="新增公共话术"
      :visible="dialogFormVisible"
      @on-data="onDialogData"
      @on-close="dialogFormVisible = false"
    />
    <!-- type: 1(公共话术)； type: 2(个人话术);  @default: 1-->
    <my-table
      :data="localTableData"
      :mypagination="mypagination"
      @handleEdit="handleEdit"
      @handleDelete="handleDelete"
      @currentChange="handleCurrentChange"
      @handleSizeChange="handleSizeChange"
      @handleSelectionChange="handleSelectionChange"
    />
    <my-dialog
      :select-list="selectList"
      title="编辑话术"
      :mydata="tableForm"
      :visible="tableFormVisible"
      @on-data="onTableData"
      @on-close="tableFormVisible = false"
    />
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import myTable from '@/views/speech/components/myTable'
  import myDialog from '@/views/speech/components/myDialog'
  import {
    delApiWbEngineerSpeech,
    deleteApiWbEngineerBatchDelete,
    getApiWbEngineerSpeech,
    postApiWbEngineerSpeech,
    putApiWbEngineerSpeech
  } from '@/api/speech'

  export default {
    name: 'my-common-speech',
    components: { myTable, myDialog },
    data() {
      return {
        dialogFormVisible: false,
        tableFormVisible: false,
        selectList: [],
        tableForm: {},
        tableData: [],
        localTableData: [],
        mypagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        },
        chooseDeleteList: [],
        formLabelWidth: '120px'
      }
    },
    computed: {
      ...mapGetters([
        'buttonPermission'
      ])
    },
    mounted() {
      this.fetchCommonList()
    },
    methods: {
      fetchCommonList() {
        return getApiWbEngineerSpeech().then(res => {
          this.tableData = res.data.common
          this.mypagination.current_page = 1
          this.localPagination()
        })
      },
      localPagination() { // 分页
        const number = (this.mypagination.current_page - 1) * this.mypagination.datanum // num
        this.localTableData = this.tableData.slice(number, number + this.mypagination.datanum)
        this.mypagination.total = this.tableData.length
      },
      addSpeech: function() {
        this.dialogFormVisible = true
      },
      batchDelete: function() {
        this.$confirm('此操作将删除所选话术, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          deleteApiWbEngineerBatchDelete({ id: this.chooseDeleteList.map(item => item.id), type: 0 }).then(response => {
            this.fetchCommonList()
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      handleEdit(row) {
        this.tableForm = {
          content: row.content,
          data: { ...row }
        }
        this.$nextTick(() => {
          this.tableFormVisible = true
        })
      },
      handleCurrentChange(val) {
        this.mypagination.current_page = val
        this.localPagination()
      },
      handleSizeChange(val) { // 改变每页条数
        this.mypagination.datanum = val
        this.localPagination()
      },
      onDialogData: function(data) {
        const param = {
          'content': data.content,
          'type': 0
        }
        postApiWbEngineerSpeech(param).then(response => {
          this.$message('添加成功，请前往相应一级话术下查看')
          this.fetchCommonList()
          this.dialogFormVisible = false
        }).catch(this.$message.error)
      },
      onTableData(data) {
        const param = {
          'content': data.content,
          'type': 0
        }
        putApiWbEngineerSpeech(data.data.id, param).then(response => {
          this.fetchCommonList()
          this.tableFormVisible = false
        }).catch(this.$message.error)
      },
      handleSelectionChange(val) {
        this.chooseDeleteList = val
      },
      handleDelete(data) {
        this.$confirm('确定删除话术?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          delApiWbEngineerSpeech(data.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchCommonList()
          }).catch(this.$message.error)
        }).catch(() => {})
      }
    }
  }
</script>

<style lang="scss" scoped>
.target_hover_text:hover{
  color: #3e8ddd !important;
}
</style>

