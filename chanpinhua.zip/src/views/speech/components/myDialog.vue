<template>
  <div class="my-dialog">
    <el-dialog
      ref="my-dialog"
      center
      :title="title"
      width="440px"
      :visible.sync="visible"
      :before-close="() => void $emit('on-close')"
    >
      <el-form ref="form" :model="data" :rules="rules" @submit.native.prevent>
        <el-form-item v-show="type !== 1" required label="所在系列" prop="titles" :label-width="formLabelWidth">
          <el-select
            v-model="data.titles"
            value-key="id"
            placeholder="请选择个人话术"
            class="w100"
          >
            <el-option
              v-for="item in selectList"
              :key="item.id"
              :label="item.content"
              :value="item"
            >
              <span class="size12">{{ item.content }}</span>
            </el-option>
          </el-select>
        </el-form-item>

        <el-form-item required label="话术内容" prop="content" :label-width="formLabelWidth">
          <el-input
            v-model="data.content"
            type="textarea"
            placeholder="请输入话术内容，最多500字"
            maxlength="500"
            :rows="4"
            auto-complete="off"
          />
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="() => void $emit('on-close')">取 消</el-button>
        <el-button type="primary" @click="onData">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { deepClone } from '@/utils'
  export default {
    name: 'my-dialog',
    props: {
      visible: {
        type: Boolean,
        required: true
      },
      mydata: {
        type: Object,
        default() {
          return {
            titles: '',
            content: ''
          }
        }
      },
      title: {
        type: String,
        default: ''
      },
      selectList: {
        type: Array,
        default: null
      },
      type: {
        type: Number,
        default: 1
      }
    },
    data() {
      return {
        data: deepClone(this.mydata),
        common: '公共话术',
        personal: '',
        content: '',
        formLabelWidth: '100px',
        rules: {
          titles: [{ required: true, trigger: 'change', message: '请选择所属一级话术分类' }],
          content: [{ required: true, trigger: ['blur', 'change'], message: '请输入话术内容' }]
        }
      }
    },
    watch: {
      visible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
        })

        // 处理话术系列组删除后，触发表单问题
        if (status && !this.selectList.length && !this.mydata.titles && this.type === 2) this.$refs['form'].resetFields()
      },
      mydata: {
        handler(newVal, oldVal) {
          this.data = deepClone(newVal)
        },
        deep: true
      }
    },
    methods: {
      onData() {
        this.$refs.form.validate((valid, vdata) => {
          if (this.type === 1) {
            if (!['content'].some(item => Object.keys(vdata).some(tt => tt === item))) {
              this.$emit('on-data', this.data)
            } else {
              return false
            }
          } else {
            if (valid) {
              this.$emit('on-data', this.data)
            } else {
              return false
            }
          }
        })
      }
    }
  }
</script>
