<template>
  <div class="app-container">
    <el-tabs v-model="activeName" tab-position="left">
      <el-tab-pane label="公共话术" name="common">
        <my-common-speech :type="activeName" />
      </el-tab-pane>
      <el-tab-pane label="个人话术" name="personal">
        <my-personal-speech :type="activeName" />
      </el-tab-pane>
    </el-tabs>
  </div>
</template>
<script>
  import myCommonSpeech from '@/views/speech/components/myCommonSpeech'
  import myPersonalSpeech from '@/views/speech/components/myPersonalSpeech'

  export default {
    name: 'chat-management',
    components: { myCommonSpeech, myPersonalSpeech },
    data() {
      return {
        activeName: 'common'
      }
    }
  }
</script>
