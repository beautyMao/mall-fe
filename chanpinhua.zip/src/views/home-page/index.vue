<template>
  <div class="flex-wrp flex-center flex-cell home-container">
    <div class="home-page-bg" />
    <p>欢迎来到魔方</p>
  </div>
</template>

<style lang="scss" scoped>
  .home-container {
    background: #f0f2f5;
    height: calc(100vh - 84px);
    overflow: auto;

    p {
      font-size: 18px;
      text-align: center;
    }
  }
  .home-page-bg {
    width: 450px;
    height: 450px;
    // ~@/assets/pencil.png
    // background: url(~@/assets/login_bg.png) no-repeat center / cover;
    background: url('/static/images/home-page.png') no-repeat center / cover;
  }
</style>
