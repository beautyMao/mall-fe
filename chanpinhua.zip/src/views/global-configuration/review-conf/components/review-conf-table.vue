<template>
  <el-card>
    <el-table
      ref="my-table"
      :data="data"
      @selection-change="handleSelectionChange"
    >
      <el-table-column
        type="selection"
        width="55"
      />
      <el-table-column
        type="index"
        :index="indexMethod"
      />
      <el-table-column
        label="推送渠道"
        width="100"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.push_channel }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="推送文案"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.push_message }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="推送时间"
        width="150"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.push_time_classify === 1 ? '实时' : (scope.row.push_time_classify === 2 ? '会话结束后' : '次日 10:00') }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="应用通路"
      >
        <template slot-scope="scope">
          <span>{{ scope.row.access.name }}</span>
        </template>
      </el-table-column>
      <el-table-column
        label="是否启用"
      >
        <template slot-scope="scope">
          <span>
            <el-switch
              v-model="scope.row.status"
              class="el-switch--mark"
              :active-value="1"
              :inactive-value="0"
              @change="(val) => void handleChangeStatus(val, scope.row)"
            />
          </span>
        </template>
      </el-table-column>
      <el-table-column label="操作" width="150">
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="handleEdit(scope.$index, scope.row)"
          >编辑
          </el-button>
          <el-button
            type="text"
            class="el-del"
            @click="handleDelete(scope.$index, scope.row)"
          >删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      :current-page="myPagination.current_page"
      :page-size="myPagination.datanum"
      :page-sizes="[10, 15, 20, 25]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="myPagination.total"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </el-card>
</template>

<script>
  export default {
    name: 'review-conf-table',
    props: {
      data: {
        type: Array,
        required: true
      },
      myPagination: {
        type: Object,
        required: true
      }
    },
    data() {
      return {}
    },
    methods: {
      indexMethod(index) {
        return index + 1
      },
      handleEdit(index, row) {
        this.$emit('edit', index, row)
      },
      handleDelete(index, row) {
        this.$emit('delete', index, row)
      },
      currentChange(val) {
        this.$emit('change', val)
      },
      handleSizeChange(val) {
        this.$emit('size-change', val)
      },
      handleChangeStatus(val, status) {
        this.$emit('handleChangeStatus', val, status)
      },
      handleSelectionChange(val) {
        this.$emit('handleSelectionChange', val)
      }
    }
  }
</script>

<style scoped lang="scss">
</style>
