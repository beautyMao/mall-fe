<template>
  <div id="jnz-dialog" class="my-dialog">
    <!-- Form -->
    <el-dialog
      ref="my-dialog"
      :title="title"
      custom-class="el-dialog-aside"
      :visible.sync="visible"
      :before-close="() => void $emit('close')"
    >
      <el-form
        ref="form"
        :model="data"
        :rules="rules"
        class=""
        @submit.native.prevent
      >
        <el-form-item
          label="服务方式"
          prop="type"
          :label-width="formLabelWidth"
        >
          <el-radio-group v-model="data.access_type">
            <!--<el-radio :label="2">电话</el-radio>-->
            <el-radio :label="1">文本</el-radio>
          </el-radio-group>
        </el-form-item>

        <el-form-item
          label="应用通路"
          prop="access"
          :label-width="formLabelWidth"
        >
          <el-select v-model="data.access_id" value-key="id" @change="changeAccessValue">
            <el-option
              v-for="item in selectData.accessList"
              :key="item.id"
              :label="item.name"
              :value="item.id"
            />
          </el-select>
        </el-form-item>

        <el-form-item
          label="推送方式"
          prop="push_channel"
          :label-width="formLabelWidth"
        >
          <el-select v-model="data.push_channel">
            <el-option
              v-for="(item, index) in selectData.pushChannelList"
              :key="item.index"
              :label="item"
              :value="item"
            />
          </el-select>
        </el-form-item>

        <div v-if="!isH5">
          <el-form-item
            v-if="!isWebchat"
            label="推送时间"
            prop="push_time_classify"
            :label-width="formLabelWidth"
          >
            <el-radio-group v-model="data.push_time_classify">
              <el-radio :label="2">会话结束后</el-radio>
              <el-radio :label="3">次日10:00</el-radio>
            </el-radio-group>
          </el-form-item>

          <el-form-item
            label="推送文案"
            prop="push_message"
            :label-width="formLabelWidth"
          >
            <el-input
              v-model="data.push_message"
              type="textarea"
              :placeholder="placeholderText"
              maxlength="60"
              show-word-limit
              style="min-height: 100px;"
              :autosize="{ minRows: 4, maxRows: 4}"
            />
          </el-form-item>
          <el-form-item :label-width="formLabelWidth"><p>
            注：<br>
            1.推送文案中符号{{}}代表自动获取数据,可调整显示位置；<br>
            2.companyName代表公司名称、Name代表客服姓名，URL代表点评链<br>
            3.邀评链接支持客服主动邀评和系统自动推送，当客服发送过邀评消息后系统不再重复发送推送文案
          </p>

          </el-form-item>
        </div>

        <el-form-item label="是否启用" :label-width="formLabelWidth">
          <el-switch
            v-model="data.status"
            class="el-switch--mark"
            :active-value="1"
            :inactive-value="0"
          />
        </el-form-item>

      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="$emit('close')">取 消</el-button>
        <el-button class="submit" type="primary" @click="onData">提 交</el-button>
      </div>
    </el-dialog>
  </div>
</template>
<script>
  import { getReviewConfAccessListApi } from '@/api/global-configuration'
  export default {
    name: 'review-conf-dialog',
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      myData: {
        type: Object,
        default() {
          return {
            id: null,
            access_id: null,
            status: 0,
            push_channel: '',
            push_message: '',
            push_time_classify: 2,
            push_time: null,
            access_type: 1,
            access_name: '',
            access: {
              name: null,
              id: null,
              type: null
            }
          }
        }
      },
      title: {
        type: String,
        default: ''
      }
    },
    data() {
      const validate_access = (rule, value, callback) => {
        if (this.data.access && this.data.access.id === null) {
          callback(new Error('请选择应用通路'))
        } else {
          callback()
        }
      }

      return {
        data: JSON.parse(JSON.stringify(this.myData)),
        formLabelWidth: '120px',
        selectData: {
          accessList: [], // 通路选择
          pushChannelList: [] // 方式选择
        },
        isH5: false,
        isWebchat: false,
        rules: {
          // type: [{ required: true, trigger: 'change', message: '请选择服务方式' }],
          push_channel: [{ required: true, trigger: 'change', message: '请选择推送方式' }],
          access: [{ validator: validate_access, required: true, message: '请选择应用通路' }],
          push_message: [{ required: true, trigger: 'change', message: '请填写推送文案' }],
          push_time_classify: [{ trigger: 'change', required: true, message: '请选择推送时间' }]
        }
      }
    },
    computed: {
      placeholderText() {
        return '【{{companyName}}】客服{{Name}}期待您的评价，点击链接{{URL}}'
      }
    },
    watch: {
      visible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
        })
        if (status) {
          this.fetchDialogData()
        }
      },
      myData: {
        handler(newVal, oldVal) {
          this.data = JSON.parse(JSON.stringify(newVal))
          this.data.access_name = this.data.access.name
        },
        deep: true
      },
      'data.push_channel': function(newVal) {
        if (newVal === '实时点评') {
          this.isH5 = true
          this.data.push_time_classify = 1
        } else {
          this.data.push_time_classify = 2
          this.isH5 = false
        }
      },
      'data.push_time_classify': function(newVal) {
        newVal === '2' ? this.data.push_time = '' : this.data.push_time
      }
    },
    mounted() {
      this.data.push_message = '【{{companyName}}】客服{{Name}}期待您的评价，点击链接{{URL}}'
    },
    methods: {
      fetchDialogData() {
        if (this.title === '新增点评规则') {
          this.data.access_type = 1
        }
        setTimeout(() => {
          getReviewConfAccessListApi(this.data.access_type).then(res => {
            this.selectData.accessList = res.data.accessList
            this.selectData.pushChannelList = res.data.pushChannelList
            this.selectData.pushChannelList = []
            this.selectData.accessList.forEach(item => {
              if (item.id === this.data.access_id) {
                if (item.en_name === 'webchat') {
                  this.isWebchat = true
                }
                if (item.en_name !== 'webchat') {
                  this.isWebchat = false
                }
                this.selectData.pushChannelList = item.pushChannel
              }
            })
          })
        }, 200)
      },
      changeAccessValue(val) {
        this.data.push_channel = ''
        this.selectData.pushChannelList = []
        this.selectData.accessList.forEach(item => {
          if (item.id === val) {
            this.selectData.pushChannelList = item.pushChannel
            if (item.en_name === 'webchat') {
              this.isWebchat = true
            }
            if (item.en_name !== 'webchat') {
              this.isWebchat = false
            }
          }
        })
        // push_channel
        this.data.access.id = this.data.access_id
      },
      onData() {
        this.$refs.form.validate(valid => {
          if (valid) {
            this.$emit('change', this.data)
          } else {
            return false
          }
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  /deep/.el-scrollbar {
    width: 182px;
  }
  p {
    margin-top: 0;
    font-size: 14px;
    line-height: normal;
    width: 360px;
  }
  /deep/ .el-input__inner {
    width: 360px;
  }
  /deep/ .el-textarea {
    margin-bottom: 0;
    width: 360px;
    /deep/ .el-textarea__inner {
      width: 360px;
    }
  }
  /deep/ .el-input__suffix {
    right: 25px !important;
  }
  .push-time {
    height: 60px !important;
    /deep/ .el-form-item__content {
      height: 60px !important;
      /deep/ .el-radio-group {
        height: 60px !important;
        width: 70px;
        .el-row {
          height: 32px !important;
          width: 70px;
          display: flex;
          align-items: center;
          /deep/ .el-input__inner {
            width: 182px;
          }
        }
      }
    }
  }
</style>
