<template>
  <div class="app-container">
    <header>
      <h1>点评配置</h1>
      <div class="flex-wrp">
        <el-button type="primary" plain @click="addVisible = true">新建点评规则</el-button>
        <el-button type="primary" plain :disabled="!isSelected" @click="handleDeleteConf">批量删除</el-button>
      </div>
    </header>

    <review-table
      :data="localTableData"
      :my-pagination="myPagination"
      @change="handleCurrentChange"
      @size-change="handleSizeChange"
      @edit="handleEdit"
      @delete="handleDelete"
      @handleSelectionChange="handleSelectionChange"
      @handleChangeStatus="handleChangeStatus"
    />

    <review-dialog
      title="新建点评规则"
      :visible="addVisible"
      @change="onDialogData"
      @close="addVisible = false"
    />
    <review-dialog
      :mode-disabled="true"
      title="编辑点评规则"
      :my-data="tableData"
      :visible="editVisible"
      @change="onTableData"
      @close="editVisible = false"
    />
  </div>
</template>

<script>
  import reviewTable from './components/review-conf-table'
  import reviewDialog from './components/review-conf-dialog'
  import { reviewConfRestApi, reviewConfStatusRestApi, deleteReviewConfAccessListApi } from '@/api/global-configuration'
  export default {
    name: 'comment-management',
    components: { reviewDialog, reviewTable },
    data() {
      return {
        addVisible: false,
        tableDataList: [],
        tableData: {},
        editVisible: false,
        localTableData: [],
        totalNum: 10,
        multipleSelection: [],
        selectedItems: [],
        myPagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        }
      }
    },
    computed: {
      isSelected() {
        return this.multipleSelection && this.multipleSelection.length
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        reviewConfRestApi.list().then(response => {
          this.tableDataList = response.data.data
          this.myPagination.current_page = 1
          this.localPagination()
        }).catch(this.$message.error)
      },
      onDialogData(data) {
        reviewConfRestApi.post(data).then(response => {
          this.$message({
            type: 'success',
            message: '创建成功!'
          })
          this.fetchData()
          this.addVisible = false
        }).catch(this.$message.error)
      },
      onTableData(data) {
        console.log(data)
        reviewConfRestApi.update(data.id, data).then(response => {
          this.$message({
            type: 'success',
            message: '修改成功!'
          })
          this.fetchData()
          this.editVisible = false
        }).catch(this.$message.error)
      },
      handleEdit(index, row) {
        this.editVisible = true
        reviewConfRestApi.get(row.id).then(response => {
          this.tableData = [response.data].map(item => {
            item.id = item.id === 0 ? '' : item.id
            item.access_id = item.access_id === 0 ? '' : item.access_id
            item.access_type = item.access.type === undefined ? 1 : item.access.type
            item.access_name = item.access.name === undefined ? '' : item.access.name
            if (!item.business_id) {
              item.channel_id = ''
            }
            return item
          })[0]
        }).catch(this.$message.error)
      },
      handleDelete(index, row) {
        this.$confirm('您是否要删除这些点评规则？', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          reviewConfRestApi.delete(row.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      handleCurrentChange(val) {
        this.myPagination.current_page = val
        this.localPagination()
      },
      localPagination() {
        // 本地分页
        const number = (this.myPagination.current_page - 1) * this.myPagination.datanum
        this.localTableData = this.tableDataList.slice(number, number + this.myPagination.datanum)
        this.myPagination.total = this.tableDataList.length
      },
      handleSizeChange(val) {
        this.myPagination.datanum = val
        this.localPagination()
      },
      handleChangeStatus(status, val) {
        const parm = {
          status: status
        }
        reviewConfStatusRestApi.update(val.id, parm).then(response => {
          this.$message({
            type: 'success',
            message: '修改成功!'
          })
          this.fetchData()
        }).catch(this.$message.error)
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
      handleDeleteConf() {
        this.multipleSelection.map(item => {
          this.selectedItems.push(item.id)
        })
        this.$confirm('您是否要删除这些点评规则?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          const parm = {
            config_comment_id: this.selectedItems
          }
          deleteReviewConfAccessListApi(parm).then(res => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
          }).catch(this.$message.error)
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  .l40{
    line-height: 40px;
    margin: 0;
  }
</style>
