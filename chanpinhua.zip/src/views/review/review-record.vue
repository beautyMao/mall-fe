<template>
  <div class="app-container">
    <header>
      <h1>点评数据查询</h1>
    </header>
    <el-card>
      <condition-query @ruleForm="ruleForm" @ExportInfo="ExportInfo" />
      <div v-if="data.length">
        <com-list :list-data="data" />
        <el-pagination
          class="page"
          background
          :page-sizes="[10, 20, 30]"
          :current-page="page"
          :page-size="Size"
          layout="total, sizes, prev, pager, next, jumper"
          :total="TotalNumber"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
      <footer v-if="!data.length">
        <h2>查询说明</h2>
        <ul>
          <li>A. 会话开始时间段默认为从今日开始往前推1个月的时间段；</li>
          <li>B. 通过用户标识查询支持查询移动电话和固定电话；</li>
          <li>C. 条件查询中的各个查询条件之间是“与”的关系，即输入信息越多，结果越准确；</li>
          <li>D. 点击“重置”按钮，会重置所有输入框的状态，点击“查询”按钮，会显示所有符合条件的结果，点击“导出”按钮，则将所有搜索结果导出成Excel格式。</li>
        </ul>
      </footer>
    </el-card>
  </div>
</template>

<script>
  import { getServiceJudgeInfo } from '@/api/review/index'
  import conditionQuery from './components/conditionQuery'
  import comList from './components/comList'
  export default {
    name: 'record-query',
    components: {
      conditionQuery,
      comList
    },
    data() {
      return {
        data: [],
        list: null,
        argument: '',
        TotalNumber: 0,
        Size: 10,
        page: 0
      }
    },
    methods: {
      ruleForm(value) { // 返回查询条件
        this.list = { ...value }
        this.list.page = 1
        this.list.size = 10
        this.page = 1
        this.Size = 10
        this.data = []
        this.argument = ''
        for (const i in this.list) {
          if (this.list[i]) {
            this.argument += i + '=' + this.list[i] + '&'
          }
        }
        getServiceJudgeInfo(this.argument).then(this.submitConditionFormInfoSucc).catch(this.error)
      },
      handleSizeChange(val) { // 条数切换
        this.list.page = 1
        this.list.size = val
        this.Size = val
        this.page = 1
        this.data = []
        this.argument = ''
        for (const i in this.list) {
          if (this.list[i]) {
            this.argument += i + '=' + this.list[i] + '&'
          }
        }
        getServiceJudgeInfo(this.argument).then(this.submitConditionFormInfoSucc).catch(this.error)
      },
      handleCurrentChange(val) { // 分页切换
        this.list.page = val
        this.list.size = this.Size
        this.page = val
        this.data = []
        this.argument = ''
        for (const i in this.list) {
          if (this.list[i]) {
            this.argument += i + '=' + this.list[i] + '&'
          }
        }
        getServiceJudgeInfo(this.argument).then(this.submitConditionFormInfoSucc).catch(this.error)
      },
      ExportInfo() { // 导出
        if (!this.argument) {
          this.$message({
            message: '请先查询数据',
            type: 'warning'
          })
        } else {
          const data = this.argument + 'is_excel=true'
          getServiceJudgeInfo(data).then(res => {
            window.location.href = res.data.download
          })
        }
      },
      submitConditionFormInfoSucc(res) { // 获取list数据
        if (res.message.info === 'Success' && !res.data.comment_lit.length) {
          this.$message({
            message: '无查询结果',
            type: 'warning'
          })
          return
        }
        this.data = res.data.comment_lit
        this.TotalNumber = res.data.total ? res.data.total : 0 // 分页总页数
      },
      error(err) {
        console.error(err)
      }
    }
  }
</script>
