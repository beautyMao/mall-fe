<template>
  <header>
    <h2>条件查询</h2>
    <el-form ref="ruleForm" :model="ruleForm" label-width="100px" :inline="true">
      <el-form-item label="" prop="access_name">
        <el-select v-model="ruleForm.access_name" placeholder="所属通路" clearable>
          <el-option v-for="item in Business" :key="item.id" :label="item.name" :value="item.name" />
        </el-select>
      </el-form-item>
      <el-form-item label="" prop="channel">
        <el-select v-model="ruleForm.channel" placeholder="点评来源" clearable>
          <el-option v-for="item in channel" :key="item.id" :label="item.name" :value="item.id" />
        </el-select>
      </el-form-item>
      <el-form-item label="" prop="level">
        <el-select v-model="ruleForm.level" placeholder="点评星级" clearable>
          <el-option v-for="item in ratings" :key="item.code" :value="item.code" />
        </el-select>
      </el-form-item>
      <el-form-item label="" prop="phone">
        <el-input v-model="ruleForm.phone" clearable placeholder="用户标识" />
      </el-form-item>
      <el-form-item label="" prop="engineer">
        <el-input v-model="ruleForm.engineer" clearable placeholder="客服工号/姓名" />
      </el-form-item>
      <el-form-item label="" prop="value1">
        <ext-date-picker
          ref="time"
          v-model="reviewdate"
          class="time"
          type="daterange"
          range-separator="至"
          placehoder="点评时间"
          start-placeholder="开始日期"
          end-placeholder="结束日期"
          :picker-options="pickerOptions2"
          format="yyyy 年 MM 月 dd 日"
          value-format="yyyy-MM-dd"
          @change="hanleTiemScope"
        />
      </el-form-item>
    </el-form>
    <p class="text-right">
      <el-button type="primary" plain @click="submitConditionForm('ruleForm')">查询</el-button>
      <el-button plain @click="resetConditionForm('ruleForm')">重置</el-button>
      <el-button plain :disabled="!buttonPermission('commentDataExport')" :class="{ active: !buttonPermission('commentDataExport') }" @click="handleExportInfo('ruleForm')">导出</el-button>
    </p>
  </header>
</template>

<script>
  import { getBusinessInfo } from '@/api/review/index'
  import ExtDatePicker from '@/components/ExtDatePicker'
  import { mapGetters } from 'vuex'

  export default {
    components: { ExtDatePicker },
    data() {
      return {
        ruleForm: {
          phone: '', // 用户标识 手机号
          access_name: '', // 通路
          engineer: '', // 客服工号姓名
          level: '', // 点评星级
          channel: '',
          start_time: '', // 开始日期
          end_time: '' // 结束日期
        },
        Business: [], // 点评来源
        ratings: [
          { code: 1, name: '1星' },
          { code: 2, name: '2星' },
          { code: 3, name: '3星' },
          { code: 4, name: '4星' },
          { code: 5, name: '5星' }],
        channel: [
          { id: 'wechat', name: '微信' },
          { id: 'chat', name: 'webchat' },
          { id: 'telephone', name: '电话' }
        ],
        baseURL: '',
        loading: false,
        reviewdate: null,
        pickerOptions2: { // 禁止选择未来时间
          disabledDate(time) {
            return time.getTime() > Date.now()
          }
        },
        input: /^[A-Za-z0-9\-]+$/
      }
    },
    computed: {
      ...mapGetters([
        'buttonPermission'
      ])
    },
    mounted() {
      this.init()
    },
    methods: {
      submitConditionForm(formName) { // 获取列表数据
        if (this.ruleForm.phone) {
          if (!this.input.test(this.ruleForm.phone)) {
            this.$message({
              message: '用户标识只可输入字母-或数字',
              type: 'warning'
            })
            return
          }
        }
        if (this.ruleForm.code) {
          if (!this.input.test(this.ruleForm.code)) {
            this.$message({
              message: '客服工号只可输入字母-或数字',
              type: 'warning'
            })
            return
          }
        }
        if (this.reviewdate) {
          this.ruleForm.start_time = this.reviewdate[0]
          this.ruleForm.end_time = this.reviewdate[1]
        }
        this.$emit('ruleForm', Object.assign({}, this.ruleForm))
      },
      handleExportInfo() {
        this.$emit('ExportInfo')
      },
      defaultTime(val) {
        const now = new Date()
        const start = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() - val)).toISOString().slice(0, 10)
        const end = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10)
        this.reviewdate = [start, end]
      },
      resetConditionForm(formName) { // 重置数据
        this.$refs[formName].resetFields()
        this.defaultTime(30)
      },
      hanleTiemScope() {}, // 设置时间跨度
      init() {
        this.defaultTime(30) // 初始默认时间段
        getBusinessInfo().then(res => {
          this.Business = [...res.data]
        })
        // this.$refs.time.$el.children[0].innerHTML = '点评时间'
        // this.$refs.time.$el.children[0].className = 'times'
      }
    }
  }
</script>
<style scoped>
  .active {
    color: #8bbbeb!important;
    background-color: #ecf4fc!important;
    border-color: #d8e8f8!important;
  }
</style>
