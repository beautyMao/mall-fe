<template>
  <div>
    <header>
      <h2>查询结果</h2>
    </header>
    <el-table :data="listData" tooltip-effect="light">
      <el-table-column label="点评ID">
        <template slot-scope="scope">
          <a style="color:#4A90E2" @click="handleEdit(scope.$index, scope.row)">{{ scope.row.id }}</a>
        </template>
      </el-table-column>
      <el-table-column prop="engineer_name" label="客服工号/姓名" width="150">
        <template slot-scope="scope">
          {{ scope.row.engineer_name }}/{{ scope.row.code }}
        </template>
      </el-table-column>
      <el-table-column prop="access_name" label="所属通路" width="120" />
      <el-table-column prop="phone" label="用户标识" width="120" />
      <el-table-column prop="channel" label="点评来源" />
      <el-table-column prop="user_name" label="用户名称" />
      <el-table-column prop="session_id" label="服务ID">
        <template slot-scope="scope">
          <a style="color:#4A90E2" @click="handleChatInfoClick(scope.row.session_id)">{{ scope.row.session_id }}</a>
        </template>
      </el-table-column>
      <el-table-column prop="level" label="点评星级" width="80" />
      <el-table-column prop="created_at" label="点评时间" width="160" />
    </el-table>
  </div>
</template>

<script>
  export default {
    props: {
      listData: {
        default: []
      }
    },
    methods: {
      handleChatInfoClick(id) { // 聊天记录
        this.$router.push({
          path: `/call-center/history`,
          query: { id }
        })
      },
      handleEdit(index, row) { // 获取详情信息
        this.$router.push({
          path: 'record/particulars',
          query: { id: row.id }
        })
      }
    }
  }
</script>
