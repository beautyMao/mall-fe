<template>
  <div v-if="particulars" class="particularsWrap app-container">
    <header>
      <h1>详细信息</h1>
    </header>
    <el-card class="particulars">
      <div class="block">
        <p class="title">客户信息</p>
        <div v-for="(item, value) of clientInfo" :key="value" class="list">
          <div class="wrap">
            <span class="key">{{ value }}</span>
            <span class="value">{{ item }}</span>
          </div>
        </div>
      </div>
      <div class="block">
        <p class="title">服务信息</p>
        <div v-for="(item, value) of serveInfo" :key="value" class="list">
          <div class="wrap">
            <span class="key">{{ value }}</span>
            <span :style="value === '服务记录ID:' ? 'color: #4A90E2' : ''" class="value" @click="handleBtnClick(value, item)">{{ item }}</span>
          </div>
        </div>
      </div>
      <div class="block">
        <p class="title">点评信息</p>
        <div v-for="(item, value) of commentInfo" :key="value" class="list">
          <div class="wrap">
            <span class="key">{{ value }}</span>
            <span class="value">{{ item }}</span>
          </div>
        </div>
      </div>
    </el-card>
  </div>
</template>

<script>
  import { getDetailInfo } from '@/api/review/index'
  export default {
    name: 'record-particulars',
    data() {
      return {
        particulars: true,
        clientInfo: {},
        serveInfo: {},
        commentInfo: {}
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      getRowClass({ row, column, rowIndex, columnIndex }) { // 设置table 标题背景色
        if (rowIndex === 0) { return 'background:#F0F4FB' } else { return '' }
      },
      init() {
        getDetailInfo(this.$route.query.id).then(res => {
          if (res.data) {
            const data = res.data
            this.clientInfo = {
              '客户ID/姓名:': (data.customer_id && data.user_name) ? data.customer_id + '/' + data.user_name : '匿名',
              '手机号码:': data.phone,
              '客户标识:': data.phone,
              '电子邮件:': data.email,
              '企业信息:': data.enterprise_information
            }
            this.serveInfo = {
              '客服工号/姓名:': data.code + '/' + data.engineer_name,
              '服务记录ID:': data.session_id,
              '服务开始时间:': data.created_at,
              '服务结束时间:': data.updated_at,
              '服务记录信息:': data.cases ? data.cases.problem_description : ''
            }
            this.commentInfo = {
              '点评ID:': data.id,
              '点评星级:': data.level,
              '点评渠道:': data.access_name,
              '点评内容:': data.content ? data.content : '暂无评论内容',
              '点评时间:': data.created_at
            }
          }
        })
      },
      handleBtnClick(name, val) {
        if (name === '服务记录ID:') {
          this.handleChatInfoClick(val)
        }
      },
      handleChatInfoClick(id) { // 聊天记录
        this.$router.push({
          path: `/call-center/history`,
          query: { id }
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
  @import '../common/css/detail.scss';
  .list {
    width: 50%!important;
    .key {
      margin-right: 50px;
    }
  }
</style>
