<template>
  <div class="app-container">
    <header>
      <h1>看板配置</h1>
    </header>
    <el-card class="box-card">
      <header>
        <h2>
          服务数据看版
          <span>（最多可选择6个数据展示）</span>
        </h2>
        <div>
          <el-checkbox-group v-model="defaultChecked" :min="3">
            <el-checkbox v-for="item in defaultDatas" :key="item.id" :label="item.id">{{ item.name }}</el-checkbox>
          </el-checkbox-group>
          <el-checkbox-group v-model="checkedDatas" :max="6">
            <el-checkbox v-for="item in Datas" :key="item.id" :label="item.id">{{ item.name }}</el-checkbox>
          </el-checkbox-group>
        </div>
      </header>
    </el-card>
    <el-card class="box-card">
      <header>
        <h2>
          重要数据看版
          <span>（最多可选择3个数据展示）</span>
        </h2>
        <div>
          <el-checkbox-group v-model="checkedDatas1" :max="3">
            <el-checkbox v-for="item in Datas1" :key="item.id" :label="item.id">{{ item.name }}</el-checkbox>
          </el-checkbox-group>
        </div>
      </header>
    </el-card>
    <div class="footer">
      <el-button type="primary" @click="submint">保存</el-button>
    </div>
  </div>
</template>
<script>
  import { getConfigDashboard, setConfigDashboard } from '@/api/ccp/index'
  import { mapGetters } from 'vuex'
  export default {
    name: 'dashboard-config',
    data() {
      return {
        checkedDatas: [],
        defaultChecked: ['total_service_number', 'current_lineup_number', 'abandonment_rate'],
        defaultDatas: [{
                         name: '总服务量',
                         id: 'total_service_number'
                       },
                       {
                         name: '当前排队量',
                         id: 'current_lineup_number'
                       },
                       {
                         name: '放弃率',
                         id: 'abandonment_rate'
                       }],
        Datas: [
          {
            name: '48小时重复来电',
            id: 'repeated_call_48'
          },
          {
            name: '30s接起量',
            id: 'pick_up_number_30'
          },
          {
            name: '服务水平',
            id: 'service_level'
          },
          {
            name: '总呼入',
            id: 'total_call_in_number'
          },
          {
            name: '总呼出量',
            id: 'total_call_out_number'
          },
          {
            name: '平均等待时长(热线)',
            id: 'average_wait_time'
          },
          {
            name: '平均等待时长',
            id: 'average_session_time'
          },
          {
            name: '放弃量',
            id: 'abandonment_number'
          },
          {
            name: '满意度',
            id: 'satisfaction'
          },
          {
            name: '机器人进入量',
            id: 'robot_enter_number'
          },
          {
            name: '机器人转人工量',
            id: 'robot_turn_artificial_number'
          },
          {
            name: '机器人转人工率',
            id: 'robot_turn_artificial_rate'
          }
        ],
        checkedDatas1: [],
        Datas1: [
          {
            name: '服务水平',
            id: 'service_level'
          },
          {
            name: '机器人转人工率',
            id: 'robot_turn_artificial_rate'
          },
          {
            name: '满意度',
            id: 'satisfaction'
          },
          {
            name: '放弃率',
            id: 'abandonment_rate'
          },
          {
            name: '愤怒会话率',
            id: 'anger_session_rate'
          },
          {
            name: '重复来电率',
            id: 'repeated_call_48_rate'
          },
          {
            name: '平均会话时长',
            id: 'average_session_time'
          }
        ]
      }
    },
    computed: {
      ...mapGetters(['allInfo'])
    },
    activated() {
      this.init()
    },
    methods: {
      init() {
        getConfigDashboard(this.allInfo.business_id).then(res => {
          this.checkedDatas1 = res.data.main_data
          this.checkedDatas = res.data.service_data
        })
      },
      submint() {
        const para = {
          business_id: this.allInfo.business_id,
          main_data: this.checkedDatas1,
          service_data: this.checkedDatas
        }
        if (para.main_data.length < 3) {
          this.$message({
            message: '重要数据至少选择3项',
            type: 'warning'
          })
          return
        }
        setConfigDashboard(para).then(res => {
          this.$message({
            message: '修改成功',
            type: 'success'
          })
        }).catch(() => {
          this.$message({
            message: '修改失败',
            type: 'error'
          })
        })
      }
    }
  }
</script>
<style lang='scss' scoped>
.box-card {
  h2 span {
    font-size: 14px;
    font-weight: normal;
  }

  /deep/ .el-checkbox-group {
    justify-content: baseline;
    display: inline-block;
    .el-checkbox {
      width: 150px;
      padding: 10px 5px;
    }
  }
}
.app-container {
  position: relative;
  width: 100%;
  height: 100%;
}
.footer {
  position: fixed;
  bottom: 0;
  right: 0;
  width: 100%;
  background-color: #fff;
  text-align: right;
  padding: 10px 20px;
  button {
    padding: 12px 50px;
  }
}
</style>

