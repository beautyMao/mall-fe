<template>
  <el-card :body-style="{ padding: '0px' }" class="business-data">
    <div class="title">重要业务数据</div>
    <div class="canvas-list">
      <div class="canvas-box">
        <canvas id="first-canvas" :height="styleH" :width="styleW" />
        <div v-if="busCanvas.first_canvas.length" class="canvas-text">
          <h5>{{ busCanvas.first_canvas[0].name }}</h5>
          <template v-if="busCanvas.first_canvas.length === 1">
            <p v-for="(item, index) in busCanvas.first_canvas" :key="index">
              <span>{{ item.name }}</span>
              <span>{{ item.value }}</span>
            </p>
            <p><span>&nbsp;</span><span>&nbsp;</span></p>
          </template>
          <p v-for="(item, index) in busCanvas.first_canvas" v-if="index > 0" :key="index">
            <span>{{ item.name }}</span>
            <span>{{ item.value }}</span>
          </p>
        </div>
      </div>
      <div class="canvas-box">
        <canvas id="second-canvas" :height="styleH" :width="styleW" />
        <div v-if="busCanvas.second_canvas.length" class="canvas-text">
          <h5>{{ busCanvas.second_canvas[0].name }}</h5>
          <template v-if="busCanvas.second_canvas.length === 1">
            <p v-for="(item, index) in busCanvas.second_canvas" :key="index">
              <span>{{ item.name }}</span>
              <span>{{ item.value }}</span>
            </p>
            <p><span>&nbsp;</span><span>&nbsp;</span></p>
          </template>
          <p v-for="(item, index) in busCanvas.second_canvas" v-if="index > 0" :key="index">
            <span>{{ item.name }}</span>
            <span>{{ item.value }}</span>
          </p>
        </div>
      </div>
      <div class="canvas-box">
        <canvas id="last-canvas" :height="styleH" :width="styleW" />
        <div v-if="busCanvas.last_canvas.length" class="canvas-text">
          <h5>{{ busCanvas.last_canvas[0].name }}</h5>
          <template v-if="busCanvas.last_canvas.length === 1">
            <p v-for="(item, index) in busCanvas.last_canvas" :key="index">
              <span>{{ item.name }}</span>
              <span>{{ item.value }}</span>
            </p>
            <p><span>&nbsp;</span><span>&nbsp;</span></p>
          </template>
          <p v-for="(item, index) in busCanvas.last_canvas" v-if="index > 0" :key="index">
            <span>{{ item.name }}</span>
            <span>{{ item.value }}</span>
          </p>
        </div>
      </div>
    </div>
  </el-card>
</template>

<script>
  import { getMainBusinessData } from '@/api/ccp/index'
  const ALL_SERCIVE_DATA = {
    'total_service_number': '总服务量',
    'current_lineup_number': '当前排队',
    'abandonment_rate': '放弃率',
    'repeated_call_48_rate': '48h重复来电',
    'pick_up_number_30': '30s接起量',
    'service_level': '服务水平',
    'total_call_in_number': '总呼入量',
    'total_call_out_number': '总呼出量',
    'average_session_time': '平均会话时长',
    'average_wait_time': '平均等待时长',
    'anger_session_rate': '愤怒会话率',
    'abandonment_number': '放弃量',
    'anger_session_num': '愤怒会话量',
    'satisfaction': '满意度',
    'robot_enter_number': '机器人进入量',
    'robot_turn_artificial_number': '机器人转人工量',
    'robot_turn_artificial_rate': '机器人转人工率'
  }
  export default {
    name: 'business-canvas',
    props: {
      styleH: {
        type: Number,
        default: 0
      },
      styleW: {
        type: Number,
        default: 0
      }
    },
    data() {
      return {
        list: [],
        busCanvas: {
          first_canvas: [],
          second_canvas: [],
          last_canvas: []
        }
      }
    },
    mounted() {
    },
    methods: {
      _getBusinessInfo() {
        this.list = []
        this.busCanvas.first_canvas = []
        this.busCanvas.second_canvas = []
        this.busCanvas.last_canvas = []
        getMainBusinessData(this.$route.query.businessID).then(response => {
          const data = response.data
          console.log(data)
          if (response.statusCode === 200) {
            data.map(item => {
              for (const key in item) {
                if (ALL_SERCIVE_DATA.hasOwnProperty(key)) {
                  for (const i in item[key]) {
                    this.list.push(item[key][i])
                  }
                }
              }
            })
            this.list.map((item, index) => {
              if (index < 3) {
                this.busCanvas.first_canvas.push(item)
              }
              if (index < 6 && index > 2) {
                this.busCanvas.second_canvas.push(item)
              }
              if (index < 9 && index > 5) {
                if (item.name === '平均会话时长') {
                  this.busCanvas.last_canvas.push({ name: '平均会话时长', value: '100%' })
                }
                this.busCanvas.last_canvas.push(item)
              }
            })
            setTimeout(() => {
              this.$nextTick(() => {
                if (document.getElementById('first-canvas')) {
                  const first_canvas = document.getElementById('first-canvas')
                  drawMain(first_canvas, this.busCanvas.first_canvas[0].value, ['#1890FF', '#7EF7FF'], '#DAF0FF', true, { width: this.styleW, height: this.styleW })
                  const second_canvas = document.getElementById('second-canvas')
                  drawMain(second_canvas, this.busCanvas.second_canvas[0].value, ['#7EF7FF', '#1890FF'], '#DAF0FF', true, { width: this.styleW, height: this.styleW })
                  const last_canvas = document.getElementById('last-canvas')
                  drawMain(last_canvas, this.busCanvas.last_canvas[0].value, ['#1890FF', '#8B70FC'], '#DAF0FF', true, { width: this.styleW, height: this.styleW })
                }
              })
            }, 300)
          }
        })
      }
    }
  }
  /*
	@drawing_elem: 绘制对象
	@percent：绘制圆环百分比, 范围[0, 100]
	@forecolor: 绘制圆环的前景色，颜色代码
	@bgcolor: 绘制圆环的背景色，颜色代码
	@data: 绘制数据
*/
  function drawMain(drawing_elem, percent, forecolor, bgcolor, isLinear, eleStyle) {
    const lineWidth = 13
    const context = drawing_elem.getContext('2d')
    const x = parseInt(eleStyle.width / 2)
    const y = parseInt(eleStyle.height / 2)
    // const radius = width - lineWidth
    const startNum = 1.5 * Math.PI
    const endNum = (startNum - (2 * Math.PI) * (Number(percent.replace('%', '') / 100) || 0))
    const percents = ((Number((percent.replace('%', '')) || 0)))
    // 先清理下
    context.clearRect(0, 0, x * 2, y * 2)

    // 绘制背景圆圈
    function backgroundCircle() {
      context.save()
      context.beginPath()
      context.lineWidth = lineWidth // 设置线宽
      context.lineCap = 'round'
      context.strokeStyle = bgcolor
      // 用于绘制context.arc(x坐标，y坐标，半径，起始角度，终止角度，顺时针/逆时针)
      context.arc(x, y, x / 2, 0, Math.PI * 2, false)
      context.stroke()
      context.closePath()
      context.restore()
    }
    function text(n) {
      context.save() // save和restore可以保证样式属性只运用于该段canvas元素
      context.fillStyle = '#303133'
      const font_size = 20
      context.textAlign = 'center'
      context.font = font_size + 'px Helvetica'
      context.fillText((Number(n) || 0) + '%', x, y + 10)
      context.restore()
    }

    // 绘制运动半圆环
    function foregroundCircle1() {
      context.save()
      context.lineWidth = lineWidth
      context.lineCap = 'round'
      const color = context.createLinearGradient(10, y / 3, x, y)
      color.addColorStop(0, forecolor[0])
      color.addColorStop(1, forecolor[1]) // forecolor[1]
      context.strokeStyle = isLinear ? color : forecolor
      context.beginPath()
      // 用于绘制圆弧context.arc(x坐标，y坐标，半径，起始角度，终止角度，顺时针/逆时针)
      context.arc(x, y, x / 2, startNum, endNum, true)
      context.stroke()
      context.closePath()
      context.restore()
    }

    backgroundCircle()
    if (Number(percents) > 0) {
      foregroundCircle1()
    }
    text(percents)
  }
</script>

<style lang="scss" scoped>
.title {
	padding: 0 10px;
	margin: 10px 0;
	color: #303133;
	font-size: 17px;
	line-height: 30px;
	font-weight: bold;
}
.pointer {
	cursor: pointer !important;
}
.canvas-list {
  text-align: center;
  .canvas-box {
    // height: 300px;
    width: 32%;
    display: inline-block;
    text-align: center;
    position: relative;
    canvas {
      transform: scale(.8)
    }
  }
  .canvas-text {
    position: absolute;
    width: 100%;
    margin-top: -50px;
    h5 {
      margin: 10px 0;
    }
    p {
      width: 60%;
      padding: 0;
      margin: 0 auto;
      display: flex;
      span {
        font-size: 12px;
        padding: 5px 0;
        text-align: left;
      }
      span:nth-child(1) {
        flex: 1;
        color:#909399;
      }
      span:nth-child(2) {
        width: 30%;
        text-align: right
      }
    }
  }
}
</style>
