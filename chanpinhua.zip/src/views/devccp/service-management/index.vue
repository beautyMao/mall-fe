<template>
  <el-card :body-style="{ padding: '0px' }" class="service-data" :style="servieStyleH">
    <div class="title pointer" @click="toPage">服务数据 <i class="el-icon-arrow-right" /></div>
    <div class="service">
      <div class="service-top">
        <service-data
          v-for="(item, index) in list"
          v-if="index < 3"
          :key="index"
          :class-name="item.class"
          :data="item"
          :style="servieStyle"
        />
        <!-- <service-data :data="lineupNumData" class-name="current_lineup_number" :style="servieStyle" />
        <service-data :data="abandonmentRate" class-name="abandonment_rate" :style="servieStyle" /> -->
      </div>
      <div class="service-middle">
        <service-data
          v-for="(item, index) in list"
          v-if="index > 2 && index < 6"
          :key="index"
          :class-name="item.class"
          :data="item"
          :style="servieStyle"
        />
        <!-- <service-data :data="serviceRateData" class-name="service-rate-data" class="service-rate-data" :style="servieStyle" />
        <service-data :data="allIntoData" class-name="all-into-data" class="all-into-data" :style="servieStyle" />
        <service-data :data="AHTData" class-name="aht-data" class="aht-data" :style="servieStyle" /> -->
      </div>
      <div class="service-middle">
        <service-data
          v-for="(item, index) in list"
          v-if="index > 5 && index < 9"
          :key="index"
          :class-name="item.class"
          :data="item"
          :style="servieStyle"
        />
        <!-- <service-data :data="lineupTimeData" class-name="lineup-time-data" class="lineup-time-data" :style="servieStyle" />
        <service-data :data="gaveupData" class-name="gaveupRateData" class="gaveup-data" :style="servieStyle" />
        <service-data :data="pickupRateData" class-name="pickup-rate-data" class="pickup-rate-data" :style="servieStyle" /> -->
      </div>
    </div>
  </el-card>
</template>
<script>
  import serviceData from './components/service-data'
  import {
    getServiceData
  } from '@/api/ccp/index'
  const ALL_SERCIVE_DATA = {
    'total_service_number': '总服务量',
    'current_lineup_number': '当前排队',
    'abandonment_rate': '放弃率',
    'repeated_call_48': '48h重复来电',
    'pick_up_number_30': '30s接起量',
    'service_level': '服务水平',
    'total_call_in_number': '总呼入量',
    'total_call_out_number': '总呼出量',
    'average_session_time': '平均会话时长',
    'average_wait_time': '平均等待时长',
    'abandonment_number': '放弃量',
    'satisfaction': '满意度',
    'robot_enter_number': '机器人进入量',
    'robot_turn_artificial_number': '机器人转人工量',
    'robot_turn_artificial_rate': '机器人转人工率'
  }
  export default {
    name: 'services-data',
    components: {
      serviceData
    },
    data() {
      return {
        list: [],
        allServiceData: {
          name: '总服务量',
          rate: 9999,
          class: 'total_service_number'
        },
        lineupNumData: {
          name: '当前排队',
          rate: 99,
          class: 'paidui'
        },
        gaveupRateData: {
          name: '放弃率',
          rate: 5.1,
          class: 'abandonment_rate'
        },
        servieStyle: '',
        servieStyleH: ''
      }
    },
    mounted() {
      if (!document.getElementsByClassName('dashboard-main')) return
      const dashboard_w = document.getElementsByClassName('dashboard-main')[0].scrollWidth
      const dashboard_h = document.getElementsByClassName('dashboard-main')[0].scrollHeight
      const service_h = document.getElementsByClassName('servcice-chart')[0].scrollHeight
      this.servieStyle = `width: ${dashboard_w / 3 - 10}px;`
      this.servieStyleH = `height: ${dashboard_h - service_h - 70}px;`
    },
    methods: {
      toPage() {
        const query = { ...this.$route.query || {}}
        this.$router.push({
          path: `service-info/${this.$route.query.businessID}`,
          query
        })
      },
      _getServiceData() {
        getServiceData(this.$route.query.businessID).then((response) => {
          this.list = []
          if (response.statusCode === 200) {
            response.data.map(item => {
              for (const key in item) {
                if (ALL_SERCIVE_DATA.hasOwnProperty(key)) {
                  const obj = item
                  obj.name = ALL_SERCIVE_DATA[key]
                  obj.class = key
                  obj.rate = item[key]
                  delete obj[key]
                  this.list.push(obj)
                }
              }
            })
          }
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
.title {
	padding: 0 10px;
	margin: 10px 0;
	color: #303133;
	font-size: 17px;
	line-height: 30px;
	font-weight: bold;
}
.pointer {
	cursor: pointer !important;
}
.service-data {
	position: relative;
	.service {
	}
	.service-top, .service-middle {
		display: flex;
		margin:  10px 0;
	}
}

</style>

