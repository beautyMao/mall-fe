<template>
  <el-card :body-style="{ padding: '0px' }" class="mapEchart">
    <div v-if="showTitle" class="title pointer" @click="toPage">{{ title }}<i class="el-icon-arrow-right" /></div>
    <div v-if="isShow" id="myEchart" ref="myEchart" :class="isShow ? 'top':'bottom'" :style="mapEchartStyle" />
    <!-- <mapWarning v-else ref="myWeatherEchart" :data-list="weatherdata" :is-show="isShow" /> -->
  </el-card>
</template>
<script>
  import echarts from 'echarts'
  import 'echarts/map/js/china'
  import mapWarning from './components/mapWarning'
  import { getWeatherBreakdown } from '@/api/ccp/index'
  export default {
    name: 'map-chart',
    components: {
      mapWarning
    },
    props: {
      showTitle: {
        type: Boolean,
        default: true
      },
      isShow: {
        type: Boolean,
        default: true
      }
    },
    data() {
      return {
        chart: null,
        customWeatherData: [],
        title: '地域来电分析',
        type: 'a',
        usercall: '地域来电量',
        PhoneCallData: [],
        orderData: [],
        WarnCallData: [],
        WarnOrderData: [],
        weatherdata: [],
        myChart: null,
        // isShow: true,
        color: ['#1890FF', '#BFB0FF', '#005AAD', '#7EF7FF', '#DAF0FF'],
        mapEchartStyle: ''
      }
    },
    watch: {
      isShow() {
        if (this.isShow === true) {
          // this._getPhoneCallData()
        }
      }
    },
    mounted() {
      const dashboard_w = document.getElementsByClassName('mapEchart')[0].scrollWidth
      // const dashboard_h = document.getElementsByClassName('mapEchart')[0].clientHeight
      this.mapEchartStyle = `height: ${dashboard_w}px;`
    },
    methods: {
      handleCommand(command) {
        if (command === 'a') {
          this.type = command
          this.title = '地域来电监控'
          this.isShow = true
        }
        if (command === 'b') {
          this.isShow = false
          this.type = command
          this.title = '全国天气监控'
        }
      },
      toPage() {
        const query = { ...(this.$route.query || {}) }
        this.$router.push({
          path: `mapchart-info/${this.$route.query.businessID}`,
          query
        })
      },
      _getPhoneCallData(pro, isReload) {
        this.PhoneCallData = []
        getWeatherBreakdown(this.$route.query.businessID, pro).then(res => {
          const order_num_data = res.data.order_num // 前五来电统计
          const province_data = res.data.province // 所有来电统计
          order_num_data.map(item => {
            item.value = item.count
          })
          province_data.map(item => {
            item.value = item.count
          })
          this.orderData = order_num_data
          this.PhoneCallData = province_data
          this.PhoneCallData.sort((x, y) => y.value - x.value)
          this.orderData.sort((x, y) => y.value - x.value)
          if (!isReload) {
            this.initMapChart()
          }
        })
      },
      initMapChart() {
        this.myChart = echarts.init(document.getElementById('myEchart'))
        this.myChart.setOption({
          tooltip: {
            trigger: 'item'
          },
          visualMap: {
            min: 0,
            max: this.PhoneCallData.length ? this.PhoneCallData[0].value || 1 : 1,
            left: '0px',
            top: '18%',
            // text: ['High', 'Low'], // 文本，默认为数值文本
            itemWidth: 16,
            itemHeight: 100,
            calculable: true,
            // orient: 'horizontal',
            inRange: {
              color: ['#e0edfa', '#1890FF']
            }
          },
          series: [
            {
              name: '地域来电量',
              type: 'map',
              mapType: 'china',
              left: '15%',
              top: '0',
              // roam: true,
              aspectScale: 0.85,
              label: {
                normal: {
                  show: true,
                  textStyle: {
                    fontSize: 6,
                    color: '#606266'
                  }
                },
                emphasis: {
                  show: true
                }
              },
              itemStyle: {
                normal: {
                  label: { show: true },
                  borderWidth: 0.5, // 省份的边框宽度
                  borderColor: '#999', // 省份的边框颜色
                  areaColor: '#fff', // 地图背景颜色
                  color: '#fff',
                  fontSize: 8
                },
                emphasis: {
                  label: { show: true },
                  areaStyle: {
                    color: '#DAF0FF' // 选中状态的地图板块颜色
                  },
                  areaColor: '#DAF0FF' // 选中状态的地图板块颜色
                }
              },
              data: this.PhoneCallData
            }
          ]
        })
        if (this.showTitle) return // 首页不用点击
        this.$nextTick(() => {
          this.myChart.on('click', (params) => {
            if (params.name.length > 0) {
              this.$emit('getCityCalls', params.name)
            }
          })
        })
      },
      handleVisibleChange(val) {
        if (val) {
          this.$refs.box.className = 'box box-focus'
        } else {
          this.$refs.box.className = 'box'
        }
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.title {
	padding: 0 10px;
	margin: 10px 0;
	color: #303133;
	font-size: 17px;
	line-height: 30px;
	font-weight: bold;
}
.pointer {
	cursor: pointer !important;
}
.mapEchart {
  position: relative;
  overflow: hidden;
  // height: 100%;
  .el-dropdown-link {
    position: relative;
    .box {
      position: absolute;
      left: 110px;
      top: 10px;
      width: 0;
      height: 0;
      transform-origin: center;
      transition: transform .3s;
      border-top: 8px solid #6675FF;
      border-right: 8px solid  rgba(0,0,0,0);
      border-left: 8px solid  rgba(0,0,0,0);
    }
    .box-focus {
      transform: rotate(180deg);
      transition: transform .3s
    }
  }
  .hot-city {
    position: absolute;
    right: 0;
    bottom: 0;
    width: 120px;
    height: 204px;
    background-color: #F5F7FA;
    text-align: center;
    color: #303133;
    font-size: 12px;
    line-height: 28px;
    ul {
      font-size: 10px;
      color: #606266;
      li {
        display: flex;
      }
      li .colorList {
        width: 27.5px;
        height: 27.5px;
        transform: scale(0.5);
        border-radius: 2px;
      }
      li span {
        flex: 1
      }
    }
  }
}
#myEchart {
  width: 100%;
  height: 100%;
  position: absolute;
  top: 50%;
  margin-top: -25%;
  transform: scale(.9)
}
.top{
  position: absolute;
  left: 0;
  top: 30px;
}
.bottom {
  position: absolute;
  left: -100%;
  top: 30px;
}
.echart-title {
    color: #303133;
    font-size: 17px;
    line-height: 30px;
    font-weight: bold;
  }
.getInfo {
  color:#1990ff;
  // width: 100%;
  position: absolute;
  right: 0;
  top: 0;
  text-align: right;
  font-size: 12px;
  z-index: 99999;
  span {
    cursor: pointer;
  }
}
</style>
