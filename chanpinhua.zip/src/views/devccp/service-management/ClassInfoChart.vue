<template>
  <el-card class="w100" :body-style="{ padding: '0px 0px 0px 0px' }">
    <div v-if="classChart.length" class="class">
      <div :id="className" class="class-chart" />
      <div class="hot-class flex-wrp flex-center">
        <ul class="pd15">
          <li v-for="(item, index) in classChart" :key="index">
            <span :style="{background: color[index]}" />
            <span :style="{marginLeft: '-20px'}">{{ item.name }}</span>
            <span>{{ item.value }} </span>
            <span>{{ getPercent(item.value, classChartMax) }}</span>
          </li>
        </ul>
      </div>
    </div>
    <div v-else class="null-info h100 flex-wrp flex-center">
      <div class="icon">
        <svg-icon icon-class="null" class="null" />
        <span class="name">暂无数据</span>
      </div>
    </div>
  </el-card>
</template>
<script>
  import echarts from 'echarts'
  import { getLabels, getWeatherBreakdown } from '@/api/ccp/index'
  export default {
    name: 'class-info-chart',
    props: {
      className: {
        type: String,
        default: 'class-chart'
      },
      title: {
        type: String,
        default: '问题分类'
      },
      showTitle: {
        type: Boolean,
        default: true
      }
    },
    data() {
      return {
        color: ['#1890FF', '#BFB0FF', '#005AAD', '#7EF7FF', '#DAF0FF', '#8B70FC'],
        classChart: [],
        wrapperStyle: ''
      }
    },
    computed: {
      classChartMax() {
        return this.classChart.map(item => item.value).reduce((prev, cur) => prev + cur)
      }
    },
    methods: {
      getPercent(num, total) {
        num = parseFloat(num)
        total = parseFloat(total)
        if (isNaN(num) || isNaN(total)) {
          return '-'
        }
        return total <= 0 ? '0%' : Math.round((Math.round(num / total * 10000) / 100.00)) + '%'
      },
      toPage() {
        const { businessID: businessId } = this.$route.query
        const query = { ...(this.$route.query || {}) }
        this.$router.push({
          path: `class-info/${businessId}`,
          query
        })
        // this.$router.push({
        //   path: `class-info/${businessId}`,
        //   query
        // })
      },
      _getNewCaseLabels(pro) { // 问题分类
        const { businessID: businessId } = this.$route.query
        this.classChart = []
        getLabels(businessId, pro).then(res => {
          this.classChart = res.data.map(item => {
            item.name = item.name[item.name.length - 1]
            return item
          })
          this.$nextTick(() => {
            this.classChart.length && this.initChart()
          })
        })
      },
      _getWeatherBreakdown(pro) { // 来电量
        const { businessID: businessId } = this.$route.query
        this.classChart = []
        getWeatherBreakdown(businessId, pro).then(res => {
          this.classChart = res.data.order_num
          this.classChart.map(item => {
            item.value = item.count
          })
          this.initChart()
        })
      },
      handleuserclass() {
        if (!this.classChart.length) return
        // 分类
        const query = { ...(this.$route.query || {}) }
        if (this.classChart[0].name === '其他' && this.classChart[0].value === 0) return
        this.$router.push({
          path: `/devccp-management/case/${Number(this.$route.params.id)}${
            this.$route.query.accessID
          }`,
          query
        })
      },
      initChart() {
        this.chart = echarts.init(document.getElementById(this.className))
        this.classChart.sort((x, y) => y.value - x.value)
        this.chart.setOption({
          color: this.color,
          tooltip: {
            trigger: 'item',
            formatter: '{b} : {c} <br/>({d}%)',
            position: [0, 0],
            extraCssText: 'white-space:pre-wrap'
          },
          series: [
            {
              name: '未激活',
              type: 'pie',
              radius: ['35%', '55%'],
              center: ['30%', '50%'],
              avoidLabelOverlap: true,
              labelLine: {
                normal: {
                  show: true
                }
              },
              label: {
                normal: {
                  position: 'outside',
                  formatter: '{d}%',
                  color: '#000'
                }
              },
              data: this.classChart
            }
          ]
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
.pointer {
	cursor: pointer !important;
}
.class {
  position: relative;
  width: 100%;
  height: calc(100%);
  .class-chart{
    height: 100%;
    div {
      height: 100%;
    }
    canvas {
      height: 100%;
    }
  }
}
.hot-class {
  position: absolute;
  right: 15%;
  top: 0;
  bottom: 0;
  text-indent: 20px;
  text-align: center;
  color: #303133;
  z-index: 999;
  font-size: 12px;
  line-height: 2;
  // max-width: 150px;
  overflow: hidden;
  ul {
    font-size: 14px;
    color: #606266;
    background-color: #f5f7fa;
    li {
      display: flex;
      margin: 2px 0;
      text-align: left;
      overflow: hidden;
      padding: 0 5px 0 0;
    }
    li span:nth-child(2) {
      text-overflow: ellipsis;
      overflow: hidden;
      white-space:nowrap;
      width: 240px;
    }
    li span:nth-child(1) {
      width: 27.5px;
      height: 27.5px;
      transform: scale(0.4);
      border-radius: 2px;
    }
    li span:nth-child(3) {
      flex: 1;
      border-radius: 2px;
    }
  }
}
.null-info {
  // position: absolute;
  // left: 0;
  // right: 0;
  // top: 50px;
  // bottom: 0;
  // margin: auto;
  display: flex;
  .icon {
    display: flex;
    flex-direction: column;
    justify-content: center;
    flex: 1;
    height: 150px;
    align-items: center;
    .null {
      width: 92px;
      height: 62px;
    }
    .name {
      margin-top: 18px;
      font-size: 14px;
      color: #D0DBEE;
    }
  }
}
</style>
