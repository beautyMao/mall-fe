<template>
  <el-card :body-style="{ padding: '30px 20px 0px 20px' }" class="class-info-data-column" :style="lineChartStyleH">
    <!-- :style="lineChartStyleH" -->
    <!-- <div class="title pointer" @click="toPage">服务量趋势 <i v-if="showTitle" class="el-icon-arrow-right" /></div> -->
    <!-- <div class="all-phone-num">总来电量 9,999</div> -->
    <div id="class-info-data-column" class="class-info-data-column" :style="chartStyleH" />
  </el-card>
</template>
<script>
  import echarts from 'echarts'
  import { formatNumberRgx } from '@/utils/index'
  export default {
    name: 'class-info-data-column',
    props: {
      showTitle: {
        type: Boolean,
        default: true
      }
    },
    data() {
      return {
        lineChartStyleH: '',
        chartStyleH: '',
        option: {
          title: {
            text: '情感会话数量和占比'
          },
          tooltip: {
            trigger: 'axis',
            // axisPointer: {
            //     type: 'shadow'
            // },
            backgroundColor: 'rgba(24,144,255,1)',
            axisPointer: {
              type: 'cross',
              label: {
                backgroundColor: '#6a7985'
              }
            }
          },
          grid: {
            left: '6%',
            right: '6%',
            bottom: 0,
            containLabel: true
          },
          xAxis: {
            type: 'value',
            show: false,
            boundaryGap: [0, 0.01]
          },
          yAxis: {
            type: 'category',
            data: []
          },
          series: {
            type: 'bar',
            barGap: 8,
            barWidth: '60%',
            data: [],
            color: function(params) {
              var colorList = [
                '#0B74D6', '#DAF0FF', '#BFB0FF', '#7EF7FF', '#1890FF',
                '#FE8463', '#9BCA63', '#FAD860', '#F3A43B', '#60C0DD',
                '#D7504B', '#C6E579', '#F4E001', '#F0805A', '#26C0C0'
              ]
              return colorList[params.dataIndex]
            },
            label: {
              normal: {
                position: 'right',
                show: true,
                formatter: function(params) {
                  return `${formatNumberRgx(params.data.value)} (${params.data.percentage})`
                }
              }
            }
          }
        }
      }
    },
    mounted() {
    },
    methods: {
      init(data) {
        const text = {
          extremely: '惊喜',
          moderately: '正常',
          not_at_all: '愤怒',
          slightly: '不满',
          very: '愉悦'
        }
        const thatMap = new Map(Object.entries(data).map(item => [item[0], { text: text[item[0]], value: item[1] }]))
        const thatData = [thatMap.get('extremely'), thatMap.get('very'), thatMap.get('moderately'), thatMap.get('slightly'), thatMap.get('not_at_all')].reverse()
        this.option.series.data = thatData.map(item => item.value).map(item => ({
          value: item,
          percentage: this.getPercent(item, Object.values(data).reduce((prev, cur) => prev + cur))
        }))
        this.option.yAxis.data = thatData.map(item => item.text)
        this.showChart()
      },
      getPercent(num, total) {
        num = parseFloat(num)
        total = parseFloat(total)
        if (isNaN(num) || isNaN(total)) {
          return '-'
        }
        return total <= 0 ? '0%' : Math.round((Math.round(num / total * 10000) / 100.00)) + '%'
      },
      toPage() {
        if (!this.showTitle) return
        const query = { ...(this.$route.query || {}) }
        this.$router.push({
          path: `service-volume-info/${this.$route.query.businessID}${this.$route.query.accessID}`,
          query
        })
      },
      showChart() {
        this.chart = echarts.init(document.getElementById('class-info-data-column'))
        this.chart.setOption(this.option)
      }
    }
  }
  // function getDiffGroup(num, min, max) {
  //   const res = []
  //   for (let i = min; i <= max; i++) {
  //     res.push(i)
  //   }
  //   const rst = []
  //   for (let i = 0; i < res.length; i += num) {
  //     rst.push(res.slice(i, i + num))
  //   }
  //   return rst
  // }
</script>
<style lang="scss" scoped>
.class-info-data-column {
  position: relative;
  // height: 50%;
  display: flex;
  flex-direction: column;

}
.title {
	padding: 0 10px;
	margin: 10px 0;
	color: #303133;
	font-size: 17px;
	line-height: 30px;
	font-weight: bold;
}
.pointer {
	cursor: pointer !important;
}
.all-phone-num {
	position: absolute;
	top: 30px;
	padding: 0 10px;
	margin: 10px 0;
	line-height: 40px;
	color: #909399;
	font-size: 14px;
}
.visual-map {
	position: absolute;
	right: 10px;
	top: 10px;
	p {
		font-size: 12px;
		padding: 5px;
		line-height: 15px;
		margin: 0;
		color: #909399;
		display: flex;
		:first-child {
			display: inline-block;
			width: 40px;
			height: 14px;
			background-color: #1890FF;
			margin-right: 5px;
		}
		.gaveupBg {
			background-color: #7EF7FF;
		}
		.gaveupRateBg {
			height: 2px;
			margin-top: 7px;
			background-color: #8B70FC;
		}
	}
}
.class-info-data-column {
  height: 100%;
  padding-bottom: 10px;
  flex: 1;
}

</style>

