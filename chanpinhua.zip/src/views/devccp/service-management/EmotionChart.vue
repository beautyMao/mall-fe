<template>
  <el-card :body-style="{ padding: '0px' }" style="position: relative" class="wrapper" :style="emotionStyle">
    <div v-if="showTitle" class="title pointer" @click="toPage">{{ title }}<i v-if="showTitle" class="el-icon-arrow-right" /></div>
    <div v-else class="title">{{ title }}</div>
    <div class="emotion">
      <div id="emotion-chart" class="emotion-chart" />
      <div class="hot-emotion">
        <ul>
          <li v-for="(item,index) in Emdata" :key="index">
            <span :style="{background: color[index]}" />
            <span>{{ item.name }}</span>
            <span>{{ item.value }} </span>
          </li>
        </ul>
      </div>
    </div>
    <div v-if="!Emdata.length" class="null-info">
      <div class="icon">
        <svg-icon icon-class="null" class="null" />
        <span class="name">暂无数据</span>
      </div>
    </div>
  </el-card>
</template>
<script>
  import echarts from 'echarts'
  import { getEmotionData } from '@/api/ccp/index'
  const EMOTION_TYPE = {
    moderately: '正常',
    very: '愉悦',
    extremely: '惊喜',
    slightly: '不满',
    not_at_all: '愤怒'
  }
  export default {
    name: 'emotion-chart',
    props: {
      emotionData: {
        type: Array,
        default: function() {
          return []
        }
      },
      showTitle: {
        type: Boolean,
        default: true
      }
    },
    data() {
      return {
        chart: null,
        Emdata: [],
        nullEmdata: [],
        title: '用户情感监控',
        color: ['#1890FF', '#BFB0FF', '#005AAD', '#7EF7FF', '#DAF0FF'],
        list: [
          // {
          //   name: '正常',
          //   value: '0',
          //   color: '#1890FF'
          // },
          // {
          //   name: '愉快',
          //   value: '0',
          //   color: '#BFB0FF'
          // },
          // {
          //   name: '惊喜',
          //   value: '0',
          //   color: '#005AAD'
          // },
          // {
          //   name: '不满',
          //   value: '0',
          //   color: '#7EF7FF'
          // },
          // {
          //   name: '愤怒',
          //   value: '0',
          //   color: '#DAF0FF'
          // }
        ],
        emotionStyle: ''
      }
    },
    mounted() {
      const dashboard_h = document.getElementsByClassName('dashboard-main')[0].scrollHeight
      this.emotionStyle = `height: ${dashboard_h / 3 - 20}px`
    },
    methods: {
      toPage() {
        const query = { ...(this.$route.query || {}) }
        this.$router.push({
          path: `/devccp-management/emotion-info`,
          query
        })
      },
      initChart() {
        getEmotionData(this.$route.query.businessID).then(response => {
          if (response.statusCode === 200) {
            this.chart = echarts.init(document.getElementById('emotion-chart'))
            this.Emdata = []
            this.nullEmdata = []
            for (const key in response.data) {
              if (EMOTION_TYPE[key]) {
                this.Emdata.push({
                  value: response.data[key],
                  name: EMOTION_TYPE[key]
                })
                if (response.data[key]) {
                  this.nullEmdata.push({
                    value: response.data[key],
                    name: EMOTION_TYPE[key]
                  })
                }
              }
            }
            if (!this.nullEmdata.length) {
              this.Emdata = []
            }
            this.Emdata.sort((x, y) => y.value - x.value)
            this.nullEmdata.sort((x, y) => y.value - x.value)
            this.chart.setOption({
              color: this.color,
              tooltip: {
                trigger: 'item',
                formatter: '{b} : {c} ({d}%)',
                position: [0, 0],
                extraCssText: 'width:150px; white-space:pre-wrap'
              },
              series: [
                {
                  name: '未激活',
                  type: 'pie',
                  radius: ['35%', '55%'],
                  center: ['30%', '50%'],
                  avoidLabelOverlap: true,
                  labelLine: {
                    normal: {
                      show: true
                    }
                  },
                  label: {
                    normal: {
                      position: 'outside',
                      formatter: '{d}%',
                      color: '#000'
                    }
                  },
                  data: this.nullEmdata
                }
              ]
            })
          }
        })
      }
    }
  }

</script>
<style lang="scss" scoped>
.title {
	padding: 0 10px;
	margin: 10px 0;
	color: #303133;
	font-size: 17px;
	line-height: 30px;
	font-weight: bold;
}
.wrapper {
  /deep/ .el-card__body {
    height: calc(100% - 10px);
  }
}
.pointer {
	cursor: pointer !important;
}
.emotion {
  position: relative;
  width: 100%;
  height: calc(100% - 50px);
  .el-card__body {
    height: 100%;
  }
  .emotion-chart {
    height: 100%;
    div {
      height: 100%;
    }
    canvas {
      height: 100%;
    }
  }
  .hot-emotion {
    position: absolute;
    right: 10px;
    top: 10%;
    text-indent: 20px;
    background-color: #f5f7fa;
    text-align: center;
    color: #303133;
    font-size: 12px;
    line-height: 28px;
    ul {
      font-size: 10px;
      color: #606266;
      li {
        display: flex;
        margin: 2px 0;
        text-align: left;
        overflow: hidden;
        padding: 0 5px 0 0;
      }
      li span:nth-child(2) {
        text-overflow: ellipsis;
        overflow: hidden;
        white-space:nowrap;
        width: 110px;
      }
      li span:nth-child(1) {
        width: 27.5px;
        height: 27.5px;
        transform: scale(0.5);
        border-radius: 2px;
      }
      li span:nth-child(3) {
        flex: 1;
        border-radius: 2px;
      }
    }
  }
  .emotion-title {
    color: #303133;
    font-size: 17px;
    line-height: 30px;
    font-weight: bold;
  }
}
.null-info {
  position: absolute;
  left: 0;
  right: 0;
  top: 50px;
  bottom: 0;
  margin: auto;
  display: flex;
  background: #fff;
  .icon {
    display: flex;
    flex-direction: column;
    justify-content: center;
    flex: 1;
    height: 150px;
    align-items: center;
    .null {
      width: 92px;
      height: 62px;
    }
    .name {
      margin-top: 18px;
      font-size: 14px;
      color: #D0DBEE;
    }
  }
}
</style>

