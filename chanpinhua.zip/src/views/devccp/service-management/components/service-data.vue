<template>
  <div class="count" :class="className">
    <div class="count-content">
      <div class="qicon"><svg-icon :icon-class="data.class || 'current_lineup_number'" /></div>
      <div class="rate">{{ data.rate }}</div>
      <div class="name">{{ data.name }}</div>
    </div>
  </div>
</template>
<script>
  export default {
    name: 'count',
    props: {
      className: {
        type: String,
        default: ''
      },
      data: {
        type: Object,
        required: true
      }
    },
    data() {
      return {}
    },
    mounted() {},
    methods: {}
  }
</script>
<style lang="scss" scoped>
.count {
	margin: 5px;
	border-radius: 3px;
	.count-content {
		text-align: center;
		width: 100%;
		height: 100%;
		display: flex;
		flex-direction: column;
		.name {
			font-size: 12px;
			line-height: 32px;
			color: #606266;
		}
		.qicon {
			margin-bottom: 10px;
		}
		.rate {
			color: #303133;
			font-size: 16px;
			line-height: 26px;
		}
	}
}
</style>

