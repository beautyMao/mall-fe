<template>
  <el-card :body-style="{ padding: '0px' }" class="echart">
    <div class="legend">
      <!-- <el-row :gutter="14">
        <el-col :span="12">
          <div class="legendItem" @click="getRainWeather('rainstorm1')">
            <span class="legend-desc rain-desc">台风</span>
            <span
              class="dot"
              :class="{'singlecolor': !togglerainstorm, 'rainstorm1':togglerainstorm }"
            />
          </div>
        </el-col>
      </el-row> -->
      <el-row :gutter="14">
        <el-col :span="12">
          <div class="legendItem" @click="getLightingWeather('rainstorm')">
            <span>雷电</span>
            <span
              class="dot"
              :class="{'singlecolor': !togglelightning, 'rainstorm':togglelightning }"
            />
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="14">
        <el-col :span="12">
          <div class="legendItem" @click="getRainWeather('lightning')">
            <span class="legend-desc rain-desc">暴雨</span>
            <span
              class="dot"
              :class="{'singlecolor': !togglerainstorm, 'lightning':togglerainstorm }"
            />
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="14">
        <el-col :span="12">
          <div class="legendItem" @click="getColdSpellWeather('cold_spell')">
            <span>降温</span>
            <span
              class="dot"
              :class="{'singlecolor': !togglecold_spell, 'cold_spell':togglecold_spell }"
            />
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="14">
        <el-col :span="12">
          <div class="legendItem" @click="getSnowWeather('snowstorm')">
            <span>暴雪</span>
            <span
              class="dot"
              :class="{'singlecolor': !togglesnowstorm, 'snowstorm':togglesnowstorm }"
            />
          </div>
        </el-col>
      </el-row>
      <el-row :gutter="14">
        <el-col :span="12">
          <div class="legendItem" @click="getFrostWeather('frost')">
            <span>结冰</span>
            <span class="dot" :class="{'singlecolor': !togglefrost, 'frost':togglefrost }" />
          </div>
        </el-col>
      </el-row>
    </div>
    <div id="myEchart" ref="myEchart" style="width: 100%; min-height: 400px;" />
  </el-card>
</template>
<script>
  import echarts from 'echarts'
  import 'echarts/map/js/china.js'
  import { getWeatherDistribute } from '@/api/ccp/pickup'
  export default {
    name: 'map-warning',
    props: {
      dataList: {
        type: Array,
        default: function() {
          return []
        }
      },
      isShow: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        chart: null,
        customWeatherData: [],
        provincesCode: [
          {
            value: [],
            weathers: [],
            name: '北京'
          },
          {
            value: [],
            weathers: [],
            name: '上海'
          },
          {
            value: [],
            weathers: [],
            name: '天津'
          },
          {
            value: [],
            weathers: [],
            name: '重庆'
          },
          {
            value: [],
            weathers: [],
            name: '黑龙江'
          },
          {
            value: [],
            weathers: [],
            name: '吉林'
          },
          {
            value: [],
            weathers: [],
            name: '辽宁'
          },
          {
            value: [],
            weathers: [],
            name: '内蒙古'
          },
          {
            value: [],
            weathers: [],
            name: '河北'
          },
          {
            value: [],
            weathers: [],
            name: '山西'
          },
          {
            value: [],
            weathers: [],
            name: '陕西'
          },
          {
            value: [],
            weathers: [],
            name: '山东'
          },
          {
            value: [],
            weathers: [],
            name: '新疆'
          },
          {
            value: [],
            weathers: [],
            name: '西藏'
          },
          {
            value: [],
            weathers: [],
            name: '青海'
          },
          {
            value: [],
            weathers: [],
            name: '甘肃'
          },
          {
            value: [],
            weathers: [],
            name: '宁夏'
          },
          {
            value: [],
            weathers: [],
            name: '河南'
          },
          {
            value: [],
            weathers: [],
            name: '江苏'
          },
          {
            value: [],
            weathers: [],
            name: '湖北'
          },
          {
            value: [],
            weathers: [],
            name: '浙江'
          },
          {
            value: [],
            weathers: [],
            name: '安徽'
          },
          {
            value: [],
            weathers: [],
            name: '福建'
          },
          {
            value: [],
            weathers: [],
            name: '江西'
          },
          {
            value: [],
            weathers: [],
            name: '湖南'
          },
          {
            value: [],
            weathers: [],
            name: '贵州'
          },
          {
            value: [],
            weathers: [],
            name: '四川'
          },
          {
            value: [],
            weathers: [],
            name: '广东'
          },
          {
            value: [],
            weathers: [],
            name: '云南'
          },
          {
            value: [],
            weathers: [],
            name: '广西'
          },
          {
            value: [],
            weathers: [],
            name: '海南'
          },
          {
            value: [],
            weathers: [],
            name: '云南'
          },
          {
            value: [],
            weathers: [],
            name: '澳门'
          },
          {
            value: [],
            weathers: [],
            name: '台湾'
          },
          {
            value: [],
            weathers: [],
            name: '南海诸岛'
          }
        ],
        data1: [],
        option: {
          tooltip: {
            trigger: 'item'
          },
          legend: {
            x: 'left',
            left: 10,
            selectedMode: false,
            data: ['雷电', '暴雨', '雾霾', '暴雪', '沙尘']
          },
          dataRange: {
            orient: 'horizontal',
            min: 0,
            max: 55000,
            text: ['高', '低'],
            splitNumber: 0
          },
          series: [
          ],
          animation: false
        },
        weatherdata: [],
        togglelightning: true,
        togglerainstorm: true,
        togglesnowstorm: true,
        togglefrost: true,
        togglecold_spell: true
      }
    },
    mounted() {
      this.init()
      this._getWeatherDistribute()
    // this.option.series[0].itemStyle.normal.label.show = this.provName
    },
    beforeDestroy() {
      if (!this.chart) {
        return
      }
      this.chart.dispose()
      this.chart = null
    },
    methods: {
      init() {
        this.weatherdata = this.dataList
        let color = ''
        this.weatherdata.forEach(ele => {
          const weathers = new Set()
          if (ele.warning.length > 0) {
            ele.warning.forEach(inner => {
              weathers.add(inner.signal)
            })
          }
          switch (ele.warning[0].cate) {
          // case 'rainstorm1':
          //   color = '#4AC0E0'
          //   break
          case 'rainstorm':
            color = '#63ABED'
            break
          case 'lightning':
            color = '##FFCC00'
            break
          case 'cold_spell':
            color = '#BDC6DF'
            break
          case 'snowstorm':
            color = '#D1E8FF'
            break
          case 'frost':
            color = '#B3D9FF'
            break
          }
          this.customWeatherData.push({
            name: ele.province,
            value: ele.warning,
            weathers: Array.from(weathers),
            itemStyle: {
              normal: {
                color: color,
                label: {
                  show: true,
                  textStyle: {
                    color: '#fff',
                    fontSize: 15
                  }
                }
              },
              emphasis: {
                // 也是选中样式
                borderWidth: 1,
                borderColor: '#ccc',
                areaColor: '#DAF0FF',
                label: {
                  show: true,
                  textStyle: {
                    color: 'blue'
                  }
                }
              }
            }
          })
        })
        this.drawChart()
      },
      // 获取暴雨
      getRainWeather(val) {
        if (this.togglerainstorm) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data)
          this.togglerainstorm = false
        } else {
          this._getWeatherDistribute('')
          this.togglerainstorm = true
        }
        this.togglelightning = true
        this.togglesnowstorm = true
        this.togglefrost = true
        this.togglecold_spell = true
      },
      getLightingWeather(val) {
        if (this.togglelightning) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data)
          this.togglelightning = false
        } else {
          this._getWeatherDistribute('')
          this.togglelightning = true
        }
        this.togglerainstorm = true
        this.togglesnowstorm = true
        this.togglefrost = true
        this.togglecold_spell = true
      },
      getSnowWeather(val) {
        if (this.togglesnowstorm) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data)
          this.togglesnowstorm = false
        } else {
          this._getWeatherDistribute('')
          this.togglesnowstorm = true
        }
        this.togglerainstorm = true
        this.togglelightning = true
        this.togglefrost = true
        this.togglecold_spell = true
      },
      getFrostWeather(val) {
        if (this.togglefrost) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data)
          this.togglefrost = false
        } else {
          this._getWeatherDistribute('')
          this.togglefrost = true
        }
        this.togglerainstorm = true
        this.togglelightning = true
        this.togglesnowstorm = true
        this.togglecold_spell = true
      },
      getColdSpellWeather(val) {
        if (this.togglecold_spell) {
          const data = {
            cate: val
          }
          this._getWeatherDistribute(data)
          this.togglecold_spell = false
        } else {
          this._getWeatherDistribute('')
          this.togglecold_spell = true
        }
        this.togglerainstorm = true
        this.togglelightning = true
        this.togglesnowstorm = true
        this.togglefrost = true
      },
      // 获取天气
      _getWeatherDistribute(data) {
        this.customWeatherData = []
        getWeatherDistribute(data)
          .then(res => {
            this.weatherdata = res.data
            let color = ''
            this.weatherdata.forEach(ele => {
              const weathers = new Set()
              if (ele.warning.length > 0) {
                ele.warning.forEach(inner => {
                  weathers.add(inner.signal)
                })
              }
              switch (ele.warning[0].cate) {
              case 'rainstorm1':
                color = '#4AC0E0'
                break
              case 'rainstorm':
                color = '#63ABED'
                break
              case 'lightning':
                color = '#FFCC00'
                break
              case 'cold_spell':
                color = '#BDC6DF'
                break
              case 'snowstorm':
                color = '#D1E8FF'
                break
              case 'frost':
                color = '#B3D9FF'
                break
              }
              this.customWeatherData.push({
                name: ele.province,
                value: ele.warning,
                weathers: Array.from(weathers),
                itemStyle: {
                  normal: {
                    color: color,
                    label: { show: true }
                  }
                }
              })
              this.data1 = []
              this.provincesCode.map(item => {
                this.customWeatherData.map(i => {
                  if (i.name === item.name) {
                    item.value = i.value
                    item.itemStyle = i.itemStyle
                    item.weathers = i.weathers
                  }
                })
              })
            })
            this.drawChart()
          })
          .catch(err => {
            console.error(err)
          })
      },
      drawChart() {
        const myChart = echarts.init(document.getElementById('myEchart'))
        myChart.setOption({
          tooltip: {
            trigger: 'item',
            formatter: function(params) {
              if (params.data) {
                return `${params.name}${params.data['weathers'].length !== 0 ? ':' : ''}${params.data['weathers'].join()}`
              }
            }
          },
          series: [
            {
              name: '',
              type: 'map',
              mapType: 'china',
              left: 'center',
              top: '10%',
              label: {
                normal: {
                  show: true,
                  textStyle: {
                    fontSize: 6,
                    color: '#606266'
                  }
                }
              },
              itemStyle: {
                normal: {
                  label: { show: true },
                  borderWidth: 0.5, // 省份的边框宽度
                  borderColor: '#999', // 省份的边框颜色
                  areaColor: '#fff', // 地图背景颜色
                  color: 'transparent',
                  fontSize: 8
                },
                emphasis: {
                  label: { show: false },
                  areaColor: '#DAF0FF' // 选中状态的地图板块颜色
                }
              },
              data: this.provincesCode
            }
          ]
        })
        myChart.on('click', (params) => {
          if (params.name.length > 0) {
            this.$emit('getCityCalls', params.name)
          }
        })
      },
      setName(Weathername, data) {
        var pData = []
        var pDataSet = new Set()
        var series = []
        for (const row in data) {
          for (const j in data[row].warning) {
            if (data[row].warning[j].signal === Weathername) {
              pData.push(data[row].province)
              pDataSet = new Set(pData)
            }
          }
        }
        for (const n in [...pDataSet]) {
          series.push({ name: [...pDataSet][n], value: 100 })
        }
        return series
      },
      // inchart() {
      // const accessID = this.$route.query.accessID
      // const businessID = this.$route.query.businessID
      // getweatherWarn(businessID, accessID).then(res => {
      //   this.option.series = []
      //   this.option.legend.data = []
      //   console.log(res.data)
      //   var provinceDate = []
      //   var weather = []
      //   var setweather = new Set()
      //   for (const item of res.data) {
      //     provinceDate.push(item)
      //     for (const row in item.warning) {
      //       weather.push(item.warning[row].signal)
      //       setweather = new Set(weather)
      //     }
      //   }
      //   for (const n in [...setweather]) {
      //     this.option.legend.data.push([...setweather][n])
      //     this.option.series.push(
      //       {
      //         name: [...setweather][n],
      //         type: 'map',
      //         mapType: 'china',
      //         selectedMode: 'multiple',
      //         itemStyle: {
      //           normal: { label: { show: true }},
      //           emphasis: { label: { show: true }}
      //         },
      //         data: this.setName([...setweather][n], provinceDate)
      //       }
      //     )
      //   }
      //   console.log(this.option.series)
      //   const myChart = echarts.init(this.$refs.myEchart) // 这里是为了获得容器所在位置
      //   myChart.setOption(this.option)
      //   // this.chinaConfigure()
      // })
      // },
      chinaConfigure() {
        const myChart = echarts.init(this.$refs.myEchart) // 这里是为了获得容器所在位置
        window.onresize = myChart.resize
        const _this = this
        function consoleb(param) {
          const selected = param.batch[0].selected
          const mapSeries = _this.option.series[0]
          const data = []
          const legendData = []
          for (let p = 0, len = mapSeries.data.length; p < len; p++) {
            const name = mapSeries.data[p].name
            if (selected[name]) {
              data.push({
                name: name,
                value: mapSeries.data[p].value
              })
              legendData.push(name)
            }
          }
          _this.$emit('mapclick', data)
          _this.option.legend.data = legendData
          myChart.setOption(_this.option, true)
        }
        myChart.on('mapselectchanged', consoleb)
        myChart.setOption(this.option, true)
      }
    }
  }
</script>
<style rel='stylesheet/scss' lang='scss' scoped>
.echart{position: relative;height: 100%;
  background: #ffffff;
}
#myEchart {
  height: 100%;
}
.legend {
  position: absolute;
  bottom: 10px;
  left: 10px;
  width: 240px;
  padding: 10px;
  z-index: 999;
  /deep/ .el-row {
    display: inline-block;
    margin-right: 0px
  }
  .legendItem {
    font-size: 14px;
    display: flex;

    cursor: pointer;
    .lengend-desc {
      display: inline-block;
      margin-right: 5px;
      font-size: 14px !important;
    }
  }
  .legendItem:nth-child(odd) {
    margin-right: 15px;
  }
  /deep/ .el-col-12 {
    width: auto;
  }
  .dot {
    // float: right;
    display: inline-block;
    width: 48px;
    height: 14px;
    margin-top: 3px;
    margin-left: 15px;
    border-radius: 2px;
  }
  .singlecolor {
    background: #c2c2c2;
  }
  .rainstorm1 {
    background: #4AC0E0;
  }
  .rainstorm1:hover {
    background: rgba(24, 144, 255, 0.5);
  }
  .lightning {
    background: rgba(24, 144, 255, 1);
  }
  .lightning:hover {
    background: rgba(24, 144, 255, 0.5);
  }
  .rainstorm {
    background: #FFCC00;
  }
  .rainstorm:hover {
    background: #c39e06;
  }
  .cold_spell {
    background: #BDC6DF;
  }
  .cold_spell:hover {
    background: rgba(0, 90, 173, 0.5);
  }
  .snowstorm {
    background: #D1E8FF;
  }
  .snowstorm:hover {
    background: rgba(191, 176, 255, 0.5);
  }
  .frost {
    background: #B3D9FF;
  }
  .frost:hover {
    background: rgba(218, 240, 255, 0.5);
  }
  .all {
    background: #000;
  }
}
</style>
