<template>
  <el-card :body-style="{ padding: '0px' }" style="position: relative" class="wrapper" :style="wrapperStyle">
    <div v-if="showTitle" class="title pointer" @click="toPage">{{ title }} <i v-if="showTitle" class="el-icon-arrow-right" /></div>
    <div v-else class="title">{{ title }}</div>
    <div class="class">
      <div :id="className" class="class-chart" />
      <div class="hot-class">
        <ul>
          <li v-for="(item,index) in nullClassChart" :key="index">
            <span :style="{background: color[index]}" />
            <span>{{ typeof item.name === 'string' ? item.name : item.name[item.name.length - 1] }}</span>
            <span>{{ item.value }} </span>
          </li>
        </ul>
      </div>
    </div>
    <div v-if="!nullClassChart.length" class="null-info">
      <div class="icon">
        <svg-icon icon-class="null" class="null" />
        <span class="name">暂无数据</span>
      </div>
    </div>
  </el-card>
</template>
<script>
  import echarts from 'echarts'
  import { getLabels, getWeatherBreakdown } from '@/api/ccp/index'
  export default {
    name: 'class-chart',
    props: {
      className: {
        type: String,
        default: 'class-chart'
      },
      title: {
        type: String,
        default: '问题分类'
      },
      showTitle: {
        type: Boolean,
        default: true
      }
    },
    data() {
      return {
        color: ['#1890FF', '#BFB0FF', '#005AAD', '#7EF7FF', '#DAF0FF', '#8B70FC'],
        classChart: [],
        nullClassChart: [],
        wrapperStyle: '',
        total: 0
      }
    },
    mounted() {
      const dashboard_h = document.getElementsByClassName('dashboard-main')[0].scrollHeight
      this.wrapperStyle = `height: ${dashboard_h / 3 - 20}px`
    },
    methods: {
      toPage() {
        const query = { ...(this.$route.query || {}) }
        this.$router.push({
          path: `/devccp-management/class-info`,
          query
        })
        // this.$router.push({
        //   path: `class-info`,
        //   query
        // })
      },
      _getNewCaseLabels(pro) { // 问题分类
        getLabels(this.$route.query.businessID, pro).then(res => {
          this.classChart = []
          this.nullClassChart = []
          this.classChart = res.data
          this.total = 0
          this.classChart.map(item => {
            this.total += item.value
          })
          this.classChart.map(item => {
            if (item.value > 0) {
              this.nullClassChart.push(item)
            }
          })
          this.initChart()
        })
      },
      _getWeatherBreakdown(pro) { // 来电量
        getWeatherBreakdown(this.$route.query.businessID, pro).then(res => {
          this.classChart = []
          this.nullClassChart = []
          this.classChart = res.data.order_num
          this.total = 0
          this.classChart.map(item => {
            this.total += item.count
            item.value = item.count
          })
          this.classChart.map(item => {
            if (item.count > 0) {
              this.nullClassChart.push(item)
            }
          })
          this.initChart()
        })
      },
      handleuserclass() {
        if (!this.classChart.length) return
        // 分类
        const query = { ...(this.$route.query || {}) }
        if (this.classChart[0].name === '其他' && this.classChart[0].value === 0) return
        this.$router.push({
          path: `/devccp-management/case/${this.$route.query.businessID}${
            this.$route.query.accessID
          }`,
          query
        })
      },
      initChart() {
        this.chart = echarts.init(document.getElementById(this.className))
        this.classChart.sort((x, y) => y.value - x.value)
        this.chart.setOption({
          color: this.color,
          tooltip: {
            trigger: 'item',
            // formatter: '{b} : {c} <br/>({d}%)',
            formatter: (classData) => {
              return `${classData.name}: ${classData.value}<br/> (${((classData.value / this.total) * 100).toFixed(2)}%)`
            },
            position: [0, 0],
            extraCssText: 'white-space:pre-wrap'
          },
          series: [
            {
              name: '未激活',
              type: 'pie',
              radius: ['35%', '55%'],
              center: ['30%', '50%'],
              avoidLabelOverlap: true,
              labelLine: {
                normal: {
                  show: true
                }
              },
              label: {
                normal: {
                  position: 'outside',
                  formatter: (classData) => {
                    return `${((classData.value / this.total) * 100).toFixed(2)}%`
                  },
                  color: '#000'
                }
              },
              data: this.nullClassChart
            }
          ]
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
.wrapper {
  // height: 175px;
  // height: 30%;
  /deep/ .el-card__body {
    height: calc(100% - 10px);
  }
}
.title {
	padding: 0 10px;
	margin: 10px 0;
	color: #303133;
	font-size: 17px;
	line-height: 30px;
	font-weight: bold;
}
.pointer {
	cursor: pointer !important;
}
.class {
  position: relative;
  width: 100%;
  height: calc(100% - 50px);
  .class-chart{
    height: 100%;
    div {
      height: 100%;
    }
    canvas {
      height: 100%;
    }
  }
}
.hot-class {
  position: absolute;
  right: 10px;
  top: 50%;
  margin-top: -20%;
  text-indent: 20px;
  background-color: #f5f7fa;
  text-align: center;
  color: #303133;
  z-index: 999;
  font-size: 12px;
  line-height: 28px;
  // max-width: 150px;
  overflow: hidden;
  ul {
    font-size: 10px;
    color: #606266;
    li {
      display: flex;
      margin: 2px 0;
      text-align: left;
      overflow: hidden;
      padding: 0 5px 0 0;
    }
    li span:nth-child(2) {
      text-overflow: ellipsis;
      overflow: hidden;
      white-space:nowrap;
      width: 100px;
    }
    li span:nth-child(1) {
      width: 27.5px;
      height: 27.5px;
      transform: scale(0.5);
      border-radius: 2px;
    }
    li span:nth-child(3) {
      flex: 1;
      border-radius: 2px;
    }
  }
}
.null-info {
  position: absolute;
  left: 0;
  right: 0;
  top: 50px;
  bottom: 0;
  margin: auto;
  display: flex;
  background: #fff;
  .icon {
    display: flex;
    flex-direction: column;
    justify-content: center;
    flex: 1;
    height: 150px;
    align-items: center;
    .null {
      width: 92px;
      height: 62px;
    }
    .name {
      margin-top: 18px;
      font-size: 14px;
      color: #D0DBEE;
    }
  }
}
</style>
