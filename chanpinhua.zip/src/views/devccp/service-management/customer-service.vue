<template>
  <el-card :body-style="{ padding: '0px' }" class="servcice-chart">
    <div class="title pointer" @click="toPage">客服数据 <i class="el-icon-arrow-right" /></div>
    <canvas id="myCanvas" class="myCanvas" />
    <div class="servcice_content">
      <div class="service ready">
        <span>就绪客服</span>
        <span style="font-weight: bold;color:#303133; font-size: 16px;">{{ serChart.online }}人</span>
      </div>
      <div class="service rest">
        <span>小休客服</span>
        <span style="font-weight: bold;color:#303133; font-size: 16px;">{{ serChart.rest }}人</span>
      </div>
      <div class="service hangup">
        <span>挂起客服</span>
        <span style="font-weight: bold;color:#303133; font-size: 16px;">{{ serChart.hangup }}人</span>
      </div>
    </div>
  </el-card>
</template>
<script>
  export default {
    name: 'customer-service',
    data() {
      return {
        serChart: {
          rest: 0,
          online: 0,
          hangup: 0,
          total: 0
        }
      }
    },
    watch: {
      serChart() {}
    },
    mounted() {
    },
    methods: {
      toPage() {
        const query = { ...(this.$route.query || {}) }
        this.$router.push({
          path: `customer-info/${this.$route.query.businessID}`,
          query
        })
      },
      initCanvas() {
        const canvas = document.getElementById('myCanvas')
        drawMain(canvas, this.serChart.total, '#606266', 'transparent', this.serChart)
      }
    }
  }
  /*
	@drawing_elem: 绘制对象
	@percent：绘制圆环百分比, 范围[0, 100]
	@forecolor: 绘制圆环的前景色，颜色代码
	@bgcolor: 绘制圆环的背景色，颜色代码
	@data: 绘制数据
*/
  function drawMain(drawing_elem, percent, forecolor, bgcolor, data) {
    const context = drawing_elem.getContext('2d')
    const lineWidth = 15
    const startNum = 3.45
    const endNum = 5.96
    const p1 = (endNum - startNum) * (data.hangup / data.total) + startNum
    const p2 = (endNum - startNum) * ((data.rest) / data.total) + p1
    // 绘制背景圆圈
    function backgroundCircle() {
      context.save()
      context.beginPath()
      context.lineWidth = lineWidth // 设置线宽
      context.lineCap = 'round'
      context.strokeStyle = bgcolor
      // 用于绘制context.arc(x坐标，y坐标，半径，起始角度，终止角度，顺时针/逆时针)
      context.arc(150, 130, 110, 0, Math.PI * 2, false)
      context.stroke()
      context.closePath()
      context.restore()
    }
    // 绘制运动半圆环
    function foregroundCircle1() {
      context.save()
      context.strokeStyle = '#DAF0FF'
      context.lineWidth = lineWidth
      context.lineCap = 'round'
      context.beginPath()
      // 用于绘制圆弧context.arc(x坐标，y坐标，半径，终止角度，起始角度，顺时针/逆时针)
      context.arc(150, 130, 110, 3.5, 5.98, false)
      context.stroke()
      context.closePath()
      context.restore()
    }
    // 绘制运动半圆环 挂起
    function foregroundCircleHangUp() {
      context.save()
      context.strokeStyle = '#866DF8'
      context.lineWidth = lineWidth
      context.lineCap = 'round'
      context.beginPath()
      // 用于绘制圆弧context.arc(x坐标，y坐标，半径，终止角度，起始角度，顺时针/逆时针)
      context.arc(150, 130, 110, p1, startNum, true)
      context.stroke()
      context.closePath()
      context.restore()
    }
    // 绘制运动半圆环 小休
    function foregroundCircleRest() {
      context.save()
      context.strokeStyle = '#7EF7FF'
      context.lineWidth = lineWidth
      context.lineCap = 'round'
      context.beginPath()
      // 用于绘制圆弧context.arc(x坐标，y坐标，半径，终止角度，起始角度，顺时针/逆时针)
      context.arc(150, 130, 110, p2, p1, true)
      context.stroke()
      context.closePath()
      context.restore()
    }
    // 绘制运动半圆环 就绪
    function foregroundCircleReady() {
      context.save()
      context.strokeStyle = '#1890FF'
      context.lineWidth = lineWidth
      context.lineCap = 'round'
      context.beginPath()
      // 用于绘制圆弧context.arc(x坐标，y坐标，半径，终止角度，起始角度，顺时针/逆时针)
      context.arc(150, 130, 110, endNum, p2, true)
      context.stroke()
      context.closePath()
      context.restore()
    }
    // 绘制文字
    function text(n) {
      context.save() // save和restore可以保证样式属性只运用于该段canvas元素
      context.fillStyle = forecolor
      const font_size = 24
      context.font = 14 + 'px Helvetica'
      context.textAlign = 'center'
      // const text_width = context.measureText(n.toFixed(0) + '%').width
      context.fillText('合计', 150, 70)
      context.font = font_size + 'px Helvetica'
      context.textAlign = 'center'
      context.fillText(n.toFixed(0) + '人', 135 + 20, 105)
      context.restore()
    }
    context.clearRect(0, 0, drawing_elem.width, drawing_elem.height)
    text(percent)
    backgroundCircle()
    foregroundCircle1()
    foregroundCircleReady() // 3
    foregroundCircleRest() // 2
    foregroundCircleHangUp() // 1
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  .servcice-chart {
    display: flex;
    justify-content: center;
    position: relative;
    // padding-bottom: 40px;
    /deep/ .el-card__body {
      width: 100% !important;
    }
    .myCanvas {
      width: 100%;
      margin: 0 auto;
    }
  }
  .title {
    padding: 0 10px;
    margin: 10px 0;
    color: #303133;
    font-size: 17px;
    line-height: 30px;
    font-weight: bold;
  }
  .pointer {
    cursor: pointer !important;
  }
	.servcice_content {
		// position: absolute;
		// left: 0;
		// bottom: 5%;
		display: flex;
		width: 80%;
		margin: 0 10%;
		.service {
			flex: 1;
			text-align: center;
			color: #606266;
			span {
				font-size: 14px;
				display: block;
				line-height: 26px;
			}
		}
	}
</style>
