<template>
  <el-card :body-style="{ padding: '0px' }" class="all-service-data" :style="lineChartStyleH">
    <!-- :style="lineChartStyleH" -->
    <div class="title pointer" @click="toPage">业务趋势 <i v-if="showTitle" class="el-icon-arrow-right" /></div>
    <!-- <div class="all-phone-num">总来电量 9,999</div> -->
    <div class="visual-map">
      <p><span /><span>服务量</span></p>
      <p><span class="gaveupBg" /><span>放弃量</span></p>
      <p><span class="gaveupRateBg" /><span>放弃率</span></p>
    </div>
    <div id="line-chart" class="line-chart" :style="chartStyleH" />
  </el-card>
</template>
<script>
  import echarts from 'echarts'
  import {
    getBusinessesTrend
  } from '@/api/ccp/index'
  export default {
    name: 'all-service-data',
    props: {
      showTitle: {
        type: Boolean,
        default: true
      }
    },
    data() {
      return {
        lineChartStyleH: '',
        chartStyleH: '',

        option: {
          color: ['#2295FF', '#7EF7FF', '#8B70FC'],
          tooltip: {
            trigger: 'axis',
            formatter: (params) => {
              let res
              // if (this.showTitle) {
              //   res = `${params[0].dataIndex * 4}: 00 - ${params[0].name}`
              // } else {
              // }
              res = `${params[0].name} - ${params[0].dataIndex + 1}: 00`
              res += `<br/>${params[0].seriesName}: ${params[0].value}`
              res += `<br/>${params[1].seriesName}: ${params[1].value}`
              res += `<br/>${params[2].seriesName}: ${(params[2].value).toFixed(2) || 0}%`
              return res
            },
            backgroundColor: '#1890FF',
            axisPointer: {
              type: 'cross',
              label: {
                backgroundColor: '#6a7985'
              }
            }
          },
          grid: {
            left: '6%',
            right: '6%',
            bottom: 0,
            containLabel: true
          },
          xAxis: [
            {
              type: 'category',
              data: [],
              axisLine: {
                onZero: false,
                lineStyle: {
                  color: '#666666'
                }
              },
              axisTick: {
                alignWithLabel: true
              },
              axisPointer: {
                type: 'shadow'
              }
            }
          ],
          yAxis: [
            {
              type: 'value',
              axisLabel: {
                interval: 0
                // formatter: '{value}' // 刻度标签的内容格式器
              }
            },
            {
              type: 'value',
              splitLine: {
                show: false
              },
              axisLabel: {
                formatter: '{value} %'
              }
            }
          ],
          series: [
            {
              name: '服务量',
              type: 'bar',
              barGap: 8,
              barWidth: '80%',
              stack: '数量',
              data: []
            },
            {
              name: '放弃量',
              type: 'bar',
              barGap: 8,
              barWidth: '80%',
              stack: '数量',
              data: []
            },
            {
              name: '放弃率',
              type: 'line',
              yAxisIndex: 1,
              smooth: true,
              // symbol: 'none', // 是否显示小圆点  默认不写
              // sampling: 'average', // 是否平滑曲线显示
              data: []
            }
          ]
        }
      }
    },
    mounted() {
    },
    methods: {
      init(download) {
        getBusinessesTrend(this.$route.query.businessID, download).then((res) => {
          this.option.series[0].data = []
          this.option.series[1].data = []
          this.option.series[2].data = []
          if (download) {
            // window.location.href = res.download
            window.open(res.data.download)
          } else {
            const data = getDiffGroup(1, 1, 24)
            const seriesData = res.data
            data.map(item => {
              this.option.series[0].data.push(seriesData[item[0] - 1].service_num)
              this.option.series[1].data.push(seriesData[item[0] - 1].abandon_num)
              this.option.series[2].data.push(seriesData[item[0] - 1].abandon_rate)
            })
            this.$emit('getTableData', seriesData)
            this.option.xAxis[0].data = ['0:00', '1:00', '2:00', '3:00', '4:00', '5:00', '6:00', '7:00', '8:00', '9:00', '10:00', '11:00', '12:00', '13:00', '14:00', '15:00', '16:00', '17:00', '18:00', '19:00', '20:00', '21:00', '22:00', '23:00']
            this.showChart()
          }
        })
      },
      toPage() {
        if (!this.showTitle) return
        const query = { ...(this.$route.query || {}) }
        this.$router.push({
          path: `service-volume-info/${this.$route.query.businessID}`,
          query
        })
      },
      showChart() {
        this.chart = echarts.init(document.getElementById('line-chart'))
        if (this.chart) {
          this.chart.setOption(this.option)
          const that = this
          setTimeout(function() {
            that.chart.resize()
          }, 2000)
        }
      }
    }
  }
  function getDiffGroup(num, min, max) {
    const res = []
    for (let i = min; i <= max; i++) {
      res.push(i)
    }
    const rst = []
    for (let i = 0; i < res.length; i += num) {
      rst.push(res.slice(i, i + num))
    }
    return rst
  }
</script>
<style lang="scss" scoped>
.all-service-data {
  position: relative;
  // height: 50%;
  display: flex;
  flex-direction: column;

}
.title {
	padding: 0 10px;
	margin: 10px 0;
	color: #303133;
	font-size: 17px;
	line-height: 30px;
	font-weight: bold;
}
.pointer {
	cursor: pointer !important;
}
.all-phone-num {
	position: absolute;
	top: 30px;
	padding: 0 10px;
	margin: 10px 0;
	line-height: 40px;
	color: #909399;
	font-size: 14px;
}
.visual-map {
	position: absolute;
	right: 10px;
	top: 10px;
	p {
		font-size: 12px;
		padding: 5px;
		line-height: 15px;
		margin: 0;
		color: #909399;
		display: flex;
		:first-child {
			display: inline-block;
			width: 40px;
			height: 14px;
			background-color: #1890FF;
			margin-right: 5px;
		}
		.gaveupBg {
			background-color: #7EF7FF;
		}
		.gaveupRateBg {
			height: 2px;
			margin-top: 7px;
			background-color: #8B70FC;
		}
	}
}
.line-chart {
  height: calc(100% - 60px);
  padding-bottom: 10px;
  flex: 1;
}

</style>

