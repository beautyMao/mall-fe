<template>
  <el-card :body-style="{ padding: '30px 5px 20px 20px' }" class="class-info-data-line" :style="lineChartStyleH">
    <!-- :style="lineChartStyleH" -->
    <!-- <div class="title pointer">地区来电量趋势</div> -->
    <!-- <div class="all-phone-num">总来电量 9,999</div>
    <div class="visual-map">
      <p><span /><span>服务量</span></p>
      <p><span class="gaveupBg" /><span>放弃量</span></p>
      <p><span class="gaveupRateBg" /><span>放弃率</span></p>
    </div> -->
    <div id="class-info-data-line" class="class-info-data-line" :style="chartStyleH" />
  </el-card>
</template>
<script>
  import echarts from 'echarts'
  export default {
    name: 'class-info-data-line',
    data() {
      return {
        lineChartStyleH: '',
        chartStyleH: '',
        option: {
          color: ['#8B70FC', '#7EF7FF', '#2295FF'],
          title: {
            text: '情感趋势'
          },
          toolbox: {
            featureTitle: {
              mark: false,
              markClear: false
            }
          },
          tooltip: {
            trigger: 'axis',
            backgroundColor: 'rgba(24,144,255,1)',
            axisPointer: {
              type: 'cross',
              lineStyle: {
                width: 2
              },
              label: {
                backgroundColor: '#6a7985',
                formatter(params, va) {
                  return params.seriesData.length ? params.value.value : params.value.toFixed(2)
                }
              }
            },
            formatter(params) {
              var htmlStr = ''
              for (var i = 0; i < params.length; i++) {
                var param = params[i]
                var xName = param.name.values// x轴的名称
                var seriesName = param.seriesName// 图例名称
                var value = param.value// y轴值
                var color = param.color// 图例颜色
                if (i === 0) {
                  htmlStr += xName + '<br/>'// x轴的名称
                }
                htmlStr += '<div>'
                // 为了保证和原来的效果一样，这里自己实现了一个点的效果
                htmlStr += '<span style="margin-right:5px;display:inline-block;width:10px;height:10px;border-radius:5px;background-color:' + color + ';"></span>'

                // 圆点后面显示的文本
                htmlStr += seriesName + '：' + value

                htmlStr += '</div>'
              }
              return htmlStr
            }
          },
          grid: {
            left: '6%',
            right: '6%',
            bottom: 0,
            containLabel: true
          },
          xAxis: {
            type: 'category',
            data: [],
            axisLabel: {
              formatter: function(value, index) {
                return value.value
              }
            }
          },
          yAxis: {
            type: 'value'
          },
          series: []
        }
      }
    },
    methods: {
      init(data) {
        const text = {
          extremely: {
            text: '惊喜',
            data: [],
            color: '#1890FF'
          },
          very: {
            text: '愉悦',
            data: [],
            color: '#7EF7FF'
          },
          moderately: {
            text: '正常',
            data: [],
            color: '#BFB0FF'
          },
          slightly: {
            text: '不满',
            data: [],
            color: '#DAF0FF'
          },
          not_at_all: {
            text: '愤怒',
            data: [],
            color: '#0B74D6'
          }
        }
        data.emotions.forEach(element => {
          text.extremely.data.push(element.extremely)
          text.moderately.data.push(element.moderately)
          text.not_at_all.data.push(element.not_at_all)
          text.slightly.data.push(element.slightly)
          text.very.data.push(element.very)
        })
        this.option.series = Object.entries(text).map(item => {
          return {
            name: item[1].text,
            type: 'line',
            // yAxisIndex: 1,
            smooth: true,
            // symbol: 'none', // 是否显示小圆点  默认不写
            sampling: 'average', // 是否平滑曲线显示
            data: item[1].data,
            color: item[1].color
          }
        })
        this.option.xAxis.data = data.hours.map((item, index, arr) => {
          return {
            value: {
              value: item,
              values: index === 0 ? `00:00 - ${item}` : `${arr[index - 1]} - ${item}`
            }
          }
        })
        this.showChart()
      },
      showChart() {
        this.chart = echarts.init(document.getElementById('class-info-data-line'))
        this.chart.setOption(this.option)
      }
    }
  }
</script>
<style lang="scss" scoped>
.class-info-data-line {
  position: relative;
  // height: 50%;
  display: flex;
  flex-direction: column;

}
.title {
	padding: 0 10px;
	margin: 10px 0;
	color: #303133;
	font-size: 17px;
	line-height: 30px;
	font-weight: bold;
}
.pointer {
	cursor: pointer !important;
}
.all-phone-num {
	position: absolute;
	top: 30px;
	padding: 0 10px;
	margin: 10px 0;
	line-height: 40px;
	color: #909399;
	font-size: 14px;
}
.visual-map {
	position: absolute;
	right: 10px;
	top: 10px;
	p {
		font-size: 12px;
		padding: 5px;
		line-height: 15px;
		margin: 0;
		color: #909399;
		display: flex;
		:first-child {
			display: inline-block;
			width: 40px;
			height: 14px;
			background-color: #1890FF;
			margin-right: 5px;
		}
		.gaveupBg {
			background-color: #7EF7FF;
		}
		.gaveupRateBg {
			height: 2px;
			margin-top: 7px;
			background-color: #8B70FC;
		}
	}
}
.class-info-data-line {
  height: 100%;
  padding-bottom: 10px;
  flex: 1;
}

</style>

