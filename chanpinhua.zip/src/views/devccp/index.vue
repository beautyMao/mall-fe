<template>
  <div class="dashboard-contenter" :class="isFullScreen ? 'fullscreen': ''">
    <div class="dashboard_select">
      <div ref="box" class="box" />
      <el-cascader
        ref="cascader"
        v-model="scene"
        :options="options"
        :props="{ checkStrictly: true }"
        :show-all-levels="false"
        :placeholder="placeholder"
        size="medium"
        class="cascader"
        @visible-change="handleVisibleChange"
        @change="handleChange"
      />
      <div class="dashboard_title">实时监控数据</div>
      <div class="time">{{ currentTime }}</div>
      <!-- <div class="right-menu" @click="toggleFullScreen"><i :class="isFullScreen ? 'el-icon-close' : 'el-icon-full-screen'" /></div> -->
      <div v-if="!isFullScreen" class="right-menu" @click="dialogVisible = true"><i class="el-icon-s-unfold" /></div>
    </div>
    <div class="dashboard-main">
      <div class="dashboard-left">
        <customer-service ref="customer" />
        <service-modal ref="service" />
      </div>
      <div class="dashboard-center">
        <all-service-data ref="allService" />
        <business-canvas ref="business" :style-h="height" :style-w="width" />
      </div>
      <div class="dashboard-right">
        <class-chart ref="classChart" />
        <emotion-chart v-if="isShowEmotion" ref="emotionChart" />
        <mapChart ref="mapChart" />
      </div>
    </div>
    <el-dialog
      ref="my-dialog"
      :title="dialogTitle"
      custom-class="el-dialog-aside"
      :visible.sync="dialogVisible"
      :before-close="() => dialogVisible = false"
      :fullscreen="isdialogfullscreen"
    >
      <ul class="el-dialog-list">
        <li @click="toPage('customer-info')">客服数据</li>
        <li @click="toPage('service-info')">服务数据</li>
        <li @click="toPage('service-volume-info')">业务趋势</li>
        <li @click="toPage('/devccp-management/class-info', 1)">问题分类</li>
        <li @click="toPage('/devccp-management/emotion-info', 1)">用户情感监控</li>
        <li @click="toPage('mapchart-info')">地域来电分析</li>
        <li @click="toggleFullScreen">全屏模式</li>
      </ul>
    </el-dialog>
  </div>
</template>

<script>
  import { getDateFormat, launchFullscreen, exitFullscreen } from '@/utils'
  import serviceModal from './service-management'
  import customerService from './service-management/customer-service'
  import allServiceData from './service-management/all-service-data'
  import businessCanvas from './service-management/business-canvas'
  import classChart from './service-management/ClassChart'
  import emotionChart from './service-management/EmotionChart'
  import mapChart from './service-management/MapChart'
  import {
    getBusinessesList,
    getEngineerStatus
    // getCount,
    // getFeedDetail,
    // getStatusCount,
    // getLocalesCount,
    // getLineupNum,
    // getAhtCount,
    // getLineupTime,
    // getNotAtAll,
    // getGaveupRate,
    // getIntervalData
  } from '@/api/ccp/index' // getIntervalNowData
  export default {
    name: 'ccp-dashboard',
    components: {
      serviceModal,
      customerService,
      allServiceData,
      businessCanvas,
      classChart,
      emotionChart,
      mapChart
    },
    data() {
      return {
        LocalesDtate: [],
        options: [],
        scene: [],
        defaultProps: {
          children: 'childs',
          label: 'name'
        },
        query: {
          businessID: '',
          businessName: ''
        },
        placeholder: '现场选择',
        currentTime: '',
        timer: null,
        timer1: null,
        isFullScreen: false,
        isShowEmotion: true,
        isdialogfullscreen: true,
        dialogVisible: false,
        dialogTitle: '项目菜单',
        width: 0,
        height: 0
      }
    },
    watch: {
      isFullScreen() {
      }
    },
    mounted() {
      window.addEventListener('resize', () => {
        this.$nextTick(() => {
          this.isFullScreen = this.ESCFullScreen()
        })
      })
      const that = this
      document.querySelectorAll('.canvas-box').forEach(el => {
        that.width = el.getBoundingClientRect().width
        that.height = el.getBoundingClientRect().width
      })
    },
    deactivated() {
      clearInterval(this.timer)
      clearInterval(this.timer1)
    },
    beforeDestroy() {
      clearInterval(this.timer)
      clearInterval(this.timer1)
    },
    activated() {
      this._getBusinessesList()
    },
    methods: {
      toPage(path, n) {
        this.dialogVisible = false
        const query = { ...(this.$route.query || {}) }
        let url = `${path}/${this.$route.query.businessID}&businessName=${this.businessName}`
        if (n) {
          url = `${path}?businessID=${this.$route.query.businessID}&businessName=${this.businessName}`
        }
        this.$router.push({
          path: url,
          query
        })
      },
      init() {
        this.dealWithTime() // 当前时间
        clearInterval(this.timer1)
        this.timer1 = setInterval(this.dealWithTime, 1000) // 当前时间
        this.$refs.service._getServiceData() // 服务数据
        this.$refs.allService.init() // 业务趋势
        this.$refs.classChart._getNewCaseLabels() // 问题分类
        if (this.isShowEmotion) {
          // 是否显示用户情感模块
          this.$refs.emotionChart.initChart() // 用户情感占比
        }
        this.$refs.business._getBusinessInfo()
        this.$refs.mapChart._getPhoneCallData()
        this._getEngineerStatus() // 客服状态数据
        this.IntervalGetdata()
      },
      IntervalGetdata() {
        this.timer = setInterval(() => {
          this.$refs.allService.init() // 业务趋势
          this.$refs.service._getServiceData() // 服务数据
          this._getEngineerStatus() // 客服状态数据
          this.$refs.classChart._getNewCaseLabels() // 问题分类
          if (this.isShowEmotion) {
            // 是否显示用户情感模块
            this.$refs.emotionChart.initChart() // 用户情感占比
          }
        }, 30000) // 30秒刷新一次
      },
      getCityCalls() { // 获取某城市来电量占比、问题分类
      },
      ESCFullScreen() {
        return document.isFullScreen || document.mozIsFullScreen || document.webkitIsFullScreen
      },
      toggleFullScreen() {
        this.$store.dispatch('toggleSideBar')
        this.$store.state.app.sidebar.opened = false
        this.dialogVisible = false
        this.isFullScreen = !this.isFullScreen
        if (this.isFullScreen) {
          launchFullscreen(document.documentElement)
        } else {
          exitFullscreen(document.documentElement)
        }
      },
      dealWithTime() {
        this.currentTime = getDateFormat()
      },
      handleVisibleChange(val) {
        if (val) {
          this.$refs.box.className = 'box box-focus'
        } else {
          this.$refs.box.className = 'box'
        }
      },
      handleChange(d) {
        this.query.businessID = d[d.length - 1]
        const query = { ...this.$route.query || {}}
        query.businessID = d[d.length - 1]
        this.setBusinessesName(this.options, d[d.length - 1])
        query.businessName = this.businessName
        this.$router.replace({
          path: this.$route.path,
          query
        })
        this.init()
      },
      setBusinessesName(data, value) {
        for (const i in data) {
          if (data[i].value === value) {
            this.businessName = data[i].name
          } else {
            this.setBusinessesName(data[i].childs, value)
          }
        }
        // return data
      },
      setBusinessesList(data) {
        for (const i in data) {
          data[i].label = data[i].name
          data[i].value = data[i].id
          if (data[i].childs.length) {
            data[i].children = data[i].childs
            this.setBusinessesList(data[i].childs)
          } else {
            delete data[i].childs
          }
        }
        return data
      },
      async defaultBusinesses(data) {
        // if (data[0].childs) {
        //   this.defaultBusinesses(data[0].childs)
        // }
        if (data[0].id) {
          this.businessName = data[0].name
          this.scene.unshift(data[0].id)
        }
      },
      _getEngineerStatus() {
        getEngineerStatus(this.$route.query.businessID).then(response => {
          if (response.statusCode === 200) {
            this.$refs.customer.serChart = response.data
            this.$refs.customer.initCanvas()
          }
        })
      },
      _getBusinessesList() { // 业务选择
        getBusinessesList().then(response => {
          this.options = []
          this.scene = []
          this.LocalesDtate = response.data
          if (response.data.length) {
            this.options = this.setBusinessesList(this.LocalesDtate)
            this.defaultBusinesses(this.LocalesDtate)
            this.query.businessID = this.scene[this.scene.length - 1]
            const query = { ...this.$route.query || {}}
            query.businessID = this.scene[this.scene.length - 1]
            query.businessName = this.businessName
            this.$router.replace({
              path: this.$route.path,
              query
            })
            this.init()
          }
        })
      }
    }
  }
</script>

<style lang='scss' scoped>
.fullscreen {
  background: #fff;
  position: fixed;
  top: -80px;
  bottom: 0;
  right: 0;
  left: 0;
  margin: auto;
  padding-top: 30px;
  z-index: 1;
  padding-left: 30px;
}
.dashboard-contenter {
  height: calc(100vh - 86px);
  min-height: 850px;
  min-width: 1600px;
  display: flex;
  flex-direction: column;
}
.dashboard_select {
  position: relative;
  // display: flex;
  justify-content: space-between;
  margin: 0;
  line-height: 36px;
  height: 36px;
  >div {
    float: left;
    margin-left: 5px;
  }
  .cascader {
    padding-left: 5px;
    /deep/ .el-input__suffix {
      display: none;
    }
  }
  .box {
    position: absolute;
    left: 130px;
    top: 14px;
    width: 0;
    height: 0;
    transform-origin: center;
    transition: transform .3s;
    border-top: 8px solid #1a8fff;
    border-right: 8px solid  rgba(0,0,0,0);
    border-left: 8px solid  rgba(0,0,0,0);
  }
  .right-menu {
    float: right;
    margin-right: 20px;
  }
  .dashboard_title {
    font-size: 16px;
    font-weight: 500;
  }
  .tmie{
    font-size:14px;
    font-weight: 500;
    color: #303133;
  }
  .box-focus {
    transform: rotate(180deg);
    transition: transform .3s
  }
  & /deep/ .el-input__inner{
    border: 0;
    background: rgba(0,0,0,0);
    color: #303133;
    font-weight: 600;
  }
  & /deep/ .el-input__icon {
    font-size: 0;
  }

  p {
    text-align: right;
    color: #4a90e2;
    font-size: 16px;
    font-weight: bold;
    margin: 0;
    float: left;
    width: 100%;
    i {
      font-style: normal;
      font-size: 24px;
      color: #ff8060;
      line-height: 36px;
      padding-left: 4px;
    }
  }
  .btn {
    width: 100px;
    height: 36px;
    margin-left: 20px;
  }
}
.dashboard-main {
  margin: 10px 20px;
  display: grid;
  grid-template-columns: 22% 50% 28%;
  grid-template-rows: auto;
  flex: 1;
}
.dashboard-left {
  width: 100%;
  display: flex;
  flex-direction: column;
  .servcice-chart {
    padding-bottom: 40px;
  }
  .service-data {
    flex: 1;
    /deep/ .el-card__body {
      display: flex;
      flex-direction: column;
      height: 100%;
      .service {
        justify-content: space-around;
        display: flex;
        flex-direction: column;
        height: 100%;
        flex: 1;
      }
    }
  }
}
.dashboard-center {
  margin: 0 10px;
  display: flex;
  flex-direction: column;
  .all-service-data {
    height: 50%;
    /deep/ .el-card__body {
      height: 100%;
    }
  }
  .business-data {
    flex: 1
  }
}
.dashboard-right {
  display: flex;
  flex-direction: column;
  .mapEchart {
    flex: 1
  }
}
.el-card {
  margin-bottom: 10px
}
.el-dialog-list {
  border-top: 1px solid #333;
  line-height: 50px;
  font-size: 16px;
  cursor: pointer;
}
</style>
