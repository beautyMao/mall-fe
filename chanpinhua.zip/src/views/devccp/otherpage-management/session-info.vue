<template>
  <div class="app-container">
    <header>
      <h1>查看会话</h1>
    </header>
    <el-card>
      <precise-query ref="precise" @exactInfoSucc="handleExactInfo" />
      <condition-query ref="condition" @ruleForm="ruleForm" />
      <div v-if="session_list.length">
        <com-list :list-data="session_list" />
        <el-pagination
          background
          :page-sizes="[10, 15, 20, 25]"
          :current-page="paging.page"
          :page-size="paging.size"
          layout="total, sizes, prev, pager, next, jumper"
          :total="paging.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div>
      <footer v-else>
        <h2>查询说明</h2>
        <ul>
          <li>A. 会话开始时间段默认为从今日开始往前推1个月的时间段；</li>
          <li>B. 通过用户标识查询支持查询移动电话和固定电话；</li>
          <li>C. 条件查询中的各个查询条件之间是“与”的关系，即输入信息越多，结果越准确；</li>
          <li>D. 点击“重置”按钮，会重置所有输入框的状态，点击“查询”按钮，会显示所有符合条件的结果，点击“导出”按钮，则将所有搜索结果导出成Excel格式。</li>
        </ul>
      </footer>
    </el-card>
  </div>
</template>

<script>
  // import { getServiceJudgeInfo } from '@/api/review/index'
  import comList from './components/comList'
  import conditionQuery from './components/conditionQuery'
  import preciseQuery from './components/preciseQuery'
  import * as ccpApi from '@/api/ccp/index'
  import { deepClone } from '@/utils'
  export default {
    name: 'record-query',
    components: {
      comList,
      conditionQuery,
      preciseQuery
    },
    data() {
      return {
        formData: {},
        session_list: [],
        paging: {
          size: 10,
          page: 1,
          total: 0
        }
      }
    },
    methods: {
      handleExactInfo(params) { // 精确查询返回单数值
        // this.$refs.precise.$refs.ruleForm.resetFields()
        this.fetchData(params, {
          size: this.paging.size,
          page: 1
        })
      },
      ruleForm(params) { // 返回查询条件
        // this.$refs.condition.$refs.ruleForm.resetFields()
        this.fetchData(params, {
          size: this.paging.size,
          page: 1
        })
      },
      fetchData(params, paging) {
        this.paging = paging
        this.formData = deepClone(params)
        ccpApi.getApiCubeCcpSessionSearch({ ...params, ...paging }).then(res => {
          if (res.data.total === 0) {
            this.$message({
              message: '未找到符合的数据',
              type: 'warning'
            })
          }
          this.session_list = res.data.session_list
          this.paging = {
            size: res.data.size,
            page: res.data.current_page,
            total: res.data.total
          }
        }).catch(this.$message.error)
      },
      handleSizeChange(size) { // 条数切换
        this.fetchData(this.formData, {
          ...this.paging,
          size,
          page: 1
        })
      },
      handleCurrentChange(page) { // 分页切换
        this.fetchData(this.formData, {
          ...this.paging,
          page
        })
      }
    }
  }
</script>
