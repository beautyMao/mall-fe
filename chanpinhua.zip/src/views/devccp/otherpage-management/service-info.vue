<template>
  <div class="app-container">
    <header>
      <div class="dashboard_select">
        <div style="width:300px;"> {{ $route.query.businessName }}&nbsp; &nbsp; &nbsp; &nbsp; 服务数据</div>
      </div>
      <div class="flex-wrap">
        <el-button type="primary" plain @click="download">下载列表</el-button>
      </div>
    </header>
    <el-card class="box-card">
      <el-table :data="tableData">
        <el-table-column
          prop="queue_info"
          label="客服组名称"
        />
        <el-table-column
          prop="queue_call_num"
          label="来电量"
          sortable
        />
        <el-table-column
          prop="queue_service_num"
          label="服务量"
          sortable
        />
        <el-table-column
          prop="queue_repeat_call_in_num"
          label="重复来电量"
          sortable
        />
        <el-table-column
          prop="queue_text_avg_session_time"
          label="平均会话时长"
          sortable
        />
        <el-table-column
          prop="queue_abandon_num"
          label="当前排队"
          sortable
        />
        <el-table-column
          prop="queue_avg_wait_time"
          label="平均等待时长"
          sortable
        />
        <el-table-column
          prop="queue_abandon_num"
          label="放弃量"
          sortable
        />
        <el-table-column
          prop="queue_service_level"
          label="服务水平"
          sortable
        />
        <el-table-column
          fixed="right"
          label="操作"
        >
          <template slot-scope="scope">
            <el-popover trigger="hover" placement="top">
              <div class="popover-class">
                <div class="popover-title">{{ scope.row.queue_info }}</div>
                <div class="popover-groups">
                  <p><span>在线客服</span><span>{{ scope.row.queue_online_engineer }}</span></p>
                  <p><span>小休客服</span><span>{{ scope.row.queue_rest_engineer }}</span></p>
                  <p><span>挂机客服</span><span>{{ scope.row.queue_hangup_engineer }}</span></p>
                </div>
                <div class="popover-title">本日服务情况</div>
                <div class="popover-service-groups">
                  <p><span>累计来电</span><span>{{ scope.row.queue_call_num }}</span></p>
                  <p><span>累计服务量</span><span>{{ scope.row.queue_service_num }}</span></p>
                  <p><span>48小时重复来电</span><span>{{ scope.row.queue_repeat_call_in_num }}</span></p>
                  <p><span>呼入量</span><span>{{ scope.row.queue_call_in_num }}</span></p>
                  <p><span>呼出量</span><span>{{ scope.row.queue_call_out_num }}</span></p>
                  <p><span>30s接起量</span><span>{{ scope.row.queue_thirty_second_up }}</span></p>
                  <p><span>服务水平</span><span>{{ scope.row.queue_service_level }}</span></p>
                  <p><span>平均会话时长</span><span>{{ scope.row.queue_text_avg_session_time }}</span></p>
                  <p><span>平均排队时长</span><span>{{ scope.row.queue_avg_wait_time }}</span></p>
                  <p><span>放弃量</span><span>{{ scope.row.queue_abandon_num }}</span></p>
                  <p><span>放弃率</span><span>{{ scope.row.queue_abandon_rate }}%</span></p><!--
                  <p><span>满意度</span><span>1</span></p> -->
                  <p><span>愤怒会话</span><span>{{ scope.row.queue_anger_session_num }}</span></p>
                </div>
              </div>
              <div slot="reference" class="name-wrapper">
                <el-button
                  type="text"
                  size="small"
                >
                  查看详情
                </el-button>
              </div>
            </el-popover>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        background
        :current-page.sync="customerDetails.page"
        :page-size="customerDetails.size"
        :page-sizes="[10, 15, 20, 25]"
        layout="total, sizes, prev, pager, next, jumper"
        :total="customerDetails.total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>
  </div>
</template>
<script>
  import {
    getQueueDetails
  } from '@/api/ccp/index'
  export default {
    name: 'service-info',
    data() {
      return {
        input: '',
        LocalesDtate: [],
        options: [],
        scene: [],
        query: {
          businessID: '',
          business: '',
          accessID: '',
          access: ''
        },
        timer: null,
        customerDetails: {
          page: 1,
          size: 20,
          total: 1
        },
        tableData: []
      }
    },
    deactivated() {
      clearInterval(this.timer)
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    mounted() {
      this.init()
    },
    methods: {
      init() {
        this._getQueueDetails()
        // this.IntervalGetdata()
      },
      IntervalGetdata() {
        this.timer = setInterval(() => {
          this._getQueueDetails()
        }, 30000) // 30秒刷新一次
      },
      _getQueueDetails() {
        const para = {
          businessId: this.$route.query.businessID,
          page: this.customerDetails.page,
          size: this.customerDetails.size
        }
        getQueueDetails(para).then(res => {
          this.tableData = res.data.list
          this.tableData.map(item => {
            if (item.queue_service_level !== '0') {
              item.queue_service_level = item.queue_service_level + '%'
            }
          })
          this.customerDetails.page = res.data.current_page
          this.customerDetails.size = res.data.size
          this.customerDetails.total = res.data.total
        }).catch(this.$message.error)
      },
      download() {
        const para = {
          businessId: this.$route.query.businessID,
          page: this.customerDetails.page,
          size: this.customerDetails.size,
          isExcel: true
        }
        getQueueDetails(para).then(res => {
          if (res.data.download) {
            window.location.href = res.data.download
          } else {
            this.$message({
              message: '暂无数据，无法进行下载。'
            })
          }
        }).catch(this.$message.error)
      },
      handleSizeChange(size) {
        this.customerDetails.size = size
        this.customerDetails.page = 1
        this._getQueueDetails()
      },
      handleCurrentChange(page) {
        this.customerDetails.page = page
        this._getQueueDetails()
      }
    }
  }
</script>
<style lang="scss" scoped>
.flex-wrap {
	margin-left: 10px;
}
.dashboard_select {
  position: relative;
  // display: flex;
  justify-content: space-between;
  margin: 0;
  line-height: 36px;
  height: 36px;
  >div {
    float: left;
    margin-left: 5px;
  }
  .cascader {
    padding-left: 5px;
    /deep/ .el-input__suffix {
      display: none;
    }
  }
  .box {
    position: absolute;
    right: 130px;
    top: 14px;
    width: 0;
    height: 0;
    transform-origin: center;
    transition: transform .3s;
    // border-top: 8px solid #1a8fff;
    border-right: 8px solid  rgba(0,0,0,0);
    border-left: 8px solid  rgba(0,0,0,0);
	}
	.dashboard_tilte {
		position: absolute;
    left: 130px;
		top: 2px;
		font-size: 14px;
		font-weight: 800;
		color: #303133;
	}
  .box-focus {
    transform: rotate(180deg);
    transition: transform .3s
  }
  & /deep/ .el-input__inner{
    border: 0;
    background: rgba(0,0,0,0);
    color: #303133;
    font-weight: 600;
  }
  & /deep/ .el-input__icon {
    font-size: 0;
  }

  p {
    text-align: right;
    color: #4a90e2;
    font-size: 16px;
    font-weight: bold;
    margin: 0;
    float: left;
    width: 100%;
    i {
      font-style: normal;
      font-size: 24px;
      color: #ff8060;
      line-height: 36px;
      padding-left: 4px;
    }
  }
  .btn {
    width: 100px;
    height: 36px;
    margin-left: 20px;
  }
}
.popover-class {
	min-height: 300px;
	width: 260px;
	overflow-y: auto;
	.popover-title {
		font-weight: 800;
		color: #303133;
	}
	p {
		font-size: 10px;
	}
	.popover-groups {
		display: flex;
		text-align: center;
		justify-content: space-between;
		p {
			span {
				display: block;
			}
		}
	}
	.popover-service-groups {
		p {
			display: flex;
			justify-content: space-between;
		}
	}
}
/deep/ .el-input__inner::-webkit-input-placeholder { /* WebKit browsers */
  color: #303133;
  font-size: 16px;
}

/deep/ .el-input__inner::-moz-placeholder { /* Mozilla Firefox 19+ */
  color: #303133;
  font-size: 16px;
}

/deep/ .el-input__inner::-ms-input-placeholder { /* Internet Explorer 10+ */
  color: #303133;
  font-size: 16px;
}
</style>

