<template>
  <div class="app-container">
    <header>
      <div class="dashboard_select">
        <!-- <div class="dashboard_tilte">{{ businessName }}</div> -->
        <div style="font-size: 14px;">{{ $route.query.businessName }} &nbsp; &nbsp; &nbsp; &nbsp;</div>
        <div ref="box" class="box" />
        <el-select v-model="value" placeholder="请选择">
          <el-option
            v-for="item in statusOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </div>
    </header>
    <div class="dashboard-main">
      <div class="dashboard-left">
        <mapChart v-if="isShow" ref="mapChart" :show-title="false" :is-show="true" @getCityCalls="getCityCalls" />
        <mapWarning v-else ref="myWeatherEchart" @getCityCalls="getCityCalls" />
      </div>
      <div class="dashboard-right">
        <line-chart v-if="value !== 1" ref="lineChart" :show-title="false" />
        <class-chart v-if="value !== 1" ref="cityChart" class-name="city-chart" title="各城市来电量占比" :show-title="false" />
        <class-chart v-if="value === 1" ref="callsChart" class-name="calls-chart" title="来电量占比" :show-title="false" />
        <class-chart v-if="value === 1" ref="classChart" class-name="class-chart" :show-title="false" />
      </div>
    </div>
  </div>
</template>
<script>
  import {
    getBusinessesList
  } from '@/api/ccp/index'
  import mapChart from '@/views/devccp/service-management/MapChart'
  import mapWarning from '@/views/devccp/service-management/components/mapWarning'
  import classChart from '@/views/devccp/service-management/ClassChart'
  import lineChart from './components/line-chart'
  export default {
    name: 'mapchart-info',
    components: {
      mapChart,
      mapWarning,
      classChart,
      lineChart
    },
    data() {
      return {
        input: '',
        LocalesDtate: [],
        options: [],
        scene: [],
        value: 1,
        isShow: true,
        statusOptions: [{
          label: '地域来电量监控',
          value: 1
        }, {
          label: '天气监控',
          value: 0
        }],
        timer: null,
        query: {
          businessID: '',
          business: '',
          accessID: '',
          access: ''
        },
        tableData: [{
          groups: 'zhangshan'
        }],
        checked: true,
        total: 0
      }
    },
    watch: {
      value: function(value) {
        this.isShow = value
        if (!value) {
          this.$nextTick(() => {
            this.$refs.cityChart._getWeatherBreakdown()
            this.$refs.lineChart._getCallsbyhours()
          })
        } else {
          this.$nextTick(() => {
            this.$refs.callsChart._getWeatherBreakdown()
            this.$refs.classChart._getNewCaseLabels()
            this.$refs.mapChart._getPhoneCallData()
          })
        }
      }
    },
    deactivated() {
      clearInterval(this.timer)
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    mounted() {
      clearInterval(this.timer)
      this.init()
      // this.IntervalGetdata()
    },
    methods: {
      init() {
        // this._getBusinessesList()
        // this.$refs.allService.init()
        this.$refs.callsChart._getWeatherBreakdown()
        this.$refs.classChart._getNewCaseLabels()
        this.$refs.mapChart._getPhoneCallData()
      },
      searchInfo() {},
      handleSelectionChange() {
      },
      IntervalGetdata() {
        this.timer = setInterval(() => {
          this.init()
        }, 30000) // 30秒刷新一次
      },
      handleVisibleChange(val) {
        if (val) {
          this.$refs.box.className = 'box box-focus'
        } else {
          this.$refs.box.className = 'box'
        }
      },
      handleChange(d) {
        this.options.map(item => {
          if (item.value === d[0]) {
            item.children.map(data => {
              if (data.value === d[1]) {
                this.query = {
                  businessID: d[0],
                  business: item.label,
                  accessID: d[1],
                  access: data.label
                }
                this.$router.push({
                  path: this.$route.path,
                  query: this.query
                })
              }
            })
          }
        })
      },
      getCityCalls(name) {
        if (this.$refs.callsChart) {
          this.$refs.callsChart._getWeatherBreakdown(name)
        }
        if (this.$refs.classChart) {
          this.$refs.classChart._getNewCaseLabels(name)
        }
        if (this.$refs.cityChart) {
          this.$refs.cityChart._getWeatherBreakdown(name)
        }
        if (this.$refs.lineChart) {
          this.$refs.lineChart._getCallsbyhours(name)
        }
      },
      setBusinessesList(data) {
        for (const i in data) {
          data[i].label = data[i].name
          data[i].value = data[i].id
          if (data[i].id !== this.$route.query.businessID) {
            if (data[i].childs.length) {
              data[i].children = data[i].childs
              this.setBusinessesList(data[i].childs)
            } else {
              delete data[i].childs
            }
          } else {
            this.businessName = data[i].label
          }
        }
        return data
      },
      async defaultBusinesses(data) {
        if (data[0].id) {
          this.scene.unshift(data[0].id)
        }
      },
      _getBusinessesList() { // 业务选择
        getBusinessesList().then(response => {
          this.options = []
          this.scene = []
          this.businessList = []
          this.LocalesDtate = response.data
          this.setBusinessesList(this.LocalesDtate)
          // console.log(this.scene)
          // if (response.data.length) {
          //   this.options = this.setBusinessesList(this.LocalesDtate)
          //   this.query.businessID = this.scene[this.scene.length - 1]
          // }
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
.flex-wrap {
	margin-left: 10px;
}
.hide-tilte .dashboard_tilte {
	font-size: 14px;
	font-weight: 500;
	color: #303133;
}
.dashboard_select {
  position: relative;
  // display: flex;
  justify-content: space-between;
  margin: 0;
  line-height: 36px;
  height: 36px;
  >div {
    float: left;
    margin-left: 5px;
  }
  .cascader {
    padding-left: 5px;
    /deep/ .el-input__suffix {
      display: none;
    }
  }
  .box {
    position: absolute;
    right: 130px;
    top: 14px;
    width: 0;
    height: 0;
    transform-origin: center;
    transition: transform .3s;
    border-top: 8px solid #1a8fff;
    border-right: 8px solid  rgba(0,0,0,0);
    border-left: 8px solid  rgba(0,0,0,0);
	}
	.dashboard_tilte {
		// position: absolute;
    left: 0px;
		top: 2px;
		font-size: 14px;
		font-weight: 500;
		color: #303133;
	}
  .box-focus {
    transform: rotate(180deg);
    transition: transform .3s
  }
  & /deep/ .el-input__inner{
    border: 0;
    background: rgba(0,0,0,0);
    color: #303133;
    font-weight: 500;
  }
  & /deep/ .el-input__icon {
    font-size: 0;
  }

  p {
    text-align: right;
    color: #4a90e2;
    font-size: 16px;
    font-weight: 500;
    margin: 0;
    float: left;
    width: 100%;
    i {
      font-style: normal;
      font-size: 24px;
      color: #ff8060;
      line-height: 36px;
      padding-left: 4px;
    }
  }
  .btn {
    width: 100px;
    height: 36px;
    margin-left: 20px;
  }
}
.popover-class {
	min-height: 300px;
	width: 260px;
	overflow-y: auto;
	.popover-title {
		font-weight: 500;
		color: #303133;
	}
	p {
		font-size: 10px;
	}
	.popover-groups {
		display: flex;
		text-align: center;
		justify-content: space-between;
		p {
			span {
				display: block;
			}
		}
	}
	.popover-service-groups {
		p {
			display: flex;
			justify-content: space-between;
		}
	}
}
.dashboard-main {
	margin-bottom: 20px;
	display: flex;
	height: calc(100vh - 180px);
	.dashboard-left {
		min-width: 800px;
		width: 60%;
		margin-right: 20px;
	}
	.dashboard-right {
    min-width:  400px;
    width: 40%;
		display: flex;
		flex-direction: column;
		.wrapper, .emotion, .all-service-data {
			flex: 1;
			/deep/ .el-card__body, canvas {
				height: 100%;
			}
		}
	}
	.dashboard-left, .mapEchart, /deep/ .el-card__body {
		height: 100%;
	}
}
/deep/ .el-input.el-input--small.el-input--suffix .el-input__suffix .el-input__suffix-inner .el-select__caret.el-input__icon.el-icon-arrow-up {
  display: none;
}
.app-container header /deep/ .el-input{
  width: 300px;
}
</style>

