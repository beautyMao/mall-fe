<template>
  <div class="app-container">
    <header>
      <div class="dashboard_select">
        <div style="width:300px;"> {{ $route.query.businessName }}&nbsp; &nbsp; &nbsp; &nbsp; 客服数据</div>
      </div>
      <div class="status">
        <span class="only">只看</span>
        <el-select v-model="value" placeholder="请选择" clearable>
          <el-option
            v-for="item in statusOptions"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </div>
      <el-button type="primary" plain @click="download">下载列表</el-button>
      <div class="flex-wrap">
        <el-input v-model="input" placeholder="请输入客服账号或姓名" class="input" clearable @keyup.enter.native="searchInfo" @blur="searchInfo">
          <i slot="prefix" class="el-input__icon el-icon-search" @click="searchInfo" />
        </el-input>
      </div>
    </header>
    <el-card class="box-card">
      <el-table :data="tableData">
        <el-table-column
          prop="engineer_info"
          label="姓名/工号"
          width="170"
        />
        <el-table-column
          prop="engineer_queue"
          label="客服组"
        />
        <el-table-column
          prop="engineer_status"
          label="当前状态"
          sortable
        />
        <el-table-column
          prop="engineer_current_session"
          label="当前会话"
          sortable
        />
        <el-table-column
          prop="engineer_current_queue"
          label="当前排队"
          sortable
        />
        <el-table-column
          prop="engineer_service_num"
          label="本日服务量"
          sortable
        />
        <el-table-column
          prop="engineer_text_avg_session_time"
          label="平均会话时长"
          sortable
        />
        <el-table-column
          prop="engineer_sum_rest_time"
          label="小休累计时长"
          sortable
        />
        <el-table-column
          prop="engineer_sum_hangup_time"
          label="挂起累计时长"
          sortable
        />
        <el-table-column
          fixed="right"
          label="操作"
        >
          <template slot-scope="scope">
            <el-popover trigger="hover" placement="top">
              <div class="popover-class">
                <div class="popover-title">{{ scope.row.engineer_info }}</div>
                <div class="popover-groups">
                  <p><span>在线</span><span>{{ scope.row.engineer_sum_online_time }}</span></p>
                  <p><span>首次登录</span><span>{{ scope.row.engineer_first_login_time }}</span></p>
                  <p><span>最后登出</span><span>{{ scope.row.engineer_end_logout_time }}</span></p>
                </div>
                <div class="popover-title">本日会话情况</div>
                <div class="popover-service-groups">
                  <p><span>本日服务量</span><span>{{ scope.row.engineer_service_num }}</span></p>
                  <p><span>本日呼出量</span><span>{{ scope.row.engineer_call_out_num }}</span></p>
                  <p><span>平均会话时长</span><span>{{ scope.row.engineer_text_avg_session_time }}</span></p>
                  <p><span>本日转接量</span><span>{{ scope.row.engineer_transfer_num }}</span></p>
                  <p><span>本日愤怒会话</span><span>{{ scope.row.engineer_anger_session_num }}</span></p>
                </div>
                <div class="popover-title">本日坐席情况</div>
                <div class="popover-service-groups">
                  <p><span>在线累计时长</span><span>{{ scope.row.engineer_sum_online_time }}</span></p>
                  <p><span>小休累计次数</span><span>{{ scope.row.engineer_rest_num }}</span></p>
                  <p><span>小休累计时长</span><span>{{ scope.row.engineer_sum_rest_time }}</span></p>
                  <p><span>挂起累计次数</span><span>{{ scope.row.engineer_hangup_num }}</span></p>
                  <p><span>挂起累计时长</span><span>{{ scope.row.engineer_sum_hangup_time }}</span></p>
                </div>
              </div>
              <div slot="reference" class="name-wrapper">
                <el-button
                  type="text"
                  size="small"
                >
                  查看详情
                </el-button>
              </div>
            </el-popover>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        background
        :current-page.sync="customerDetails.page"
        :page-size="customerDetails.size"
        :page-sizes="[10, 15, 20, 25]"
        layout="total, sizes, prev, pager, next, jumper"
        :total="customerDetails.total"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </el-card>
  </div>
</template>
<script>
  import {
    getCustomerDetails
  } from '@/api/ccp/index'
  export default {
    name: 'customer-info',
    data() {
      return {
        input: '',
        LocalesDtate: [],
        options: [],
        statusOptions: [{
          label: '全部',
          value: ''
        }, {
          label: '在线',
          value: 'online'
        }, {
          label: '离线',
          value: 'offline'
        }, {
          label: '小休',
          value: 'rest'
        }],
        timer: null,
        value: '',
        scene: [],
        defaultProps: {
          children: 'childs',
          label: 'name'
        },
        query: {
          businessID: '',
          business: '',
          accessID: '',
          access: ''
        },
        tableData: [{
          name: 'zhangshan'
        }],
        customerDetails: {
          page: 1,
          size: 20,
          total: 1
        },
        total: 0
      }
    },
    watch: {
      value: function() {
        this._getCustomerDetails()
      }
    },
    mounted() {
      clearInterval(this.timer)
      this.init()
      // this.IntervalGetdata()
    },
    deactivated() {
      clearInterval(this.timer)
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    methods: {
      init() {
        this._getCustomerDetails()
      },
      IntervalGetdata() {
        this.timer = setInterval(() => {
          this.init()
        }, 30000) // 30秒刷新一次
      },
      searchInfo() {
        this._getCustomerDetails()
      },
      handleSelectionChange() {
      },
      examine(item) {
        console.log(item)
      },
      download() {
        const para = {
          businessId: this.$route.query.businessID,
          engineer: this.input,
          status: this.value,
          page: this.customerDetails.page,
          size: this.customerDetails.size,
          isExcel: true
        }
        getCustomerDetails(para).then(res => {
          if (res.data.download) {
            window.location.href = res.data.download
          } else {
            this.$message({
              message: '暂无数据，无法进行下载。'
            })
          }
        }).catch(this.$message.error)
      },
      _getCustomerDetails() {
        const para = {
          businessId: this.$route.query.businessID,
          status: this.value,
          engineer: this.input,
          page: this.customerDetails.page,
          size: this.customerDetails.size
        }
        getCustomerDetails(para).then(res => {
          this.customerDetails.page = res.data.current_page
          this.customerDetails.size = res.data.size
          this.customerDetails.total = res.data.total
          this.tableData = res.data.list
        })
      },
      handleSizeChange(size) {
        this.customerDetails.size = size
        this.customerDetails.page = 1
        this._getCustomerDetails()
      },
      handleCurrentChange(page) {
        this.customerDetails.page = page
        this._getCustomerDetails()
      }
    }
  }
</script>
<style lang="scss" scoped>
.status {
	flex: 1;
	.only {
		color: #606266;
		font-size: 12px;
	}
}
.flex-wrap {
	margin-left: 10px;
}
.dashboard_select {
  position: relative;
  // display: flex;
  justify-content: space-between;
  margin: 0;
  line-height: 36px;
  height: 36px;
  >div {
    float: left;
    margin-left: 5px;
  }
  .cascader {
    padding-left: 5px;
    /deep/ .el-input__suffix {
      display: none;
    }
  }
  .box {
    position: absolute;
    right: 130px;
    top: 14px;
    width: 0;
    height: 0;
    transform-origin: center;
    transition: transform .3s;
    // border-top: 8px solid #1a8fff;
    border-right: 8px solid  rgba(0,0,0,0);
    border-left: 8px solid  rgba(0,0,0,0);
	}
	.dashboard_tilte {
		position: absolute;
    left: 130px;
		top: 2px;
		font-size: 14px;
		font-weight: 800;
		color: #303133;
	}
  .box-focus {
    transform: rotate(180deg);
    transition: transform .3s
  }
  & /deep/ .el-input__inner{
    border: 0;
    background: rgba(0,0,0,0);
    color: #303133;
    font-weight: 600;
  }
  & /deep/ .el-input__icon {
    font-size: 0;
  }

  p {
    text-align: right;
    color: #4a90e2;
    font-size: 16px;
    font-weight: bold;
    margin: 0;
    float: left;
    width: 100%;
    i {
      font-style: normal;
      font-size: 24px;
      color: #ff8060;
      line-height: 36px;
      padding-left: 4px;
    }
  }
  .btn {
    width: 100px;
    height: 36px;
    margin-left: 20px;
  }
}
.popover-class {
  min-height: 300px;
  width: 260px;
  overflow-y: auto;
  .popover-title {
    font-weight: 800;
    color: #303133;
  }
  p {
    font-size: 10px;
  }
  .popover-groups {
    display: flex;
    text-align: center;
    justify-content: space-between;
    p {
      span {
        display: block;
      }
    }
  }
  .popover-service-groups {
    p {
      display: flex;
      justify-content: space-between;
    }
  }
}
</style>

