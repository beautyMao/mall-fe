<template>
  <div class="app-container">
    <header>
      <h1>会话详情</h1>
    </header>
    <div class="pb60">
      <el-card>
        <session-detail-list :list-data="data.session_info ? [data.session_info] : []" />
      </el-card>
      <el-card>
        <user-detail-list :list-data="data.user_info ? [data.user_info] : []" />
      </el-card>
      <el-card>
        <service-detail-list :list-data="data.case_info" />
      </el-card>
    </div>
    <div class="text-right session-detail-footer flex-wrp flex-bottom ptb15 pr20 border-t bg-white">
      <el-button type="primary" class="plr55 ptb15 size14" plain @click="downloadVoice">{{ $route.query.client_type !== 'phone' ? '导出聊天记录' : '导出录音' }}</el-button>
    </div>
  </div>
</template>
<script>
  import * as ccpApi from '@/api/ccp/index'
  import sessionDetailList from './components/sessionDetailList'
  import userDetailList from './components/userDetailList'
  import serviceDetailList from './components/serviceDetailList'
  // getApiCubeCcpSessionInfo
  export default {
    name: 'session-detail',
    components: {
      sessionDetailList,
      userDetailList,
      serviceDetailList
    },
    data() {
      return {
        data: {}
      }
    },
    mounted() {
      const { params: { id: sessionId }, query: { businessID: businessId }} = this.$route
      ccpApi.getApiCubeCcpSessionInfo({
        businessId,
        sessionId
      }).then(res => {
        res.data.session_info.problem_type = res.data.session_info.problem_type[res.data.session_info.problem_type.length - 1]
        res.data.case_info = res.data.case_info.map(item => {
          item.problem_type = item.problem_type[item.problem_type.length - 1]
          return item
        })
        this.data = res.data
      })
    },
    methods: {
      downloadVoice() {
        const { params: { id: sessionId }, query: { businessID: businessId }} = this.$route
        ccpApi.getApiCubeCcpSessionExcel({ sessionId, businessId }).then(res => {
          window.location.href = res.data.download
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
.session-detail-footer {
  position: fixed;
  bottom: 0;
  right: 0;
  left: 0;
  z-index: 10;
}
</style>

