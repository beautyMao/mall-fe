<template>
  <div class="app-container">
    <header>
      <div class="dashboard_select">
        <div style="width:300px;"> {{ $route.query.businessName }}&nbsp; &nbsp; &nbsp; &nbsp; 业务趋势</div>
      </div>
      <div class="flex-wrap">
        <el-button type="primary" plain @click="download">下载列表</el-button>
      </div>
    </header>
    <div class="dashboard-main">
      <div class="dashboard-left">
        <all-service-data ref="allService" :show-title="false" @getTableData="getTableData" />
      </div>
      <div class="dashboard-right">
        <class-chart ref="classChart" />
        <emotion-chart ref="emotionChart" />
      </div>
    </div>
    <header class="hide-tilte">
      <div class="dashboard_tilte"><el-checkbox v-model="checked" />&nbsp;&nbsp;隐藏无进入量时段</div>
    </header>
    <el-card class="box-card">
      <el-table :data="checked ? searchTableData : tableData">
        <el-table-column
          prop="time_paragraph"
          label="时间段"
          sortable
        />
        <el-table-column
          prop="call_numm"
          label="来电量"
          sortable
          width="135"
        />
        <el-table-column
          prop="service_num"
          label="服务量"
          sortable
          width="135"
        />
        <el-table-column
          prop="call_in_num"
          label="呼入量"
          sortable
          width="135"
        />
        <el-table-column
          prop="call_out_num"
          label="呼出量"
          sortable
          width="135"
        />
        <el-table-column
          prop="thirty_second_up"
          label="30s接起量"
          sortable
          width="135"
        />
        <el-table-column
          prop="avg_call_time"
          label="平均等待时长"
          sortable
        />
        <el-table-column
          prop="abandon_num"
          label="放弃量"
          sortable
          width="135"
        />
        <el-table-column
          prop="abandon_rate"
          label="放弃率"
          sortable
          width="135"
        />
        <el-table-column
          prop="service_level"
          label="服务水平"
          sortable
          width="135"
        >
          <template slot-scope="props">
            <span>{{ props.row.service_level + '%' }}</span>
          </template>
        </el-table-column>
        <el-table-column
          fixed="right"
          label="操作"
        >
          <template>
            <!-- @click.native.prevent="examine(scope.$index, tableData)" -->
            <el-button
              type="text"
              size="small"
              @click="$router.push({ path: `/devccp-management/session-info`})"
            >
              查看会话
            </el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
  </div>
</template>
<script>
  import allServiceData from '@/views/devccp/service-management/all-service-data'
  import classChart from '@/views/devccp/service-management/ClassChart'
  import emotionChart from '@/views/devccp/service-management/EmotionChart'
  export default {
    name: 'service-volume-info',
    components: {
      allServiceData,
      classChart,
      emotionChart
    },
    data() {
      return {
        placeholder: '现场选择',
        input: '',
        LocalesDtate: [],
        scene: Number(this.$route.query.businessID),
        UpOrderStatus: [],
        timer: null,
        query: {
          businessID: '',
          business: '',
          accessID: '',
          access: ''
        },
        tableData: [],
        searchTableData: [],
        checked: true,
        total: 0
      }
    },
    mounted() {
      clearInterval(this.timer)
      this.init()
      // this.IntervalGetdata()
    },
    deactivated() {
      clearInterval(this.timer)
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    methods: {
      init() {
        this.$refs.allService.init()
        this.$refs.classChart._getNewCaseLabels()
        this.$refs.emotionChart.initChart()
      },
      IntervalGetdata() {
        this.timer = setInterval(() => {
          this.init()
        }, 30000) // 30秒刷新一次
      },
      download() {
        this.$refs.allService.init(true)
      },
      getTableData(tableData) {
        const data = []
        this.searchTableData = []
        for (const key in tableData) {
          data.push(tableData[key])
          if (tableData[key].abandon_num || tableData[key].call_in_num || tableData[key].call_numm || tableData[key].call_out_num || tableData[key].service_num || tableData[key].thirty_second_up) {
            this.searchTableData.push(tableData[key])
          }
        }
        this.tableData = data
      }
    }
  }
</script>
<style lang="scss" scoped>
.flex-wrap {
	margin-left: 10px;
}
.hide-tilte .dashboard_tilte {
	font-size: 14px;
	font-weight: 800;
	color: #303133;
}
.dashboard_select {
  position: relative;
  // display: flex;
  justify-content: space-between;
  margin: 0;
  line-height: 36px;
  height: 36px;
  >div {
    float: left;
    margin-left: 5px;
  }
  .el-cascader {
    min-width: 200px;
    max-width: 300px;
    padding-left: 5px;
    /deep/ .el-input, input {
      // display: none;
      width: 200px;
    }
  }
  .box {
    position: absolute;
    left: 130px;
    top: 14px;
    width: 0;
    height: 0;
    transform-origin: center;
    transition: transform .3s;
    border-top: 8px solid #1a8fff;
    border-right: 8px solid  rgba(0,0,0,0);
    border-left: 8px solid  rgba(0,0,0,0);
  }
  .right-menu {
    float: right;
    margin-right: 20px;
  }
  .tmie{
    font-size:14px;
    font-weight: 500;
    color: #303133;
  }
  .box-focus {
    transform: rotate(180deg);
    transition: transform .3s
  }
  & /deep/ .el-input__inner{
    border: 0;
    background: rgba(0,0,0,0);
    color: #303133;
    font-weight: 600;
  }
  & /deep/ .el-input__icon {
    font-size: 0;
  }

  p {
    text-align: right;
    color: #4a90e2;
    font-size: 16px;
    font-weight: bold;
    margin: 0;
    float: left;
    width: 100%;
    i {
      font-style: normal;
      font-size: 24px;
      color: #ff8060;
      line-height: 36px;
      padding-left: 4px;
    }
  }
  .btn {
    width: 100px;
    height: 36px;
    margin-left: 20px;
  }
}
.popover-class {
	min-height: 300px;
	width: 260px;
	overflow-y: auto;
	.popover-title {
		font-weight: 800;
		color: #303133;
	}
	p {
		font-size: 10px;
	}
	.popover-groups {
		display: flex;
		text-align: center;
		justify-content: space-between;
		p {
			span {
				display: block;
			}
		}
	}
	.popover-service-groups {
		p {
			display: flex;
			justify-content: space-between;
		}
	}
}
.dashboard-main {
	height: 500px;
  min-width: 1200px;
	margin-bottom: 20px;
	display: flex;
	.dashboard-left {
		width: 65%;
		margin-right: 20px;
	}
	.dashboard-right {
		// flex: 1;
    width: 35%;
		display: flex;
		flex-direction: column;
		.wrapper, .emotion {
			flex: 1;
		}
	}
	.dashboard-left, .all-service-data, /deep/ .el-card__body {
		height: 100%;
	}
}
/deep/ .el-input__inner::-webkit-input-placeholder { /* WebKit browsers */
  color: #303133;
  font-size: 16px;
}

/deep/ .el-input__inner::-moz-placeholder { /* Mozilla Firefox 19+ */
  color: #303133;
  font-size: 16px;
}

/deep/ .el-input__inner::-ms-input-placeholder { /* Internet Explorer 10+ */
  color: #303133;
  font-size: 16px;
}
</style>

