<template>
  <div class="app-container">
    <header>
      <div class="dashboard_select">
        <div style="width:300px;"> {{ $route.query.businessName }}&nbsp; &nbsp; &nbsp; &nbsp; 情感监控</div>
      </div>
      <div class="flex-wrap">
        <el-date-picker
          v-model="seldate"
          :style="{width: '160px'}"
          :editable="false"
          :clearable="false"
          type="date"
          :picker-options="pickerOptions"
          value-format="yyyy-MM-dd"
          placeholder="选择日期"
          @change="userseldate"
        />
        <el-button class="ml10" type="primary" plain :disabled="!tableData.length" @click="downloadExcel">下载列表</el-button>
      </div>
    </header>
    <div class="dashboard-main">
      <div class="dashboard-left">
        <class-info-data-column ref="classInfoDataColumn" :show-title="false" />
      </div>
      <div class="dashboard-right">
        <class-info-data-line ref="classInfoDataLine" :show-title="false" />
      </div>
    </div>
    <div class="pb20">
      <span class="bold size16 mr5" :style="{color: '#303133'}">情绪</span>
      <el-select v-model="emotion" placeholder="情绪" @change="emotionChange">
        <el-option
          v-for="item in emotions"
          :key="item.value"
          :label="item.name"
          :value="item.name"
        />
      </el-select>
    </div>
    <el-card class="box-card">
      <el-table :data="tableData">
        <el-table-column
          prop="id"
          label="会话ID"
          sortable
        />
        <el-table-column
          prop="status"
          label="会话状态"
          sortable
        />
        <el-table-column
          prop="start_talking_at"
          label="开始时间"
          sortable
        />
        <el-table-column
          prop="continued_time"
          label="持续时间"
          sortable
        />
        <el-table-column
          prop="engineer"
          label="客服"
          sortable
        />
        <el-table-column
          prop="current_queue_name"
          label="客服组"
          sortable
        />
        <el-table-column
          prop="emotion"
          label="当前情感"
          sortable
        />
        <el-table-column
          fixed="right"
          label="操作"
        >
          <template slot-scope="scope">
            <!-- @click.native.prevent="examine(scope.$index, tableData)" -->
            <el-button
              type="text"
              size="small"
              @click="$router.push({ path: `/devccp-management/session-detail/${scope.row.id}`, query: scope.row })"
            >
              查看会话
            </el-button>
          </template>
        </el-table-column>
      </el-table>
      <!-- <div class="pagination-container">
        <el-pagination
          background
          :current-page="mypagination.current_page"
          :page-size="mypagination.datanum"
          :page-sizes="[10, 15, 20, 25]"
          layout="total, sizes, prev, pager, next, jumper"
          :total="mypagination.total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </div> -->
    </el-card>
  </div>
</template>
<script>
  import * as ccpApi from '@/api/ccp/index'
  import classInfoDataColumn from '@/views/devccp/service-management/class-info-data-column'
  import classInfoDataLine from '@/views/devccp/service-management/class-info-data-line'
  import classChart from '@/views/devccp/service-management/ClassChart'
  export default {
    name: 'emotion-info',
    components: {
      classInfoDataColumn,
      classInfoDataLine,
      classChart
    },
    data() {
      return {
        scene: Number(this.$route.query.businessID),
        tableData: [],
        emotions: [{
          name: '全部',
          value: 'all'
        }, {
          name: '惊喜',
          value: '3'
        }, {
          name: '愉悦',
          value: '2'
        }, {
          name: '正常',
          value: '1'
        }, {
          name: '不满',
          value: '4'
        }, {
          name: '愤怒',
          value: '5'
        }],
        emotion: '全部',
        localTableData: [],
        mypagination: {
          current_page: 1,
          datanum: 20,
          total: 1
        },
        timer: null,
        UpOrderStatus: [],
        seldate: '',
        pickerOptions: '',
        placeholder: ''
      }
    },
    deactivated() {
      clearInterval(this.timer)
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    mounted() {
      clearInterval(this.timer)
      this.getInitData()
      this.init()
      // this.IntervalGetdata()
    },
    methods: {
      init(date = this.seldate) {
        // this.seldate = date
        const { businessID: businessId } = this.$route.query
        // SAAS - saas数据看板情感数据列表
        this.emotionChange()
        // SAAS - saas数据看板情感趋势
        ccpApi.getApiCubeCcpEmotionGetEmotionsByHours({ date, businessId }).then(res => {
          this.$refs.classInfoDataLine.init(res.data)
        })
        // SAAS - saas数据看板用户情感占比
        ccpApi.getApiCubeCcpEmotionGet({ date, businessId }).then(res => {
          this.$refs.classInfoDataColumn.init(res.data)
        })
      },
      getInitData() {
        const initdate = new Date()
        const curentday = initdate.getDate() < 10 ? '0' + initdate.getDate() : initdate.getDate()
        const curentmonth = initdate.getMonth() + 1 < 10 ? '0' + `${initdate.getMonth() + 1}` : `${initdate.getMonth() + 1}`
        this.seldate = `${initdate.getFullYear()}-${curentmonth}-${curentday}`
        this.pickerOptions = {
          disabledDate(time) {
            return time.getTime() > Date.now()
          }
        }
      },
      IntervalGetdata() {
        this.timer = setInterval(() => {
          this.init()
        }, 30000) // 30秒刷新一次
      },
      userseldate(date) {
        this.init(date)
      },
      handleCascaderChange(businessID) {
        this.$router.push({ query: { businessID }})
        this.init()
      },
      handleCurrentChange(val) {
        this.mypagination.current_page = val
        this.localPagination()
      },
      localPagination() {
        const number = (this.mypagination.current_page - 1) * this.mypagination.datanum
        this.localTableData = this.tableData.slice(number, number + this.mypagination.datanum)
        this.mypagination.total = this.tableData.length
      },
      handleSizeChange(val) {
        this.mypagination.datanum = val
        this.localPagination()
      },
      emotionChange() {
        const { businessID: businessId } = this.$route.query

        // SAAS - saas数据看板情感数据列表
        ccpApi.getApiCubeCcpEmotionGetEmotionsList({ date: this.seldate, businessId }).then(res => {
          if (this.emotion === '全部') {
            this.tableData = res.data
            this.mypagination.current_page = 1
            this.localPagination()
          } else {
            this.tableData = res.data.filter(item => item.emotion === this.emotion)
            this.mypagination.current_page = 1
            this.localPagination()
          }
        })
      },
      downloadExcel() {
        console.log(this.seldate, this.emotion, 111)
        const { businessID: businessId } = this.$route.query
        let emotion = ''
        switch (this.emotion) {
        case '愤怒':
          emotion = 'not_at_all'
          break
        case '不满':
          emotion = 'slightly'
          break
        case '正常':
          emotion = 'moderately'
          break
        case '愉悦':
          emotion = 'very'
          break
        case '惊喜':
          emotion = 'extremely'
          break
        }
        console.log({ emotion: emotion, date: this.seldate, businessId, isExcel: true })
        ccpApi.getApiCubeCcpEmotionGetEmotionsList({ emotion: emotion, date: this.seldate, businessId, isExcel: true }).then(res => {
          window.location.href = res.data.download
        })
      },
      clearChildren(arr) {
        const { businessID: businessId } = this.$route.query
        const arrFn = item => {
          item.forEach(it => {
            if (it.id === Number(businessId)) {
              this.placeholder = it
            }
            if (it.childs && !it.childs.length) {
              delete it.childs
            }
            Array.isArray(it.childs) && arrFn(it.childs)
          })
        }
        arrFn(arr)
        return arr
      },
      getQuestion() {
        ccpApi.getBusinessesList().then(res => {
          this.UpOrderStatus = this.clearChildren(res.data)
        })
      }
    }
  }
</script>
<style lang="scss" scoped>
.flex-wrap {
	margin-left: 10px;
}
.hide-tilte .dashboard_tilte {
	font-size: 14px;
	font-weight: 800;
	color: #303133;
}
.dashboard_select {
  position: relative;
  // display: flex;
  justify-content: space-between;
  margin: 0;
  line-height: 36px;
  height: 36px;
  >div {
    float: left;
    margin-left: 5px;
  }
  .el-cascader {
    min-width: 200px;
    max-width: 300px;
    padding-left: 5px;
    /deep/ .el-input, input {
      // display: none;
      width: 200px;
    }
  }
  .box {
    position: absolute;
    left: 130px;
    top: 14px;
    width: 0;
    height: 0;
    transform-origin: center;
    transition: transform .3s;
    border-top: 8px solid #1a8fff;
    border-right: 8px solid  rgba(0,0,0,0);
    border-left: 8px solid  rgba(0,0,0,0);
  }
  .right-menu {
    float: right;
    margin-right: 20px;
  }
  .dashboard_title {
    font-size: 16px;
    font-weight: 500;
  }
  .tmie{
    font-size:14px;
    font-weight: 500;
    color: #303133;
  }
  .box-focus {
    transform: rotate(180deg);
    transition: transform .3s
  }
  & /deep/ .el-input__inner{
    border: 0;
    background: rgba(0,0,0,0);
    color: #303133;
    font-weight: 600;
  }
  & /deep/ .el-input__icon {
    font-size: 0;
  }

  p {
    text-align: right;
    color: #4a90e2;
    font-size: 16px;
    font-weight: bold;
    margin: 0;
    float: left;
    width: 100%;
    i {
      font-style: normal;
      font-size: 24px;
      color: #ff8060;
      line-height: 36px;
      padding-left: 4px;
    }
  }
  .btn {
    width: 100px;
    height: 36px;
    margin-left: 20px;
  }
}
.popover-class {
	min-height: 300px;
	width: 260px;
	overflow-y: auto;
	.popover-title {
		font-weight: 800;
		color: #303133;
	}
	p {
		font-size: 10px;
	}
	.popover-groups {
		display: flex;
		text-align: center;
		justify-content: space-between;
		p {
			span {
				display: block;
			}
		}
	}
	.popover-service-groups {
		p {
			display: flex;
			justify-content: space-between;
		}
	}
}
.dashboard-main {
	height: 400px;
	margin-bottom: 20px;
	display: flex;
	.dashboard-left {
		width: 55%;
		margin-right: 20px;
	}
	.dashboard-right {
		width: 45%;
		display: flex;
		flex-direction: column;
		.wrapper, .emotion {
			flex: 1;
		}
	}
	.dashboard-left, .all-service-data, /deep/ .el-card__body {
		height: 100%;
	}
}
</style>

