<template>
  <div>
    <header>
      <h2>查询结果</h2>
    </header>
    <el-table :data="listData" tooltip-effect="light">
      <el-table-column label="会话ID" width="120">
        <template slot-scope="scope">
          <a style="color:#4A90E2" @click="handleEdit(scope.$index, scope.row)">{{ scope.row.id }}</a>
        </template>
      </el-table-column>
      <el-table-column prop="user_name" label="客户姓名" width="100" />
      <el-table-column label="来电号码">
        <template slot-scope="scope">
          <span v-if="scope.row.phone">{{ scope.row && Array.isArray(JSON.parse(scope.row.phone)) ? JSON.parse(scope.row.phone).join(', ') : JSON.parse(scope.row.phone) }}</span>
          <span v-else />
        </template>
      </el-table-column>
      <el-table-column prop="access_name" label="通路" />
      <el-table-column prop="emotion" label="会话情感" width="80">
        <template slot-scope="scope">
          {{ scope.row.emotion && emotionsFn(scope.row.emotion) }}
        </template>
      </el-table-column>
      <!-- <el-table-column prop="channel" label="通路" /> -->
      <!-- <el-table-column prop="session_id" label="问题分类" /> -->
      <el-table-column prop="level" label="处理客服" width="120">
        <template slot-scope="scope">
          {{ scope.row.engineer_name }}/{{ scope.row.engineer_code }}
        </template>
      </el-table-column>
      <el-table-column prop="current_queue_name" label="客服组" width="120" />
      <el-table-column prop="created_at" label="开始时间" width="160" />
    </el-table>
  </div>
</template>

<script>
  export default {
    props: {
      listData: {
        type: Array,
        default: () => []
      }
    },
    data() {
      return {}
    },
    methods: {
      handleEdit(index, row) { // 获取详情信息
        this.$router.push({
          path: `/devccp-management/session-detail/${row.id}`,
          query: row
        })
      },
      emotionsFn(val) {
        if (val <= 1) {
          return '愤怒'
        } else if (val > 1 && val <= 2) {
          return '不满'
        } else if (val > 2 && val <= 3) {
          return '正常'
        } else if (val > 3 && val <= 4) {
          return '愉悦'
        } else if (val > 4) {
          return '惊喜'
        }
      }
    }
  }
</script>
