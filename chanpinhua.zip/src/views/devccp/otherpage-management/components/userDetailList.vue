<template>
  <div>
    <header>
      <h2>客户基本信息</h2>
    </header>
    <el-table :data="listData" tooltip-effect="light">
      <el-table-column label="客户ID">
        <template slot-scope="scope">
          <el-button type="text" @click="gotoDetail(scope.row)">{{ scope.row.customer_id }}</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="user_name" label="客户姓名" />
      <el-table-column label="主叫号码" :formatter="displayPhone" />
      <el-table-column prop="open_id" label="OpenID" />
    </el-table>
  </div>
</template>

<script>
  export default {
    props: {
      listData: {
        type: Array,
        default: () => []
      }
    },
    methods: {
      // phone 可能是个数组字符串
      displayPhone(row) {
        let re = row.phone
        if (!re) {
          return re
        }
        try {
          re = JSON.parse(re).join(',')
        } catch (e) { e }
        return re
      },
      gotoDetail(row) {
        this.$router.push({
          path: '/crm/detail', query: {
            cid: row.customer_id
          }
        })
      }
    }
  }
</script>
