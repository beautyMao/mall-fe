<template>
  <header>
    <h2>精确查询</h2>
    <el-form ref="ruleForm" label-width="100px" :model="chatData" :rules="rules" :inline="true" @submit.native.prevent>
      <el-form-item prop="session_id">
        <el-input v-model="chatData.session_id" clearable placeholder="会话ID" />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" plain @click="submitExactForm">查询</el-button>
      </el-form-item>
    </el-form>
  </header>
</template>

<script>
  export default {
    name: 'precise-query',
    data() {
      const validateSessionId = (rule, value, callback) => {
        if (value === '') {
          callback(new Error('请输入会话ID'))
        } else if (!/^[A-Za-z0-9\-\_]+$/.test(this.session_id)) {
          callback(new Error('IR ID只可输入字母或数字_-'))
        } else if (value.length > 50) {
          callback(new Error('IR ID最多输入50个字符'))
        } else {
          callback()
        }
      }
      return {
        chatData: {
          session_id: ''
        },
        rules: {
          session_id: [
            { validator: validateSessionId, trigger: 'blur' }
          ]
        }
      }
    },
    methods: {
      submitExactForm() { // 获取列表数据
        this.$refs['ruleForm'].validate(valid => {
          if (valid) {
            this.$emit('exactInfoSucc', this.chatData)
          } else {
            return false
          }
        })
      }
    }
  }
</script>
