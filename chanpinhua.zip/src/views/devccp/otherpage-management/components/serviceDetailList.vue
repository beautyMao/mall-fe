<template>
  <div>
    <header>
      <h2>关联服务记录</h2>
    </header>
    <el-table :data="listData" tooltip-effect="light">
      <el-table-column label="服务记录ID">
        <template slot-scope="scope">
          <el-button type="text" style="color:#4A90E2" @click="$router.push({ path: '/demand/case-query/particulars', query: { ...scope.row, case_id: scope.row.id } })">{{ scope.row && scope.row.id }}</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="problem_type" label="问题分类" />
      <el-table-column prop="description" label="问题描述" />
      <el-table-column prop="file" label="是否有附件" />
      <el-table-column prop="create_name" label="创建人" />
      <el-table-column prop="created_at" label="创建时间" />
    </el-table>
  </div>
</template>

<script>
  export default {
    props: {
      listData: {
        type: Array,
        default: () => []
      }
    },
    methods: {
    }
  }
</script>
