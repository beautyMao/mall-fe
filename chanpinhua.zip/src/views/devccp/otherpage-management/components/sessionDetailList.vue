<template>
  <div>
    <header>
      <h2>会话信息</h2>
    </header>
    <el-table :data="listData" tooltip-effect="light">
      <el-table-column label="会话ID">
        <template slot-scope="scope">
          <el-button type="text" style="color:#4A90E2" @click="$router.push({ path: '/demand/touch/particulars', query: { ...scope.row, type: scope.row.client_type } })">{{ scope.row && scope.row.id }}</el-button>
        </template>
      </el-table-column>
      <el-table-column prop="access_name" label="通路" />
      <el-table-column prop="emotion" label="会话情感" />
      <el-table-column prop="problem_type" label="问题分类" />
      <el-table-column prop="engineer" label="处理客服" />
      <el-table-column prop="engineer_group" label="客服组" />
      <el-table-column prop="start_talking_at" label="开始时间" />
      <el-table-column prop="end_talking_at" label="结束时间" />
    </el-table>
  </div>
</template>

<script>
  export default {
    props: {
      listData: {
        type: Array,
        default: () => []
      }
    }
  }
</script>
