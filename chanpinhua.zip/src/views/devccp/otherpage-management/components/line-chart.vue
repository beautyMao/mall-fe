<template>
  <el-card :body-style="{ padding: '0px' }" class="all-service-data" :style="lineChartStyleH">
    <!-- :style="lineChartStyleH" -->
    <div class="title">地区来电量趋势</div>
    <!-- <div class="all-phone-num">总来电量 9,999</div>
    <div class="visual-map">
      <p><span /><span>服务量</span></p>
      <p><span class="gaveupBg" /><span>放弃量</span></p>
      <p><span class="gaveupRateBg" /><span>放弃率</span></p>
    </div> -->
    <div id="line-chart" class="line-chart" :style="chartStyleH" />
  </el-card>
</template>
<script>
  import echarts from 'echarts'
  import {
    getCallsbyhours
  } from '@/api/ccp/index'
  export default {
    name: 'line-chart',
    data() {
      return {
        lineChartStyleH: '',
        chartStyleH: '',
        option: {
          color: ['#8B70FC', '#7EF7FF', '#2295FF'],
          tooltip: {
            trigger: 'axis',
            formatter: function(params) {
              // let res = `${params[0].name}${params[0].dataIndex * 2 > 9 ? params[0].dataIndex * 2 + 1 : '0' + (params[0].dataIndex * 2 + 1)}: 00`
              let res = `${params[0].name}`
              res += `<br/>来电量: ${params[0].value || 0}`
              return res
            },
            backgroundColor: '#1890FF',
            axisPointer: {
              type: 'cross',
              label: {
                backgroundColor: '#6a7985'
              }
            }
          },
          grid: {
            left: '6%',
            right: '6%',
            bottom: 0,
            containLabel: true
          },
          xAxis: [
            {
              type: 'category',
              data: ['0:00', '4:00', '8:00', '12:00', '16:00', '20:00', '24:00'],
              axisLine: {
                onZero: false,
                lineStyle: {
                  color: '#2295FF'
                }
              },
              axisPointer: {
                type: 'shadow'
              }
            }
          ],
          yAxis: [
            {
              type: 'value',
              axisLabel: {
                formatter: '{value}' // 刻度标签的内容格式器
              }
            },
            {
              type: 'value',
              splitLine: {
                show: false
              },
              axisLabel: {
                formatter: '{value} %'
              }
            }
          ],
          series: [
            {
              name: '放弃率',
              type: 'line',
              yAxisIndex: 1,
              smooth: true,
              // symbol: 'none', // 是否显示小圆点  默认不写
              // sampling: 'average', // 是否平滑曲线显示
              data: []
            }
          ]
        }
      }
    },
    mounted() {
    },
    methods: {
      _getCallsbyhours(pro) {
        getCallsbyhours(this.$route.query.businessID, pro).then(res => {
          this.option.xAxis[0].data = res.data.hours
          this.option.series[0].data = res.data.robot
          this.$nextTick(() => {
            this.showChart()
          })
        })
      },
      showChart() {
        this.chart = echarts.init(document.getElementById('line-chart'))
        if (this.chart) {
          this.chart.setOption(this.option)
          const that = this
          setTimeout(function() {
            window.onresize = function() {
              that.chart.resize()
            }
          }, 200)
        }
      }
    }
  }
</script>
<style lang="scss" scoped>
.all-service-data {
  position: relative;
  // height: 50%;
  display: flex;
  flex-direction: column;

}
.title {
	padding: 0 10px;
	margin: 10px 0;
	color: #303133;
	font-size: 17px;
	line-height: 30px;
	font-weight: bold;
}
.pointer {
	cursor: pointer !important;
}
.all-phone-num {
	position: absolute;
	top: 30px;
	padding: 0 10px;
	margin: 10px 0;
	line-height: 40px;
	color: #909399;
	font-size: 14px;
}
.visual-map {
	position: absolute;
	right: 10px;
	top: 10px;
	p {
		font-size: 12px;
		padding: 5px;
		line-height: 15px;
		margin: 0;
		color: #909399;
		display: flex;
		:first-child {
			display: inline-block;
			width: 40px;
			height: 14px;
			background-color: #1890FF;
			margin-right: 5px;
		}
		.gaveupBg {
			background-color: #7EF7FF;
		}
		.gaveupRateBg {
			height: 2px;
			margin-top: 7px;
			background-color: #8B70FC;
		}
	}
}
.line-chart {
  height: calc(100% - 60px);
  padding-bottom: 10px;
  flex: 1;
}

</style>

