<template>
  <header>
    <h2>条件查询</h2>
    <el-form ref="ruleForm" :model="ruleForm" :rules="rules" label-width="100px" :inline="true">
      <el-form-item label="" prop="user_name">
        <el-input v-model="ruleForm.user_name" clearable placeholder="客户姓名" />
      </el-form-item>
      <el-form-item label="" prop="phone">
        <el-input v-model="ruleForm.phone" clearable placeholder="来电号码" />
      </el-form-item>
      <el-form-item label="" prop="client_type">
        <el-select v-model="ruleForm.client_type" value="" clearable placeholder="接触方式">
          <el-option
            v-for="item in IRType"
            :key="item.ParaValue"
            :label="item.ParaValue"
            :value="item.ParaCode"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="" prop="emotion">
        <el-select v-model="ruleForm.emotion" placeholder="会话情感" clearable>
          <el-option v-for="item in emotions" :key="item.value" :label="item.name" :value="item.value" />
        </el-select>
      </el-form-item>
      <!-- <el-form-item label="" prop="class_name">
        <el-cascader
          placeholder="问题分类，可搜索"
          filterable
          clearable
          :options="UpOrderStatus"
          :props="{ label: 'name', value: 'name', children: 'children', emitPath: false }"
          v-model="ruleForm.class_name"
        />
      </el-form-item> -->
      <el-form-item label="" prop="engineer">
        <el-select
          v-model="ruleForm.engineer"
          filterable
          remote
          clearable
          reserve-keyword
          placeholder="客服工号 / 姓名"
          :remote-method="remoteMethod"
        >
          <el-option
            v-for="item in users"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="" prop="groups">
        <el-select
          v-model="ruleForm.groups_name"
          filterable
          remote
          clearable
          reserve-keyword
          placeholder="客服组"
          :remote-method="remoteMethodGroupsName"
        >
          <el-option
            v-for="item in groups"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label="" prop="reviewdate">
        <ext-date-picker
          ref="time"
          v-model="ruleForm.reviewdate"
          class="time"
          type="daterange"
          range-separator="至"
          placehoder="IR开始时间"
          start-placeholder="开始时间"
          end-placeholder="结束时间"
          :picker-options="pickerOptions"
          format="yyyy 年 MM 月 dd 日"
          value-format="yyyy-MM-dd"
          @change="hanleTiemScope"
        />
      </el-form-item>
    </el-form>
    <p class="text-right">
      <el-button type="primary" plain @click="submitConditionForm('ruleForm')">查询</el-button>
      <el-button plain @click="resetConditionForm('ruleForm')">重置</el-button>
    </p>
  </header>
</template>

<script>
  // import { getBusinessInfo } from '@/api/review/index'
  import * as ccpApi from '@/api/queue-management/pond'
  import ExtDatePicker from '@/components/ExtDatePicker'
  import { getApiWbClassifiedProblem } from '@/api/queue-management/demand/case.js'
  import { getIRContactType, getSearchEngineer } from '@/api/touch'
  import { getDateFormat, deepClone } from '@/utils'
  // getApiWbQueueSearch
  export default {
    components: { ExtDatePicker },
    data() {
      return {
        ruleForm: {
          user_name: '', // 用户标识 手机号
          phone: '', // 通路
          client_type: '', // 客服工号姓名
          emotion: '', // 点评星级
          classified_problem_id: '',
          engineer: '', // 开始日期
          groups: '', // 结束日期
          reviewdate: [getDateFormat('yyyy-MM-dd', new Date(Date.now() - (3600000 * 24 * 6))), getDateFormat('yyyy-MM-dd', new Date())]
        },
        rules: {
          user_name: [{ trigger: 'blur', message: '请输入客户姓名' }],
          phone: [{ trigger: 'blur', message: '请输入来电号码' }],
          client_type: [{ trigger: 'blur', message: '请选择接触方式' }],
          emotion: [{ trigger: 'blur', message: '请选择会话情感' }],
          classified_problem_id: [{ required: false, trigger: 'blur', message: '请选择问题类型' }],
          engineer: [{ trigger: 'blur', message: '请输入客服工号 / 姓名' }],
          groups: [{ trigger: 'blur', message: '请选择客服组' }],
          reviewdate: [{ required: true, trigger: ['change', 'blur'], message: '请选择开始日期 / 结束日期' }]
        },
        IRType: [],
        emotions: [{
          name: '惊喜',
          value: '4'
        }, {
          name: '愉悦',
          value: '3'
        }, {
          name: '正常',
          value: '2'
        }, {
          name: '不满',
          value: '1'
        }, {
          name: '愤怒',
          value: '0'
        }],
        ratings: [
          { code: 1, name: '1星' },
          { code: 2, name: '2星' },
          { code: 3, name: '3星' },
          { code: 4, name: '4星' },
          { code: 5, name: '5星' }],
        channel: [
          { id: 'wechat', name: '微信' },
          { id: 'chat', name: 'webchat' },
          { id: 'telephone', name: '电话' }
        ],
        reviewdate: null,
        pickerOptions: { // 禁止选择未来时间
          disabledDate(time) {
            return time.getTime() > Date.now()
          }
        },
        permission: {
          export: false
        },
        input: /^[A-Za-z0-9\-]+$/,
        UpOrderStatus: [],
        users: [],
        groups: []
      }
    },
    mounted() {
      // this.init()
      getIRContactType().then(res => { this.IRType = res.data }) // 接触方式
      this.getQuestion()
    },
    methods: {
      clearChildren(arr) {
        const arrFn = item => {
          item.forEach(it => {
            if (it.children && !it.children.length) {
              delete it.children
            }
            Array.isArray(it.children) && arrFn(it.children)
          })
        }
        arrFn(arr)
        return arr
      },
      getQuestion() {
        getApiWbClassifiedProblem().then(res => {
          this.UpOrderStatus = this.clearChildren(res.data)
        })
      },
      submitConditionForm(formName) { // 获取列表数据
        const ruleForm = deepClone(this.ruleForm)
        if (this.ruleForm.phone) {
          if (!this.input.test(this.ruleForm.phone)) {
            this.$message({
              message: '用户标识只可输入字母-或数字',
              type: 'warning'
            })
            return
          }
        }
        if (this.ruleForm.code) {
          if (!this.input.test(this.ruleForm.code)) {
            this.$message({
              message: '客服工号只可输入字母-或数字',
              type: 'warning'
            })
            return
          }
        }
        if (this.ruleForm.reviewdate) {
          ruleForm.start_time = this.ruleForm.reviewdate[0]
          ruleForm.end_time = this.ruleForm.reviewdate[1]
        }
        delete ruleForm.reviewdate
        ruleForm.queue_code = ruleForm.groups_name
        delete ruleForm.groups_name
        this.$emit('ruleForm', ruleForm)
      },
      defaultTime(val) {
        const now = new Date()
        const start = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() - val)).toISOString().slice(0, 10)
        const end = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10)
        this.ruleForm.reviewdate = [start, end]
      },
      resetConditionForm(formName) { // 重置数据
        this.ruleForm.groups_name = ''
        this.$refs[formName].resetFields()
        this.defaultTime(30)
      },
      hanleTiemScope() {}, // 设置时间跨度
      // init() {
      //   for (const i of this.$store.getters.user.buttonPermission) {
      //     switch (i.keyword) {
      //     case 'commentDataExport':
      //       this.permission.export = true
      //       break
      //     }
      //   }
      //   this.defaultTime(30) // 初始默认时间段
      //   getBusinessInfo().then(res => {
      //     this.Business = [...res.data]
      //   })
      // },
      remoteMethod(query) { // 模糊查询 客服
        getSearchEngineer(query).then(res => {
          this.users = res.data.map(item => ({
            value: item.code,
            label: item.code + ' / ' + item.name
          }))
        }).catch(this.$message.error)
      },
      remoteMethodGroupsName(query) { // 模糊查询 客服
        ccpApi.getApiWbQueueSearch(query).then(res => {
          this.groups = res.data.map(item => ({
            value: item.code,
            label: item.code + ' / ' + item.name
          }))
        }).catch(this.$message.error)
      }
    }
  }
</script>
