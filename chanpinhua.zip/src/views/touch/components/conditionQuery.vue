<template>
  <div>
    <h2>条件查询</h2>
    <el-form ref="ruleForm" :model="ruleForm" label-width="100px" :inline="true">
      <el-form-item prop="client_type" class="required">
        <el-select v-model="ruleForm.client_type" value="" clearable placeholder="接触方式">
          <el-option
            v-for="item in IRType"
            :key="item.ParaValue"
            :label="item.ParaValue"
            :value="item.ParaCode"
          />
        </el-select>
      </el-form-item>
      <el-form-item prop="tel_phone">
        <el-input v-model="ruleForm.tel_phone" clearable placeholder="客户电话" class="input" />
      </el-form-item>
<!--      <el-form-item prop="cube_uid">-->
<!--        <el-input v-model="ruleForm.cube_uid" clearable placeholder="客户ID" class="input" />-->
<!--      </el-form-item>-->
      <el-form-item prop="Enengineer_codegineer">
        <el-select
          v-model="ruleForm.engineer_code"
          filterable
          remote
          clearable
          reserve-keyword
          placeholder="客服ID/姓名"
          :remote-method="remoteMethod"
          :loading="loading"
          @change.native="handleUserChange"
          @click.native="handleUserClick"
        >
          <el-option
            v-for="item in user"
            :key="item.code"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
      </el-form-item>
      <el-form-item label-width="160px" prop="value1" class="required">
        <ext-date-picker
          ref="time"
          v-model="value1"
          size="large"
          type="daterange"
          placehoder="IR 开始时间"
          start-placeholder="开始时间"
          end-placeholder="结束日期"
          :picker-options="pickerOptions2"
          format="yyyy 年 MM 月 dd 日"
          value-format="yyyy-MM-dd"
          @change="hanleTiemScope"
        />
      </el-form-item>
    </el-form>
    <p class="text-right">
      <el-button plain type="primary" @click="submitConditionForm">查询</el-button>
      <el-button plain @click="resetConditionForm('ruleForm')">重置</el-button>
    </p>
  </div>
</template>

<script>
  import { getIRContactType, getSearchEngineer } from '@/api/touch'
  import ExtDatePicker from '@/components/ExtDatePicker'

  export default {
    components: { ExtDatePicker },
    data() {
      return {
        ruleForm: {
          client_type: '',
          tel_phone: '',
          cube_uid: '',
          engineer_code: '',
          begin_time: '',
          end_time: ''
        },
        debounceQuery: null,
        loading: false,
        user: [],
        value1: null,
        IRType: [],
        pickerOptions2: { // 禁止选择未来时间
          disabledDate(time) {
            return time.getTime() > Date.now()
          }
        },
        input: /^[A-Za-z0-9\-_]+$/
      }
    },
    activated() {
      const cube_uid = this.$route.query.cube_uid
      if (cube_uid) {
        this.ruleForm.cube_uid = cube_uid
        this.init()
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      submitConditionForm() { // 获取列表数据
        if (!this.ruleForm.client_type) {
          this.$message({
            message: '接触方式为必填项目',
            type: 'warning'
          })
          return
        }
        if (this.value1 === null) {
          this.$message({
            message: 'IR时间为必填项目',
            type: 'warning'
          })
          return
        }
        if (this.ruleForm.tel_phone) {
          if (!this.input.test(this.ruleForm.tel_phone)) {
            this.$message({
              message: '客户电话只可输入字母或数字_-',
              type: 'warning'
            })
            return
          }
          if (this.ruleForm.tel_phone.length > 50) {
            this.$message({
              message: '客户电话最多输入50个字符',
              type: 'warning'
            })
            return
          }
        }
        if (this.ruleForm.cube_uid) {
          if (!this.input.test(this.ruleForm.cube_uid)) {
            this.$message({
              message: '客户ID只可输入字母或数字下划线',
              type: 'warning'
            })
            return
          }
          if (this.ruleForm.cube_uid.length > 50) {
            this.$message({
              message: '客户ID最多输入50个字符',
              type: 'warning'
            })
            return
          }
        }
        if (this.ruleForm.engineer_code) {
          const input = /^[\w\u4E00-\u9FA5]{1,20}$/
          if (!input.test(this.ruleForm.engineer_code)) {
            this.$message({
              message: '客服ID/姓名输入格式错误',
              type: 'warning'
            })
            return
          }
        }
        this.ruleForm.begin_time = this.value1[0]
        this.ruleForm.end_time = this.value1[1]
        this.$emit('ruleForm', Object.assign({}, this.ruleForm))
      },
      resetConditionForm(formName) { // 重置数据
        this.$router.replace({
          path: this.$route.path,
          query: {}
        })
        this.$refs[formName].resetFields()
        this.ruleForm.engineer_code = ''
        this.$emit('reset')
        this.defaultTime(6)
      },
      hanleTiemScope() { // 设置时间跨度
        if (this.value1 === null) return
        let a = this.value1[0]
        let b = this.value1[1]
        a = new Date(a.replace(/-/g, '/')).getTime()
        b = new Date(b.replace(/-/g, '/')).getTime()
        if (b - a > 2592000000) {
          this.$message({
            message: '整体时间跨度不超过31天',
            type: 'warning'
          })
          this.value1 = null
          this.ruleForm.begin_time = ''
          this.ruleForm.end_time = ''
          this.defaultTime(6)
        }
      },
      // 默认时间
      defaultTime(val) {
        const now = new Date()
        const start = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() - val)).toISOString().slice(0, 10)
        const end = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10)
        this.value1 = [start, end]
      },
      handleUserClick() {
        this.user = []
      },
      handleUserChange() {
        this.ruleForm.engineer_code = ''
      },
      remoteMethod(query) { // 模糊查询 客服
        this.ruleForm.engineer_code = query
        this.loading = true
        this.fuzzyEngineerSearch(query)
      },
      fuzzyEngineerSearch(query) {
        if (query !== '') {
          getSearchEngineer(query).then((res) => {
            var data = []
            for (const i in res.data) {
              data.push(res.data[i])
            }
            this.user = data.map(item => {
              return {
                value: item.code,
                label: item.code + ' / ' + item.name
              }
            })
            this.loading = false
          }).catch(() => {
            this.user = []
            this.loading = false
          })
        }
      },
      init() {
        // 接触方式
        getIRContactType().then(res => {
          this.IRType = res.data
          if (this.IRType.length) {
            this.ruleForm.client_type = this.IRType[0].ParaCode

            // 客户详情页跳转过来，触发自动执行查询动作
            if (this.ruleForm.cube_uid) {
              this.submitConditionForm()
            }
          }
        })
        this.defaultTime(6) // IR开始时间初始默认时间段
      }
    }
  }
</script>
