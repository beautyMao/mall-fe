<template>
  <div>
    <h2>精确查询</h2>
    <el-form label-width="100px" :inline="true" @submit.native.prevent>
      <el-form-item prop="CaseID">
        <el-input v-model="IRID" clearable placeholder="IR ID" />
      </el-form-item>
      <el-form-item>
        <el-button type="primary" plain @click="submitExactForm">查询</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  export default {
    name: 'precise-query',
    data() {
      return {
        IRID: '',
        input: /^[A-Za-z0-9\-\_]+$/
      }
    },
    methods: {
      submitExactForm() { // 获取列表数据
        if (!this.IRID) {
          this.$message({
            message: 'IR ID为必填项目',
            type: 'warning'
          })
          return
        }
        if (!this.input.test(this.IRID)) {
          this.$message({
            message: 'IR ID只可输入字母或数字_-',
            type: 'warning'
          })
          return
        }
        if (this.IRID.length > 50) {
          this.$message({
            message: 'IR ID最多输入50个字符',
            type: 'warning'
          })
          return
        }
        this.$emit('exactInfoSucc', this.IRID)
      },
      reset() {
        this.IRID = ''
      }
    }
  }
</script>
