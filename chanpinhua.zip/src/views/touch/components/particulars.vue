<template>
  <div v-if="particulars" class="app-container particularsWrap">
    <header>
      <h1>IR详情</h1>
    </header>
    <el-card>
      <section>
        <h2>IR基本信息</h2>
        <div v-for="(item, value) of basicInfo" :key="value" class="list-item">
          <span class="key">{{ value }}</span>
          <span :style="value === 'IR ID：' ? { color: '#4A90E2', cursor: 'pointer' } : ''" class="value" @click="handleBtnClick(value, item)">{{ item }}</span>
        </div>
      </section>
      <section>
        <h2>服务记录</h2>
        <el-table :data="particulars.attributeInfo">
          <el-table-column prop="id" label="服务记录ID">
            <template slot-scope="scope">
              <a style="color:#4A90E2" @click="handleEdit(scope.$index, scope.row)">{{ scope.row.id }}</a>
            </template>
          </el-table-column>
          <el-table-column prop="classified_problem_id" label="问题分类" />
          <el-table-column prop="problem_description" label="问题描述" />
          <el-table-column prop="created_at" label="创建时间" />
          <el-table-column prop="updated_at" label="更新时间" />
        </el-table>
      </section>
    </el-card>
  </div>
</template>

<script>
  import { getDetailInfo } from '@/api/touch'
  export default {
    data() {
      return {
        particulars: null,
        basicInfo: {}
      }
    },
    mounted() {
      this.$nextTick(() => {
        if (this.$route.query.id && this.$route.query.type) {
          getDetailInfo(this.$route.query.id, this.$route.query.type).then(res => {
            this.particulars = res.data
            this.getInfo()
          }).catch(this.error)
        }
      })
    },
    methods: {
      getInfo() {
        if (this.particulars) {
          this.basicInfo = {
            'IR ID：': this.particulars.basicInfo.IRID,
            '接触方式：': this.particulars.basicInfo.client_type,
            '客户ID：': this.particulars.basicInfo.customer_id,
            '客户昵称：': this.particulars.basicInfo.user_name,
            '客户姓名：': this.particulars.basicInfo.user_name,
            '处理人：': this.particulars.basicInfo.engineer_code + '/' + this.particulars.basicInfo.engineer_name,
            'IR开始时间：': this.particulars.basicInfo.start_talking_at,
            'IR结束时间：': this.particulars.basicInfo.end_talking_at
          }
        }
      },
      handleBtnClick(name, val) {
        if (name === 'IR ID：') {
          this.handleChatInfoClick(val)
        }
      },
      handleChatInfoClick(id) { // 聊天记录
        this.$router.push({
          path: `/call-center/history`,
          query: { id }
        })
      },
      handleEdit(index, row) {
        const data = { case_id: row.id }
        this.$router.push({ name: 'case-query-particulars', query: data })
      },
      error(err) {
        console.error(err)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .list-item {
    display: inline-block;
    width: 33%;
    font-size: 14px;
    margin-bottom: 10px;

    .key {
      display: inline-block;
      width: 120px;
      text-align: right;
    }
  }
</style>
