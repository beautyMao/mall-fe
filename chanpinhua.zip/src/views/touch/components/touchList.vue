<template>
  <div ref="ele">
    <h2>查询结果</h2>
    <el-table :data="listData">
      <el-table-column prop="id" label="IR ID" min-width="150">
        <template slot-scope="scope">
          <a style="color:#4A90E2" @click="handleEdit(scope.$index, scope.row)">{{ scope.row.id }}</a>
        </template>
      </el-table-column>
      <el-table-column prop="client_type" label="接触方式" />
      <el-table-column prop="direction" label="呼入呼出" />
      <el-table-column prop="phone" label="客户电话" :formatter="displayPhone" />
      <el-table-column prop="IRCreateBy" label="客服ID/姓名" min-width="108">
        <template slot-scope="scope">
          {{ scope.row.engineer_code }}
          <span v-if="scope.row.engineer_code && scope.row.engineer_name">/</span>
          {{ scope.row.engineer_name }}
        </template>
      </el-table-column>
      <el-table-column prop="start_talking_at" label="开始时间" min-width="106" />
      <el-table-column prop="end_talking_at" label="结束时间" min-width="106" />
    </el-table>
  </div>
</template>

<script>
  export default {
    props: {
      listData: {
        type: Array,
        default: function() {
          return []
        }
      }
    },
    data() {
      return {
        IRTypeID: ''
      }
    },
    methods: {
      // phone 可能是个数组字符串
      displayPhone(row) {
        let re = row.phone
        if (!re) {
          return re
        }
        try {
          re = JSON.parse(re).join(',')
        } catch (e) { e }
        return re
      },
      handleEdit(index, row) { // 获取详情信息
        this.$router.push({
          path: `touch/particulars`,
          query: {
            id: row.id,
            type: row.client_type
          }
        })
      }
    }
  }
</script>
