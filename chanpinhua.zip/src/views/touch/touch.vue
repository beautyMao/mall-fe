<template>
  <div class="app-container">
    <header>
      <h1>接触记录查询</h1>
    </header>
    <el-card>
      <section>
        <precise-query ref="precise" @exactInfoSucc="handleExactInfo" />
        <condition-query @ruleForm="ruleForm" @reset="reset" />
      </section>
      <section v-if="data">
        <touch-list :list-data="data" />
        <el-pagination
          background
          :page-sizes="[10, 20, 30]"
          :current-page="list.page_index"
          :page-size="list.page_size"
          layout="total, sizes, prev, pager, next, jumper"
          :total="TotalNumber"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </section>
      <footer v-if="!data">
        <h2>查询说明</h2>
        <ol>
          <li>不支持无条件查询；</li>
          <li>精确查询中IR ID字段有内容时，条件查询中的字段在查询中失效；</li>
          <li>如果使用条件查询，IR开始时间段为必填字段，整体时间跨度不超过31天；</li>
          <li>IR开始时间段默认为从今日开始往前推7日的时间段；</li>
          <li>通过客户电话查询支持查询移动电话和固定电话；</li>
          <li>条件查询中的各个查询条件之间是“与”的关系，即输入信息越多，结果越准确；</li>
          <li>点击“重置”按钮，会重置所有输入框的状态。</li>
        </ol>
      </footer>
    </el-card>
  </div>
</template>

<script>
  import preciseQuery from './components/preciseQuery'
  import conditionQuery from './components/conditionQuery'
  import touchList from './components/touchList'
  import { getListInfo, getListInfo1 } from '@/api/touch'
  export default {
    name: 'touch-query',
    components: {
      preciseQuery,
      conditionQuery,
      touchList
    },
    data() {
      return {
        data: null,
        list: {},
        TotalNumber: 0,
        IRID: null
      }
    },
    methods: {
      handleExactInfo(value) { // 精确查询返回单数值
        this.IRID = value
        getListInfo(this.IRID).then(this.submitSucc).catch(this.error)
      },
      reset() {
        this.$refs.precise.reset()
      },
      ruleForm(value) { // 返回查询条件
        this.list = value
        this.data = null
        this.IRID = null
        this.list.page_index = 1
        this.list.page_size = 10
        getListInfo1(this.list).then(this.submitSucc).catch(this.error)
      },
      handleSizeChange(val) { // 条数切换
        this.list.page_size = val
        this.list.page_index = 1
        this.data = null
        if (this.IRID) {
          getListInfo(this.IRID).then(this.submitSucc).catch(this.error)
        } else {
          getListInfo1(this.list).then(this.submitSucc).catch(this.error)
        }
      },
      handleCurrentChange(val) { // 分页切换
        this.list.page_index = val
        this.data = null
        if (this.IRID) {
          getListInfo(this.IRID).then(this.submitSucc).catch(this.error)
        } else {
          getListInfo1(this.list).then(this.submitSucc).catch(this.error)
        }
      },
      submitSucc(res) { // 获取list数据
        if (!res.data.case_info.length) {
          this.$message({
            message: '无查询结果',
            type: 'warning'
          })
          return
        }
        this.data = res.data.case_info
        this.TotalNumber = res.data.case_total ? res.data.case_total : 0 // 分页总页数
      },
      error(err) {
        console.error(err)
      }
    }
  }
</script>
