<template>
  <div>
    <h2>条件查询</h2>
    <el-form ref="ruleForm" :model="ruleForm" :rules="rules" :inline="true">
      <el-form-item prop="code_customer">
        <el-input v-model="ruleForm.code_customer" clearable placeholder="客户ID" />
      </el-form-item>
      <el-form-item prop="engineer">
        <el-select
          v-model="ruleForm.engineer"
          filterable
          remote
          clearable
          reserve-keyword
          placeholder="客服工号 / 姓名"
          :remote-method="remoteMethod"
        >
          <el-option
            v-for="item in users"
            :key="item.value"
            :label="item.label"
            :value="item.value"
          />
        </el-select>
        <!--        <el-input v-model="ruleForm.engineer" clearable placeholder="客服工号 / 姓名" />-->
      </el-form-item>
      <el-form-item prop="classified_problem_id">
        <el-cascader
          v-model="ruleForm.classified_problem_id"
          placeholder="问题类型"
          :options="UpOrderStatus"
          :props="{ label: 'name', value: 'name', children: 'children', emitPath: false }"
          clearable
        />
      </el-form-item>
      <div class="times">
        <el-form-item prop="times" required>
          <ext-date-picker
            ref="times"
            v-model="ruleForm.times"
            size="large"
            type="daterange"
            placehoder="服务时间"
            range-separator="至"
            start-placeholder="开始日期"
            end-placeholder="结束日期"
            format="yyyy 年 MM 月 dd 日"
            value-format="yyyy-MM-dd"
          />
        </el-form-item>
      </div>
      <p class="text-right">
        <el-button plain type="primary" @click="submitConditionForm">查询</el-button>
        <el-button plain @click="resetConditionForm('ruleForm')">重置</el-button>
      </p>
    </el-form>
  </div>
</template>

<script>
  import { getDateFormat, deepClone } from '@/utils'
  import { getSearchEngineer } from '@/api/touch'
  import { getApiWbClassifiedProblem } from '@/api/queue-management/demand/case.js'
  import ExtDatePicker from '@/components/ExtDatePicker'

  export default {
    name: 'case-query-condition-query',
    components: { ExtDatePicker },
    data() {
      return {
        ruleForm: {
          code_customer: '',
          engineer: '',
          classified_problem_id: [],
          times: [getDateFormat('yyyy-MM-dd', new Date(Date.now() - (3600000 * 24 * 6))), getDateFormat('yyyy-MM-dd', new Date())]
        },
        UpOrderStatus: [],
        loading: false,
        users: [],
        rules: {
          code_customer: [{ trigger: 'blur', message: '客户ID' }],
          engineer: [{ trigger: 'blur', message: '请输入客服工号 / 姓名' }],
          classified_problem_id: [{ required: false, trigger: 'blur', message: '请选择问题类型' }],
          times: [{ required: true, trigger: ['change', 'blur'], message: '请选择开始日期 / 结束日期' }]
        }
      }
    },
    activated() {
      const cube_uid = this.$route.query.cube_uid
      if (cube_uid) {
        this.ruleForm.code_customer = cube_uid
        this.$nextTick(() => {
          this.submitConditionForm()
        })
      }
    },
    mounted() {
      this.getQuestion()
    },
    methods: {
      submitConditionForm() { // 获取列表数据
        this.$refs.ruleForm.validate(valid => {
          if (valid) {
            const ruleForm = deepClone(this.ruleForm)
            ruleForm.start_time = ruleForm.times[0]
            ruleForm.end_time = ruleForm.times[1]
            delete ruleForm.times
            this.$emit('rule-form', ruleForm)
            return true
          } else {
            return false
          }
        })
      },
      clearChildren(arr) {
        const arrFn = item => {
          item.forEach(it => {
            if (it.children && !it.children.length) {
              delete it.children
            }
            Array.isArray(it.children) && arrFn(it.children)
          })
        }
        arrFn(arr)
        return arr
      },
      getQuestion() {
        getApiWbClassifiedProblem().then(res => {
          this.UpOrderStatus = this.clearChildren(res.data)
        })
      },
      resetConditionForm(formName) { // 重置数据
        this.$refs[formName].resetFields()
        this.$emit('reset')
      },
      remoteMethod(query) { // 模糊查询 客服
        getSearchEngineer(query).then(res => {
          this.users = res.data.map(item => ({
            value: item.code,
            label: item.code + ' / ' + item.name
          }))
        }).catch(this.$message.error)
      }
    }
  }
</script>
