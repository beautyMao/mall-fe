<template>
  <div>
    <header>
      <h2>查询结果</h2>
    </header>
    <el-table
      :data="data.case_list"
    >
      <el-table-column
        prop="id"
        label="服务记录 ID"
      >
        <template slot-scope="scope">
          <el-button type="text" @click="infoCase(scope.row)">{{ scope.row.id }}</el-button>
        </template>
      </el-table-column>
      <el-table-column
        prop="customer_id"
        label="客户 ID"
      />
      <el-table-column
        prop="created_at"
        label="创建时间"
      />
      <el-table-column
        prop="classified_problem_id"
        label="问题分类"
      >
        <template slot-scope="scope">
          <template v-if="typeof scope.row.classified_problem_id === 'string' && scope.row.classified_problem_id.length > 10">
            <el-popover
              placement="bottom"
              title="问题分类:"
              width="420"
              trigger="hover"
              :content="scope.row.classified_problem_id"
            >
              <span slot="reference" class="pointer">{{ `${scope.row.classified_problem_id.substring(0, 10)}...` }}</span>
            </el-popover>
          </template>
          <span v-else>{{ scope.row.classified_problem_id }}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="problem_description"
        label="问题描述"
        min-width="106"
      >
        <template slot-scope="scope">
          <template v-if="typeof scope.row.problem_description === 'string' && scope.row.problem_description.length > 10">
            <el-popover
              placement="bottom-end"
              title="问题描述:"
              width="420"
              trigger="hover"
              :content="scope.row.problem_description"
            >
              <span slot="reference" class="pointer">{{ `${scope.row.problem_description.substring(0, 10)}...` }}</span>
            </el-popover>
          </template>
          <span v-else>{{ scope.row.problem_description }}</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="file_url"
        label="附件"
        min-width="106"
      >
        <template slot-scope="scope">
          <!--          <img v-if="scope.row.case_file.length && scope.row.case_file.length === 1 && checkImg(scope.row.case_file[0].file_url)" :style="{width: '60px', height: '60px'}" class="pointer" :src="scope.row.case_file[0].file_url" @click="showImg(scope.row.case_file[0].file_url, scope.row.case_file)">-->
          <template v-if="scope.row.case_file.length">
            <el-popover
              :ref="`popover-${scope.$index}`"
              placement="bottom-end"
              width="512"
              trigger="hover"
              popper-class="case-query-case-list-popover"
              :content="scope.row.problem_description"
            >
              <div>
                <div class="flex-wrp flex-between flex-align-center size14 plr20">
                  <div>附件（ {{ scope.row.case_file.length === 1 ? 1 : scope.row.case_file.length-1 }} ）</div>
                  <a target="_blank" class="block" :href="handleDownload(scope.row.case_file[scope.row.case_file.length-1])" download><el-button type="text"><svg-icon icon-class="down" /> 全部下载</el-button></a>
                </div>
                <div>
                  <template v-for="(item, index) in scope.row.case_file">
                    <div v-if="scope.row.case_file.length-1 !== index || scope.row.case_file.length === 1" :key="index" class="file-item flex-wrp flex-between size12 flex-align-center ptb5">
                      <template v-if="checkImg(item.file_url)">
                        <div class="flex-wrp flex-align-center">
                          <img :style="{width: '42px', height: '42px'}" class="block pointer" :src="item.file_url" @click="showImg(item.file_url, scope.row.case_file)">
                          <div class="text-nowrap pointer ml10 size14" :title="item.file_name" :style="{width: '320px'}" @click="showImg(item.file_url, scope.row.case_file)">{{ item.file_name }}</div>
                        </div>
                        <div class="flex-wrp flex-bottom">
                          <div><el-button type="text" @click="showImg(item.file_url, scope.row.case_file, scope)">查看</el-button></div>
                          <a target="_blank" class="block ml10" :href="handleDownload(item)" download><el-button type="text">下载</el-button></a>
                        </div>
                      </template>
                      <template v-else>
                        <div class="flex-wrp flex-align-center">
                          <div :style="{width: '42px', height: '42px', color: '#7d88a4'}" class="flex-wrp flex-center">
                            <svg-icon icon-class="wendang" class="size38" :style="{color: '#7d88a4'}" />
                          </div>
                          <div class="text-nowrap ml10 size14" :title="item.file_name" :style="{width: '320px'}">{{ item.file_name }}</div>
                        </div>
                        <a target="_blank" class="block" :href="handleDownload(item)" download><el-button type="text">下载</el-button></a>
                      </template>
                    </div>
                  </template>
                </div>
              </div>
              <el-button slot="reference" type="text">附件</el-button>
            </el-popover>
          </template>
          <span v-else>无</span>
        </template>
      </el-table-column>
      <el-table-column
        prop="engineer_name"
        label="创建人"
      >
        <template slot-scope="scope">{{ `${scope.row.engineer_code} / ${scope.row.engineer_name}` }}</template>
      </el-table-column>
    </el-table>
    <el-pagination
      background
      :current-page="listData.current_page"
      :page-size="listData.size"
      :page-sizes="[10, 15, 20, 25]"
      layout="total, sizes, prev, pager, next, jumper"
      :total="listData.total"
      @size-change="handleSizeChange"
      @current-change="currentChange"
    />
  </div>
</template>

<script>
  export default {
    name: 'case-query-case-list',
    props: {
      listData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        data: this.listData,
        SRItemID: ''
      }
    },
    watch: {
      listData: {
        handler(listData) {
          this.data = listData
        },
        deep: true
      }
    },
    methods: {
      getRowClass({ row, column, rowIndex, columnIndex }) {
        // 设置table 标题背景色
        if (rowIndex === 0) {
          return 'background:#F0F4FB'
        } else {
          return ''
        }
      },
      // handleEdit(index, row) {
      //   // 获取详情信息
      //   this.$router.push({
      //     path: 'case/particulars',
      //     query: {
      //       caseID: row.SRItemID
      //     }
      //   })
      // },
      showImg(item, files, scope) {
        files = files.filter(tt => this.checkImg(tt.file_url)).map(item => item.file_url)
        const index = files.indexOf(item)
        scope._self.$refs[`popover-${scope.$index}`].doClose()
        this.$emit('show-img', index, files)
      },
      handleEdit(row) {
        this.$emit('edit', row)
      },
      handleDownload(data) {
        if (this.checkImg(data.file_url)) {
          return `/api/csc/resource/download?link=${data.file_url}`
        } else {
          return data.file_url
        }
      },
      currentChange(val) {
        this.$emit('change', val)
      },
      handleSizeChange(val) {
        this.$emit('size-change', val)
      },
      infoCase(val) {
        this.$emit('info-case', val)
      },
      checkImg(img_url) {
        img_url = img_url.substring(img_url.lastIndexOf('.'))
        if (img_url !== '.png' && img_url !== '.jpg' && img_url !== '.jpeg') {
          return false
        } else {
          return true
        }
      }
    }
  }
</script>

<style scoped lang="scss">
  .file-item {
    transition: background 0.3s;
    background: #fff;
    padding: 0 20px;
    &:hover {
      background: rgba(240,244,251,1);
    }
  }
</style>

<style lang="scss">
  .case-query-case-list-popover {
    padding: 18px 0 !important;
  }
</style>
