<template>
  <div>
    <h2>精确查询</h2>
    <el-form ref="form" :model="ruleForm" label-width="100px" :rules="rules" :inline="true" @submit.native.prevent>
      <el-form-item prop="caseId">
        <el-input
          v-model="ruleForm.caseId"
          clearable
          placeholder="服务记录 ID"
          @keyup.enter.native="submitExactForm"
        />
      </el-form-item>
      <el-form-item>
        <el-button plain type="primary" @click="submitExactForm">查询</el-button>
      </el-form-item>
    </el-form>
  </div>
</template>

<script>
  export default {
    name: 'precise-query',
    data() {
      return {
        ruleForm: {
          caseId: ''
        },
        rules: {
          caseId: [{ required: true, trigger: 'blur', message: '请输入 CaseID' }]
        }
      }
    },
    methods: {
      submitExactForm() { // 获取列表数据
        this.$refs.form.validate(valid => {
          if (valid) {
            this.$emit('exact-info-succ', this.ruleForm.caseId)
          } else {
            return false
          }
        })
      },
      reset() {
        this.ruleForm.caseId = ''
      }
    }
  }
</script>
