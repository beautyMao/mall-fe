<template>
  <div class="app-container">
    <header>
      <h1>服务记录查询</h1>
    </header>
    <el-card>
      <header>
        <case-query-precise-query ref="precise" @exact-info-succ="handleExactInfo" />
        <case-query-condition-query @rule-form="ruleForm" @reset="reset" />
      </header>
      <case-query-case-list
        v-if="tableDataList.case_list.length"
        :list-data="tableDataList"
        @change="handleCurrentChange"
        @size-change="handleSizeChange"
        @edit="handleEdit"
        @show-img="handleShowImg"
        @info-case="handleInfoCase"
      />
      <image-viewer ref="imageView" :srcs="imageSrc" />

      <footer v-if="!tableDataList.case_list.length">
        <h2>查询说明</h2>
        <ul>
          <li>A. 不支持无条件查询；</li>
          <li>B. 精确查询中Case ID字段有内容时，条件查询中的字段在查询中失效；</li>
          <li>C. 如果使用条件查询，创建时间段为必填字段，不限制整体时间跨度；</li>
          <li>D. 创建时间段默认为从今日开始往前推7日的时间段；</li>
          <li>E. 关闭时间段的起始时间不能早于创建时间段的起始时间；</li>
          <li>F. 条件查询中的各个查询条件之间是“与”的关系，即输入信息越多，结果越准确；</li>
          <li>G. 点击“重置”按钮，会重置所有输入框的状态。</li>
        </ul>
      </footer>
    </el-card>
  </div>
</template>

<script>
  import * as api from '@/api/queue-management/demand/case'
  import ImageViewer from '@/components/ImageViewer'
  import CaseQueryPreciseQuery from './case-query-precise-query'
  import CaseQueryConditionQuery from './case-query-condition-query'
  import CaseQueryCaseList from './case-query-case-list'
  import { mapGetters } from 'vuex'
  import { deepClone } from '@/utils'
  export default {
    name: 'case-query',
    components: {
      CaseQueryPreciseQuery,
      CaseQueryConditionQuery,
      CaseQueryCaseList,
      ImageViewer
    },
    data() {
      return {
        tableDataList: {
          case_list: [],
          current_page: 1,
          size: 10,
          total: 0
        },
        imageSrc: [],
        preciseData: '',
        currentData: {
          page: 1,
          size: 10
        }
      }
    },
    computed: {
      ...mapGetters(['engineerCode'])
    },
    methods: {
      handleExactInfo(case_id) { // 精确查询
        const params = {
          case_id,
          customer_id: '',
          engineer: this.engineerCode,
          start_time: '',
          end_time: ''
        }
        api.getApiWbCaseSearch({ ...this.currentData, ...params, page: 1 }).then(res => {
          this.currentData = { ...params }
          return this.submitConditionFormInfoSucc(res)
        }).catch(this.$message.error)
      },
      reset() {
        this.$refs.precise.reset()
      },
      ruleForm(params) { // 返回查询条件
        const currentData = deepClone(this.currentData)
        delete currentData.case_id
        api.getApiWbCaseSearch({
          ...currentData,
          ...params,
          query: params.classified_problem_id,
          page: 1
        }).then(res => {
          this.currentData = { ...params }
          return this.submitConditionFormInfoSucc(res)
        }).catch(this.$message.error)
      },
      handleSizeChange(size) { // 条数切换
        this.currentData.size = size
        this.currentData.page = 1
        const query = { ...this.currentData, size }
        api.getApiWbCaseSearch(query).then(this.submitConditionFormInfoSucc).catch(this.$message.error)
      },
      handleCurrentChange(page) { // 分页切换
        this.currentData.page = page
        const query = { ...this.currentData, page }
        api.getApiWbCaseSearch(query).then(this.submitConditionFormInfoSucc).catch(this.$message.error)
      },
      submitConditionFormInfoSucc(res) { // 获取list数据
        this.tableDataList = res.data
        if (!res.data.total) this.$message.warning('查询不到数据')
        this.currentData.page = res.data.current_page
        this.currentData.size = res.data.size
      },
      handleEdit(data) {
        console.log('触发了编辑', data)
      },
      handleShowImg(index, files) {
        this.imageSrc = files
        this.$nextTick(() => {
          this.$refs.imageView.showViewer(index)
        })
      },
      handleInfoCase(data) {
        this.$router.push({ path: 'case-query/particulars', query: data })
      },
      checkImg(img_url) {
        img_url = img_url.substring(img_url.lastIndexOf('.'))
        if (img_url !== '.png' && img_url !== '.jpg' && img_url !== '.jpeg') {
          return false
        } else {
          return true
        }
      }
    }
  }
</script>
