<template>
  <div class="cascontent_pad">
    <h2>当前现场：{{ this.$route.query.business }} {{ this.$route.query.access }}</h2>
    <div class="caseBox">
      <pie-chart />
    </div>
  </div>
</template>
<script>
  import pieChart from './components/pieChart'
  export default {
    name: 'class-manage',
    components: { pieChart },
    data() {
      return {
      }
    },
    methods: {
      // handleManpower() {
      //   this.$router.push({
      //     path: `/Threshold-settings/${this.$route.query.businessID}${this.$route.query.accessID}`,
      //     query: {
      //       businessID: this.$route.query.businessID,
      //       business: this.$route.query.business,
      //       accessID: this.$route.query.accessID,
      //       access: this.$route.query.access
      //     }
      //   })
      // }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  h2{
    margin: 0 auto;
    padding: 0;
    font-weight:600;
    font-size: 24px;
    line-height: 24px;
    color: #303133;
    margin: 12px auto;
    width:95%;
  }
  .caseBox{
    width:98%;
    height:100%;
    background: #fff;
    margin: 0 auto;
    border: 1px solid #DCDFE6;
  }
  .el-button--primary.is-plain{
    width:150px;
    font-size: 14px;
  }
  .elbox{ text-align: center; margin-top: 20px; }
</style>
