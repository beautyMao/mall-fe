<!--<template>-->
  <!--<div id="Weatherhold" class="Weatherhold"></div>-->
<!--</template>-->
<!--<script>-->
  <!--import Vue from 'vue'-->
  <!--import echarts from 'echarts'-->
  <!--Vue.prototype.$echarts = echarts-->
  <!--export default {-->
    <!--data() {-->
      <!--return {-->
        <!--option: {-->
          <!--tooltip: {-->
            <!--trigger: 'item',-->
            <!--formatter: '{b}'-->
          <!--},-->
          <!--series: [-->
            <!--{-->
              <!--name: '中国',-->
              <!--type: 'map',-->
              <!--mapType: 'china',-->
              <!--selectedMode: 'multiple',-->
              <!--label: {-->
                <!--normal: {-->
                  <!--show: true-->
                <!--},-->
                <!--emphasis: {-->
                  <!--show: true-->
                <!--}-->
              <!--},-->
              <!--data: [-->
                <!--{ name: '广东', selected: true }-->
              <!--]-->
            <!--}-->
          <!--]-->
        <!--}-->
      <!--}-->
    <!--},-->
    <!--methods: {-->
      <!--initChart() {-->
        <!--this.drawPie()-->
      <!--},-->
      <!--drawPie() {-->
        <!--const myChart = this.$echarts.init(document.getElementById('weatherhold'))-->
        <!--myChart.setOption(this.option)-->
      <!--}-->
    <!--},-->
    <!--mounted() {-->
      <!--this.initChart()-->
    <!--}-->
  <!--}-->
<!--</script>-->
<!--<style rel="stylesheet/scss" lang="scss" scoped>-->
  <!--h2{-->
    <!--padding: 0;-->
    <!--font-weight:600;-->
    <!--font-size: 24px;-->
    <!--line-height: 24px;-->
    <!--color: #303133;-->
    <!--margin: 12px auto;-->
    <!--width:95%;-->
  <!--}-->
  <!--.caseBox{-->
    <!--width:98%;-->
    <!--height:100%;-->
    <!--background: #fff;-->
    <!--margin: 0 auto;-->
    <!--border: 1px solid #DCDFE6;-->
  <!--}-->
  <!--.el-button&#45;&#45;primary.is-plain{-->
    <!--width:150px;-->
    <!--font-size: 14px;-->
  <!--}-->
  <!--.elbox{ text-align: center; margin-top: 20px; }-->
<!--</style>-->
