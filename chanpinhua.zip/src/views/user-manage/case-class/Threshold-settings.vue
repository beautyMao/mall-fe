<template>
  <div class="setContent">
    <h2>
      <el-cascader
        ref="a"
        v-model="scene"
        :options="options"
        placeholder="现场选择"
        size="medium"
        @change="handleChange"
      />
    </h2>
    <div class="TabSetBox">
      <p>pickup人员设置</p>
      <el-table
        v-loading="listLoading"
        :data="PickUpData"
        style="width: 100%"
      >
        <el-table-column
          v-if="isShow"
          align="center"
          label="业务id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.business_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          v-if="isShow"
          align="center"
          label="通路id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.access_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="工程师编号"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.warning_person_code"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.warning_person_code }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="工程师姓名"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.warning_person_name"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.warning_person_name }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="操作"
        >
          <template slot-scope="scope">
            <div v-if="scope.row.edit">
              <span
                class="save"
                @click="confirmEditPickUp(scope.row)"
              >保存</span>
              <span
                class="save"
                @click="cancelEditPickUp(scope.row)"
              >取消</span>
            </div>
            <span
              v-else
              class="save"
              @click="scope.row.edit=!scope.row.edit"
            >编辑</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="TabSetBox">
      <p>问题分类占比</p>
      <el-table
        v-loading="listLoading"
        :data="ProblemData"
        style="width: 100%"
      >
        <el-table-column
          v-if="isShow"
          align="center"
          label="业务id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.business_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          v-if="isShow"
          align="center"
          label="通路id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.access_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="黄色预警当前阈值"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.yellow_value"
                :class="{'change': !scope.row.yellow_value || scope.row.yellow_value >1 || scope.row.yellow_value <0}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.yellow_value }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="橙色预警当前阈值"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.orange_value"
                :class="{'change': !scope.row.orange_value || scope.row.orange_value >1 || scope.row.orange_value <0}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.orange_value }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="红色预警当前阈值"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.red_value"
                :class="{'change': !scope.row.red_value || scope.row.red_value >1 || scope.row.red_value <0}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.red_value }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="提醒方式"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.notice_method }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="操作"
        >
          <template slot-scope="scope">
            <span
              v-if="scope.row.edit"
              class="save"
              @click="confirmEditProblem(scope.row)"
            >保存</span>
            <span
              v-else
              class="save"
              @click="scope.row.edit=!scope.row.edit"
            >编辑</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="TabSetBox">
      <p>机器人阈值设置</p>
      <el-table
        v-loading="listLoading"
        :data="robotData"
        style="width: 100%"
      >
        <el-table-column
          v-if="isShow"
          align="center"
          label="业务id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.business_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          v-if="isShow"
          align="center"
          label="通路id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.access_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="预警项目"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.warning_item }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="红色预警值"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.red_value"
                :class="{'change': !scope.row.red_value || scope.row.red_value<0}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.red_value }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="黄色预警值"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.yellow_value"
                :class="{'change': !scope.row.yellow_value || scope.row.yellow_value<0}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.yellow_value }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="橙色预警值"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.orange_value"
                :class="{'change': !scope.row.orange_value || scope.row.orange_value<0}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.orange_value }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="提醒方式"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.notice_method }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="操作"
        >
          <template slot-scope="scope">
            <span
              v-if="scope.row.edit"
              class="save"
              @click="confirmEditRobot(scope.row)"
            >保存</span>
            <span
              v-else
              class="save"
              @click="scope.row.edit=!scope.row.edit"
            >编辑</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="TabSetBox">
      <p>放弃率预警对象</p>
      <el-table
        v-loading="listLoading"
        :data="AbandonData"
        style="width: 100%"
      >
        <el-table-column
          v-if="isShow"
          align="center"
          label="业务id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.business_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          v-if="isShow"
          align="center"
          label="通路id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.access_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="预警级别"
        >
          <template slot-scope="scope">
            <span v-if="scope.row.level==1">红色</span>
            <span v-if="scope.row.level==2">黄色</span>
            <span v-if="scope.row.level==3">橙色</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="预警人员"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.warning_person_name"
                :class="{'change': !scope.row.warning_person_name}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.warning_person_name }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="预警最小值"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.warning_minvalue"
                :class="{'change': !scope.row.warning_minvalue}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.warning_minvalue }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="预警最大值"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.warning_maxvalue"
                :class="{'change': !scope.row.warning_maxvalue}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.warning_maxvalue }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="预警人员电话"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.warning_person_phone"
                :class="{'change': !scope.row.warning_person_phone}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.warning_person_phone }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="ITcode"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.warning_person_email"
                :class="{'change': !scope.row.warning_person_email}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.warning_person_email }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="操作"
        >
          <template slot-scope="scope">
            <span
              v-if="scope.row.edit"
              class="save"
              @click="confirmEditAbandon(scope.row)"
            >保存</span>
            <span
              v-else
              class="save"
              @click="scope.row.edit=!scope.row.edit"
            >编辑</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="TabSetBox">
      <p>排队量设置</p>
      <el-table
        v-loading="listLoading"
        :data="tableData"
        style="width: 100%"
      >
        <el-table-column
          v-if="isShow"
          align="center"
          label="business_id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.business_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          v-if="isShow"
          align="center"
          label="通路id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.access_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="预警项目"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.warning_item }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="通路"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.accesses_name }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="分类"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.queue_type }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="名称"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.route_type }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="提醒方式"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.notice_method }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="预警阈值"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.warning_value"
                :class="{'change': !scope.row.warning_value || scope.row.warning_value<0}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.warning_value }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="操作"
        >
          <template slot-scope="scope">
            <span
              v-if="scope.row.edit"
              class="save"
              @click="confirmEdit(scope.row)"
            >保存</span>
            <span
              v-else
              class="save"
              @click="scope.row.edit=!scope.row.edit"
            >编辑</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
    <div class="TabSetBox">
      <p>状态时长阈值设置</p>
      <el-table
        v-loading="listLoading"
        :data="StatusTimeData"
        style="width: 100%"
      >
        <el-table-column
          v-if="isShow"
          align="center"
          label="业务id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.business_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          v-if="isShow"
          align="center"
          label="通路id"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.access_id }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="时间"
        >
          <template slot-scope="scope">
            <span>{{ scope.row.time_type }}</span>
          </template>
        </el-table-column>
        <el-table-column
          align="center"
          label="红色预警当前阈值"
        >
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input
                v-model="scope.row.red_value"
                :class="{'change': !scope.row.red_value || scope.row.red_value < 0}"
                class="edit-input"
                size="small"
              />
            </template>
            <span v-else>{{ scope.row.red_value }}</span>
          </template>
        </el-table-column>
        <!-- <el-table-column align="center" label="黄色预警当前阈值">
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input v-model="scope.row.yellow_value" v-bind:class="{'change': !scope.row.yellow_value || scope.row.yellow_value < 0}" class="edit-input" size="small"/>
            </template>
            <span v-else>{{ scope.row.yellow_value }}</span>
          </template>
        </el-table-column>
        <el-table-column align="center" label="橙色预警当前阈值">
          <template slot-scope="scope">
            <template v-if="scope.row.edit">
              <el-input v-model="scope.row.orange_value" class="edit-input" v-bind:class="{'change': !scope.row.orange_value || scope.row.orange_value < 0}" size="small"/>
            </template>
            <span v-else>{{ scope.row.orange_value }}</span>
          </template>
        </el-table-column> -->
        <el-table-column
          align="center"
          label="操作"
        >
          <template slot-scope="scope">
            <span
              v-if="scope.row.edit"
              class="save"
              @click="confirmEditStatusTime(scope.row)"
            >保存</span>
            <span
              v-else
              class="save"
              @click="scope.row.edit=!scope.row.edit"
            >编辑</span>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </div>
</template>
<script>
  import { threshold, Updatethreshold, thresholdRobot, thresholdAbandon, UpdatethresholdAbandon, UpdatethresholdRobot, UpdatethresholdStatusTime, thresholdStatusTime, thresholdProblem, UpdatethresholdProblem, thresholdPickup, UpdatethresholdPickup } from '@/api/ccp/threshold'
  import { EngineerLocales } from '@/api/ccp/index'
  import { ThresholdRoute } from '@/api/ccp/link'
  import debounce from 'throttle-debounce/debounce'
  export default {
    beforeRouteEnter: debounce(200, ThresholdRoute),
    beforeRouteUpdate: debounce(200, ThresholdRoute),
    data() {
      return {
        listLoading: false,
        tableData: null,
        robotData: null,
        AbandonData: null,
        StatusTimeData: null,
        ProblemData: [],
        PickUpData: [
        ],
        PickUpData_copy: [],
        isShow: false,
        options: [],
        scene: [Number(this.$route.query.businessID), Number(this.$route.query.accessID)],
        businessID: null,
        business: null,
        accessID: null,
        access: null,
        onchangebr: false
      }
    },
    mounted() {
      this.getEngineer()
    },
    methods: {
      pageInfo() { // 获取页面数据
        this.$router.push({
          path: '' + this.options[0].value + this.options[0].children[0].value,
          query: {
            businessID: this.options[0].value,
            business: this.options[0].label,
            accessID: this.options[0].children[0].value,
            access: this.options[0].children[0].label
          }
        })
      },
      handleChange(value) { // 通路切换 打开新页面
        this.businessID = value[0]
        this.accessID = value[1]
        this.getList()
        this.getListRobot()
        this.getListAbandon()
        this.getListStatusTime()
        this.getListProblem()
        this.getListPickUp()
      // this.$router.push({
      //   path: '',
      //   query: {
      //     businessID: value[0],
      //     business: this.$refs.a.currentLabels[0],
      //     accessID: value[1],
      //     access: this.$refs.a.currentLabels[1]
      //   }
      // })
      },
      getEngineer() { // 现场选择
        EngineerLocales().then(response => {
          var item = response.data
          for (const i in item) {
            const childrenList = []
            for (const j in item[i].children) {
              if (item[i].children[j].power === 2) {
                childrenList.push(item[i].children[j])
              }
            }
            if (childrenList.length > 0) {
              this.options.push({
                'value': item[i].value,
                'label': item[i].label,
                'children': childrenList
              })
            }
          }
          if (this.options.length > 0) {
            this.businessID = this.options[0].value
            this.accessID = this.options[0].children[0].value
            this.getList()
            this.getListRobot()
            this.getListAbandon()
            this.getListStatusTime()
            this.getListProblem()
            this.getListPickUp()
          }
        })
      },
      getList() {
        threshold(this.businessID, this.accessID).then(response => {
          const items = response.data
          this.tableData = items.map(v => {
            this.$set(v, 'edit', false)
            return v
          })
        })
      },
      getListPickUp() {
        thresholdPickup(this.businessID, this.accessID).then(response => {
          const items = response.data
          const obj = {
            access_id: '',
            business_id: '',
            warning_person_code: '',
            warning_person_name: ''
          }
          if (items.length === 0) {
            items.push(obj)
          }
          this.PickUpData = items.map(v => {
            this.$set(v, 'edit', false)
            return v
          })
          sessionStorage.setItem('temp', JSON.stringify(this.PickUpData))
        })
      },
      getListRobot() {
        thresholdRobot(this.businessID, this.accessID).then(response => {
          const items = response.data
          this.robotData = items.map(v => {
            this.$set(v, 'edit', false)
            return v
          })
        })
      },
      getListAbandon() {
        thresholdAbandon(this.businessID, this.accessID).then(response => {
          const items = response.data
          this.AbandonData = items.map(v => {
            this.$set(v, 'edit', false)
            return v
          })
        })
      },
      getListStatusTime() {
        thresholdStatusTime(this.businessID, this.accessID).then(response => {
          const items = response.data
          this.StatusTimeData = items.map(v => {
            this.$set(v, 'edit', false)
            v.originalTitle = v.title
            return v
          })
        })
      },
      getListProblem() {
        thresholdProblem(this.businessID, this.accessID).then(response => {
          this.ProblemData = []
          this.ProblemData.push({ business_id: response.data.business_id, access_id: response.data.access_id, orange_value: response.data.orange_value, red_value: response.data.red_value, yellow_value: response.data.yellow_value, notice_method: response.data.notice_method })
          this.ProblemData.forEach(v => {
            this.$set(v, 'edit', false)
          })
        })
      },
      confirmEditPickUp(row) {
        row.edit = false
        const data = {
          business: this.businessID,
          access: this.accessID,
          warning_person_code: row.warning_person_code,
          warning_person_name: row.warning_person_name
        }
        if (row.warning_person_code === '' || row.warning_person_name === '') {
          this.$message({
            message: '工程师编号或姓名不能为空',
            type: 'error'
          })
          this.getListPickUp()
          return
        }
        UpdatethresholdPickup(data).then(response => {
        })
        this.$message({
          message: '修改成功',
          type: 'success'
        })
      },
      cancelEditPickUp() {
        const obj = {
          access_id: '',
          business_id: '',
          warning_person_code: '',
          warning_person_name: '',
          edit: false
        }
        if (this.PickUpData.length === 0) {
          this.PickUpData.push(obj)
        } else {
          this.PickUpData = JSON.parse(sessionStorage.getItem('temp'))
        }
      },
      confirmEdit(row) {
        row.edit = false
        const data = {
          business: row.business_id,
          access: row.access_id,
          warning_value: row.warning_value,
          queue_type: row.queue_type,
          route_type: row.route_type,
          warning_item: row.warning_item
        }
        if (row.warning_value === '') {
          this.$message({
            message: '当前预警阈值不能为空',
            type: 'error'
          })
          this.getList()
          return
        } else if (row.warning_value < 0) {
          this.$message({
            message: '当前预警阈值最小为0',
            type: 'error'
          })
          this.getList()
          return
        }
        Updatethreshold(data).then(response => {
        })
        this.$message({
          message: '修改成功',
          type: 'success'
        })
      },
      confirmEditAbandon(row) {
        row.edit = false
        const data = {
          business: row.business_id,
          access: row.access_id,
          level: row.level,
          warning_person_name: row.warning_person_name,
          warning_person_email: row.warning_person_email,
          warning_minvalue: row.warning_minvalue,
          warning_maxvalue: row.warning_maxvalue,
          warning_person_phone: row.warning_person_phone
        }
        if (row.warning_person_name === '' || row.warning_person_email === '' || row.warning_minvalue === '' || row.warning_maxvalue === '' || row.warning_person_phone === '') {
          this.$message({
            message: '当前属性不能为空',
            type: 'error'
          })
          this.getListAbandon()
          return
        } else if (!(/^1(3|4|5|7|8)\d{9}$/.test(row.warning_person_phone))) {
          this.$message({
            message: '手机号码不正确',
            type: 'error'
          })
          this.getListAbandon()
          return
        } else if (!/^[A-Za-z\d]+([-_.][A-Za-z\d]+)*@([A-Za-z\d]+[-.])+[A-Za-z\d]{2,4}$/.test(row.warning_person_email)) {
          this.$message({
            message: '邮箱格式不正确',
            type: 'error'
          })
          this.getListAbandon()
          return
        }
        UpdatethresholdAbandon(data).then(response => {
          if (response.data.error === 422) {
            this.$message({
              message: response.data.message,
              type: 'warning'
            })
          }
        }).catch((e) => {
          this.getListAbandon()
        })
        this.$message({
          message: '修改成功',
          type: 'success'
        })
      },
      confirmEditRobot(row) {
        row.edit = false
        const vm = {
          business: row.business_id,
          access: row.access_id,
          warning_item: row.warning_item,
          data: [
            { level: 1, warning_value: row.red_value },
            { level: 2, warning_value: row.yellow_value },
            { level: 3, warning_value: row.orange_value }
          ]
        }
        if (row.yellow_value === '' || row.red_value === '' || row.orange_value === '') {
          this.$message({
            message: '当前预警值不能为空',
            type: 'error'
          })
          this.getListRobot()
          return
        } else if (row.yellow_value < 0 || row.red_value < 0 || row.orange_value < 0) {
          this.$message({
            message: '当前预警值至少是0',
            type: 'error'
          })
          this.getListRobot()
          return
        }
        UpdatethresholdRobot(vm).then(response => {
        // console.log(response)
        })
        this.$message({
          message: '修改成功',
          type: 'success'
        })
      },
      confirmEditStatusTime(row) {
        row.edit = false
        const vm = {
          business: row.business_id,
          access: row.access_id,
          time_type: row.time_type,
          data: [
            { level: 1, warning_value: row.red_value }
          // { level: 2, warning_value: row.yellow_value },
          // { level: 3, warning_value: row.orange_value }
          ]
        }
        if (row.yellow_value === '' || row.red_value === '' || row.orange_value === '') {
          this.$message({
            message: '当前阈值不能为空',
            type: 'error'
          })
          this.getListStatusTime()
          return
        } else if (row.yellow_value < 0 || row.red_value < 0 || row.orange_value < 0) {
          this.$message({
            message: '当前阈值最少为0',
            type: 'error'
          })
          this.getListStatusTime()
          return
        }
        UpdatethresholdStatusTime(vm).then(response => {
        // console.log(response)
        })
        this.$message({
          message: '修改成功',
          type: 'success'
        })
      },
      confirmEditProblem(row) {
        row.edit = false
        const vm = {
          business: row.business_id,
          access: row.access_id,
          notice_method: row.notice_method,
          data: [
            { level: 1, warning_value: row.red_value },
            { level: 2, warning_value: row.yellow_value },
            { level: 3, warning_value: row.orange_value }
          ]
        }
        if (row.yellow_value === '' || row.red_value === '' || row.orange_value === '') {
          this.$message({
            message: '当前阈值不能为空',
            type: 'error'
          })
          this.ProblemData = []
          this.getListProblem()
          return
        } else if (row.yellow_value > 1 || row.yellow_value < 0 || row.red_value > 1 || row.red_value < 0 || row.orange_value > 1 || row.orange_value < 0) {
          this.$message({
            message: '当前预警值必须再0到1之间',
            type: 'error'
          })
          this.ProblemData = []
          this.getListProblem()
          return
        }
        UpdatethresholdProblem(vm).then(response => {
        // console.log(response)
        })
        this.$message({
          message: '修改成功',
          type: 'success'
        })
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
.setContent {
  width: 98%;
  margin: 12px auto;
  border-bottom: 1px solid #ccc;
  h2 {
    padding: 0;
    font-size: 20px;
    color: #303133;
  }

  .TabSetBox {
    border: 1px solid #ccc;
    border-bottom: none;
    p {
      padding: 0;
      margin: 0;
      background: #fff;
      display: block;
      width: 100%;
      border-bottom: 1px solid #ccc;
      font-size: 18px;
      color: #303133;
      font-weight: bold;
      font-family: 'Microsoft YaHei';
      height: 50px;
      line-height: 50px;
      text-indent: 30px;
    }
  }
  /deep/ .el-table th.is-leaf {
    background: #f0f4fb;
    border-bottom: 1px solid #e5e8ee;
    padding: 6px 0;
    font-size: 14px;
    color: #303133;
  }
  /deep/ .el-table th.is-leaf:first-child {
    text-align: left;
    padding: 0 0 0 20px;
  }
  /deep/ .el-table th.is-leaf:nth-last-child(2) .cell {
    text-align: right;
    padding: 0 30px 0 0;
  }
  /deep/ .el-table--enable-row-transition .el-table__body td {
    font-size: 14px;
    border-bottom: 1px solid #f1f3f6;
    padding: 6px 0;
  }
  .save {
    color: #4a90e2;
    cursor: pointer;
  }
  /deep/ .el-table--enable-row-transition .el-table__body td:first-child .cell {
    text-align: left;
    padding: 0 0 0 30px;
  }
  /deep/ .el-table--enable-row-transition .el-table__body td:last-child .cell {
    text-align: right;
    padding: 0 30px 0 0;
  }
  .change /deep/ .el-input__inner {
    border: 1px solid #f00;
  }
  .setContent /deep/ .el-cascader__label {
    font-weight: normal;
  }
}
</style>
