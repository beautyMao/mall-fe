<template>
  <div class="Wrap" :data="TargetWeekData">
    <h2><el-cascader ref="a" v-model="scene" :options="options" placeholder="现场选择" size="medium" @change="handleChange" />
    </h2>
    <div class="tagetBox">
      <dl>
        <dt>日期</dt>
        <dd>
          <span v-for="(row, index) in TargetWeekData" :class="{'greyin':(index<weekday)}">{{ row.date }}</span>
        </dd>
      </dl>
      <dl>
        <dt>星期</dt>
        <dd>
          <span v-for="(row, index) in TargetWeekData" :class="{'greyin':(index<weekday)}">{{ row.week }}</span>
        </dd>
      </dl>
      <dl>
        <dt>ACTUAL/FCST</dt>
        <dd>
          <span v-for="(row, index) in TargetWeekData" :class="{'greyin':(index<weekday)}">
            <div v-if="row.actualOrForecast.constructor == Array">
              {{ row.actualOrForecast[0] }} / {{ row.actualOrForecast[1] }}
            </div>
            <i v-else>
              {{ row.actualOrForecast }}
            </i>
          </span>
        </dd>
      </dl>
      <dl>
        <dt>放弃量</dt>
        <dd>
          <span v-for="(row, index) in TargetWeekData" :class="{'greyin':(index<weekday)}">
            <div v-if="row.numAbandon.constructor == Array">
              {{ row.numAbandon[0] }} / {{ row.numAbandon[1] }}
            </div>
            <i v-else>
              {{ row.numAbandon }}
            </i>
          </span>
        </dd>
      </dl>
      <dl>
        <dt>达标值</dt>
        <dd>
          <span v-for="(row, index) in TargetWeekData" :class="{'greyin':(index<weekday)}">{{ row.systemAbandonRate }}</span>
        </dd>
      </dl>
      <dl>
        <dt>放弃率</dt>
        <dd>
          <span v-for="(row, index) in TargetWeekData">
            <i v-if="row.abandonRate.constructor == Array" class="gtybox">
              <i class="greyin1">{{ row.abandonRate[0] }}</i> /
              <el-input
                v-model="row.abandonRate[1]"
                :readonly="(index>=weekday && index<=6)?false:true"
                class="edit-input"
                :class="{ 'inBoxBorder1': (index>=weekday && index<=6), 'inBox1': !(index>=weekday && index<=6), 'greyin':(index<weekday), 'inBox-clik1': index===number, 'change': !row.abandonRate }"
                size="small"
                @blur="inEditOver"
                @change="confirmEditTarget(index)"
                @click.native="editBox(index)"
              />
            </i>
            <i v-else>
              <el-input
                v-model="row.abandonRate"
                :readonly="(index>=weekday && index<=6)?false:true"
                class="edit-input"
                :class="{ 'inBoxBorder': (index>=weekday && index<=6), 'inBox': !(index>=weekday && index<=6), 'greyin':(index<weekday), 'inBox-clik': index===number, 'change': !row.abandonRate }"
                size="small"
                @blur="inEditOver"
                @change="confirmEditTarget(index)"
                @click.native="editBox(index)"
              />
            </i>
          </span>
        </dd>
      </dl>
      <dl>
        <dt>目标值</dt>
        <dd>
          <span v-for="(row, index) in TargetWeekData" :class="{'greyin':(index<weekday)}"> {{ row.kpi }}</span>
        </dd>
      </dl>
    </div>
  </div>
</template>
<script>
  import { targetWeek, Updatetarget } from '@/api/ccp/targetData'
  import { EngineerLocales } from '@/api/ccp/index'
  import { targetDateRoute } from '@/api/ccp/link'
  import moment from 'moment'
  import 'moment/locale/zh-cn'
  import debounce from 'throttle-debounce/debounce'
  export default {
    beforeRouteEnter: debounce(200, targetDateRoute),
    beforeRouteUpdate: debounce(200, targetDateRoute),
    data() {
      return {
        TargetWeekData: null,
        isReadOnly: true,
        number: 5,
        weekday: '',
        options: [],
        scene: [Number(this.$route.query.businessID), Number(this.$route.query.accessID)],
        businessID: null,
        business: null,
        accessID: null,
        access: null,
        timer: null
      }
    },
    mounted() {
      this.number = ''
      this.handleInterval()
      this.getEngineer()
      this.gettargetWeek()
      this.handleInterval()
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    methods: {
      handleInterval() {
        clearInterval(this.timer)
        this.timer = setInterval(() => {
          this.gettargetWeek()
        }, 10000)
      },
      handleChange(value) { // 通路切换 打开新页面
        this.$router.push({
          path: '',
          query: {
            businessID: value[0],
            business: this.$refs.a.currentLabels[0],
            accessID: value[1],
            access: this.$refs.a.currentLabels[1]
          }
        })
      },
      gettargetWeek() {
        targetWeek(this.$route.query.businessID, this.$route.query.accessID).then(response => {
          this.TargetWeekData = response.data
          this.weekday = moment().get('weekday')
        })
      },
      getEngineer() { // 现场选择
        EngineerLocales(this.$route.query.businessID, this.$route.query.accessID).then(response => {
          var item = response.data
          for (const i in item) {
            const childrenList = []
            for (const j in item[i].children) {
              if (item[i].children[j].power === 2) {
                childrenList.push(item[i].children[j])
              }
            }
            if (childrenList.length > 0) {
              this.options.push({
                'value': item[i].value,
                'label': item[i].label,
                'children': childrenList
              })
            }
          }
        })
      },
      confirmEditTarget(index) {
        const data2 = []
        if (this.TargetWeekData[index].abandonRate.constructor === Array) {
          data2.push({ 'businessId': this.$route.query.businessID, 'accessId': this.$route.query.accessID, 'date': this.TargetWeekData[index].date, 'abandonRate': this.TargetWeekData[index].abandonRate[1] })
        } else {
          data2.push({ 'businessId': this.$route.query.businessID, 'accessId': this.$route.query.accessID, 'date': this.TargetWeekData[index].date, 'abandonRate': this.TargetWeekData[index].abandonRate })
        }
        if (this.TargetWeekData[index].abandonRate === '') {
          this.$message({
            message: '此项为必填项',
            type: 'error'
          })
          this.number = ''
          this.gettargetWeek()
          return
        }
        // if (!/^(100|[1-9]?\d(\.\d\d?\d?)?)%$|0$/.test(this.TargetWeekData[index].abandonRate)) {
        //   this.$message({
        //     message: '格式有误,请输入正确的格式',
        //     type: 'error'
        //   })
        //   this.number = ''
        //   this.gettargetWeek()
        //   return
        // }
        Updatetarget(data2[0]).then(response => {
          if (!response.data.length) {
            if (response.data.error === 422) {
              this.$message({
                message: response.data.message,
                type: 'warning'
              })
              this.gettargetWeek()
            } else {
              this.$message({
                message: '修改成功',
                type: 'success'
              })
            }
          }
          this.number = ''
        }).catch((err) => {
          console.log(err)
        })
      },
      editBox(index) {
        if (index >= this.weekday && index <= 6) {
          this.number = index
        }
      },
      inEditOver() {
        this.number = ''
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  .Wrap {
    width: 97%;
    padding: 12px 0;
    margin:0 auto;
    i{
      font-style: normal;
    }
    h2{
      padding: 0;
      font-size: 20px;
      color: #303133;
    }
    .tagetBox{
      border:1px solid #e1e2e3;
      background: #fff;
      min-width: 1500px;
      dl{ clear: both; overflow: hidden;
        dt{float: left;
          width: 160px;
          height: 60px;
          line-height: 60px;
          text-indent: 30px;
          background: #f0f4fb;}
        dd {
          float: left;
          width: calc(100% - 160px);
          height: 60px;
          line-height: 60px;
          font-size: 14px;
          color: #606266;
          border-bottom: 1px solid #e4e7ed;
          &:hover{background: #e5f2ff}
          span{ display: block; text-align: center; float: left; width: calc(100%/10);}
        }
      }
    }
    .el-button--primary{ float: right; font-size:14px; margin-top: 10px; width: 150px; height: 40px;}
    .inBoxBorder1{ width: 65px;}
    .el-input /deep/ .el-input__inner{ border:0; background: none; text-align: center;}
    .greyin /deep/ .el-input__inner{color: #C0C4CC;}
    .inBoxBorder /deep/ .el-input__inner{
       text-align: center; width: 70%;
       background:url('~@/assets/pencil.png') no-repeat right center;
       cursor: pointer;
     }
    .inBoxBorder1 /deep/ .el-input__inner{
      text-align: left; width: 100%;
      background:url('~@/assets/pencil.png') no-repeat right center;
      cursor: pointer;
      padding-right: 20px;
      padding-left: 0;
    }
    .inBox-clik /deep/ .el-input__inner {background:#fff; border: 1px solid #ccc;}
    .inBox-clik1 /deep/ .el-input__inner {background:#fff; border: 1px solid #ccc; padding-left:3px;}
    .change /deep/ .el-input__inner{border: 1px solid #f00;}
    .greyin{ color: #C0C4CC;}
    .greyin1{ color: #C0C4CC; display: inline-block; padding:0 0 0 4px; text-align: right; }
    .gtybox{ width: 100%; display: inline-block}
  }
</style>
