<template>
  <div :class="className" :style="{height:height,width:width}" />
</template>
<script>
  import { getCaseClass } from '@/api/ccp/case'
  import echarts from 'echarts'
  require('echarts/theme/macarons') // echarts theme
  export default {
    props: {
      className: {
        type: String,
        default: 'chart'
      },
      width: {
        type: String,
        default: '100%'
      },
      height: {
        type: String,
        default: '500px'
      }
    },
    data() {
      return {
        businessId: '',
        accessId: '',
        chart: null,
        timer: null,
        option: {
          color: ['#9860E5', '#5354D0', '#1E3077', '#1890FF', '#13C2C2', '#4ECC74', '#5E8A2B', '#FB8903', '#FBD438', '#F3647C', '#F5ADE2'],
          tooltip: {
            trigger: 'item',
            triggerOn: 'click',
            position: [20, 20],
            formatter: function(data) {
              var res = `<table width="100%" border="0" cellspacing="0" cellpadding="0" style="color:#303133; font-weight:bold; background:#f0f4fb; font-size:14px; padding:10px 5px">
            <tr>
            <td width="55%">类型</td>
            <td width="20%" align="center">数量</td>
            <td align="center">百分比</td>
            </tr>
            </table>`
              if (data.data.labels) {
                const total = data.data.total
                for (const i of data.data.labels) {
                  res += `<table width = "100%" border = "0" cellspacing = "0"  cellpadding = "0" style = "color: #606266; font-size:12px;">
                <tr style = "border-bottom:1px solid #DCDFE6">
                <td width = "55%" style = "border-bottom: 1px solid #DCDFE6; padding: 8px; ">
                ${i.name}</td>
                <td width = "20%" align = "center" style = "border-bottom:1px solid #DCDFE6">
                ${i.value}</td>
                <td align = "center" style = "border-bottom:1px solid #DCDFE6">${'(' + (i.value / total * 100).toFixed(2) + '%)'}</td>
                </table>
                </tr>`
                }
              } else {
                res += `<table width="100%" border="0" cellspacing="0" cellpadding="0" style="color:#606266; font-size:12px;">
              <tr style="border-bottom:1px solid #DCDFE6">
              <td width="55%" style="border-bottom:1px solid #DCDFE6; padding: 8px; ">${data.name}</td>
              <td width = "20%" align="center" style="border-bottom:1px solid #DCDFE6">${data.value}</td>
              <td align = "center" style = "border-bottom:1px solid #DCDFE6">${'(' + data.percent + '%)'}</td>
              </table>
              </tr>`
              }
              return res
            },
            backgroundColor: '#fff',
            borderColor: '#e5e9ee',
            borderWidth: 1,
            padding: 0
          },
          legend: {
            icon: 'circle',
            itemGap: 20,
            itemWidth: 10,
            itemHeight: 10,
            orient: 'vertical',
            right: '40px',
            top: '10%',
            data: [],
            textStyle: {
              color: '#606266'
            }
          },
          series: [
            {
              name: '问题分类',
              type: 'pie',
              legendHoverLink: true,
              radius: '65%',
              center: ['38%', '48%'],
              label: {
                normal: {
                  formatter: '{b|{b}：} {per|{d}%}',
                  rich: {
                    b: {
                      fontSize: 12,
                      lineHeight: 33
                    }
                  }
                }
              },
              data: [],
              itemStyle: {
                emphasis: {
                  shadowBlur: 10,
                  shadowOffsetX: 0,
                  shadowColor: 'rgba(0, 0, 0, 0.5)'
                }
              }
            }
          ]
        }
      }
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    deactivated() {
      clearInterval(this.timer)
    },
    mounted() {
      this.initChart()
      this.handleInterval()
    },
    methods: {
      handleInterval() {
        clearInterval(this.timer)
        this.timer = setInterval(() => {
          this.initChart()
        }, 15000)
      },
      initChart() {
        const accessID = this.$route.query.accessID
        const businessID = this.$route.query.businessID
        getCaseClass(businessID, accessID).then(res => {
          // res.data.sort((x, y) => y.value - x.value)
          this.option.series[0].data = res.data
          for (const item of res.data) {
            this.option.legend.data.push(item.name)
          }
          this.drawPie()
        })
      },

      drawPie() {
        this.chart = echarts.init(this.$el)
        this.chart.setOption(this.option)
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
</style>
