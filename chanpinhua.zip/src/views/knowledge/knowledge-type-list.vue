<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div class="app-container">
    <header>
      <h1>知识库管理</h1>
      <div class="flex-wrp">
        <el-button type="primary" plain @click="addVisible = true">新增文章分类</el-button>
      </div>
    </header>
    <knowledgeTable
      type="type"
      :list-data="tableDataList"
      @change="handleCurrentChange"
      @handleSizeChange="handleSizeChange"
      @delete="handleDelete"
      @edit="handleEdit"
      @goArt="handleGoArt"
      @deleteMultipleData="handleDeleteMultipleData"
    />
    <KnowledgeDialog
      :visible="addVisible"
      title="新增文章分类"
      @close="addVisible = false"
      @submitData="handleSubmitData"
    />

    <KnowledgeDialog
      :visible="editVisible"
      title="修改文章分类"
      :name-val="nameVal"
      @close="editVisible = false"
      @submitData="handleSubmitData"
    />
  </div>
</template>

<script>
  import {
    configClassifiedKnowledgeRestApi,
    searchApiWbClassifiedKnowledge,
    commitDeleteBatchClassifiedKnowledge
  } from '@/api/knowledge-info'
  import KnowledgeTable from './components/knowledge-table'
  import KnowledgeDialog from './components/knowledge-dialog'

  export default {
    name: 'knowledge-type-list',
    components: { KnowledgeTable, KnowledgeDialog },
    data() {
      return {
        addVisible: false,
        editVisible: false,
        nameVal: '',
        tableDataList: {
          case_list: [],
          current_page: 1,
          size: 10,
          total: 0
        },
        currentData: {
          page: 1,
          pageSize: 10
        }
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        searchApiWbClassifiedKnowledge(this.currentData).then(this.renderTable).catch(this.$message.error)
      },
      handleDelete(index, row) {
        this.$confirm(`确定删除【${row.name}】文章分类吗？此操作无法撤销！`, '提示', {
          confirmButtonText: '确定删除',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          configClassifiedKnowledgeRestApi.delete(row.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      handleEdit(index, row) {
        this.nameVal = row.name
        console.log(row)
        this.editVisible = true
      },
      handleSubmitData(data) {
        configClassifiedKnowledgeRestApi.post(data).then(response => {
          this.fetchData()
          this.addVisible = false
        }).catch(this.$message.error)
      },
      handleCurrentChange(page) {
        this.currentData.page = page
        searchApiWbClassifiedKnowledge(this.currentData).then(this.renderTable).catch(this.$message.error)
      },
      handleSizeChange(size) {
        this.currentData.pageSize = size
        this.currentData.page = 1
        searchApiWbClassifiedKnowledge(this.currentData).then(this.renderTable).catch(this.$message.error)
      },
      renderTable(res) {
        this.tableDataList = res.data
        this.currentData.page = res.data.current_page
        this.currentData.pageSize = res.data.per_page
      },
      handleGoArt(index, row) {
        this.$router.push({
          path: `/knowledge/knowledgeArticleList`,
          query: {
            aid: row.id,
            aname: row.name
          }
        })
      },
      handleDeleteMultipleData(val) {
        if (val.length === 0) {
          this.$message({
            type: 'error',
            message: '请选择要删除的文章分类'
          })
          return false
        }
        this.$confirm(`确定删除选中的文章分类吗？删除分类后，文章也会被删除。`, '是否删除', {
          confirmButtonText: '确定删除',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          const postId = val.map(item => item.id)
          commitDeleteBatchClassifiedKnowledge({ id: postId }).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
          }).catch(this.$message.error)
        }).catch(() => {})
      }
    }
  }
</script>

