<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div class="app-container">
    <el-card>
      <header>
        <h1 style="margin-top:15px;">{{ title }}</h1>
      </header>
      <hr style="background:rgba(228,231,237,1)">
      <div style="margin-top: 10px;overflow: hidden;">
        <img src="@/assets/engineer_icon.png" style="width: 56px;height: auto;float: left;">
        <div style="float: left;margin-left: 20px;">
          <p style="color: #303133;font-size: 14px;margin:6px 0;">作者姓名:{{ engineer_name }}</p>
          <p style="color:#606266;font-size: 14px;">{{ updated_at }} | 文档编号：{{ id }}</p>
        </div>
      </div>
      <content style="color: #606266;font-size: 14px;margin-bottom: 50px;display: block;" v-html="content" />
    </el-card>
  </div>
</template>

<script>
  // import ArticleDetail from './components/ArticleDetail'
  import {
    configKnowledgeRestApi
  } from '@/api/knowledge-info'
  export default {
    name: 'article-info',
    components: { },
    data() {
      return {
        id: '',
        title: '',
        content: '',
        engineer_code: '',
        engineer_name: '',
        engineer_avatar: '',
        updated_at: ''
      }
    },
    created() {
      const id = this.$route.query.id
      this.fetchData(id)
    },
    methods: {
      fetchData(id) {
        configKnowledgeRestApi.get(id).then(response => {
          this.id = response.data.id
          this.title = response.data.title
          this.content = response.data.content
          this.updated_at = response.data.updated_at
          this.engineer_code = response.data.engineer_code
          this.engineer_name = response.data.engineer_name
        }).catch(this.$message.error)
      }
    }
  }
</script>
<style lang="scss" scoped>
  content{
    margin: 40px;
    /deep/ code{
      white-space:pre-wrap;
      word-break:break-all;
       word-wrap:break-word;
    }
  }
</style>
