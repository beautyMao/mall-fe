<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div class="app-container">
    <header>
      <h1>{{ artName }}</h1>
      <div class="flex-wrp">
        <el-button type="primary" plain @click="$router.push({path: '/knowledge/create',query: {aid: artId}})">创建文章</el-button>
      </div>
    </header>
    <knowledgeTable
      type="article"
      :list-data="tableDataList"
      @change="handleCurrentChange"
      @handleSizeChange="handleSizeChange"
      @delete="handleDelete"
      @edit="handleEdit"
      @goArt="handleGoArt"
      @deleteMultipleData="handleDeleteMultipleData"
      @removeMultipleData="handleRemoveMultipleData"
    />

    <el-dialog title="请选择目标分类" :visible.sync="dialogRemoveVisible">
      <el-select
        v-model="problem_id"
        filterable
        placeholder="请选择文章分类"
      >
        <el-option v-for="(item, index) in typeList" :key="index" :label="item.name" :value="item.id" />
      </el-select>
      <div slot="footer" class="dialog-footer">
        <el-button @click="dialogRemoveVisible = false">取 消</el-button>
        <el-button type="primary" @click="handleMoveArticle">确 定</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import {
    configKnowledgeRestApi,
    searchApiWbClassifiedKnowledge,
    commitDeletBatchKnowledgeArticle,
    commitRemoveBatchKnowledgeArticle,
    searchApiWbClassifiedKnowledgeById
  } from '@/api/knowledge-info'
  import knowledgeTable from './components/knowledge-table'
  import KnowledgeDialog from './components/knowledge-dialog'

  export default {
    name: 'knowledge-article-list',
    components: { knowledgeTable, KnowledgeDialog },
    data() {
      return {
        dialogRemoveVisible: false,
        artName: this.$route.query.aname,
        artId: this.$route.query.aid,
        typeList: '',
        multipleSelection: [],
        problem_id: '',
        tableDataList: {
          case_list: [],
          current_page: 1,
          size: 10,
          total: 0
        },
        currentData: {
          page: 1,
          pageSize: 10
        }
      }
    },
    mounted() {
      this.fetchData()
    },
    methods: {
      fetchData() {
        searchApiWbClassifiedKnowledgeById(this.artId, this.currentData).then(this.renderTable).catch(this.$message.error)
      },
      handleDelete(index, row) {
        this.$confirm(`确定删除【${row.title}】这篇文章吗？此操作无法撤销！`, '提示', {
          confirmButtonText: '确定删除',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          configKnowledgeRestApi.delete(row.id).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.fetchData()
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      handleEdit(index, row) {
        // this.editVisible = true
        this.$router.push({
          path: `/knowledge/edit`,
          query: {
            tId: row.id
          }
        })
      },
      handleGoArt(index, row) {
        this.$router.push({
          path: `/knowledge/article-info`,
          query: {
            id: row.id
          }
        })
      },
      handleCurrentChange(page) {
        this.currentData.page = page
        searchApiWbClassifiedKnowledgeById(this.artId, this.currentData).then(this.renderTable).catch(this.$message.error)
      },
      handleSizeChange(size) {
        this.currentData.pageSize = size
        this.currentData.page = 1
        searchApiWbClassifiedKnowledgeById(this.artId, this.currentData).then(this.renderTable).catch(this.$message.error)
      },
      renderTable(res) {
        this.tableDataList = res.data
        this.currentData.page = res.data.current_page
        this.currentData.pageSize = res.data.per_page
      },
      handleDeleteMultipleData(val) {
        this.multipleSelection = val
        if (this.multipleSelection.length === 0) {
          this.$message({
            type: 'error',
            message: '请选择要删除的文章'
          })
          return false
        }
        this.$confirm(`确定删除选中的文章吗？删除不可恢复。`, '是否删除', {
          confirmButtonText: '确定删除',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          const postId = this.multipleSelection.map(item => item.id)
          commitDeletBatchKnowledgeArticle({ id: postId }).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            this.multipleSelection = []
            this.fetchData()
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      handleRemoveMultipleData(val) {
        this.multipleSelection = val
        if (this.multipleSelection.length === 0) {
          this.$message({
            type: 'error',
            message: '请选择要移动的文章'
          })
          return false
        }
        searchApiWbClassifiedKnowledge().then(res => {
          this.typeList = res.data.data
          this.dialogRemoveVisible = true
        }).catch(this.$message.error)
      },
      handleMoveArticle() {
        const postId = this.multipleSelection.map(item => item.id)
        if (this.problem_id === '') {
          this.$message({
            type: 'error',
            message: '请选择要移动的文章分类'
          })
          return false
        }
        commitRemoveBatchKnowledgeArticle({ id: postId, problem_id: this.problem_id }).then(res => {
          this.dialogRemoveVisible = false
          this.$message({
            type: 'success',
            message: '文章移动成功!'
          })
          this.multipleSelection = []
          this.fetchData()
        }).catch(this.$message.error)
      }
    }
  }
</script>

<style scoped lang="scss">
/deep/ .el-dialog .el-dialog__body{
  margin-bottom: 20px;
}
</style>
