<template>
  <el-card>
    <el-table
      ref="multipleTable"
      :data="tableData.data"
      tooltip-effect="dark"
      @select="handleSelectionChange"
      @select-all="handleSelectionChange"
    >
      <el-table-column
        type="selection"
        width="55"
      />
      <el-table-column
        v-if="!isArt"
        width="700"
        label="标题"
      >
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="handleGoArt(scope.$index, scope.row)"
          >{{ scope.row.name }}
          </el-button>
        </template>
      </el-table-column>
      <el-table-column
        v-if="isArt"
        label="标题"
        width="600"
      >
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="handleGoArt(scope.$index, scope.row)"
          >{{ scope.row.title }}
          </el-button>
        </template>
      </el-table-column>
      <el-table-column v-if="isArt" label="发布日期">
        <template slot-scope="scope">
          {{ scope.row.created_at }}
        </template>
      </el-table-column>
      <el-table-column v-if="isArt" label="更新日期">
        <template slot-scope="scope">
          {{ scope.row.updated_at }}
        </template>
      </el-table-column>
      <el-table-column label="操作">
        <template slot-scope="scope">
          <el-button
            type="text"
            @click="handleEdit(scope.$index, scope.row)"
          >编辑
          </el-button>
          <el-button
            type="text"
            class="el-del"
            @click="handleDelete(scope.$index, scope.row)"
          >删除
          </el-button>
        </template>
      </el-table-column>
    </el-table>
    <div class="flex-wrp flex-between">
      <div class="del-btn">
        <span @click="handleDeleteMultipleData">删除</span>
        <span v-if="isArt" style="margin-left: 20px" @click="handleRemoveMultipleData">移动</span>
      </div>
      <el-pagination
        class="flex-wrp"
        background
        :current-page="tableData.current_page"
        :page-size="tableData.size"
        :page-sizes="[10, 15, 20, 25]"
        layout="total, sizes, prev, pager, next, jumper"
        :total="tableData.total"
        @size-change="handleSizeChange"
        @current-change="currentChange"
      />
    </div>
  </el-card>
</template>

<script>
  export default {
    name: 'knowledge-table',
    props: {
      type: {
        type: String,
        required: true
      },
      listData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        isArt: this.type === 'article',
        tableData: [],
        multipleSelection: []
      }
    },
    watch: {
      listData: {
        handler(newVal, oldVal) {
          this.tableData = Object.assign({}, newVal)
          this.multipleSelection = []
        },
        deep: true
      }
    },
    mounted() {
      // console.log(this.isArt)
    },
    methods: {
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
      handleEdit(index, row) {
        this.$emit('edit', index, row)
      },
      handleDelete(index, row) {
        this.$emit('delete', index, row)
      },
      currentChange(val) {
        this.$emit('change', val)
      },
      handleSizeChange(val) {
        this.$emit('handleSizeChange', val)
      },
      handleDeleteMultipleData() {
        this.$emit('deleteMultipleData', this.multipleSelection)
      },
      handleRemoveMultipleData() {
        this.$emit('removeMultipleData', this.multipleSelection)
      },
      handleGoArt(index, row) {
        this.$emit('goArt', index, row)
      }
    }
  }
</script>
<style scoped lang="scss">
.del-btn{
  display: flex;
  color: #3E8DDD;
  font-size: 14px;
  padding-left: 14px;
  align-items: center;
}
</style>
