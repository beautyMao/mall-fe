<template>
  <el-card class="add-problem">
    <div slot="header" class="clearfix">
      <span class="add-title">新增客户标签</span>
    </div>
    <el-form ref="form" :model="form" />

  </el-card>
</template>

<script>
  export default {
    name: 'said-dialog',
    props: {
    },
    data() {
      return {
      }
    },
    mounted() {
    },
    methods: {

    }
  }
</script>

<style scoped lang="scss">

  .add-problem {
    width: 33%;
    .add-title {
      font-weight: bolder;
    }
    /deep/.el-card__header {
      border: none !important;
      font-size: 20px;
      padding: 20px 20px 30px 30px;
    }
    /deep/.el-card__body {
      padding: 0 30px 30px !important;
      /deep/ .el-form {
        /deep/ .el-form-item {
          /deep/ .el-form-item__label {
            height: 40px !important;
            line-height: 40px;
          }
        }
      }
    }
    /deep/ .el-form-item__content {
      display: flex;
      flex-wrap: nowrap;
      justify-content: flex-start;
      /deep/ .el-cascader {
        height: 40px;
        width: 100%;
      }
      /deep/ .el-cascader__label {
        height: 40px;
      }
      /deep/ .el-input {
        height: 40px;
      }
      /deep/ .el-input__inner {
        height: 40px;
      }
      /deep/ .el-cascader--mini {
        line-height: 40px;
      }
    }
    .err-message {
      font-size: 14px;
      color: #F37261;
      text-align: center;
      margin-bottom: 0;
    }
    .duplicate-info {
      border-color: #F37261 !important;
      /deep/ .el-input__inner {
        border: 1px solid #F37261 !important;
      }
    }

    ul {
      color: #303133;
      li {
        display: flex;
        flex-wrap: nowrap;
        justify-content: flex-start;
        align-items: center;
        width: 100%;
        margin-top: 20px !important;
        .title {
          display: block;
          font-size: 14px;
          line-height: 14px;
          width: 80px !important;
        }
        span {
          font-size: 14px !important;
          font-weight: 500 !important;
          line-height: 14px;
        }
      }
      .err-message {
        font-size: 14px;
        color: #F37261;
        text-align: center;
        margin-bottom: 0;
      }
    }
    .problem {

    }
    .duplicate-info {
      border-color: #F37261 !important;
      /deep/ .el-input__inner {
        border: 1px solid #F37261 !important;
      }
    }
    .btn-list {
      margin: 0 auto;
      display: flex !important;
      width: 220px;
      justify-content: space-between !important;
      padding-left: 20px;
      li {
        margin: 0;
        .reset {
          width: 90px;
          height: 36px;
          border-radius: 4px;
          border: 1px solid #c0c4cc;
          color: #909399;
        }
        .submit {
          width: 90px;
          height: 36px;
          border-radius: 4px;
          background-color: #BDC6DF;
          color: #FFFFFF;
        }
        .submit-enable {
          background-color: #3E8DDD;
        }
      }
    }
  }
</style>
