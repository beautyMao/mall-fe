<template>
  <el-dialog
    ref="my-dialog"
    v-loading="dialogLoading"
    :title="title"
    custom-class="el-dialog-aside"
    :visible.sync="visible"
    :before-close="() => void $emit('close')"
  >
    <el-form
      ref="form"
      :model="data"
      :rules="rules"
      @submit.native.prevent
    >
      <el-form-item
        label="文章分类名称"
        prop="name"
        :label-width="formLabelWidth"
      >
        <el-input
          v-model="data.name"
          placeholder="仅支持中英文和数字的组合，10字符内"
          type="text"
          auto-complete="off"
        />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="$emit('close')">取 消</el-button>
      <el-button type="primary" @click="onData">提 交</el-button>
    </div>
  </el-dialog>
</template>

<script>

  export default {
    name: 'knowledge-dialog',
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      title: {
        type: String,
        default: ''
      },
      nameVal: {
        type: String,
        default: ''
      },
      myData: {
        type: Object,
        default() {
          return {
            name: '',
            operator_name: this.$store.getters.user.allInfo.name,
            operator_code: this.$store.getters.user.allInfo.code
          }
        }
      }
    },
    data() {
      const validateName = (rule, value, callback) => {
        const reg = /^[A-Za-z0-9-\(\)\u4e00-\u9fa5]{1,10}$/
        if (!reg.test(this.data.name)) {
          callback(new Error('仅支持中英文和数字的组合，10字符内'))
        } else {
          callback()
        }
      }
      return {
        dialogLoading: false,
        dialogTableVisible: true,
        data: Object.assign({}, this.myData),
        formLabelWidth: '120px',
        rules: {
          name: [{ required: true, validator: validateName, trigger: 'blur' }]
        }
      }
    },
    watch: {
      visible(status) {
        !status && this.$nextTick(() => {
          this.$refs['form'].resetFields()
        })
      },
      nameVal: {
        handler(newVal, oldVal) {
          this.data.name = newVal
        }
      },
      myData: {
        handler(newVal, oldVal) {
          this.data = Object.assign({}, newVal)
        },
        deep: true
      }
    },
    methods: {
      onData() {
        this.$refs.form.validate(valid => {
          if (valid) {
            this.$emit('submitData', this.data)
          }
        })
      }
    }
  }
</script>
