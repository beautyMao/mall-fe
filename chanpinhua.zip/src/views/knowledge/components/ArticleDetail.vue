<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div class="app-container">
    <el-form ref="postForm" :model="postForm" class="form-container" :rules="rules">
      <el-form-item label="文章标题" prop="title">
        <el-input
          v-model="postForm.title"
          placeholder="仅支持中英文和数字的组合，50字符内"
          type="text"
          auto-complete="off"
          style="width: 70%;"
        />
      </el-form-item>

      <el-form-item label="文章分类" style="margin-bottom: 40px;" prop="problem_id">
        <el-select
          v-model="postForm.problem_id"
          filterable
          popper-class="select-option"
          placeholder="请选择文章分类"
          style="z-index: 10000"
        >
          <el-option v-for="(item, index) in typeList" :key="index" :label="item.name" :value="item.id" />
        </el-select>
      </el-form-item>

      <el-form-item prop="content" style="margin-bottom: 30px;">
        <Tinymce ref="editor" v-model="postForm.content" :height="500" />
      </el-form-item>

    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="close">取 消</el-button>
      <el-button class="submit" type="primary" @click="onData">发 布</el-button>
    </div>
  </div>
</template>

<script>
  import axios from 'axios'
  import { mapActions } from 'vuex'
  import Tinymce from '@/components/Tinymce'
  import { getToken } from '@/utils/auth'
  import {
    searchApiWbClassifiedKnowledge,
    configKnowledgeRestApi
  } from '@/api/knowledge-info.js'

  const defaultForm = {
    title: '', // 文章题目
    content: '', // 文章内容
    problem_id: '',
    engineer_code: ''
  }

  export default {
    name: 'article-detail',
    components: { Tinymce },
    props: {
      isEdit: {
        type: Boolean,
        default: false
      }
    },
    data() {
      const validateTitle = (rule, value, callback) => {
        const reg = /^[A-Za-z0-9-\(\)\u4e00-\u9fa5]{1,50}$/
        if (!reg.test(this.postForm.title)) {
          callback(new Error('仅支持中英文和数字的组合，50字符内'))
        } else {
          callback()
        }
      }
      return {
        postForm: Object.assign({}, defaultForm),
        formLabelWidth: '120px',
        uploadUrl: `https://imccdev.lenovo.com.cn/api/wb/image/up?token=${getToken()}`,
        typeList: '',
        loading: false,
        editor: null, // 编辑器实例
        rules: {
          problem_id: [{ required: true, trigger: 'change', message: '请选择文章分类' }],
          title: [{ required: true, validator: validateTitle, trigger: 'blur' }],
          content: [{ required: true, trigger: 'blur', message: '请填写文章内容' }]
        }
      }
    },
    mounted() {
      this.init()
    },
    created() {
      if (this.isEdit) {
        const id = this.$route.query.tId
        this.fetchData(id)
      } else {
        const id = this.$route.query.aid
        this.postForm = Object.assign({}, defaultForm)
        this.postForm.problem_id = parseInt(id)
      }
    },
    methods: {
      ...mapActions('tagsView', [
        'initAllViews',
        'addView',
        'updateVisitedView',
        'delCachedView',
        'delView',
        'delOthersViews',
        'delAllViews'
      ]),
      closeSelectedTag(view) {
        this.delView(this.$route).then(({ visitedViews }) => {
          const latestView = visitedViews.slice(-1)[0]
          if (latestView) {
            this.$router.push(latestView)
          } else {
            this.$router.push('/')
          }
        })
      },
      init() {
        searchApiWbClassifiedKnowledge().then(res => {
          this.typeList = res.data.data
        }).catch(this.$message.error)
      },
      fetchData(id) {
        configKnowledgeRestApi.get(id).then(response => {
          this.postForm.problem_id = response.data.id
          this.postForm = response.data
        })
      },
      close() {
        this.closeSelectedTag()
      },
      onData() {
        // this.postForm.content = this.editor.getData()
        console.log(this.postForm.content)
        this.postForm.engineer_code = this.$store.getters.user.allInfo.code
        this.$refs.postForm.validate(valid => {
          if (valid) {
            if (this.isEdit) {
              const id = this.$route.query.tId
              configKnowledgeRestApi.update(id, this.postForm).then(this.renderSuccess).catch(this.$message.error)
            } else {
              axios({
                method: 'POST',
                url: `https://imccdev.lenovo.com.cn/api/wb/knowledgeBase`,
                data: this.postForm,
                headers: {
                  'Authorization': `Bearer ${getToken()}`
                }
              }).then(response => {
                this.renderSuccess()
              }).catch(err => {
                console.log(err)
              })
              // postApiWbKnowledgeBase(this.postForm).then(this.renderSuccess).catch(this.$message.error)
            }
          } else {
            console.log('error submit!!')
            return false
          }
        })
      },
      renderSuccess() {
        this.$notify({
          title: '成功',
          message: '发布文章成功',
          type: 'success',
          duration: 2000
        })
        this.closeSelectedTag()
      }
    }
  }
</script>
<style lang="scss">
.select-option{
  z-index: 20000!important;
}
</style>
