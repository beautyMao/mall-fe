<template>
  <el-card style="width: 66%;">
    <el-tree
      :props="props"
      lazy
      show-checkbox
      @check-change="handleCheckChange"
    />

  </el-card>
</template>

<script>
  export default {
    name: 'knowledge-table',
    props: {
      type: {
        type: String,
        required: true
      },
      listData: {
        type: Object,
        required: true
      }
    },
    data() {
      return {
        props: {
          label: 'name',
          children: 'zones'
        },
        count: 1
      }
    },
    watch: {
      listData: {
        handler(newVal, oldVal) {
          this.tableData = Object.assign({}, newVal)
          this.multipleSelection = []
        },
        deep: true
      }
    },
    mounted() {
      // console.log(this.isArt)
    },
    methods: {
      handleCheckChange(data, checked, indeterminate) {
        console.log(data, checked, indeterminate)
      },
      handleSelectionChange(val) {
        this.multipleSelection = val
      },
      handleEdit(index, row) {
        this.$emit('edit', index, row)
      },
      handleDelete(index, row) {
        this.$emit('delete', index, row)
      },
      currentChange(val) {
        this.$emit('change', val)
      },
      handleSizeChange(val) {
        this.$emit('handleSizeChange', val)
      },
      handleDeleteMultipleData() {
        this.$emit('deleteMultipleData', this.multipleSelection)
      },
      handleRemoveMultipleData() {
        this.$emit('removeMultipleData', this.multipleSelection)
      },
      handleGoArt(index, row) {
        this.$emit('goArt', index, row)
      }
    }
  }
</script>
<style scoped lang="scss">
.del-btn{
  display: flex;
  color: #3E8DDD;
  font-size: 14px;
  padding-left: 14px;
  align-items: center;
}
</style>
