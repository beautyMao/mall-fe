<template>
  <el-container class="call-center-history">
    <el-aside v-if="session" class="history-aside" width="265px">
      <h2>聊天记录</h2>
      <p class="clearfix"><span>会话ID：</span><b>{{ session.id }}</b></p>
      <p class="clearfix"><span>用户情感值：</span><b>{{ session.emotion }}</b></p>
      <p class="clearfix"><span>用户：</span><b>{{ session.user_name }}</b></p>
      <p class="clearfix"><span>客服：</span><b>{{ session.engineer_name }}</b></p>
      <p class="clearfix"><span>开始时间：</span><b>{{ session.start_talking_at }}</b></p>
      <p class="clearfix"><span>结束时间：</span><b>{{ session.end_talking_at }}</b></p>
    </el-aside>
    <el-aside v-else class="history-aside" width="220px">
      <h2>会话：{{ $route.query.id }}</h2>
      <p>未查询到相关信息，请确认会话ID是否正确。</p>
    </el-aside>

    <el-main>
      <ul v-if="messages.length" ref="list" class="chat-list">
        <chat-message
          v-for="message in messages"
          v-if="messages"
          :key="message.id"
          :message="message"
          :session="session"
          @image="handleImageView">
        </chat-message>
      </ul>
      <ul v-else class="chat-list">
        <li class="empty">没有聊天内容</li>
      </ul>
      <image-viewer ref="viewer" :srcs="imageList" />
    </el-main>
  </el-container>
</template>

<script type="text/ecmascript-6">
  import { getCaseInfo, getHistory } from '@/api/call-center/call-center'
  import {
    convertCharacterEntity,
    convertHistoryToMessage,
    convertToSession
  } from '@/store/modules/call-center/convert'

  import ChatMessage from './components/chat-message'
  import ImageViewer from '@/components/ImageViewer'
  import { QINIU_HOST, QINIU_IMAGEVIEW } from '@/api/qiniu'
  import { MESSAGE_TYPE } from '@call/msg-util'

  export default {
    name: 'chat-history',
    components: {
      ChatMessage, ImageViewer
    },
    data() {
      return {
        messages: [],
        session: null,
        imageList: []
      }
    },
    watch: {
      '$route': function(route) {
        this.init()
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      async init() {
        const id = this.$route.query.id
        if (!id) {
          return this.$message({
            message: '缺少会话信息参数'
          })
        }

        const sessionData = await getCaseInfo(id)
        if (!this.$get(sessionData, 'data.cube_uid')) {
          return this.$message.warning('获取会话信息失败，请确认会话ID 有效性')
        }
        // const userInfoData = await getUserInfo(sessionData.data.cube_uid)
        // if (!this.$get(userInfoData, 'data[0]')) {
        //   return this.$message.warning('获取用户信息失败，请确认会话中用户的有效性')
        // }
        // this.session = convertToSession(sessionData.data, userInfoData.data)
        this.session = convertToSession(sessionData.data)
        const messageResData = await getHistory(id, this.session.cube_uid)
        const dataMessages = messageResData.data.data
        if (!dataMessages.length) {
          return false
        }

        this.messages = dataMessages.reverse().map(message => {
          message.text = convertCharacterEntity(message.text)
          return convertHistoryToMessage(message, this.session)
        }).filter(message => {
          return message.content.trim() !== ''
        })
        this.session.messages = this.messages
      },
      handleImageView(target) {
        const imageMessages = this.session.messages.filter(m => m.type === MESSAGE_TYPE.Image)
        if (imageMessages.length) {
          const index = imageMessages.findIndex(m => m.content === target)
          this.imageList = imageMessages.map(m => {
            if (m.content.includes(QINIU_HOST)) {
              return m.content + QINIU_IMAGEVIEW
            }
            return m.content
          })
          this.$refs.viewer.showViewer(index)
        }
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "./scss/rules";

  .call-center-history {
    max-width: 950px;
    margin-left: auto;
    margin-right: auto;

    .history-aside {
      p {
        font-size: 14px;
        line-height: 1.2;
      }
      b {
        display: block;
        word-break: break-all;
        margin-left: 100px;
      }
      h2 {
        font-size: 16px;
        color: $ldark;
        line-height: 40px;
        height: 40px;
      }

      span {
        display: inline-block;
        width: 95px;
        text-align: right;
        padding-right: 5px;
        float: left;
      }
    }

    .chat-list {
      border: 1px solid $borderColor;
      background-color: white;
      height: calc(100vh - 130px);
      overflow-y: auto;
      padding-top: 20px;
      padding-bottom: 50px;

      .empty {
        padding-left: 20px;
        color: $lldark;
      }
    }
  }

</style>
