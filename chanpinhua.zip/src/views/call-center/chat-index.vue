<template>
  <div
    class="call-center"
    @keydown="keyboardArrowSwitch"
  >
    <chat-user-list/>

    <keep-alive exclude="session-chat">
      <component :is="'session-' + sessionType"/>
    </keep-alive>

    <chat-functional />
  </div>
</template>

<script type="text/ecmascript-6">
  import VoiceWindow from './components/voice-window'
  import ChatUserList from './components/chat-user-list'
  import ChatWindow from './components/chat-window'
  import ChatWelcome from './components/chat-welcome'
  import ChatFunctional from './components/chat-functional'

  import { mapActions, mapGetters } from 'vuex'
  import { ClientType } from '@/store/modules/call-center/enum'

  export default {
    name: 'call-center',
    components: {
      ['session-' + ClientType.Telephone]: VoiceWindow,
      'session-chat': ChatWindow,
      'session-welcome': ChatWelcome,
      ChatUserList,
      ChatFunctional
    },
    computed: {
      ...mapGetters(['engineerCode']),
      ...mapGetters('call', ['currentSession', 'currentSessionID', 'sessions']),
      ...mapGetters('call', ['sessionPhoneId']),
      sessionType() {
        if (this.currentSession) {
          // keep alive 造成了currentSession = null 时，子组件仍然需要做判断的麻烦
          // 所以干脆将wechat 和webchat 类型合并，避免切换组件导致功能失效（包括上下切换、草稿等）
          const isChat = [ClientType.Wechat, ClientType.Webchat].includes(this.currentSession.client_type)
          return isChat ? 'chat' : this.currentSession.client_type
        }
        // 空框电话状态
        if (this.sessionPhoneId) {
          return ClientType.Telephone // telephone
        }
        return 'welcome'
      }
    },
    beforeMount() {
      this.login(this.engineerCode).then(re => {
        this.$message.success('呼叫中心初始化成功')
      }).catch(error => {
        this.$message.error('呼叫中心初始化失败' + error.ErrorInfo)
      })
      // 由于登录只执行了一次，刷新动作仍然需要从sessionStorage 里获取并填充
      // 避免两次ready 情况
      // this.loginSoftphone()
      // this.initSoftphone()
      this.checkSoftphoneSession()
    },
    beforeDestroy() {
      // 同时移除TX IM 上的事件监听，防止客服二次收到消息
      this.logout()
    },
    methods: {
      ...mapActions('call', [
        'login',
        'logout',
        'switchSession',
        'checkSoftphoneSession'
      ]),
      keyboardArrowSwitch(event) {
        if (event.code === 'ArrowUp') {
          this.switchSessionMethod(true)
        } else if (event.code === 'ArrowDown') {
          this.switchSessionMethod()
        }
      },
      switchSessionMethod(isPrevious) {
        const ids = Object.keys(this.sessions)
        if (!ids.length) {
          return
        }

        const index = ids.lastIndexOf(this.currentSessionID)
        let id
        if (isPrevious) {
          id = ids[(index + ids.length - 1) % ids.length]
        } else {
          id = ids[(index + ids.length + 1) % ids.length]
        }
        this.switchSession(this.sessions[id])
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .call-center {
    height: calc(100vh - (34px + 50px));
    display: flex;
    flex-flow: row;
    overflow-y: hidden;

    .status-echeats {
      transition: all 0.3s;
      transform: scale(0.8);

      &:hover {
        transform: scale(1);
      }
    }
  }
</style>
