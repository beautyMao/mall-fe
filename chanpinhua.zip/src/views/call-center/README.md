## 呼叫中心开发文档

- 由于简化了部分 vuex state 的生成，部分变量命名方式直接使用的后端返回值。

腾讯云 IM 错误码文档： https://cloud.tencent.com/document/product/269/1671

### 腾讯 IM 事件监听注册

我们已经封装了 IM 的消息接收，能够同时处理用户消息和管理员通知

```javascript
txim.addEventListener(txim.EVENT_TYPE.NOTIFY, message => {
  console.log('收到通知消息：', message)
})
txim.addEventListener(txim.EVENT_TYPE.MSG, message => {
  console.log('收到的聊天消息：', message.text)
})
txim.addEventListener(txim.EVENT_TYPE.LOGIN, message => {
  this.$message.success('IM 登录成功')
})
txim.addEventListener(txim.EVENT_TYPE.RECONNECT, message => {
  this.$message.warning('IM 网络状态不好已断开，正在尝试重连')
})
txim.addEventListener(txim.EVENT_TYPE.CONNECTRET, message => {
  this.$message.success('IM 已连接')
})
txim.addEventListener(txim.EVENT_TYPE.KICKOFF, message => {
  this.$notify.error({
    title: 'IM 被踢出',
    message:
      'IM 已经离线，当前无法收到用户发来的消息，请确保账户没有被重复登录之后，刷新页面重新连接。',
    duration: 0
  })
})
```

### 腾讯 IM 自定义消息格式示例

普通文本消息

```json
{
  "access_name": "联想服务公众号",
  "chat_type": "Chat",
  "client_type": "wechat",
  "emotion": "3.2",
  "engineer_code": "A03962",
  "lenovo_id": "10006337124",
  "media_url": "",
  "message_type": "Text",
  "open_id": "ohP4Z6AwCXET1Vj1qhpRi4WOKOFY",
  "send_time": "2018-10-25 15:39:06",
  "send_type": 100,
  "session_id": "7EF3A60C-Bq",
  "text": "http://10.120.24.200/yuandonghua/Cube/tree/master/05_开发/数据"
}
```

表情和文字混排

```json
{
  "access_name": "联想服务公众号",
  "chat_type": "Chat",
  "client_type": "wechat",
  "emotion": "3.1",
  "engineer_code": "A03962",
  "lenovo_id": "10006337124",
  "media_url": "",
  "message_type": "Text",
  "open_id": "ohP4Z6AwCXET1Vj1qhpRi4WOKOFY",
  "send_time": "2018-10-25 15:42:08",
  "send_type": 100,
  "session_id": "7EF3A60C-Bq",
  "text": "/:X-)表情和文字/::(/::("
}
```

图片

```json
{
  "access_name": "联想服务公众号",
  "chat_type": "Chat",
  "client_type": "wechat",
  "emotion": 0,
  "engineer_code": "A03962",
  "lenovo_id": "10006337124",
  "media_url": "http://resource.lenovo.com.cn/wx/M00/2E/55/CmCtrFvRdG6AeWAdAAG7QQg0PzA891.jpg",
  "message_type": "Image",
  "open_id": "ohP4Z6AwCXET1Vj1qhpRi4WOKOFY",
  "send_time": "2018-10-25 15:44:46",
  "send_type": 100,
  "session_id": "7EF3A60C-Bq",
  "text": ""
}
```

语音

```json
{}
```

视频文件

```json
{
  "access_name": "联想服务公众号",
  "chat_type": "Chat",
  "client_type": "wechat",
  "emotion": 0,
  "engineer_code": "A03962",
  "lenovo_id": "10006337124",
  "media_url": "http://resource.lenovo.com.cn/wx/M00/2E/56/CmCtrFvRdOCAcq37ABVvj7FPEbU497.mp4",
  "message_type": "Video",
  "open_id": "ohP4Z6AwCXET1Vj1qhpRi4WOKOFY",
  "send_time": "2018-10-25 15:46:41",
  "send_type": 100,
  "session_id": "7EF3A60C-Bq",
  "text": ""
}
```

其中，send_type 是区分用户与客服，机器人与用户的标识，100=用户发送，200=客服发送，300=机器人回复，400=用户给机器人。

### 通知类消息

服务端关闭会话，超时处理，IM 会收到通知消息。

```json
{
  "chat_type": "Notification",
  "engineer_code": "A06618",
  "message_type": "Timeout",
  "send_time": "2018-11-16 18:44:03",
  "send_type": 500,
  "text": "超时会话已关闭，需要刷新会话列表"
}
```

## 用户会话（Session）说明

### 结构

- 会话基本属性：id, open_id, lenovo_id
- 消息记录相关：caseList, messages, draft
- 机器人相关：robots, robotSearch
- 会话状态：userActive, isVirtual
- 用户信息：userInfo, details

  - userInfo 下重复了 details

## API v-loading

```vue
<template>
  <container v-loading="loading('knowledgeSearch')">
    ...
  </container>
</template>
```

```javascript
export default {
  computed: {
    ...mapGetters('api', ['loading'])
  }
}
```

## 易迅返回值说明

```
VirualQueue // 队列名
```
