<template>
  <li class="voice-item"
      v-if="showVoicePlaceholder"
      :class="{active: sessionActive}"
      @click="switchClick">

    <template v-if="consultSession.active">
      <div class="content flex-between flex-wrp">
        <i>{{displayInternalName}} {{consultSession.otherDn}}</i>
        <i class="el-icon-phone-outlin"></i>
      </div>
      <div class="msg flex-between flex-wrp">
        <i>{{displayCallState}}</i>
      </div>
    </template>
    <template v-else>
      <div class="content flex-between flex-wrp">
        <i>{{displayWaiting}}</i>
        <i class="el-icon-phone-outlin"></i>
      </div>
      <div class="msg flex-between flex-wrp">
        <i>{{displayMainState}}</i>
      </div>
    </template>

  </li>
</template>

<script type="text/ecmascript-6">
  import { mapActions, mapGetters, mapMutations } from 'vuex'
  import { ClientType } from '@/store/modules/call-center/enum'
  import { AgentState, MessageType, CallType, MessageName, ThirdPartyRole } from '@call/voice/enum'
  import ws from '@/api/call-center/softphone-ws'
  import { isMankindOperation, isMobile, removePhonePrefix } from '@/store/modules/call-center/voice/util'
  import { afterCallWork } from '@/api/call-center/softphone'

  const agentNameMap = {
    [AgentState.Ready]: '就绪',
    [AgentState.NotReady]: '未就绪',
    [AgentState.AfterCallWork]: '案面',
    [AgentState.AuxWork]: '小休'
  }

  const callStateMessageMap = {
    [MessageName.EventRinging]: '振铃中',
    [MessageName.EventEstablished]: '通话中'
  }

  /**
   * 这里不关联vuex store 的正式session
   * 仅用于当出现chat session 时，提供可以返回电话台的入口
   */
  export default {
    data() {
      return {
        sessionActive: true
      }
    },
    computed: {
      ...mapGetters('call', [
        'currentSessionID',
        'hasVoicePermission',
        'sessions'
      ]),
      ...mapGetters('call', [
        'agentStateExt',
        // 会议&多方通话&转接前协商，使用的临时session
        'consultSession'
      ]),
      showVoicePlaceholder() {
        if (this.consultSession.active) {
          return true
        }

        const hasVoiceSession = Object.values(this.sessions).some(s => s.client_type === ClientType.Telephone)
        return this.hasVoicePermission && !hasVoiceSession
      },
      displayInternalName() {
        return !isMobile(this.consultSession.otherDn) ? '[内部]' : ''
      },
      displayMainState() {
        return agentNameMap[this.agentStateExt] || ''
      },
      displayWaiting() {
        return this.agentStateExt !== AgentState.Offline ? '等待接入中…' : '已离线'
      },
      displayCallState() {
        return callStateMessageMap[this.consultSession.currentCallState]
      }
    },
    watch: {
      currentSessionID(sessionId) {
        this.sessionActive = !sessionId
      }
    },
    methods: {
      ...mapActions('call', [
        'switchSession'
      ]),
      ...mapMutations('call', {
        updateConsultSession: 'UPDATE_CONSULT_SESSION'
      }),
      switchClick() {
        // 让currentSessionId = null，仍然复用以前的defaultSession 概念
        !this.sessionActive && this.switchSession({ id: null })
      },
      // 专门处理通话场景里的Consult 类型事件，期望能够在这里独立处理
      // 此类型事件用户无感知，仅在工程师之间有明显的提示
      // todo 可以作为独立的handle 将其挪到store message handle 里一起处理，作为一个子任务，但得借助vuex store 比较麻烦
      messageEventHandle(message) {
        const {
          call: { callType, connId, transferConnId },
          messageName,
          otherDn,
          thirdPartyRole
        } = message.data

        // 如果是自动流程产生的事件消息，跳过
        if (!isMankindOperation(message)) {
          return
        }

        // 多方或者接受转接，结束 这里的结束callType !== consult
        // const names = [MessageName.EventPartyChanged, MessageName.EventPartyAdded, MessageName.EventPartyDeleted]
        const endRoles = [ThirdPartyRole.TransferredBy, ThirdPartyRole.ConferencedBy]
        if (messageName === MessageName.EventPartyChanged && endRoles.includes(thirdPartyRole)) {
          this.updateConsultSession({
            active: false
          })
        }

        // 接下来的处理都需要依赖CallType.Consult
        if (callType !== CallType.Consult) {
          return
        }

        const acceptNames = [
          MessageName.EventRinging,
          MessageName.EventDialing
        ]
        // 开始内部通话
        if (acceptNames.includes(messageName) && !this.consultSession.active) {
          // 如果当前正在进行着内部通话，则挂断并给工程师提示
          this.updateConsultSession({
            active: true,
            connId,
            transferConnId,
            otherDn: removePhonePrefix(otherDn),
            currentCallState: messageName
          })
        }

        // 结束
        if ([MessageName.EventReleased, MessageName.EventAbandoned].includes(messageName)) {
          this.updateConsultSession({
            active: !this.consultSession.connId === connId
          })

          // 如果在转接过程中被用户挂断了，此刻将工程师置为案面
          const operation = this.$get(message, 'data.call.userData.ecloud_consult_operation')
          const operationNames = ['conference', 'transfer']
          if (operationNames.includes(operation)) {
            afterCallWork()
          }
        }
        // 被废弃的转接给工程师提示一下
        if (messageName === MessageName.EventAbandoned) {
          this.$message.info('该通话已被系统废弃，魔方已将其移除')
        }

        // 当前只能保障一个内部通话
        if (connId === this.consultSession.connId) {
          this.updateConsultSession({
            currentCallState: messageName
          })
        }
      }
    },
    mounted() {
      ws.addEventListener(MessageType.CallStateChange, this.messageEventHandle)
    },
    beforeDestroy() {
      ws.removeEventListener(MessageType.CallStateChange, this.messageEventHandle)
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .voice-item {
    width: 100%;
    height: 90px;
    padding: 15px;
    overflow: hidden;
    cursor: pointer;
    background-color: $lightWhite;
    transition: background-color 200ms;
    border-bottom: 1px solid $borderColor;

    &:hover {
      background-color: #E2E4E6;
    }

    &.active {
      background-color: $session-active-bg;

      &:hover {
        background-color: darken($session-active-bg, 5%)
      }
    }

    &.overtime {
      background-color: $bg-danger;
      color: darken($color-danger, 10%);

      &:hover {
        background-color: darken($bg-danger, 5%);
      }
    }

    i {
      font-style: normal;
      flex: 0 1 auto;
    }

    .content {
      display: flex;
      margin-bottom: 10px;
      line-height: 22px;

      i {
        font-size: 16px;
        font-weight: 400;

        b {
          color: $blackblue;
        }
      }

      i.el-icon-phone-outlin {
        font-size: 20px;
        margin-top: 4px;
        width: 20px;
        height: 20px;
        background: url(~@/assets/phone.png) no-repeat;
        :before {
          content: ''
        }
      }
    }

    .msg i {
      font-size: 12px;
      color: $ldark;
    }

  }
</style>
