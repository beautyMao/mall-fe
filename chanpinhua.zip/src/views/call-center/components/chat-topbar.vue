<template>
  <div class="chat-header">
    <el-row class="user">
      <el-popover
        placement="bottom-start"
        :title="currentSession.user_name"
        trigger="hover"
        :content="queueName"
      >
        <el-col slot="reference" class="user-source" :span="24">{{ queueName }}</el-col>
      </el-popover>
    </el-row>

    <el-popover
      v-if="permissionEmotion"
      placement="bottom"
      width="450"
      trigger="click"
    >
      <chat-emotion :user-name="userName" :user-msgs="userMsgs" />
      <span
        slot="reference"
        class="face"
        :class="[emotionClass, emotionUnactiveClass, emotionHideClass]"
        @click="initEmotionData"
      >
        <svg-icon :icon-class="emotionClass" />
        {{ emotion }}
      </span>
    </el-popover>

    <el-popover
      v-show="!currentSession.isVirtual"
      placement="right"
      width="320"
      trigger="click"
    >
      <div class="transfer-wrap">
        <transfer />
      </div>
      <span slot="reference" class="transfer">
        转接
        <i class="el-icon-caret-bottom" />
      </span>
    </el-popover>

    <a class="finish-conversation" @click="endSession">结束会话</a>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapActions, mapGetters } from 'vuex'
  import ChatEmotion from './chat-emotion'
  import Transfer from './transfer'
  import { MESSAGE_TYPE } from '@/store/modules/call-center/msg-util'
  import { CUBE } from '@/configuration'

  export default {
    components: {
      ChatEmotion,
      Transfer
    },
    data() {
      return {
        // saas 智能情绪分析权限
        permissionEmotion: CUBE.permission.wisdom.emotion,
        // for emotion chart component
        userName: '',
        userMsgs: []
      }
    },
    computed: {
      ...mapGetters('call', ['currentSession', 'currentSessionID']),
      queueName() {
        if (this.currentSession.last_queue_name) {
          return `从 ${this.currentSession.last_queue_name} 进入 ${this.currentSession.current_queue_name}`
        } else {
          return `从 ${this.currentSession.current_queue_name || '未知队列'} 进入`
        }
      },
      emotion() {
        const userMsgs = this.currentSession.messages.filter(message => {
          return message.hasOwnProperty('isEngineer') &&
            !message.isEngineer &&
            message.sessionId === this.currentSessionID &&
            (message.type === MESSAGE_TYPE.Text || message.type === MESSAGE_TYPE.Voice)
        })
        if (userMsgs.length) {
          const lastMsg = userMsgs[userMsgs.length - 1]
          return lastMsg.emotion
        } else {
          // 用户没有发送任何消息时，默认给5
          return 5
        }
      },
      emotionUnactiveClass() {
        if (!this.currentSession.userActive) {
          return 'unactive'
        }
        return ''
      },
      emotionHideClass() {
        if (!this.currentSession.messages.length) {
          return 'emotion-hide'
        }

        const chatMessages = this.currentSession.messages.filter(m => m.hasOwnProperty('isEngineer') && m.sessionId === this.currentSessionID)
        const userMsgs = chatMessages.filter(m => !m.isEngineer && (m.type === MESSAGE_TYPE.Text || m.type === MESSAGE_TYPE.Voice))
        if (!userMsgs.length) {
          return 'emotion-hide'
        }
        return ''
      },
      emotionClass() {
        // 惊喜：大于4分，小于等于5分；
        // 愉悦：大于3分，小于等于4分；
        // 正常：大于2分，小于等于3分；
        // 不满：大于1分，小于等于2分；
        // 愤怒：大于等于0分，小于等于1分；
        // faceDissatisfied
        // faceGray
        // faceHappy
        // faceNormal
        // faceSurprise
        if (this.emotion > 4) {
          return 'faceSurprise'
        } else if (this.emotion > 3 && this.emotion <= 4) {
          return 'faceHappy'
        } else if (this.emotion > 2 && this.emotion <= 3) {
          return 'faceNormal'
        } else if (this.emotion > 1 && this.emotion <= 2) {
          return 'faceDissatisfied'
        } else {
          return 'faceAngry'
        }
      }
    },
    methods: {
      ...mapActions('call', [
        'closeSession',
        'refreshSessions'
      ]),
      endSession() {
        const userName = this.currentSession.user_name
        this.$confirm(`即将关闭与【${userName}】的对话，请确认。`, '注意', {
          confirmButtonText: '确定关闭',
          cancelButtonText: '取消',
          type: 'error'
        }).then(() => {
          this.closeSession({ session: this.currentSession }).then(() => {
            this.$message.success(`会话【${userName}】关闭成功`)
          }).finally(() => {
            this.refreshSessions()
          })
        }).catch(() => {})
      },
      initEmotionData() {
        this.userName = this.currentSession.user_name
        // 只有文本和语音包含了情绪值
        this.userMsgs = this._userMsgs()
      },
      _userMsgs() {
        return this.currentSession.messages.filter(message => {
          return message.hasOwnProperty('isEngineer') &&
            !message.isEngineer &&
            message.sessionId === this.currentSessionID &&
            (message.type === MESSAGE_TYPE.Text || message.type === MESSAGE_TYPE.Voice)
        })
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .chat-header {
    min-width: 426px;
    font-size: 14px;
    height: 40px;
    line-height: 40px;
    border-bottom: 1px solid $borderColor;
    background-color: white;
    padding-left: 20px;
    padding-right: 20px;
    color: $ldark;
    display: flex;

    .face {
      width: 80px;
      color: #6ABF4A;
      font-size: 16px;
      display: inline-block;
      cursor: pointer;

      .svg-icon {
        margin-right: 10px;
      }

      /*with emotion class*/
      &.emotion-hide {
        display: none;
      }

      &.unactive {
        color: $lldark !important;
      }

      &.faceUnactive {
        color: $lldark;
      }

      &.faceHappy, &.faceSurprise {
        color: $dark;
      }

      &.faceDissatisfied, &.faceNormal {
        color: orange;
      }

      &.faceAngry {
        color: $color-danger;
      }
    }

    .user {
      min-width: 200px;
      flex: 1;
      cursor: pointer;

      .user-name {
        font-size: 18px;
        min-width: 60px;
        max-width: 120px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        color: $dark;
      }

      .user-source {
        color: #606266;
        min-width: 60px;
        /*max-width: 120px;*/
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
    }

    .transfer {
      width: 70px;
      font-size: 16px;
      outline: none;
      cursor: pointer;
      display: inline-block;

      .through {
        font-size: 30px;
        float: left;
        margin: 15px 5px 0 0;
      }

      .arr-icon {
        font-size: 10px;
        float: left;
        margin: 26px 0 0;
      }

      &:hover {
        color: #1989FA;
      }
    }

    .finish-conversation {
      margin-right: -20px;
      cursor: pointer;
      width: 80px;
      font-size: 14px;
      font-weight: bold;
      color: $warnColor;
      text-align: center;
      background-color: $bg-warning;
      outline: none;
      display: inline-block;

      &:hover {
        color: lighten($warnColor, 10%);
      }
    }

    .search {
      text-align: right;
      z-index: 100;
    }
  }
</style>
