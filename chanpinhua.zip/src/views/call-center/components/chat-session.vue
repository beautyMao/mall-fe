<template>
  <li
    ref="contextMenuTarget"
    class="user-item"
    :class="[userEmotion, isSessionActive ? 'active': '', isUserUnactive ? 'zombie': '', isOvertime ? 'overtime' : '']"
    @click="switchClick(session)"
  >
    <div class="user-wrap">
      <div class="head-img-wrap">
        <img :src="session.user_avatar" :style="{backgroundColor: session.user_color}" class="head-img">
        <span v-if="unread > 0" class="unread-num">{{ unread }}</span>
      </div>
      <div class="user-info">
        <a :title="session.user_name" class="user-name">{{ session.user_name }}</a>

        <span v-if="!isSessionActive && session.draft !== ''" class="chat-draft">[草稿]</span>
        <!--<span class="chat-draft" v-if="engineerUnreply === '' && isUserUnactive && !willCloseTag">[用户未响应]</span>-->
        <span v-if="!IMReady" class="chat-draft">[IM未登录，不能交互]</span>
        <span v-if="session.isVirtual" class="chat-draft">[客户已关闭会话]</span>

        <!--<span v-if="session.userType === 'wechat'" class="chat-user-type">-->
        <!--<i class="fa fa-weixin" aria-hidden="true" title="来自联想服务公众号"></i>-->
        <!--</span>-->

        <svg-icon :icon-class="iconType" class="user-icon-svg" />
      </div>
    </div>
    <div class="user-msg">
      <span class="user-msg-last" v-html="lastMsg.content" />
      <el-popover
        v-if="!isProd"
        width="650"
        placement="right"
        trigger="hover"
      >
        <ul>
          <li>isUserTalked: {{ isUserTalked }}</li>
          <li>sessionActive: {{ sessionActive }}</li>
          <li>lastUserActive: {{ lastUserActive }}</li>
          <li>lastEngineerActive: {{ lastEngineerActive }}</li>
          <li>lastMsg: isAuto={{ lastMsg.isAuto }}, isEngineer={{ lastMsg.isEngineer }}</li>
          <li>=========</li>
          <li><b>OvertimeSetting 超时配置：</b></li>
          <li v-for="config in overtimeSetting.unReplyConfig.list">
            <div class="pl20">overtime: {{config.overtime}} | closeSession: {{config.closeSession}}</div>
            <div class="pl20 border-b">pushTalk: {{config.pushTalk}}</div>
          </li>
          <li><b>OvertimeSetting 空框配置：</b></li>
          <li v-for="config in overtimeSetting.unActiveConfig.list">
            <div class="pl20">overtime: {{config.overtime}} | closeSession: {{config.closeSession}}</div>
            <div class="pl20 border-b">pushTalk: {{config.pushTalk}}</div>
          </li>
        </ul>
        <span slot="reference" class="chat-time">{{ sessionActive|time }}</span>
      </el-popover>
      <span v-else class="chat-time">{{ sessionActive|time }}</span>
    </div>

    <context-menu
      :target="contextMenuTarget"
      :show="contextMenuVisible"
      @update:show="show => contextMenuVisible = show"
    >
      <a v-if="session.isMock" @click="remove">移除模拟会话</a>
      <a v-if="session.isVirtual" @click="remove">移除案面会话</a>
      <a v-else @click="close">关闭会话</a>
      <a @click="refresh">刷新会话列表</a>
      <a @click="errorReport">反馈该会话的问题</a>
    </context-menu>
  </li>
</template>

<script type="text/babel">
  import { mapActions, mapGetters, mapMutations } from 'vuex'
  import config from '@/store/modules/call-center/config'
  import { MESSAGE_TYPE } from '@/store/modules/call-center/msg-util'
  import { report } from '@/utils/error-report'
  import { deepClone, isProd, sleep } from '@/utils'

  import ContextMenu from '@/components/ContextMenu'
  import { ClientType } from '@call/enum'
  import { getTimeoutReplay } from '@/api/call-center/call-center'

  // 避免初始的计时器数值错误，导致显示错误
  // todo 这里应该采用服务器时间，更加稳妥
  const getStartSec = (timeFromServer) => {
    let re = 0
    try {
      re = parseInt((Date.now() - Date.parse(timeFromServer)) / 1000)
    } catch (e) {
      console.log('chat session getStartSec error:', e)
    }

    if (re < 0 || Number.isNaN(re)) {
      re = 0
    }
    return re
  }

  // 接近某个时间点
  // const closer = function(sec) {
  //   return Math.floor(sec / 10)
  // }

  export default {
    name: 'chat-session',
    components: {
      // https://github.com/xunleif2e/vue-context-menu
      ContextMenu
    },
    // eslint-disable-next-line vue/require-prop-types
    props: ['session'],
    data() {
      return {
        sessionActive: 0,
        lastUserActive: 0,
        lastEngineerActive: 0,
        autoSessionReplay: -1, // 自动话术计时器，缺省值 -1
        unread: 0,
        lastMsg: {
          id: '',
          content: '',
          isAuto: false, // 是否由自动话术流程发送
          isEngineer: true // 默认由客服起手
        },
        isUserTalked: false, // 用户是否发送过消息
        emotion: 4,

        initialized: false,
        timers: [],
        // 每个会话（by 队列）是独立的自动话术配置
        overtimeSetting: deepClone(config.overtimeSetting),
        // 客服自动话术内容，用于辅助判断消息是否由客服主动发送
        // todo 当客服主动复制发送话术内容，将导致无法重现计时
        autoTalkContentSet: new Set(),

        contextMenuVisible: false,
        contextMenuTarget: null,
        isProd,
        isOvertime: false
      }
    },
    computed: {
      ...mapGetters('call', ['currentSessionID', 'IMReady']),
      isSessionActive() {
        return this.session.id === this.currentSessionID
      },
      isUserUnactive() {
        return this.lastUserActive >= config.overtimeSetting.unactive
      },
      // 新版，根据用户情绪来变色
      userEmotion() {
        // 根据用户当前情绪值，当小于等于3分，大于1分时，用户框置黄；
        // 当情绪值小于等于1分时，用户框置红；
        if (this.emotion > 1 && this.emotion <= 3) {
          return 'emotion-yellow'
        } else if (this.emotion <= 1) {
          return 'emotion-red'
        } else {
          return ''
        }
      },
      iconType() {
        const iconTypeMap = {
          [ClientType.Webchat]: 'html5',
          [ClientType.Wechat]: 'chat'
        }
        return iconTypeMap[this.session.client_type]
      }
    },
    watch: {
      // 由于客服send message 从pending 到 success，会修改两次message，这里会被执行两次
      // session init 从空框状态到 get current session history，这里也会初始化两次
      'session.messages': function(messages, oldMessages) {
        // route 右键刷新，也会进入这里，message = [], oldMessage = [...]
        if (oldMessages.length > messages.length) {
          return
        }

        this.$nextTick(() => {
          // 只有双方的对话信息，才会包含isEngineer 属性
          const chatMessages = messages.filter(m => m.hasOwnProperty('isEngineer') && m.sessionId === this.session.id)
          const userMsgs = chatMessages.filter(m => !m.isEngineer)
          const lastMessage = chatMessages.length > 0 ? chatMessages[chatMessages.length - 1] : null
          // const setting = config.overtimeSetting

          // session 组件mounted 之后的状态预处理
          if (!this.initialized) {
            const engineerMsgs = chatMessages.filter(m => m.isEngineer)
            // 如果刷新页面后，发现会话里仍然没有消息，将采用session start talk time
            const startWithSec = getStartSec(this.session.start_talking_at)

            if (engineerMsgs.length) {
              this.lastEngineerActive = getStartSec(engineerMsgs[engineerMsgs.length - 1].sendTime)
            } else {
              this.lastEngineerActive = startWithSec
            }
            if (userMsgs.length) {
              this.lastUserActive = getStartSec(userMsgs[userMsgs.length - 1].sendTime)
            } else {
              this.lastUserActive = startWithSec
            }

            // 刷新页面后，也将以最后一条客服回复时间，作为自动话术流程的起始时间
            // if (lastMessage && lastMessage.isEngineer) {
            //   // 如果此刻已经超出了第一次自动话术的发送时间，那么就先给定一个值？
            //   if (this.lastEngineerActive > setting.unActivePushSpeech1) {
            //     this.autoSessionReplay = setting.unActivePushSpeech1 - 60
            //   } else {
            //     this.autoSessionReplay = this.lastEngineerActive
            //   }
            // }

            // 如果是一个空框状态，自动话术流程启动
            // if (!chatMessages.length) {
            //   this.autoSessionReplay = 0
            // }
          } else if (lastMessage && !lastMessage.isEngineer) {
            // 处理未读消息计数 仅在非初始化状态下计算，初始加载的本次会话历史记录里的用户信息，不应该参与计算
            if (this.session.id !== this.currentSessionID && lastMessage.id !== this.lastMsg.id) {
              this.unread += 1
            }
          }

          // 用户和客服活跃计数器
          // 客服发送的自动话术，不会重置lastEngineerActive
          // 初始化过程已经有一次根据history message 设置的时间，在这里避免重复设置
          if (this.initialized && lastMessage) {
            if (lastMessage.isEngineer && !this.autoTalkContentSet.has(lastMessage.content)) {
              this.lastEngineerActive = 0
            } else if (!lastMessage.isEngineer) {
              this.lastUserActive = 0
            }
          }

          if (!this.initialized) {
            this.initialized = true
          }

          // 接下来的处理动作，都需要message 里有内容
          if (!lastMessage) {
            return
          }

          // 处理会话框显示最后一条聊天内容
          const reMap = {
            [MESSAGE_TYPE.Text]: lastMessage.safeContent,
            [MESSAGE_TYPE.Image]: '[图片]',
            [MESSAGE_TYPE.Video]: '[视频]',
            [MESSAGE_TYPE.Voice]: '[语音]' + lastMessage.text
          }
          this.lastMsg.content = reMap[lastMessage.type]
          this.lastMsg.isEngineer = lastMessage.isEngineer
          this.lastMsg.id = lastMessage.id
          // 防止用户发送相同内容扰乱计时
          this.lastMsg.isAuto = lastMessage.isEngineer ? this.autoTalkContentSet.has(lastMessage.content) : false

          // 用户的最后一条消息
          if (userMsgs.length) {
            this.isUserTalked = true
            // 情绪值处理，只有文字和语音有emotion
            const userMsgsWithEmotion = userMsgs.filter(msg => msg.type !== MESSAGE_TYPE.Image)
            if (userMsgsWithEmotion.length) {
              this.emotion = userMsgsWithEmotion[userMsgsWithEmotion.length - 1].emotion
            }
          }
        })
      },
      'session.isVirtual': function(isVirtual) {
        if (isVirtual) {
          this.timers.forEach(clearInterval)
          this.timers = []
        }
      },
      'currentSessionID': function() {
        this.$nextTick(() => {
          if (this.session.id === this.currentSessionID) {
            this.unread = 0
          }
        })
      },
      'IMReady': function(isReady) {
        if (!isReady) {
          // 监听IM kickoff 状态，如果出现了踢出动作，停止所有的定时器
          this.timers.forEach(clearInterval)
          this.timers = []
        }
      },
      // 用户发送会话后，大于等于3分钟，客服未回复用户，给客服提醒
      lastUserActive(userActiveDuration) {
        if (userActiveDuration >= 180 && !this.lastMsg.isEngineer || (this.lastEngineerActive - this.lastUserActive) >= 180) {
          this.isOvertime = true
        } else {
          this.isOvertime = false
        }
      }
    },
    beforeDestroy() {
      this.timers.forEach(clearInterval)
      this.timers = []
    },
    mounted() {
      // 使用的是用户开始对话的时间，并非排队时间：created_at
      let startWithSec = 0
      // 收到推送消息主动创建的会话，从0 开始计时
      if (!this.session.isNewSession && this.session.start_talking_at) {
        startWithSec = getStartSec(this.session.start_talking_at)
      }
      this.start(startWithSec)

      // 初始化右键菜单
      this.contextMenuTarget = this.$refs.contextMenuTarget

      this.initEngineerAutoTalk()
    },
    methods: {
      ...mapActions('call', [
        'closeSession',
        'removeSession',
        'sendMessage',
        'switchSession',
        'refreshSessions',
        'tryFixUserAccount'
      ]),
      ...mapMutations('call', ['UPDATE_USER_ACTIVE']),
      switchClick(session) {
        if (this.currentSessionID === session.id) {
          return
        }
        this.switchSession(session)
      },
      start(sec = 0) {
        this.sessionActive = sec
        // session 计时器独立出来运行
        this.timers.push(setInterval(() => {
          this.sessionActive += 1
        }, 1000))
        this.timers.push(setInterval(this.autoLoopReply, 1000))
      },
      // 新版循环的自动话术和关闭流程
      // 在正常会话中，将以客服的最后主动话术的发送时间开始计时，执行自动话术推送流程（自动话术不会影响计时）
      // 在空框用户中，和旧版逻辑一致
      autoLoopReply() {
        this.lastUserActive += 1
        this.lastEngineerActive += 1

        const session = this.session

        // 如果最后一条消息是用户发送的，不做下列动作
        if (!this.lastMsg.isEngineer) {
          return
        }

        // 接下来，自动话术计时，都是从最后一条客服信息发送时间开始算起
        const setting = this.overtimeSetting

        // 用户不活跃状态处理
        if (this.session.userActive && this.sessionActive >= setting.unactive) {
          this.UPDATE_USER_ACTIVE({
            sessionId: this.session.id,
            isActive: false
          })
        }

        let speech
        // 非空框情况下，以客服的最后一句主动消息开始计时
        if (this.isUserTalked) {
          speech = setting.unReplyConfig.list.find(config => config.overtime === this.lastEngineerActive)
        }

        // 空框情况下，直接使用session 初始化时间开始计时
        if (!this.isUserTalked) {
          speech = setting.unActiveConfig.list.find(config => config.overtime === this.sessionActive)
        }

        let sendPromise = null
        if (speech && this.IMReady) {
          // 关闭会话配置现在没有push talk
          if (speech.pushTalk) {
            sendPromise = this.sendMessage({
              text: speech.pushTalk, session
            }).catch(error => {
              this.$report(error, {
                msg: '自动话术发送失败',
                session
              })
            })
          } else {
            sendPromise = Promise.resolve('ok')
          }
        }

        // todo 如果在关闭倒计时来临前，刷新了页面，会导致该动作不执行
        if (sendPromise && speech.closeSession) {
          sendPromise.then(() => {
            // 发送消息执行完成之后，延迟3s
            // 因为TX通路和魔方关闭是两个异步流程，如果先完成了关闭会导致用户收不到消息
            return sleep(3000)
          }).then(() => {
            const userName = this.session.user_name
            this.closeSession({ session, isAuto: 'auto' }).then(() => {
              this.$message.success(`会话【${userName}】未回复任何消息，被自动关闭`)
            }).finally(() => {
              this.refreshSessions()
            }).catch(() => {
              this.$message.warning(`会话【${userName}】自动关闭失败，已被保留`)
            })
          })
        }
      },
      close() {
        this.contextMenuVisible = false

        this.$confirm(`即将关闭与【${this.session.user_name}】的对话，请确认。`, '注意', {
          confirmButtonText: '确定关闭',
          cancelButtonText: '取消',
          type: 'error'
        }).then(() => {
          this.closeSession({ session: this.session }).then(() => {
            this.$message.success(`会话【${this.session.user_name}】关闭成功`)
          }).finally(() => {
            this.refreshSessions()
          })
        }).catch((reject) => {
        })
      },
      remove(e) {
        this.contextMenuVisible = false
        this.removeSession(this.session)
        // 点穿菜单后导致switchSession action 被执行了
        e.stopPropagation()
      },
      refresh() {
        this.contextMenuVisible = false
        this.refreshSessions().then(doneContexts => {
          this.$message.success('会话列表刷新成功')
        }).catch(error => {
          this.$report(error, {
            msg: '会话列表刷新失败'
          })
          this.$message.error('会话列表刷新失败' + error)
        })
      },
      tryFix() {
        this.contextMenuVisible = false
        this.tryFixUserAccount({ session: this.session }).then((data) => {
          this.$message('修复会话成功，请重新发送失败的消息')
        }).catch(error => {
          this.$message.error('修复会话失败' + error.message)
        })
      },
      errorReport() {
        this.$prompt('请简述遇到的问题', '会话问题反馈', {
          confirmButtonText: '提交反馈',
          cancelButtonText: '取消'
        }).then(({ value }) => {
          const {
            sessionActive,
            lastUserActive,
            lastEngineerActive,
            autoSessionReplay,
            unread,
            lastMsg,
            isUserTalked,
            emotion,
            timers
          } = this._data

          report({
            feedback: value || '无反馈内容',
            messages: this.session.messages,
            session: this.session,
            currentSessionID: this.currentSessionID,
            componentData: {
              sessionActive,
              lastUserActive,
              lastEngineerActive,
              autoSessionReplay,
              unread,
              lastMsg,
              isUserTalked,
              emotion,
              timers
            },
            componentComputed: Object.keys(this._computedWatchers).map(key => {
              return {
                key, value: this._computedWatchers[key].value
              }
            })
          }, 'call-center:session')

          this.$message.success('已反馈，感谢您帮助魔方成长')
        }).catch(() => {
        })
      },
      initAutoTalkContent() {
        this.autoTalkContentSet.clear()
        this.overtimeSetting.unActiveConfig.list.forEach((content) => {
          this.autoTalkContentSet.add(content.pushTalk)
        })
        this.overtimeSetting.unReplyConfig.list.forEach((content) => {
          this.autoTalkContentSet.add(content.pushTalk)
        })
      },
      // 根据当前用户队列，初始化自动话术配置
      initEngineerAutoTalk() {
        this.initAutoTalkContent()
        if (this.session.current_queue_code) {
          getTimeoutReplay(this.session.current_queue_code).then((response) => {
            if (!response.data) {
              return
            }

            const unReplayList = this.overtimeSetting.unReplyConfig.list
            unReplayList[0].overtime = this.$get(response, 'data.timeoutSpeech.timeout_time_first', unReplayList[0].overtime / 60) * 60
            unReplayList[0].pushTalk = this.$get(response, 'data.timeoutSpeech.timeout_content_first', unReplayList[0].pushTalk)
            unReplayList[1].overtime = this.$get(response, 'data.timeoutSpeech.timeout_time_second', unReplayList[1].overtime / 60) * 60
            unReplayList[1].pushTalk = this.$get(response, 'data.timeoutSpeech.timeout_content_second', unReplayList[1].pushTalk)

            const unActiveList = this.overtimeSetting.unActiveConfig.list
            unActiveList[0].overtime = this.$get(response, 'data.silentSpeech.silent_time_first', unActiveList[0].overtime / 60) * 60
            unActiveList[0].pushTalk = this.$get(response, 'data.silentSpeech.silent_content_first', unActiveList[0].pushTalk)
            unActiveList[1].overtime = this.$get(response, 'data.silentSpeech.silent_time_second', unActiveList[1].overtime / 60) * 60
            unActiveList[1].pushTalk = this.$get(response, 'data.silentSpeech.silent_content_second', unActiveList[1].pushTalk)

            // 目前RD 的结构没有支持三条超时配置，使用默认配置的空框第二次内容
            unReplayList[2].overtime = this.$get(response, 'data.timeoutSpeech.timeout_time_all', unReplayList[2].overtime / 60) * 60
            unActiveList[2].overtime = this.$get(response, 'data.silentSpeech.silent_time_all', unActiveList[2].overtime / 60) * 60
          }).finally(() => {
            this.initAutoTalkContent()
          })
        }
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .user-item {
    width: 100%;
    height: 90px;
    padding-top: 10px;
    padding-bottom: 10px;
    padding-left: 15px;
    overflow: hidden;
    cursor: pointer;
    background-color: $lightWhite;
    transition: background-color 200ms;
    border-bottom: 1px solid $borderColor;

    &:hover {
      background-color: #E2E4E6;
    }

    &.unreply-yellow, &.emotion-yellow {
      background-color: $bg-warning;

      .user-name {
        color: darken($color-warning, 10%) !important;
      }

      &:hover {
        background-color: darken($bg-warning, 5%)
      }
    }

    &.unreply-red, &.emotion-red {
      background-color: $bg-danger;

      .user-name {
        color: darken($color-danger, 10%) !important;
      }

      &:hover {
        background-color: darken($bg-danger, 5%)
      }
    }

    &.zombie {
      opacity: 0.5;
      background-color: $lightWhite;

      &:hover {
        background-color: darken($lightWhite, 5%)
      }
    }

    &.zombie.active {
      opacity: 0.7;
      background-color: $session-active-bg;
    }

    &.active {
      background-color: $session-active-bg;

      .user-name, .chat-time, .user-msg-last {
        color: $ldark;
      }

      &:hover {
        background-color: darken($session-active-bg, 5%)
      }
    }

    .user-wrap {
      height: 42px;
      display: flex;
      align-items: center;
    }

    .head-img-wrap {
      width: 42px;
      height: 42px;
      margin-right: 18px;
      position: relative;

      &.source-weibo:after {
        border-top: 12px solid #e43930;
        border-left: 12px solid #e43930;
      }

      &.source-qq:after {
        border-top: 12px solid #5394f5;
        border-left: 12px solid #5394f5;
      }

      &.source-wechat:after {
        border-top: 12px solid #5ca80b;
        border-left: 12px solid #5ca80b;
      }

      &.source-at:after {
        border-top: 12px solid #2b61a3;
        border-left: 12px solid #2b61a3;
      }

      .head-img {
        width: 100%;
        height: 100%;
        border-radius: 3px;
      }

      .unread-num {
        height: 16px;
        padding-left: 5px;
        padding-right: 5px;
        display: inline-block;
        background-color: $warnColor;
        border-radius: 5px;
        font-size: 12px;
        line-height: 16px;
        color: #fff;
        text-align: center;
        vertical-align: middle;

        position: absolute;
        top: -5px;
        right: -10px;
      }

    }

    .user-info {
      flex: 1;
      position: relative;
      height: 42px;

      .user-name {
        width: 180px;
        font-size: 14px;
        margin-top: 6px;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        margin-bottom: 6px;
        color: $dark;
        display: block;
      }

      .chat-draft {
        font-size: 14px;
        color: darken($color-danger, 10%);
        display: block;
      }

      .user-icon-svg {
        width: 20px;
        font-size: 30px;
        color: #606266;
        text-align: center;
        text-shadow: 1px 1px 1px $dark;

        position: absolute;
        right: 10px;
        top: 12px;
      }
    }

    .user-msg {
      font-size: 12px;
      color: #8F8F8F;
      line-height: 38px;
      align-items: center;
      display: flow-root;

      .user-msg-last {
        text-overflow: ellipsis;
        overflow: hidden;
        white-space: nowrap;
        float: left;
        width: 180px;
      }

      .chat-time {
        padding-right: 10px;
        width: 75px;
        text-align: right;
        float: right;
      }

      /deep/ .emoji-icon {
        width: 22px;
        vertical-align: middle;
        margin-top: -2px;
        margin-right: 2px;
      }
    }

    .chat-user-type {
      i {
        margin-top: 16px;
        font-size: 18px;
        margin-left: -5px;

        &.fa-android {
          font-size: 22px;
        }

        &.fa-mobile-phone {
          font-size: 28px;
          margin-top: 12px;
          margin-left: -3px;
          transform: rotate(90deg) scale(1.5, 1);
        }
      }
    }

    &.overtime {
      border: solid 3px #F37261 !important;
    }
  }

</style>
