<template>
  <div ref="chart" class="chart-container" />
</template>

<script type="text/ecmascript-6">
  // 引入 ECharts 主模块
  import echarts from 'echarts/lib/echarts'
  // import echarts from 'echarts'
  // 引入柱状图
  require('echarts/lib/chart/line')
  // 引入提示框和标题组件
  require('echarts/lib/component/tooltip')
  require('echarts/lib/component/title')

  let chart = null

  const defaultOpt = {
    title: {
      text: `用户情绪图`
    },
    tooltip: {
      trigger: 'axis',
      formatter: function(params) {
        const data = params[0].data
        return [`情绪值：${data.value[1]}`, data.value[0], data.name].join('<br>')
      },
      axisPointer: {
        animation: false
      }
    },
    xAxis: {
      type: 'time',
      splitLine: {
        show: false
      }
    },
    yAxis: {
      type: 'value',
      boundaryGap: [0, '100%'],
      max: 5
    },
    grid: {
      top: 40,
      left: '2%',
      right: '8%',
      bottom: '2%',
      containLabel: true
    },
    series: [{
      name: '情绪值',
      type: 'line',
      smooth: true,
      showSymbol: false,
      hoverAnimation: false,
      data: []
    }]
  }

  /**
   * 更新数据
   * @param userName
   * @param userMsgs {Array}
   * @return {Object}
   */
  const createOption = (userName, userMsgs) => {
    const data = userMsgs.map(message => {
      return {
        // 兼容语音内容
        name: message.text || message.content,
        // value:['2016/12/18 6:38:08', 80]
        value: [
          message.sendTime.replace(/-/g, '/'),
          parseFloat(message.emotion)
        ]
      }
    })
    return {
      title: {
        text: `用户${userName}的情绪图`
      },
      series: [{
        data: data
      }]
    }
  }

  export default {
    props: ['userName', 'userMsgs'],
    data() {
      return {}
    },
    watch: {
      'userMsgs': function() {
        if (this.userMsgs.length) {
          chart.setOption(createOption(this.userName, this.userMsgs))
        }
      }
    },
    mounted() {
      // 基于准备好的dom，初始化echarts实例
      chart = echarts.init(this.$refs.chart)
      chart.setOption(defaultOpt)
    },
    beforeDestroy() {
      if (chart) {
        chart.dispose()
        chart = null
      }
    },
    methods: {}
  }

</script>

<style lang='scss' type="text/scss" scoped>
  .chart-container {
    width: calc(450px - 24px);
    height: 300px;
  }
</style>
