<template>
  <div class="mock-button">
    <el-tooltip effect="dark" content="增加一个模拟用户" placement="top">
      <el-button type="warning" icon="el-icon-plus" circle @click="mock" />
    </el-tooltip>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapActions, mapGetters, mapMutations } from 'vuex'
  import { defaultSession } from '@/store/modules/call-center/index'
  import { getDatetime } from '@/utils'
  import {
    convertToMessage,
    convertToTXMessage, getRandomHeadColor,
    getRandomHeadImage,
    getRandomNickname,
    uuid
  } from '@/store/modules/call-center/convert'
  import { MESSAGE_TYPE } from '@/store/modules/call-center/msg-util'
  import { ClientType } from '@call/enum'

  export default {
    name: 'mock-user',
    data() {
      return {
        timer: null
      }
    },
    computed: mapGetters('call', ['sessions']),
    methods: {
      ...mapActions('call', ['initChatSession']),
      ...mapMutations('call', ['RECEIVE_SESSION', 'USER_SEND_MESSAGE']),
      mock() {
        const session = {
          ...defaultSession,
          cube_uid: 'Orz5d13308e401ff_GIZFpNQOA9k',
          client_type: ClientType.Webchat,

          isMock: true, // mock session 额外的字段标记
          id: uuid('mock-session'),
          user_name: '[模拟] ' + getRandomNickname(),
          user_avatar: getRandomHeadImage(),
          user_color: getRandomHeadColor(),
          start_talking_at: getDatetime(),
          created_at: getDatetime(),
          current_queue_code: 'QW042',
          current_queue_name: '魔方点选mock'
        }
        this.RECEIVE_SESSION(session)
        this.initChatSession({
          session,
          isNewSession: true
        })
      }
    },
    mounted() {
      this.timer = setInterval(() => {
        const ids = Object.keys(this.sessions).filter(id => id.startsWith('mock-session'))
        if (!ids.length) {
          return
        }

        const sessionId = ids[Math.floor(Math.random() * ids.length)]
        const txMsg = convertToTXMessage('这里是奇怪的话术，我是自动发出来的', MESSAGE_TYPE.Text, this.sessions[sessionId])
        const message = convertToMessage(txMsg.MessageBody, this.sessions[sessionId], false)
        this.USER_SEND_MESSAGE({
          sessionId,
          message
        })
      }, 50 * 1000)
    },
    beforeDestroy() {
      clearInterval(this.timer)
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .mock-button {
    position: absolute;
    bottom: 20px;
    left: 100px;
  }
</style>
