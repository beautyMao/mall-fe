<template>
  <div class="bg-white pd15">
    <div class="transfer-wrap">
      <el-tabs v-model="activeName" class="transfer">
        <el-tab-pane label="队列" name="first" v-if="transfer !== 2">
          <el-input clearable @keyup.enter.native="searchBig" v-model="bigQueueInp">
            <i slot="prefix" class="el-input__icon el-icon-search"></i>
          </el-input>
          <div class="crumbs">
            <div v-show="!returnQueue">
              <span @click="returnList">业务</span>
              <span v-show="listQueueVisible">> 队列</span>
            </div>
            <div v-show="returnQueue">
              <span>搜索结果</span>
              <el-button type="text" @click="returnList" class="toRight">返回队列列表</el-button>
            </div>
          </div>
          <ul class="trans-list list-height" v-show="bigBusVisbible">
            <li v-for="(item, i) in businessArr" @click="getTransQueue(item.id, i)" :class="{'selCur':  i == busIndex}"
                :key="i">
              <span class="right-arrow"><svg-icon icon-class="arrowRight" class="arrow"/></span>{{item.name}}
            </li>
          </ul>
          <ul class="trans-list list-height" v-show="bigQueueVisibile">
            <li v-for="(item, i) in transList" @click="transferPars(item, i)" :class="{'selCur': i == active}" :key="i">
              <span v-if="item.recommend"><span class="recommend">推荐队列</span><span
                class="strong">{{item.name}}</span></span>
              <span v-else>{{item.name}}</span>
            </li>
          </ul>
          <div class="to-center">
            <el-button size="medium" type="primary" :disabled='queueTrans' @click="transferQueue">转接</el-button>
          </div>
        </el-tab-pane>
        <el-tab-pane label="个人" name="second">
          <el-input clearable @keyup.enter.native="searchPersonal" v-model="personQueueInp">
            <i slot="prefix" class="el-input__icon el-icon-search"></i>
          </el-input>
          <div v-show="searchVisible">
            <div class="crumbs">
              <span @click="returnVisible">业务 </span>
              <span @click="returnQueueList" v-show="queueCrumbs">> 队列 </span>
              <span v-show="engVisible">> 工程师</span>
            </div>
            <ul class="trans-list list-height" v-show="busListVisibile">
              <li v-for="(item, i) in businessArr" @click="busQueue(item.id, i)" :class="{'selCur':  i == busIndex}"
                  :key="i">
                <span class="right-arrow"><svg-icon icon-class="arrowRight" class="arrow"/></span>{{item.name}}
              </li>
            </ul>
            <ul class="queue-list list-height" v-show="queueListVisibile">
              <li v-for="(item, i) in transListPerson" @click="personList(item.code, i)" :class="{'selCur': i == queue}"
                  :key="i">
                <span v-if="item.recommend"><span class="recommend">推荐队列</span><span
                  class="strong">{{item.name}}</span></span>
                <span v-else=""><span class="right-arrow"><svg-icon icon-class="arrowRight" class="arrow"/></span>{{item.name}}</span>
              </li>
            </ul>
            <ul class="engineer-list list-height" v-show="engListVib">
              <li v-for="(item, i) in engineerList" @click="selectEngineer(item, i)" :class="{'selCur': i == engI}"
                  :key="i">
                  {{item.name}} / {{item.code}}
                  <span v-if="item.status === 1" class="ready status">就绪</span>
                  <span v-else-if="item.status === 2" class="busy status">忙碌</span>
                  <span class="status ready" v-if="item.status === 4">在线</span>
                  <span class="status busy" v-else-if="item.status === 5">小休</span>
                  <span class="status busy" v-else-if="item.status === 6">案面</span>
                  <span class="status busy" v-else>异常</span>
                  <!-- <span v-else class="busy status">排队满</span> -->
              </li>
            </ul>
          </div>
          <div v-show="!searchVisible">
            <div class="crumbs">
              <el-button type="text" @click="returnPerson" class="toRight">返回队列列表</el-button>
              搜索结果
            </div>
            <ul class="search-englist list-height">
              <li v-for="(item, i) in searchEngList" @click="selSearchEng(item, i)" :class="{'selCur': i == queueIndex}"
                  :key="i">
                <span class="status ready" v-if="item.status === 4">在线</span>
                <span class="status busy" v-else-if="item.status === 5">小休</span>
                <span class="status busy" v-else-if="item.status === 6">案面</span>
                <span class="status busy" v-else>异常</span>
                <span class="search-name" :title="item.name">{{item.engName}} / {{item.engCode}} / {{item.name}}</span>
              </li>
            </ul>
          </div>
          <div class="to-center">
            <el-button size="medium" type="primary" :disabled="personTrans" @click="transferPersonal">转接</el-button>
          </div>
        </el-tab-pane>
      </el-tabs>
    </div>
  </div>
</template>

<script>
  import {
    transSearchBigQueue,
    businessList,
    telBusinessQueue
  } from '@/api/call-center/call-center'
  import { mapActions, mapGetters } from 'vuex'
  import { getApiWbPhoneSkillEngineerList, getApiWbPhoneSkillSearchEngineer } from '@/api/call-center/call-center-phone'
  // import { AgentState } from '@call/voice/enum'

  // todo transfer 组件应该是一个通用的，适用于不同的通路的组件
  export default {
    props: ['defaultActiveName', 'visible', 'transfer'],
    data() {
      return {
        engCode: this.$store.getters.allInfo.code, // 工程师code
        engName: this.$store.getters.allInfo.name, // 工程师name
        onlyKA: false, // 仅转接KA
        searchVisible: true, // 搜索个人队列列表
        bigQueueInp: '', // 搜索大队列input
        personQueueInp: '', // 搜索个人队列input
        activeName: this.defaultActiveName,
        transList: [], // 队列列表
        transListPerson: [], // 个人队列列表
        engineerList: [], // 工程师列表
        searchEngList: [], // 搜索工程师列表
        queueTrans: true, // 队列【转接】按钮状态
        personTrans: true, // 个人【转接】按钮状态
        transferName: '', // 大队队列名称
        transferId: '', // 大队列队列id
        transferNum: '', // 大队列队列值
        active: '',
        queue: '',
        engI: '',
        queueIndex: '',
        busIndex: '',
        type: 3, // 队列转接标识
        perTransNum: '', // 个人队列队列值
        engineerCode: '', // 个人队列转接工程师账号,
        engineerName: '', // 个人队列转接工程师名称,
        busListVisibile: true, // 业务列表
        queueListVisibile: false, // 队列列表
        engListVib: false, // 工程师列表
        queueCrumbs: false, // 面包屑-队列
        engVisible: false, // 面包屑-工程师
        big_customer: 0, // 是不是大客户队列 1是 0不是,全部队列
        returnQueue: false, // 队列--返回队列列表
        businessArr: [],
        bigBusVisbible: true, // 队列-业务列表
        bigQueueVisibile: false, // 队列-队列列表
        listQueueVisible: false, // 队列-面包屑,
        phone: ''
      }
    },
    mounted() {
      this.getBusList()
    },
    watch: {
      visible(status) {
        console.log(status)
        if (!status) this.activeName = this.defaultActiveName
      }
    },
    computed: {
      ...mapGetters('call', ['currentSession', 'agentStateExt'])
    },
    methods: {
      ...mapActions('call', ['transferSession']),
      getBusList() { // 个人--获取所有业务列表
        this.clearSel()
        businessList(2).then(response => {
          this.businessArr = response.data
          if (this.activeName === 'first') {
            this.returnList()
          } else {
            this.returnVisible()
          }
        }).catch(err => {
          this.$report(err, {
            message: '默认获取业务列表失败'
          })
        })
      },
      busQueue(id, i) { // 点击事件--根据业务获取队列
        this.busIndex = i
        this.busListVisibile = false
        this.queueCrumbs = true
        this.queueListVisibile = true
        this.getBusQueue(id)
      },
      getBusQueue(id) { // 根据业务获取队列
        telBusinessQueue(id).then(response => {
          this.transListPerson = []
          this.transListPerson = response.data
        }).catch(err => {
          console.log(err)
        })
      },
      getTransQueue(id, i) { // 获取转接大队列队列
        this.bigQueueVisibile = true
        this.bigBusVisbible = false
        this.listQueueVisible = true
        telBusinessQueue(id).then(response => {
          // 只筛选出 type = 2 （电话通路）
          this.transList = response.data.filter(item => item.type === 2)
        }).catch(err => {
          console.log(err)
        })
      },
      searchBig() { // 搜索大队列
        this.returnQueue = true
        if (this.bigQueueInp !== '') {
          transSearchBigQueue(this.bigQueueInp, 2).then(response => {
            if (response.data && response.data.length !== 0) {
              this.bigBusVisbible = false
              this.bigQueueVisibile = true
              this.transList = response.data
            } else if (response.data.length === 0) {
              this.returnList()
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          this.returnList()
        }
      },
      searchPersonal() { // 搜索个人队列
        if (this.personQueueInp !== '') {
          if (this.personQueueInp === this.engCode || this.personQueueInp === this.engName) {
            this.$message({
              message: '不可转接给当前工程师',
              type: 'warning'
            })
            return
          }
          this.searchVisible = false
          // type 在线转接2  转接1
          console.log(this.transfer, 2222)
          getApiWbPhoneSkillSearchEngineer(this.personQueueInp, this.engCode, this.transfer).then(response => {
            const newInfor = []
            response.data.map((item, i) => {
              if (item.queueList) {
                for (const j in item.queueList) {
                  const name = { engName: item.name, status: item.status, engCode: item.code }
                  console.log(item.queueList[j].name, '每次的名字', item.queueList[j].code)
                  name.name = item.queueList[j].name
                  name.code = item.queueList[j].code
                  newInfor.push(name)
                }
              }
            })
            this.searchEngList = newInfor
          }).catch(err => {
            console.log(err)
            this.returnPerson()
          })
        } else {
          this.returnPerson()
        }
      },
      transferPars(item, i) { // 选择要转接的队列
        // 电话转接队列
        this.transferName = item.name
        this.transferId = item.id
        this.transferNum = item.code
        this.active = i
        this.queueTrans = false
        console.log(this.transferName, this.transferId, this.transferNum)
      },
      personList(code, i) { // 获取大队列转接的队列列表
        console.log(code, '获取个人队列转接的队列列表')
        this.engVisible = true
        this.engListVib = true
        this.queueListVisibile = false
        this.queue = i
        this.perTransNum = code
        getApiWbPhoneSkillEngineerList(code, this.$store.getters.allInfo.code, this.transfer).then(response => {
          this.engineerList = response.data
        }).catch(err => {
          console.log(err)
        })
      },
      selectEngineer(item, i) { // 选中要转接的工程师
        console.log(item, '工程师')
        this.engineerName = item.name
        this.engineerCode = item.code
        this.engI = i
        this.personTrans = false
        this.phone = item.phone
      },
      selSearchEng(item, i) { // 选择搜索工程师队列
        this.queueIndex = i
        this.engineerName = item.engName
        this.engineerCode = item.engCode
        this.perTransNum = item.code
        this.personTrans = false
        console.log(this.engineerName, this.engineerCode, this.perTransNum)
      },
      transferQueue() { // 点击转接
        this.$confirm(`是否将用户转接到"${this.transferName}"`, '', {
          confirmButtonText: '转接',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          // 电话队列code 前缀是没有V的，避免后续踩坑，这里主动处理下
          const skill = this.transferNum.replace(/^V|^v/, '')
          this.submitQueue({ skill, enter_type: 1 })
          // const transferPromise = this.submitQueue({ code: this.transferNum, enter_type: 1 })
          // this.handleTransfer(transferPromise)
        }).catch(() => {})
      },
      submitQueue(data) {
        return this.$emit('onsubmitqueue', data)
      },
      transferPersonal() { // 个人队列转接
        this.$confirm(`是否将用户转接到"${this.engineerName}(${this.engineerCode})"`, '', {
          confirmButtonText: '转接',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this.submitPersonal({ skill: this.perTransNum, code: this.engineerCode, phone: this.phone, enter_type: 2 })
          // const transferPromise = this.submitPersonal({ code: this.engineerCode, enter_type: 2 })
          // this.handleTransfer(transferPromise)
        }).catch(() => {})
      },
      submitPersonal(data) {
        return this.$emit('onsubmitpersonal', data)
      },
      handleTransfer(promise) {
        promise.then(() => {
          this.$message.success(`转接成功`)
        }).catch(error => {
          this.$message.error(`转接失败，${error}`)
        })
      },
      returnVisible() {
        this.busListVisibile = true
        this.queueListVisibile = false
        this.queueCrumbs = false
        this.engVisible = false
        this.engListVib = false
        this.clearSel()
      },
      returnPerson() {
        console.log('返回个人队列列表')
        this.searchVisible = true
      },
      returnList() {
        console.log('返回业务列表')
        this.bigBusVisbible = true
        this.bigQueueVisibile = false
        this.listQueueVisible = false
        this.returnQueue = false
        this.clearSel()
      },
      returnQueueList() {
        console.log('返回队列列表')
        this.busListVisibile = false
        this.queueListVisibile = true
        this.engListVib = false
        this.engVisible = false
        this.clearSel()
      },
      clearSel() {
        this.busIndex = -1
        this.queue = -1
        this.engI = -1
        this.busIndex = -1
        this.active = -1
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  @import "../scss/rules";

  .transfer-wrap {
    /*max-height: 90vh;*/
  }

  .to-center {
    text-align: center;
  }

  .engineer-list {
    margin: 0 0 20px 0;
    color: #606266;
    font-size: 14px;
    li {
      height: 34px;
      line-height: 34px;
      .status {
        float: right;
      }
      .ready {
        color: #6ABF4A;
      }
      .busy {
        color: #F37261;
      }
    }
    li:hover,
    .selCur {
      cursor: pointer;
      background: #F5F7FA;
    }
  }

  .trans-list,
  .queue-list{
    margin-bottom: 30px;
    color: #606266;
    font-size: 14px;
    li {
      height: 34px;
      line-height: 34px;
      .recommend,
      .right-arrow {
        float: right;
        font-weight: bold;
      }
      .right-arrow {
        font-size: 10px;
      }
      .strong {
        font-weight: bold;
      }
    }
    li:hover,
    .selCur {
      background: #F5F7FA;
      cursor: pointer;
      color: $link;
    }
  }

  .crumbs {
    margin: 20px 0 10px 0;
    span {
      cursor: pointer;
    }
    .toRight {
      float: right;
    }
  }

  .search-englist {
    margin-bottom: 30px;
    width: 100%;
    li {
      height: 34px;
      line-height: 34px;
      .status {
        float: right;
      }
      .ready {
        color: #6ABF4A;
      }
      .busy {
        color: #F37261;
      }
      .search-name {
        height: 34px;
        line-height: 34px;
        width: 240px;
        display: inline-block;
        overflow: hidden;
        text-overflow:ellipsis;
        white-space: nowrap;
      }
    }
    li:hover,
    .selCur {
      background: #F5F7FA;
      cursor: pointer;
      color: $link;
    }
  }

  .transfer-wrap {
    position: relative;
    max-height: 90vh;
    .only-ka {
      position: absolute;
      right: 0;
      top: 10px;
      z-index: 9;
    }
    .list-height {
      max-height: calc(90vh - 240px);
      overflow: auto;
    }
    .list-height::-webkit-scrollbar {
      display: none;
    }
  }
</style>
