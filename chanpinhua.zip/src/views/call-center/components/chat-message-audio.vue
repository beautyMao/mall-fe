<template>
  <p class="chat-content-audio" @click="play">
    <i v-if="!duration && tryCount <= 5" class="el-icon-loading" />
    <i v-if="!duration && tryCount > 5" class="el-icon-warning-outline" title="语音资源加载失败，点击重试" />
    <span v-if="duration" class="audio-icon">
      <svg-icon v-if="!playing" icon-class="audio" />
      <svg-icon v-else icon-class="audioPlay" />
    </span>
    <span v-if="message.text">{{ message.text }}</span>
    <span v-else class="tip">[ 环境吵杂或者无法被识别 ]</span>
    <audio
        ref="audio"
        :src="asyncSrc"
        @error="retry"
        @loadedmetadata="getDuration"
        @ended="onEnd"
        preload="auto"
        style="display: none;" />
    <span v-show="duration" class="duration" :class="{'beside-robot': message.robotIndex > -1}">{{ duration }}</span>
  </p>
</template>

<script type="text/ecmascript-6">
  import { mapGetters, mapMutations } from 'vuex'

  export default {
    props: ['message'],
    data() {
      return {
        playing: false,
        asyncSrc: '',
        duration: false,

        tryCount: 0
      }
    },
    computed: {
      ...mapGetters('call', ['audioPlaying'])
    },
    watch: {
      'audioPlaying': function(playItem) {
        if (playItem && this._uid !== playItem && this.playing) {
          this.playing = false
          this.$refs.audio.pause()
          this.$refs.audio.currentTime = 0
        }
      }
    },
    mounted() {
      // 语音文件由于是异步转存七牛，需要一个时间
      this.$nextTick(() => {
        this.asyncSrc = this.message.content
      })
    },
    beforeDestroy() {
      if (this.playing) {
        this.$refs.audio.pause()
      }
    },
    methods: {
      ...mapMutations('call', ['AUDIO_PLAYING']),
      play() {
        if (!this.duration) {
          if (this.tryCount > 5) {
            this.tryCount = 0
            this.retry()
          }
          return
        }

        if (this.playing) {
          this.$refs.audio.pause()
          this.$refs.audio.currentTime = 0
          this.AUDIO_PLAYING(false)
        } else {
          this.$refs.audio.play()
          this.AUDIO_PLAYING(this._uid)
        }
        this.playing = !this.playing
      },
      // pause() {
      //   this.playing = false
      //   this.$refs.audio.pause()
      // },
      onEnd() {
        this.AUDIO_PLAYING(false)
        this.playing = false
      },
      retry() {
        if (this.playing) {
          this.onEnd()
        }

        // 延迟1s 再次请求
        if (this.tryCount++ < 5) {
          setTimeout(() => {
            this.asyncSrc = this.message.content + '?t=' + this.tryCount
          }, 1000 + 500 * this.tryCount)
        }
      },
      getDuration() {
        let duration = this.$refs.audio.duration
        if (duration < 0 || Number.isNaN(duration)) {
          duration = 0
        }

        const sec_num = parseInt(duration, 10)
        const minutes = Math.floor(sec_num / 60) % 60
        const seconds = sec_num % 60
        this.duration = [minutes > 0 ? minutes + '\'' : '', seconds, '"'].join('')
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .chat-content-audio {
    cursor: pointer !important;

    span.tip {
      color: $lldark;
    }

    span.audio-icon {
      width: 18px;
      display: inline-block;
    }

    span.duration {
      position: absolute;
      right: -30px;
      top: 6px;
      color: $lldark;
      font-size: 12px;
      font-weight: bold;

      &.beside-robot {
        right: -50px;
      }
    }

    &.robot {
      span.duration {
        right: -50px;
      }
    }

    .svg-icon {
      font-size: 16px;

      &.playing {
        color: white;
      }
    }
  }
</style>
