<template>
  <div class="recorder-container" v-if="containerDisplay">
    <el-form :inline="true" class="recorder-form">
      <el-form-item label="记录名称">
        <el-input v-model="name" :disabled="recording" placeholder="请输入记录名称"></el-input>
      </el-form-item>
      <el-form-item>
        <el-switch
          v-model="recording"
          @change="recordingChange"
          :disabled="name === ''"
          active-text="记录中"
          inactive-text="停止"></el-switch>
      </el-form-item>
      <span>已记录 <b>{{messages.length}}</b> 条</span>
    </el-form>
    <el-form :inline="true" class="recorder-form">
      <el-form-item label="选择记录">
        <el-select placeholder="请选择回放记录" v-model="selectedRecord" @change="recordChange">
          <el-option v-for="record in recordsList" :label="record.name" :value="record.key" :key="record.key"></el-option>
        </el-select>
      </el-form-item>

      <span>剩余 <b>{{replayMessages.length}}</b> 条</span>

      <el-button-group>
        <el-button type="primary" @click="autoPlay" v-if="!timer">自动</el-button>
        <el-button type="primary" @click="stopPlay" v-else>停止</el-button>
      </el-button-group>

      <el-button-group>
        <el-button type="primary" @click="stepPlay">单步</el-button>
      </el-button-group>

      <el-dropdown trigger="click">
        <el-button type="danger">
          更多操作<i class="el-icon-arrow-down el-icon--right"></i>
        </el-button>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item @click.native="reviewRecord">查看记录</el-dropdown-item>
          <el-popover
            placement="left"
            width="50"
            trigger="click">
            <div class="text-center">
              <a ref="link" class="link"><i class="el-icon-download"></i>下载记录数据</a>
            </div>
            <el-dropdown-item slot="reference" @click.native="downloadRecord">下载记录</el-dropdown-item>
            <el-dropdown-item slot="reference" @click.native="addRecord">填写记录</el-dropdown-item>
            <el-dropdown-item slot="reference" @click.native="uploadRecord">载入记录</el-dropdown-item>
          </el-popover>
          <el-popover
            placement="left"
            width="200"
            trigger="click">
            <el-form-item>
              <el-slider v-model="speed" :min="0.5" :max="2" :step="0.5"></el-slider>
            </el-form-item>
            <el-dropdown-item slot="reference">播放速度调整</el-dropdown-item>
          </el-popover>

          <el-dropdown-item @click.native="removeRecord" divided>移除记录</el-dropdown-item>
          <el-dropdown-item @click.native="removeAllRecords">移除全部记录</el-dropdown-item>
          <el-dropdown-item @click.native="hideTool" divided>关闭工具栏</el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>

    </el-form>

    <el-dialog
      title="数据查看"
      fullscreen
      :before-close="() => {this.reviewMessagesData = []}"
      :visible="reviewMessagesData.length > 0">
      <el-table
        :data="reviewMessagesData"
        style="width: 100%">
        <el-table-column
          prop="time"
          label="time"
          width="180">
        </el-table-column>
        <el-table-column
          prop="callState"
          label="callState"
          width="180">
        </el-table-column>
        <el-table-column
          prop="messageName"
          label="messageName"
          width="180">
        </el-table-column>
        <el-table-column
          prop="otherDn"
          label="otherDn"
          width="180">
        </el-table-column>
        <el-table-column
          prop="connId"
          label="connId">
        </el-table-column>
        <el-table-column
          prop="transferConnId"
          label="transferConnId">
        </el-table-column>
        <el-table-column
          prop="callType"
          label="callType">
        </el-table-column>
        <el-table-column
          prop="VirualQueue"
          label="VirualQueue">
        </el-table-column>
        <el-table-column
          prop="displayName"
          label="displayName">
        </el-table-column>
        <el-table-column
          prop="functionPoint"
          label="functionPoint">
        </el-table-column>
      </el-table>
      <span slot="footer" class="dialog-footer">
        <el-select placeholder="请选择回放记录" v-model="selectedRecord" @change="viewRecordChange">
          <el-option v-for="record in recordsList" :label="record.name" :value="record.key" :key="record.key"></el-option>
        </el-select>
        <el-button type="primary" @click="reviewMessagesData = []">关闭</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script type="text/ecmascript-6">
  import { MessageType } from '@call/voice/enum'
  import ws from '@/api/call-center/softphone-ws'
  import { isProd, uuid } from '@/utils'
  import get from 'lodash.get'
  import axios from 'axios'

  const recordMessageTypes = [MessageType.CallStateChange, MessageType.DeviceStateChange]
  const RECORD_STORAGE_PREFIX = 'RECORD_STORAGE_PREFIX'

  export default {
    name: 'voice-recorder',
    data() {
      return {
        name: '',
        recording: false,
        messages: [],

        selectedRecord: '',
        recordsList: [],
        replayMessages: [],
        reviewMessagesData: [],
        readyToPlay: false,
        timer: null,
        speed: 0.5,

        containerDisplay: !isProd
      }
    },
    mounted() {
      recordMessageTypes.forEach(type => {
        ws.addEventListener(type, this._recorderMessageHandle)
      })
      this.refreshRecordList()
    },
    beforeDestroy() {
      recordMessageTypes.forEach(type => {
        ws.addEventListener(type, this._recorderMessageHandle)
      })
      this.timer && clearInterval(this.timer)
    },
    methods: {
      _recorderMessageHandle(message, type) {
        if (!this.recording) {
          return
        }

        this.messages.push(message)
      },
      recordingChange(state) {
        if (state) {
          this.recording = true
          this.messages = []
        } else {
          if (!this.messages.length) {
            this.$message.warning('没有捕获到电话事件，不做保存')
            return
          }
          localStorage.setItem(uuid(RECORD_STORAGE_PREFIX), JSON.stringify({
            name: this.name,
            messages: this.messages
          }))

          this.refreshRecordList()
          this.$message.success('事件记录已保存')

          this.recording = false
          this.name = ''
        }
      },
      reviewRecord() {
        if (!this.selectedRecord) {
          this.$message.warning('请选择要查看的事件记录')
          return
        }

        const recordData = JSON.parse(localStorage.getItem(this.selectedRecord))
        recordData.messages.filter(item => item.data).forEach(({ data }) => {
          this.reviewMessagesData.push({
            time: data.timestamp.split(' ')[1],
            callState: get(data, 'call.state'),
            messageName: data.messageName,
            displayName: get(data, 'devices[0].userState.displayName', ''),
            otherDn: get(data, 'otherDn', ''),
            connId: get(data, 'call.connId', ''),
            transferConnId: get(data, 'call.transferConnId', ''),
            callType: get(data, 'call.callType', ''),
            VirualQueue: get(data, 'call.userData.VirualQueue', ''),
            functionPoint: get(data, 'call.userData.functionPoint', '')
          })
        })
      },
      viewRecordChange() {
        this.reviewMessagesData = []
        this.reviewRecord()
      },
      removeRecord() {
        if (!this.selectedRecord) {
          this.$message.warning('请选择要移除的事件记录')
          return
        }

        const recordData = JSON.parse(localStorage.getItem(this.selectedRecord))
        this.$confirm('确定移除？' + recordData.name).then(() => {
          localStorage.removeItem(this.selectedRecord)
          this.refreshRecordList()
          this.$message.success('事件记录已移除')
        }).catch(() => {})
      },
      removeAllRecords() {
        this.$confirm('确定全部移除？').then(() => {
          this.recordsList = []

          for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i)
            if (key.startsWith(RECORD_STORAGE_PREFIX)) {
              localStorage.removeItem(key)
            }
          }
          this.refreshRecordList()
          this.$message.success('事件记录已批量移除')
        }).catch(() => {})
      },
      downloadRecord() {
        if (!this.selectedRecord) {
          this.$message.warning('请选择要下载事件记录')
          return
        }

        const recordData = JSON.parse(localStorage.getItem(this.selectedRecord))

        if (!recordData.messages.length) {
          this.$message.warning('播放事件队列为空，请重新录制或者选择其他记录')
          return
        }

        // https://codepen.io/vidhill/pen/bNPEmX
        const json = JSON.stringify(recordData)
        const blob = new Blob([json], { type: 'octet/stream' })

        this.$refs.link.href = window.URL.createObjectURL(blob)
        this.$refs.link.target = '_blank'
        // target filename
        this.$refs.link.download = `${this.selectedRecord}-${recordData.name}-record.json`
      },
      addRecord() {
        this.$prompt('JSON 内容').then(({ value }) => {
          localStorage.setItem(uuid(RECORD_STORAGE_PREFIX), value)
          this.refreshRecordList()
          this.$message.success('事件记录已保存')
        }).catch(() => {})
      },
      uploadRecord() {
        let recordData
        this.$prompt('sentry 捕获到的JSON 地址').then(({ value }) => {
          return axios.get(value.trim(), {
            timeout: 10 * 1000,
            headers: {
              'Content-Type': 'application/json',
              'charset': 'utf-8'
            }
          })
        }).then((json) => {
          recordData = json.data
          return this.$prompt('获取数据成功，填写记录名称')
        }).then(({ value }) => {
          localStorage.setItem(uuid(RECORD_STORAGE_PREFIX), JSON.stringify({
            name: value.trim(),
            // 可能包含了error 信息
            messages: recordData.filter(item => item.data).reverse()
          }))
          this.refreshRecordList()
          this.$message.success('事件记录已保存')
        }).catch(() => {})
      },
      refreshRecordList() {
        this.recordsList = []

        for (let i = 0; i < localStorage.length; i++) {
          const key = localStorage.key(i)
          if (key.startsWith(RECORD_STORAGE_PREFIX)) {
            const data = JSON.parse(localStorage.getItem(key))
            this.recordsList.push({
              key,
              name: data.name
            })
          }
        }

        // 根据name 排个序吧，方便对用例进行管理
        this.recordsList = this.recordsList.sort((a, b) => a.name.charCodeAt() - b.name.charCodeAt())
        this.selectedRecord = ''
      },
      recordChange(key) {
        const data = JSON.parse(localStorage.getItem(key))
        this.replayMessages = data.messages
      },
      _beforePlay() {
        if (!this.replayMessages.length) {
          this.$message.warning('播放事件队列为空，请重新录制或者选择其他记录')
          return false
        }
        if (!this.readyToPlay) {
          ws.destroy()
          this.$message.info('开始播放后，电话条不再接收真实事件，刷新后可恢复')
        }
        this.readyToPlay = true
        return true
      },
      autoPlay() {
        if (!this.selectedRecord) {
          this.$message.warning('请选择事件记录')
          return
        }

        // 恢复一下数据
        if (!this.replayMessages.length) {
          this.recordChange(this.selectedRecord)
        }

        if (!this._beforePlay()) {
          return
        }

        this.timer = setInterval(() => {
          const data = this.stepPlay()
          if (!data) {
            clearInterval(this.timer)
            this.timer = null
          }
        }, this.speed * 1000)
      },
      stopPlay() {
        this.timer && clearInterval(this.timer)
        this.timer = null
      },
      stepPlay() {
        if (!this._beforePlay()) {
          return
        }

        const data = this.replayMessages.shift()
        if (data) {
          ws.addPool(data)
        }
        return data
      },
      hideTool() {
        this.containerDisplay = false
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../../scss/rules";

  .recorder-container {
    border-bottom: 1px solid $borderColor;
    background-color: $bg-light-blue;
    padding-top: 10px;
    padding-left: 10px;
    padding-right: 10px;

    .recorder-form span {
      color: $ldark;
      display: inline-block;
      line-height: 28px;
      font-size: 14px;
    }

    .link {
      color: $link;
    }
  }
  /deep/ .is-active {
    color: #2691ff
  }
</style>
