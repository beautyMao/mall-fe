<template>
  <div>
    <div class="error-button">
      <el-tooltip effect="dark" content="电话台：反馈问题" placement="top">
        <el-button type="danger" icon="el-icon-phone" circle @click="dialogTableVisible = true" />
      </el-tooltip>
    </div>

    <el-dialog title="电话台反馈问题" :visible.sync="dialogTableVisible" width="30%">
      <el-form :model="feedbackForm" class="feedback-form">
        <el-form-item label="故障描述">
          <el-input v-model="feedbackForm.describe" type="textarea" placeholder="请详细描述问题" />
        </el-form-item>
        <el-form-item label="故障号码">
          <el-input v-model="feedbackForm.number" placeholder="用于辅助定位问题" />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button type="text">已记录{{ eventData.length }}条日志</el-button>
        <el-button @click="dialogTableVisible = false">取 消</el-button>
        <el-button type="primary" @click="feedback">提交反馈</el-button>
      </div>
    </el-dialog>

  </div>
</template>

<script type="text/ecmascript-6">
  import ws from '@/api/call-center/softphone-ws'
  import { MessageType } from '@/store/modules/call-center/voice/enum'
  import { report } from '@/utils/error-report'
  import { cubeUploadFile } from '@/api/qiniu'
  import { mapGetters } from 'vuex'

  // 按照抓取经验来看，一通电话一般也就30以内的事件
  const MAX_LOG_NUMBER = 50

  export default {
    name: 'softphone-feedback',
    data() {
      return {
        dialogTableVisible: false,
        feedbackForm: {
          describe: '',
          number: ''
        },
        eventData: []
      }
    },
    computed: {
      ...mapGetters(['allInfo'])
    },
    mounted() {
      ws.addEventListener(MessageType.CallStateChange, this.messageEventHandle)
      ws.addEventListener(MessageType.DeviceStateChange, this.messageEventHandle)
      ws.addEventListener(MessageType.ErrorMessage, this.messageEventHandle)
    },
    beforeDestroy() {
      ws.removeEventListener(MessageType.CallStateChange, this.messageEventHandle)
      ws.removeEventListener(MessageType.DeviceStateChange, this.messageEventHandle)
      ws.removeEventListener(MessageType.ErrorMessage, this.messageEventHandle)
    },
    methods: {
      messageEventHandle(message) {
        if (this.eventData.length > MAX_LOG_NUMBER) {
          this.eventData.pop()
        }
        this.eventData.unshift(message)
      },
      feedback() {
        if (!this.eventData.length) {
          return this.$message.warning('没有收集到电话事件，暂不能反馈问题')
        }

        // https://codepen.io/vidhill/pen/bNPEmX
        const json = JSON.stringify(this.eventData)
        const blob = new Blob([json], { type: 'octet/json' })
        cubeUploadFile(blob).then((data) => {
          report({
            ...this.feedbackForm,
            jsonFile: data.url,
            feedback: this.feedbackForm.describe || '未描述的软电话条故障',
            ...this.$store.state.call.voice.session
          }, 'softphone feedback')

          this.feedbackForm.describe = ''
          this.feedbackForm.number = ''
          this.$message.success('已反馈，感谢您帮助魔方成长')
        }).finally(() => {
          this.dialogTableVisible = false
        })
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .feedback-form {
    line-height: 28px;
  }

  /deep/ .el-dialog__body {
    padding-top: 10px;
  }

  .error-button {
    position: absolute;
    bottom: 20px;
    left: 60px;
  }
</style>
