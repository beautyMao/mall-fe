<template>
  <el-popover
    v-model="talkVisible"
    placement="top"
  >
    <div class="talk-wrap">
      <ul class="first-list">
        <li
          v-for="(item, index) in classesList"
          :key="index"
          :class="{'selected': index === classes}"
          @click="showTalks(item, index)"
        >
          <svg-icon icon-class="arrowRight" class="right" />
          <span class="trick-con">{{ item.content }}</span>
        </li>
        <li>
          <el-button type="text" :disabled="!buttonPermission('workBenchEditSpeech')"  @click="editTalks">编辑话术</el-button>
        </li>
      </ul>
      <ul v-show="personVisible" class="first-list">
        <li
          v-for="(item, i) in firstTalks"
          :key="i"
          :class="{'selected': i === firstIndex}"
          @click="getChildTalkList(item, i)"
        >
          <svg-icon v-show="item.type === 1" icon-class="arrowRight" class="right" />
          <span class="trick-con">{{ item.content }}</span>
        </li>
      </ul>
      <ul v-show="commonVisible" class="first-list com-list">
        <li
          v-for="(item, i) in commonList"
          :key="i"
          :class="{'selected': i === firstIndex}"
          @click="getChildTalkList(item, i)"
        >
          <svg-icon v-show="item.type === 1" icon-class="arrowRight" class="right" />
          <span class="trick-con">{{ item.content }}</span>
        </li>
      </ul>
      <ul v-show="childVisible" class="third-list">
        <li v-for="(item, i) in childTalk" :key="i" :class="{'selected': i === childIndex}" @click="selTalk(item, i)">
          {{ item.content }}
        </li>
        <li v-show="moreVisible" class="load-more" @click="getMoreTalks">
          <el-button type="text">加载更多话术</el-button>
        </li>
      </ul>
    </div>

    <span slot="reference" @click="getTalksList">
      <svg-icon icon-class="text" class="talk-icon" />
    </span>
  </el-popover>
</template>

<script type="text/ecmascript-6">
  import { engineerPartList, enginneerTalkList } from '@/api/call-center/call-center'
  import { mapGetters } from 'vuex'

  export default {
    name: 'ChatEditorTalk',
    data() {
      return {
        firstTalks: [], // 一级话术
        childTalk: [], // 2级话术
        classesList: [
          {
            content: '公共话术',
            type: 'common'
          },
          {
            content: '个人话术',
            type: 'person'
          }
        ], // 类别数组
        classes: -1, // 类别选择下标
        firstIndex: -1, // 一级选下标
        childIndex: -1, // 子级选下标
        talkVisible: false,
        childVisible: false,
        page: 1,
        pageSize: 5,
        childId: '',
        moreVisible: false,
        commonList: [],
        commonVisible: false,
        personVisible: false
      }
    },
    mounted() {
      this.getTalksList()
    },
    computed: {
      ...mapGetters([
        'buttonPermission'
      ])
    },
    methods: {
      showTalks(par, index) { // 显示公共话术、个人话术
        this.childVisible = false
        this.classes = index
        this.firstIndex = -1
        if (par.type === 'common') {
          this.commonVisible = true
          this.personVisible = false
        } else if (par.type === 'person') {
          this.personVisible = true
          this.commonVisible = false
        }
      },
      getTalksList() { // 获取一级话术
        this.firstIndex = -1
        this.childIndex = -1
        this.childVisible = false
        enginneerTalkList().then(response => {
          this.commonList = response.data.common
          const firstList = response.data.personal
          // this.firstTalks = commonList.concat(firstList)
          this.firstTalks = firstList
        }).catch(err => {
          console.log(err)
        })
      },
      getChildTalkList(item, i) {
        this.commonVisible = false
        this.firstIndex = i
        if (item.type === 0) {
          this.$emit('content-click', item.content)
          this.talkVisible = false
          return
        }
        this.childId = item.id
        this.page = 1
        this.getLoadTalks(this.childId, 1, this.pageSize)
      },
      selTalk(item, i) {
        this.childIndex = i
        this.talkVisible = false
        this.childIndex = -1
        this.firstIndex = -1
        this.classes = -1
        this.childVisible = false
        this.commonVisible = false
        this.personVisible = false
        this.$emit('content-click', item.content)
      },
      editTalks() {
        this.$router.push('/chat-conf/speech')
      },
      getMoreTalks() { // 加载更多话术
        this.page = this.page + 1
        engineerPartList(this.childId, this.page, this.pageSize).then(response => {
          this.childVisible = true
          this.childTalk = this.childTalk.concat(response.data.data)
          if (this.childTalk.length < response.data.total) {
            this.moreVisible = true
          } else if (this.childTalk.length === response.data.total) {
            this.moreVisible = false
          }
        }).catch(err => {
          console.log(err)
        })
      },
      getLoadTalks(id, page, pageSize) { // 加载二级话术
        engineerPartList(id, page, pageSize).then(response => {
          this.childVisible = true
          this.childTalk = response.data.data
          this.moreVisible = response.data.total > 5
        }).catch(err => {
          console.log(err)
        })
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .talk-wrap {
    max-height: 300px;
    border-radius: 5px;
    font-size: 14px;
    display: flex;
    margin: -12px;

    ul {
      max-height: 298px;
      overflow-y: auto;
      position: relative;
      padding: 0;
      margin: 0;

      li {
        width: 100%;
        height: 34px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
        color: $ldark;
        line-height: 34px;
        padding: 0 10px;
      }

      li:hover, li.selected {
        background: rgba(245, 247, 250, 1);
        cursor: pointer;
        color: $base;
      }
    }

    ul.first-list {
      width: 210px;
      border-right: 1px solid $borderColor;

      li {
        position: relative;
      }

      .trick-con {
        display: inline-block;
        width: 175px;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }

      .right {
        float: right;
        font-size: 12px;
        margin: 10px 0 0;
      }

      .edit-talks {
        margin: 0 0 0 10px;
        position: absolute;
        left: 0;
        bottom: 0;
        z-index: 10;
      }
    }

    ul.child-list {
      width: 420px;
      flex: 1;
    }

    ul.com-list {
      max-height: 400px;
      overflow: auto;
    }
  }

  .talk-icon {
    font-size: 28px;
    line-height: 28px;
    color: $lldark;
    cursor: pointer;
    transition: color 200ms;
  }

  .talk-icon:hover {
    color: $dark;
  }

  .load-more {
    text-align: center;
  }
</style>
