<template>
  <el-container>
    <el-main v-loading="loading('knowledgeContent')">
      <div v-html="content"></div>
    </el-main>
  </el-container>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { allSearchKnowInfo } from '@/api/call-center/call-center'

  export default {
    name: 'knowledge-info',
    data() {
      return {
        content: ''
      }
    },
    computed: {
      ...mapGetters('api', ['loading'])
    },
    mounted() {
      const id = this.$route.query.id
      console.log(this.$route.query)
      // 获取知识库详情
      allSearchKnowInfo(id).then(response => {
        if (response.data.content !== '') {
          this.content = response.data.content
        } else {
          this.content = '文章内容为空!'
        }
      }).catch(err => {
        console.log(err)
        this.content = '内容获取失败!'
      })
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  a {
    color: $link;
  }
</style>
