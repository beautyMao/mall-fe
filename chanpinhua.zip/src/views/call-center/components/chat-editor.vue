<template>
  <div class="editor-container" :class="{'isdisabled': !IMReady || currentSession.isVirtual}">
    <div class="editor-toolbar">
      <ul class="toolist">
        <li class="toolitem">
          <el-popover
            placement="top-start"
            width="500"
            trigger="click">
            <chat-emoji @insertEmoji='insertEmoji'></chat-emoji>
            <svg-icon slot="reference" id="tool-emoji" icon-class="emoji" class="icon" />
          </el-popover>
        </li>
        <li>
          <label for="select-file">
            <svg-icon icon-class="pic" class="icon" />
          </label>
        </li>
        <li>
          <chat-editor-talk @content-click="setContent" />
        </li>
        <li @click="tryInviteComment">
          <el-tooltip effect="dark" content="推送邀评" placement="top">
            <i class="el-icon-s-comment icon" :class="readyForInvite ? '' : 'disabled'" />
          </el-tooltip>
        </li>
      </ul>

      <el-dialog
        title="邀评提示"
        :visible.sync="invite.dialogVisible"
        width="30%">
        <p>确定给当前用户发送邀评信息？</p>
        <p><el-checkbox v-model="invite.noTip" >不再提示</el-checkbox></p>
        <span slot="footer" class="dialog-footer">
          <el-button @click="invite.dialogVisible = false">取 消</el-button>
          <el-button type="primary" @click="inviteComment">确 定</el-button>
        </span>
      </el-dialog>

      <!--accept="image/jpeg,image/png"-->
      <form ref="fileForm">
        <input
          id="select-file"
          ref="file"
          type="file"
          accept="image/jpeg,image/png"
          @change="fileChange"
        >
      </form>
    </div>

    <div
      id="editor-content"
      ref="chatTextarea"
      class="editor-field"
      :contenteditable="IMReady"
      @keydown="checkContentLength"
      @keydown.enter.stop.prevent="trySendMessage($event, 'enter')"
      @paste="paste"
      @drop="drop"
    />
    <div class="chat-operation">
      <el-link :type="contentLength > 650 ? 'danger' : 'primary'">{{contentLength}}/650</el-link>
      <el-dropdown
        split-button
        type="primary"
        trigger="click"
        placement="top-end"
        :class="{'disabled': contentLength > 650}"
        @click="trySendMessage"
      >
        发送消息
        <el-dropdown-menu slot="dropdown" class="chat-operation-item">
          <el-radio-group v-model="keyBind">
            <el-dropdown-item>
              <el-radio label="enter">Enter 发送</el-radio>
            </el-dropdown-item>
            <el-dropdown-item>
              <el-radio label="ctrl+enter">Ctrl + Enter 发送</el-radio>
            </el-dropdown-item>
<!--            <el-dropdown-item>-->
<!--              <el-radio v-model="keyBind" label="alt+s">Alt + S 发送</el-radio>-->
<!--            </el-dropdown-item>-->
          </el-radio-group>
        </el-dropdown-menu>
      </el-dropdown>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapActions, mapGetters } from 'vuex'
  import { WEIXIN_QQ_TEXT_LIST } from '@/utils/emoji'
  import ChatEditorTalk from './chat-editor-talk'
  import ChatEmoji from './chat-emoji'
  import { debounce } from '@/utils'
  import { checkInviteComment, inviteComment } from '@/api/call-center/call-center'
  import { getLocalStorage } from '@/utils/local-storage'

  const imageFileList = []
  const STORAGE_KEY = 'chat-editor:keyBind'

  export default {
    name: 'chat-editor',
    components: { ChatEditorTalk, ChatEmoji },
    data() {
      return {
        id: null,
        isdisabled: false,
        keyBind: 'enter',
        contentLength: 0,

        invite: {
          dialogVisible: false,
          noTip: false
        }
      }
    },
    computed: {
      ...mapGetters(['engineerCode']),
      ...mapGetters('call', [
        'currentSession',
        'currentSessionID',
        'IMReady'
      ])
    },
    watch: {
      'keyBind': function(val) {
        getLocalStorage().setItem(STORAGE_KEY, val)
      },
      'currentSession.state': function(state) {
        this.$nextTick(() => {
          this.isdisabled = state === 'stop'
        })
      },
      'currentSessionID': function(id, prevId) {
        const draft = this.$refs.chatTextarea.innerHTML.trim()
        if (draft) {
          this.saveDraft({ sessionId: prevId, draft: draft })
          this.$refs.chatTextarea.textContent = ''
        } else {
          this.saveDraft({ sessionId: prevId, draft: '' })
        }
        this.$nextTick(() => {
          this.$refs.chatTextarea.innerHTML = this.currentSession.draft
          this.$refs.chatTextarea.focus()
        })
      }
    },
    mounted() {
      this.$nextTick(() => {
        const keyBind = getLocalStorage().getItem(STORAGE_KEY)
        if (keyBind) {
          this.keyBind = keyBind
        }
      })
    },
    methods: {
      ...mapActions('call', [
        'saveDraft',
        'sendMessage',
        'sendImage',
        'addSystemMessage',
        'tryFixUserAccount',
        'changeRightRouter'
      ]),
      // 将光标挪到末尾
      _moveToEnd() {
        const selection = window.getSelection()
        const range = selection.getRangeAt(0)
        if (range) {
          range.setStartAfter(this.$refs.chatTextarea.lastChild)
        }
      },
      // 插入表情
      insertEmoji(emojiEl) {
        this.$refs.chatTextarea.innerHTML += emojiEl
      },
      checkContentLength: debounce(function() {
        this.contentLength = this.$refs.chatTextarea.innerText.length
      }, 300),
      // 当用户和客服交互超过3回合，才能使用邀评功能
      readyForInvite() {
        // todo 需要处理刷新后的邀评状态，session 里得有个字段进行了标识
        const messages = this.currentSession.messages
        if (!messages.length) {
          return false
        }

        // 只有双方的对话信息，才会包含isEngineer 属性
        const chatMessages = messages.filter(m => m.hasOwnProperty('isEngineer') && m.sessionId === this.currentSessionID)
        const userMsgs = chatMessages.filter(m => !m.isEngineer)
        const engineerMsgs = chatMessages.filter(m => m.isEngineer)
        return userMsgs.length > 3 && engineerMsgs.length > 3
      },
      // 尝试发送邀评，如果设置了不提示，则直接发送
      tryInviteComment() {
        if (!this.readyForInvite()) {
          return this.$message.info('当前会话沟通内容较少，不满足邀评条件')
        }

        if (!this.invite.noTip) {
          return this.invite.dialogVisible = true
        }

        this.inviteComment()
      },
      // 发送邀评
      inviteComment() {
        this.invite.dialogVisible = false

        checkInviteComment(this.currentSessionID).then(res => {
          if (res.data) {
            return this.$message.warning('该会话已经发起过邀评，不能重复发送')
          }
          inviteComment(this.currentSession).then(() => {
            this.$message.success('发送邀评成功')
            this.addSystemMessage({ session: this.currentSession, text: '邀评信息已发送' })
          }).catch(this.$message.error)
        })
      },
      trySendMessage(event, from) {
        let isContinue = false
        // if not ctrl key mode
        if (from === 'enter' && event.ctrlKey && this.keyBind === 'ctrl+enter') {
          isContinue = true
        } else if (from === 'enter' && !event.ctrlKey && this.keyBind === 'enter') {
          isContinue = true
        } else if (from === 'alt' && event.altKey && this.keyBind === 'alt+s') {
          isContinue = true
        }

        // 仅针对有from 属性，即是组合键过来的
        if (!isContinue && from) {
          return
        }

        const innerText = this.$refs.chatTextarea.innerText
        let message = ''
        if (!innerText && !this.$refs.chatTextarea.innerHTML) {
          message = '输入内容不能为空'
        } else if (innerText.length > 650) {
          message = '输入内容过长，请拆分后发送'
        }

        if (message) {
          this.$notify.error({
            title: '错误',
            position: 'bottom-right',
            message
          })
          return
        }

        const session = this.currentSession
        const nodes = Array.prototype.slice.call(this.$refs.chatTextarea.childNodes)
        if (nodes.length < 1) {
          return
        }

        const preCompressNodes = []
        const compressNodes = []

        nodes.forEach((node) => {
          // 处理文本串和换行（被解释为DIV）
          if (node.nodeName === '#text' || node.nodeName === 'DIV') {
            const text = node.textContent.trim()
            if (text) {
              preCompressNodes.push(text)
            }
          } else if (node.nodeName === 'IMG' && node.className === 'emoji-icon') {
            // preCompressNodes.push(`[${node.title || node.dataset.title}]`)
            if (!isNaN(node.title)) {
              preCompressNodes.push(WEIXIN_QQ_TEXT_LIST[parseInt(node.title || node.dataset.title)])
            } else {
              preCompressNodes.push(`[${node.title || node.dataset.title}]`)
            }
          } else if (node.nodeName === 'A') {
            preCompressNodes.push(node.outerHTML)
          } else if (node.nodeName === 'IMG') {
            preCompressNodes.push(node)
          }
        })

        // 将临近的文本和表情合并
        preCompressNodes.forEach((preNode) => {
          const last = compressNodes.pop()
          if (typeof last === 'undefined') {
            if (typeof preNode === 'string') {
              compressNodes.push([preNode])
              return
            }
            compressNodes.push(preNode)
          } else if (Object.prototype.toString.call(last) === '[object Array]') {
            if (typeof preNode === 'string') {
              last.push(preNode)
              compressNodes.push(last)
              return
            }

            compressNodes.push(last)
            compressNodes.push(preNode)
          } else {
            compressNodes.push(last)
            if (typeof preNode === 'string') {
              compressNodes.push([preNode])
              return
            }

            compressNodes.push(preNode)
          }
        })

        // 将混排消息转为单条消息，逐条发送消息
        // let sessionMe = this.currentSession
        const sender = (cnode) => {
          if (Object.prototype.toString.call(cnode) === '[object Array]') {
            return this.sendMessage({ text: cnode.join(''), session })
          }

          return this.sendImage({
            base64: cnode.src,
            fileSize: cnode.getAttribute('size'),
            session
          })
        }

        const loop = (promise, next) => {
          return promise.then(next).then((it) => {
            return !it.done && loop(sender(it.value[1]), next)
          })
        }

        // https://www.w3ctech.com/topic/916
        // http://devdocs.io/javascript/global_objects/array/entries
        Promise.resolve(compressNodes.entries()).then((iter) => {
          return loop(Promise.resolve('begin'), iter.next.bind(iter))
        }).then((done) => {
          this.$refs.fileForm.reset()
        }).catch(({ error, message }) => {
          // 用户未登录IM 自动处理 20003
          if (this.$get(error, 'ErrorCode') === 20003) {
            this.tryFixUserAccount({ session }).then(() => {
              this.$message('检测并修复了异常用户，请重新发送内容')
            })
          }
        })

        this.$refs.chatTextarea.textContent = ''
        event && event.preventDefault()
      },
      fileChange(e) {
        const files = e.target.files
        this.$refs.chatTextarea.focus()

        if (!files.length) {
          return
        }

        // 如果是文件是图片则按照图片方式传输，如果是其他格式文件则走文件传输
        if (/.*\.(jpg|gif|bmp|jpeg|png)/.test(files[0].name.toLowerCase())) {
          this.createImage(files[0])
        } else {
          alert('请选择图片类型文件')
        }

        e.target.value = null
      },
      paste(e) {
        const copiedData = e.clipboardData.items[0]
        if (!copiedData) {
          return e.preventDefault()
        }

        if (copiedData.type.indexOf('image') === 0) {
          const imageFile = copiedData.getAsFile()
          this.createImage(imageFile)
          return
        }

        e.preventDefault()

        const text = e.clipboardData.getData('text/plain')
        document.execCommand('insertText', false, text)
      },
      drop(e) {
        Array.prototype.slice.call(e.dataTransfer.files).forEach((file) => {
          if (file.type.indexOf('image') > -1) {
            this.createImage(file)
          }
        })
        e.preventDefault()
      },
      createImageTag(evt, fileSize) {
        let result = evt

        if (typeof (evt) === 'object') {
          result = evt.target.result // base64 encoded image
        }

        /* Create an image element and append it to the content editable div */
        const img = document.createElement('img')
        img.src = result
        img.setAttribute('size', fileSize)
        img.style.maxHeight = '70px'
        img.style.maxWidth = '150px'
        img.dataset.index = imageFileList.length

        this.$refs.chatTextarea.appendChild(img)
      },
      createImage(imageFile) {
        const reader = new FileReader()

        imageFileList.push(imageFile)

        reader.onload = (evt) => {
          this.createImageTag(evt, imageFile.size)
          this._moveToEnd()
        }
        reader.readAsDataURL(imageFile)
      },
      setContent(content) {
        this.$refs.chatTextarea.textContent += content
        this.$refs.chatTextarea.focus()
        this._moveToEnd()
      }
    }
  }
</script>

<style>
  .chat-operation .el-button.el-button--primary.el-button--mini {
    line-height: inherit;
  }
</style>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .editor-container {
    background-color: #f9f9f9;
    transition: background-color 500ms;
    position: relative;
    border-top: 1px solid $borderColor;

    &:hover, &:focus {
      background-color: white;
    }

    &.isdisabled:after {
      position: absolute;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
      content: "已关闭的会话或是IM未登录，不能交互";
      font-size: 14px;
      display: block;
      background-color: ghostwhite;
      color: #888;
      opacity: 0.92;
      z-index: 200;
      padding-top: 100px;
      text-align: center;
    }

    .editor-toolbar {
      height: 45px;
      padding: 10px 10px 10px 15px;
      flex: none;

      ul {
        margin-left: 6px;

        li {
          float: left;
          margin-right: 20px;

          .icon {
            font-size: 28px;
            line-height: 28px;
            color: $lldark;
            cursor: pointer;
            transition: color 200ms;

            &.disabled {
              color: lighten($lldark, 20%);
            }
          }

          .icon:hover {
            color: $dark;
          }
        }

        .toolitem-right {
          float: right;
          margin-right: 5px;
        }
      }

      .fa {
        font-size: 20px;
        color: $ldark;

        &:hover {
          color: $base;
        }
      }

      label {
        font-weight: normal;
      }

      form {
        display: none;
      }
    }

    .editor-field {
      outline: none;
      margin: 15px 20px 50px;
      font-size: 16px;
      height: 100px;
      color: $dark;
      line-height: 1.5;
      cursor: pointer;
      flex: none;
      overflow-y: auto;
      overflow-x: hidden;
      word-break: break-word;
      /*-webkit-user-select: auto;*/

      .item-img {
        width: 200px;
      }

      /deep/ .emoji-icon {
        width: 28px;
        vertical-align: middle;
        margin-top: -5px;
      }
    }

    .chat-operation {
      text-align: right;
      position: absolute;
      right: 20px;
      bottom: 15px;

      /deep/ .el-dropdown.disabled .el-button {
        background-color: $bg-blue;
        border-color: $borderColor;
      }
    }
  }

  .chat-operation-item label {
    width: 100%;
    height: 100%;
    line-height: 30px;
  }

  .emoji_container {
    z-index: 1100;
  }
</style>
