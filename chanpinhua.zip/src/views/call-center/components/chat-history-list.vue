<template>
  <div>
    <el-table
      class="history-list"
      :data="tableData"
      max-height="230"
      style="width: 100%"
      @row-click="handleRowClick"
    >
      <el-table-column
        prop="created_at"
        label="开始时间"
        width="150"
      />
      <el-table-column
        prop="emotion"
        label="结束情感"
        width="100"
      />
      <el-table-column
        prop="id"
        label="接触ID"
        width="160"
      />
    </el-table>
    <div class="pagination-container mt5">
      <el-pagination
        background
        :current-page.sync="mypagination.current_page"
        :page-size="mypagination.datanum"
        layout="prev, pager, next"
        :total="mypagination.total"
        @current-change="currentChange"
      />
    </div>
  </div>
</template>

<script>
  import { getSessionsList } from '@/api/call-center/call-center'
  import { mapGetters } from 'vuex'

  export default {
    data() {
      return {
        cubeUid: '',
        mypagination: {
          current_page: 1,
          datanum: 5,
          total: 1
        },
        tableData: []
      }
    },
    watch: {
      session(newValue) {
        this.cubeUid = newValue.cube_uid
        this.mypagination.current_page = 1
        if (this.session.cube_uid) {
          this.fetchData(this.mypagination.current_page)
        } else {
          this.mypagination.total = 0
          this.tableData = []
        }
      }
    },
    mounted() {
      this.cubeUid = this.session.cube_uid
      this.mypagination.current_page = 1
      if (this.session.cube_uid) {
        this.fetchData(this.mypagination.current_page)
      }
    },
    computed: mapGetters('call', {
      session: 'currentSessionOrDefault'
    }),
    methods: {
      currentChange(val) {
        this.mypagination.page = val
        this.fetchData(val)
      },
      fetchData(page) {
        getSessionsList(this.cubeUid, page, this.mypagination.datanum).then(res => {
          this.mypagination.total = res.data.total
          this.tableData = res.data.data
        })
      },
      handleRowClick(row) {
        this.$router.push(`history?id=${row.id}`)
      }
    }
  }
</script>

<style scoped>
  .history-list {
    background: transparent;
    padding-left: 10px;
  }
</style>
