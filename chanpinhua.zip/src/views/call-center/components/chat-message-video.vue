<template>
  <p class="chat-content-video" @click="play">
    <span v-if="!isReady && tryCount <= 5" class="loading">
      <i class="el-icon-video-camera" />
      <i class="el-icon-loading" />
      视频加载中
    </span>
    <span v-if="!isReady && tryCount > 5" class="loading">
      <i class="el-icon-warning-outline" />
      视频资源加载失败，点击重试
    </span>
    <transition name="fade">
      <video
          ref="media"
          v-show="isReady"
          :src="asyncSrc"
          @error="retry"
          @loadedmetadata="loaded"
          @ended="onEnd"
          preload="metadata" />
    </transition>
  </p>
</template>

<script type="text/ecmascript-6">
  import { mapGetters, mapMutations } from 'vuex'

  export default {
    props: ['message'],
    data() {
      return {
        playing: false,
        asyncSrc: '',
        isReady: false,

        tryCount: 0
      }
    },
    computed: {
      ...mapGetters('call', ['audioPlaying'])
    },
    watch: {
      'audioPlaying': function(playItem) {
        if (playItem && this._uid !== playItem && this.playing) {
          this.playing = false
          this.$refs.media.pause()
          this.$refs.media.currentTime = 0
        }
      }
    },
    mounted() {
      // 语音文件由于是异步转存七牛，需要一个时间
      this.$nextTick(() => {
        this.asyncSrc = this.message.content
      })
    },
    beforeDestroy() {
      if (this.playing) {
        this.$refs.media.pause()
      }
    },
    methods: {
      ...mapMutations('call', ['AUDIO_PLAYING']),
      play() {
        if (!this.isReady) {
          if (this.tryCount > 5) {
            this.tryCount = 0
            this.retry()
          }
          return
        }

        if (this.playing) {
          this.$refs.media.pause()
          this.$refs.media.currentTime = 0
          this.AUDIO_PLAYING(false)
        } else {
          this.$refs.media.play()
          this.AUDIO_PLAYING(this._uid)
        }
        this.playing = !this.playing
      },
      // pause() {
      //   this.playing = false
      //   this.$refs.media.pause()
      // },
      loaded() {
        this.isReady = true
      },
      onEnd() {
        this.AUDIO_PLAYING(false)
        this.playing = false
      },
      retry() {
        if (this.playing) {
          this.onEnd()
        }

        // 延迟1s 再次请求
        if (this.tryCount++ < 5) {
          setTimeout(() => {
            this.asyncSrc = this.message.content + '?t=' + this.tryCount
          }, 1000 + 500 * this.tryCount)
        }
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .chat-content-video {
    padding-bottom: 2px !important;
    line-height: 0;
    border-radius: 5px;


    span.loading {
      width: 200px;
      height: 306px;
      display: inline-block;
      padding-top: 100px;
      text-align: center;

      .el-icon-video-camera, .el-icon-warning-outline {
        display: block;
        font-size: 40px;
        color: #fff;
      }
    }

    video {
      height: 300px;
      max-width: 400px;
      cursor: pointer;
    }
  }
</style>
