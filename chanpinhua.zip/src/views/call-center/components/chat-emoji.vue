<template>
  <ul>
    <li @click.stop="insertText(item)" v-for="(item, index) in emojiList" :key="index">
      <a :title="item.title" :data-index="index">
        <img class="emoji-icon" :src="item.emoji" :title="item.title">
      </a>
    </li>
  </ul>
</template>

<script>
  import { emojiOptions } from '@/utils/emoji'

  function getEmoji(option) {
    return option.data.filter((emoji, index) => !option.excludeNums.includes(index)).map(emoji => {
      return {
        title: emoji.cn,
        emoji: `${option.path}${emoji.en}${option.ext}`
      }
    })
  }

  export default {
    name: 'chat-emoji',
    data() {
      return {
        emojiList: []
      }
    },
    methods: {
      insertText(item) {
        const imgSrc = `<img class='emoji-icon' src='${item.emoji}' title='${item.title}'>`
        this.$emit('insertEmoji', imgSrc)
      }
    },
    mounted() {
      this.emojiList = getEmoji(emojiOptions)
    }
  }
</script>

<style lang='scss' scoped>
  ul {
    height: 200px;
    overflow-x: hidden;
    overflow-y: scroll;
    cursor: pointer;

    li {
      float: left;
      border-radius: 4px;
      border: 1px solid #fff;
      padding: 0;
      margin: 0;
      transition: all 200ms ease;

      a {
        vertical-align: middle;
        line-height: 1;
        display: inline-block;
      }

      &:hover {
        background-color: lightcyan;
        border-color: lightblue;
      }
    }
  }

  .emoji-icon {
    margin-right: 0;
    width: 40px;
    height: 40px;
  }
</style>
