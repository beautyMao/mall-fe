<template>
  <div class="voice-user-list">
    <el-form
      ref="phones"
      :rules="phonesRules"
      :model="phones"
      @submit.native.prevent>
      <el-form-item v-if="isDialAction">
        <el-select v-model="phones.skill" size="medium" placeholder="请选择业务">
          <el-option v-for="opt in allInfo.phone_queues" :label="opt.name" :value="opt.id" :key="opt.id"></el-option>
        </el-select>
      </el-form-item>
      <el-form-item prop="tel">
        <el-input
          v-model="phones.tel"
          size="medium"
          ref="telInput"
          @keyup.enter.native="onSubmit"
          :type="type === 'transfer' ? 'number' : 'text'"
          :placeholder="type === 'transfer' ? `请输入转接电话` : type === 'meeting' ? `请输入会议电话` : `请输入外拨电话`">
          <el-button type="primary" slot="append" @click.prevent="onSubmit" icon="el-icon-phone"/>
        </el-input>
      </el-form-item>
    </el-form>
    <div class="voice-serve-list">
      <h2>我的服务</h2>
      <div
        v-for="(item, index) in service"
        :key="index"
        class="flex-wrp flex-between item"
        @click="phones.tel = item.phone === null ? '' : removePhonePrefix(item)"
      >
        <span class="ellipsis">{{ !item.user_name ? item.phone : `${item.user_name} / ${item.phone}` }}</span>
        <span style="width: 150px;text-align: right">{{ !item.start_talking_at ? '' : item.start_talking_at }}</span>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapGetters } from 'vuex'
  import { removePhonePrefix } from '@/store/modules/call-center/voice/util'
  import { getLocalStorage } from '@/utils/local-storage'

  export default {
    props: ['visible', 'type', 'complete', 'dialing'],
    data() {
      return {
        phones: {
          tel: '',
          skill: ''
        },
        phonesRules: {
          tel: [
            { required: true, message: '请输入电话号码', trigger: 'change' },
            {
              min: this.type === 'transfer' ? 8 : 5,
              max: 16,
              message: `请输入正确的号码${this.type === 'transfer' ? ', 且禁止内部转接' : ''}`,
              trigger: 'change'
            }
          ]
        }
      }
    },
    computed: {
      ...mapGetters(['allInfo']),
      ...mapGetters('call', [
        'service'
      ]),
      isDialAction() {
        return this.dialing === true
      }
    },
    watch: {
      visible(status) {
        !status && this.$refs['phones'].resetFields()
        if (status) {
          this.$nextTick(() => {
            this.$refs.telInput.focus()
          })
        }
      },
      'phones.skill': function(skill) {
        if (skill) {
          getLocalStorage().setItem('SOFTPHONE_DIAL_SKILL', skill)
        }
      },
      // 路由唤起拨号盘
      // todo 限定条件下，不能拨打电话
      '$route.query.callNumber': function(callNumber) {
        if (callNumber) {
          this.phones.tel = callNumber
          // 移除query 参数
          this.$nextTick(() => {
            const query = { ...this.$route.query || {}}
            delete query.callNumber
            this.$router.replace({
              path: this.$route.path,
              query
            })
          })
        }
      }
    },
    mounted() {
      let bid = getLocalStorage().getItem('SOFTPHONE_DIAL_SKILL')
      if (bid) {
        bid = parseInt(bid)
        const target = this.allInfo.phone_queues.find(item => item.id === bid)
        if (!target) {
          bid = ''
        }
      }
      this.phones.skill = bid
    },
    methods: {
      removePhonePrefix(item) {
        let phoneLike = ''
        if (item.phone) { // 我的服务
          phoneLike = item.phone
        }
        return removePhonePrefix(phoneLike)
      },
      onSubmit() {
        this.$refs['phones'].validate(valid => {
          if (valid) {
            const params = { tel: this.phones.tel }
            if (this.dialing) {
              params.skill = this.phones.skill
            }
            this.$emit('onsubmit', params)
          } else {
            return false
          }
        })
      }
    }
  }
</script>

<style lang="scss" scoped>
  .voice-user-list {
    .voice-serve-list {
      height: 300px;
      overflow-y: auto;

      h2 {
        font-size: 14px;
        font-weight: bold;
      }
      .item {
        height: 40px;
        line-height: 40px;
        font-size: 14px;
        color: #323232;
        cursor: pointer;
        background: #fff;
        transition: all .3s;

        &:hover {
          background: #f5f7fa;
        }
        span {
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }
      }
    }
  }
</style>

