<template>
  <div class="chat-window">
    <chat-topbar />

    <ul ref="list" class="chat-list">
      <chat-message
        v-for="message in currentSession.messages"
        v-if="currentSession.messages"
        :key="message.id"
        :message="message"
        :session="currentSession"
        @image="handleImageView"
      />
    </ul>

    <chat-editor />

    <context-menu
      :target="contextMenuTarget"
      :show="contextMenuVisible"
      @update:show="showHandle"
    >
      <a :class="{disabled: contextMenuDisabled}" @click="searchContent">检索内容 <span>{{ selectRange }}</span></a>
    </context-menu>
    <image-viewer ref="viewer" :srcs="imageList" />
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex'
  import ChatTopbar from './chat-topbar'
  import ChatEditor from './chat-editor'
  import ChatMessage from './chat-message'
  import ContextMenu from '@/components/ContextMenu'
  import ImageViewer from '@/components/ImageViewer'
  import { MESSAGE_TYPE } from '@call/msg-util'
  import { QINIU_HOST, QINIU_IMAGEVIEW } from '@/api/qiniu'

  export default {
    components: {
      ChatTopbar, ChatEditor, ChatMessage, ContextMenu, ImageViewer
    },
    data() {
      return {
        lastId: '',
        scrollTop: 0,
        imageList: [],

        contextMenuVisible: false,
        contextMenuTarget: null,
        contextMenuDisabled: false,
        selectRange: ''
      }
    },
    computed: {
      ...mapGetters('call', [
        'currentSession',
        'currentSessionID'
      ])
    },
    watch: {
      'currentSessionID': function() {
        this.lastId = ''
        this.$refs.viewer.imageViewClose()
      },
      'currentSession.messages': function(messages) {
        if (!messages || !messages.length) {
          return
        }

        // 仅最后一条发生变化时，更新滚动条，否则在查看历史时会乱跳
        const last = messages[messages.length - 1]
        if (this.lastId !== last.id) {
          this.$nextTick(() => {
            const ul = this.$refs.list
            ul.scrollTop = ul.scrollHeight
          })
          this.lastId = last.id
        }
      }
    },
    mounted() {
      // 初始化右键菜单
      // this.contextMenuTarget = this.$refs.list
    },
    activated() {
      this.$nextTick(() => {
        this.$refs.list.scrollTop = this.scrollTop
      })
    },
    deactivated() {
      this.scrollTop = this.$refs.list.scrollTop
    },
    methods: {
      searchContent() {
        this.contextMenuVisible = false
        if (!this.selectRange) {
          return
        }
        const text = String.prototype.trim.call(this.selectRange)
        if (text) {
          this.$router.push({
            path: this.$route.path,
            query: { tab: 'search', search: text }
          })
        }
      },
      showHandle(show) {
        this.contextMenuVisible = show
        // 检测是否有选取内容
        if (show) {
          const selection = window.getSelection()
          const range = selection.getRangeAt(0)
          if (range && range.startContainer.data) {
            this.selectRange = range.startContainer.data.substring(range.startOffset, range.endOffset)
            this.contextMenuDisabled = this.selectRange === ''
          }
        }
      },
      handleImageView(target) {
        const imageMessages = this.currentSession.messages.filter(m => m.type === MESSAGE_TYPE.Image)
        if (imageMessages.length) {
          const index = imageMessages.findIndex(m => m.content === target)
          this.imageList = imageMessages.map(m => {
            if (m.content.includes(QINIU_HOST)) {
              return m.content + QINIU_IMAGEVIEW
            }
            return m.content
          })
          this.$refs.viewer.showViewer(index)
        }
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .chat-window {
    flex: 1;
    display: flex;
    flex-direction: column;
    height: calc(100vh - (34px + 50px));

    .chat-list {
      flex: 1;
      overflow-y: auto;
      background-color: $white;
      color: $dark;
      padding-bottom: 10px;
    }

    .context-menu {
      a > span {
        color: $link;
      }
    }
  }
</style>
