<template>
  <div ref="contextMenuTarget" class="user-list-container">
    <chat-serve-info />
    <ul class="user-list">
      <!-- 占位session 当有电话权限但无电话会话框时出现 -->
      <voice-placeholder-session />
      <transition-group name="slide-fade" mode="out-in" tag="ul">
        <component
          :is="'session-' + session.client_type"
          v-for="session in orderedSessions"
          :key="session.id"
          :session="session"
        />
      </transition-group>
    </ul>

    <context-menu
      :target="contextMenuTarget"
      :show="contextMenuVisible"
      @update:show="(show) => this.contextMenuVisible = show"
    >
      <a @click="refresh">刷新会话列表</a>
    </context-menu>

    <error-report />
    <softphone-feedback v-if="hasVoicePermission" />
    <mock-user v-if="!isProd" />
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapActions, mapGetters } from 'vuex'
  import { ClientType } from '@/store/modules/call-center/enum'

  import ChatServeInfo from './chat-serve-info'
  import ChatSession from './chat-session'
  import VoiceSession from './voice-session'
  import VoicePlaceholderSession from './voice-placeholder-session'

  import ContextMenu from '@/components/ContextMenu'
  import ErrorReport from './error-report'
  import SoftphoneFeedback from '@/views/call-center/components/softphone-feedback'
  import MockUser from './mock/mock-user'
  import { isProd } from '@/utils'

  export default {
    components: {
      ['session-' + ClientType.Wechat]: ChatSession,
      ['session-' + ClientType.Webchat]: ChatSession,
      ['session-' + ClientType.Telephone]: VoiceSession,
      VoicePlaceholderSession,
      ChatServeInfo,
      ContextMenu,
      ErrorReport,
      SoftphoneFeedback,
      MockUser
    },
    data() {
      return {
        contextMenuVisible: false,
        contextMenuTarget: null,

        timer: null,

        isProd
      }
    },
    computed: {
      ...mapGetters('call', [
        'sessions',
        'IMReady',
        'hasVoicePermission'
      ]),
      orderedSessions() {
        return Object.values(this.sessions).sort((a, b) => {
          return new Date(b.created_at).getTime() - new Date(a.created_at).getTime()
        }).sort((a, b) => {
          return Number(a.isVirtual) - Number(b.isVirtual)
        })
      }
    },
    watch: {
      // 关闭自动刷新会话列表功能
      'IMReady': function(isReady) {
        if (!isReady) {
          console.log('IM 断开，关闭自动刷新会话列表功能')
          clearInterval(this.timer)
        }
      }
    },
    mounted() {
      // https://devdocs.io/vue~2/api/index#ref
      // ref 在vue 的render 之后才会生成
      this.contextMenuTarget = this.$refs.contextMenuTarget

      // 每隔30s 刷新会话
      if (isProd) {
        this.timer = setInterval(this.checkAndRefresh, 30 * 1000)
      }
    },
    beforeDestroy() {
      clearInterval(this.timer)
    },
    methods: {
      ...mapActions('call', [
        'refreshSessions'
      ]),
      checkAndRefresh() {
        // 如果有增减，就应该触发检查IM轮询是否正常
        this.refreshSessions().then(promiseData => {
          if (promiseData.length > 1) {
            this.$message.success('自动刷新会话列表完成')
            // todo check im loop
          }
        })
      },
      refresh() {
        this.contextMenuVisible = false
        this.refreshSessions().then(done => {
          this.$message.success('会话列表刷新成功')
        }).catch(error => {
          this.$message.error('会话列表刷新失败' + error)
        })
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .user-list-container {
    width: 280px;
    min-width: 280px;
    border-right: 1px solid $borderColor;
    background-color: $bg-light-blue;
    overflow-x: hidden;
    display: flex;
    flex-direction: column;
  }

  .user-closed-head {
    height: 40px;
    line-height: 40px;
    font-size: 14px;
    color: $ldark;
    background-color: $lightWhite;
    display: flow-root;
    border-top: 1px solid $borderColor;
    border-bottom: 1px solid $borderColor;
    padding-left: 10px;
    padding-right: 10px;

    a.link {
      color: $link;
      cursor: pointer;
      float: right;
    }
  }

  .user-list {
    overflow-y: auto;
    flex: 1;

    li.tip {
      width: 100%;
      border: none;
      border-bottom: 1px solid $borderColor;
      padding-left: 5px;
      font-size: 12px;
      line-height: 30px;
      color: $ldark;
      background-color: lightgoldenrodyellow;
    }
  }

  .slide-fade-enter-active {
    transition: all .3s ease;
  }
  .slide-fade-leave-active {
    transition: all .3s cubic-bezier(1.0, 0.5, 0.8, 1.0);
  }
  .slide-fade-enter, .slide-fade-leave-to
    /* .slide-fade-leave-active for below version 2.1.8 */ {
    transform: translateX(20px);
    opacity: 0;
  }
  .slide-fade-move {
    transition: transform 0.5s;
  }
</style>
