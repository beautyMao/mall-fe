<template>
  <div class="transfer-wrap">
    <el-tabs v-model="activeName" class="transfer">
      <el-tab-pane label="队列" name="first">
        <el-input v-model="bigQueueInp" clearable @keyup.enter.native="searchBig">
          <i slot="prefix" class="el-input__icon el-icon-search" />
        </el-input>
        <div class="crumbs">
          <div v-show="!returnQueue">
            <span @click="returnList">业务</span>
            <span v-show="listQueueVisible">> 队列</span>
          </div>
          <div v-show="returnQueue">
            <span>搜索结果</span>
            <el-button type="text" class="toRight" @click="returnList">返回队列列表</el-button>
          </div>
        </div>
        <ul v-show="bigBusVisbible" class="trans-list list-height">
          <li
            v-for="(item, i) in businessArr"
            :key="i"
            :class="{'selected': i == busIndex}"
            @click="getTransQueue(item.id, i)"
          >
            <span class="right-arrow"><svg-icon icon-class="arrowRight" class="arrow" /></span>{{ item.name }}
          </li>
        </ul>
        <ul v-show="bigQueueVisibile" class="trans-list list-height">
          <li v-for="(item, i) in transList" :key="i" :class="{'selected': i == active}" @click="transferPars(item, i)">
            <span v-if="item.recommend"><span class="recommend">推荐队列</span><span
              class="strong"
            >{{ item.name }}</span></span>
            <span v-else="">{{ item.name }}</span>
          </li>
        </ul>
        <div class="to-center">
          <el-button size="medium" type="primary" :disabled="queueTrans" @click="transferQueue">转接</el-button>
        </div>
      </el-tab-pane>
      <el-tab-pane label="个人" name="second">
        <el-input v-model="personQueueInp" clearable @keyup.enter.native="searchPersonal">
          <i slot="prefix" class="el-input__icon el-icon-search" />
        </el-input>
        <div v-show="searchVisible">
          <div class="crumbs">
            <span @click="returnVisible">业务 </span>
            <span v-show="queueCrumbs" @click="returnQueueList">> 队列 </span>
            <span v-show="engVisible">> 客服</span>
          </div>
          <ul v-show="busListVisibile" class="trans-list list-height">
            <li
              v-for="(item, i) in businessArr"
              :key="i"
              :class="{'selected': i == busIndex}"
              class="text-nowrap"
              :title="item.name"
              @click="busQueue(item.id, i)"
            >
              <span class="right-arrow"><svg-icon icon-class="arrowRight" class="arrow" /></span>{{ item.name }}
            </li>
          </ul>
          <ul v-show="queueListVisibile" class="queue-list list-height">
            <li
              v-for="(item, i) in transListPerson"
              :key="i"
              :class="{'selected': i == queue}"
              :title="item.name"
              @click="personList(item.code, i)"
            >
              <span v-if="item.recommend"><span class="recommend">推荐队列</span><span
                class="strong"
              >{{ item.name }}</span></span>
              <span v-else=""><span class="right-arrow"><svg-icon icon-class="arrowRight" class="arrow" /></span>{{ item.name }}</span>
            </li>
          </ul>
          <ul v-show="engListVib" class="engineer-list list-height">
            <li
              v-for="(item, i) in engineerList"
              :key="i"
              :class="{'selected': i == engI}"
              @click="selectEngineer(item, i)"
            >
              {{ item.name }} / {{ item.code }}
              <span v-if="item.status === 1" class="ready status">就绪</span>
              <span v-else-if="item.status === 2" class="busy status">忙碌</span>
              <span v-else class="busy status">排队满</span>
            </li>
          </ul>
        </div>
        <div v-show="!searchVisible">
          <div class="crumbs">
            <el-button type="text" class="toRight" @click="returnPerson">返回队列列表</el-button>
            搜索结果
          </div>
          <ul class="search-englist list-height">
            <li
              v-for="(item, i) in searchEngList"
              :key="i"
              :class="{'selected': i == queueIndex}"
              @click="selSearchEng(item, i)"
            >
              <span v-if="item.status === 1" class="status ready">就绪</span>
              <span v-else-if="item.status === 2" class="status busy">忙碌</span>
              <span v-else class="status busy">排队满</span>
              <span
                class="search-name"
                :title="item.name"
              >{{ item.engName }} / {{ item.engCode }} / {{ item.name }}</span>
            </li>
          </ul>
        </div>
        <div class="to-center">
          <el-button size="medium" type="primary" :disabled="personTrans" @click="transferPersonal">转接</el-button>
        </div>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script>
  import {
    businessList,
    businessQueue,
    transferEngneersList,
    transPersonQueue,
    transSearchBigQueue
  } from '@/api/call-center/call-center'
  import { mapActions, mapGetters } from 'vuex'

  export default {
    data() {
      return {
        engCode: this.$store.getters.allInfo.code, // 客服code
        engName: this.$store.getters.allInfo.name, // 客服name
        searchVisible: true, // 搜索个人队列列表
        bigQueueInp: '', // 搜索大队列input
        personQueueInp: '', // 搜索个人队列input
        activeName: 'first',
        transList: [], // 队列列表
        transListPerson: [], // 个人队列列表
        engineerList: [], // 客服列表
        searchEngList: [], // 搜索客服列表
        queueTrans: true, // 队列【转接】按钮状态
        personTrans: true, // 个人【转接】按钮状态
        transferName: '', // 大队队列名称
        transferId: '', // 大队列队列id
        transferNum: '', // 大队列队列值
        active: '',
        queue: '',
        engI: '',
        queueIndex: '',
        busIndex: '',
        type: 3, // 队列转接标识
        perTransNum: '', // 个人队列队列值
        engineerCode: '', // 个人队列转接客服账号,
        engineerName: '', // 个人队列转接客服名称,
        busListVisibile: true, // 业务列表
        queueListVisibile: false, // 队列列表
        engListVib: false, // 客服列表
        queueCrumbs: false, // 面包屑-队列
        engVisible: false, // 面包屑-客服
        big_customer: 0, // 是不是大客户队列 1是 0不是,全部队列
        returnQueue: false, // 队列--返回队列列表
        businessArr: [],
        bigBusVisbible: true, // 队列-业务列表
        bigQueueVisibile: false, // 队列-队列列表
        listQueueVisible: false // 队列-面包屑
      }
    },
    mounted() {
      this.getBusList()
    },
    computed: {
      ...mapGetters('call', ['currentSession'])
    },
    methods: {
      ...mapActions('call', ['transferSession']),
      getBusList() { // 个人--获取所有业务列表
        this.clearSel()
        businessList().then(response => {
          this.businessArr = response.data
        }).catch(err => {
          this.$report(err, {
            message: '默认获取业务列表失败'
          })
        })
      },
      busQueue(id, i) { // 点击事件--根据业务获取队列
        this.busIndex = i
        this.busListVisibile = false
        this.queueCrumbs = true
        this.queueListVisibile = true
        this.getBusQueue(id)
      },
      getBusQueue(id) { // 根据业务获取队列
        businessQueue(id).then(response => {
          this.transListPerson = []
          this.transListPerson = response.data
        }).catch(err => {
          console.log(err)
        })
      },
      getTransQueue(id, i) { // 获取转接大队列队列
        this.bigQueueVisibile = true
        this.bigBusVisbible = false
        this.listQueueVisible = true
        businessQueue(id).then(response => {
          this.transList = response.data
        }).catch(err => {
          console.log(err)
        })
      },
      searchBig() { // 搜索大队列
        this.returnQueue = true
        if (this.bigQueueInp !== '') {
          transSearchBigQueue(this.bigQueueInp).then(response => {
            if (response.data && response.data.length !== 0) {
              this.bigBusVisbible = false
              this.bigQueueVisibile = true
              this.transList = response.data
            } else if (response.data.length === 0) {
              this.returnList()
            }
          }).catch(err => {
            console.log(err)
          })
        } else {
          this.returnList()
        }
      },
      searchPersonal() { // 搜索个人队列
        if (this.personQueueInp !== '') {
          if (this.personQueueInp === this.engCode) {
            this.$message.warning('不可转接给当前客服')
            return
          }
          this.searchVisible = false
          transPersonQueue(this.engCode, this.personQueueInp).then(response => {
            const newInfor = []
            response.data.map((item, i) => {
              if (item.queueList) {
                for (const j in item.queueList) {
                  const name = { engName: item.name, status: item.status, engCode: item.code }
                  name.name = item.queueList[j].name
                  name.code = item.queueList[j].code
                  newInfor.push(name)
                }
              }
            })
            this.searchEngList = newInfor
          }).catch(err => {
            console.log(err)
            this.returnPerson()
          })
        } else {
          this.returnPerson()
        }
      },
      transferPars(item, i) { // 选择要转接的队列
        this.transferName = item.name
        this.transferId = item.id
        this.transferNum = item.code
        this.active = i
        this.queueTrans = false
      },
      personList(code, i) { // 获取大队列转接的队列列表
        this.engVisible = true
        this.engListVib = true
        this.queueListVisibile = false
        this.queue = i
        this.perTransNum = code
        transferEngneersList(code, this.$store.getters.allInfo.code).then(response => {
          this.engineerList = response.data
        }).catch(err => {
          console.log(err)
        })
      },
      selectEngineer(item, i) { // 选中要转接的客服
        this.engineerName = item.name
        this.engineerCode = item.code
        this.engI = i
        this.personTrans = false
      },
      selSearchEng(item, i) { // 选择搜索客服队列
        this.queueIndex = i
        this.engineerName = item.engName
        this.engineerCode = item.engCode
        this.perTransNum = item.code
        this.personTrans = false
        console.log(this.engineerName, this.engineerCode, this.perTransNum)
      },
      transferQueue() { // 点击转接
        if (this.currentSession.isVirtual) {
          return this.$message.warning('当前会话已经处于案面状态，不能进行转接')
        }
        this.$confirm(`是否将用户转接到"${this.transferName}"`, '', {
          confirmButtonText: '转接',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          const transferPromise = this.transferSession({
            session: this.currentSession,
            toSkill: this.transferNum
          })
          this.handleTransfer(transferPromise)
        }).catch(() => {
        })
      },
      transferPersonal() { // 个人队列转接
        if (this.currentSession.isVirtual) {
          return this.$message.warning('当前会话已经处于案面状态，不能进行转接')
        }
        if (this.engCode === this.engineerCode) {
          return this.$message.warning('不可转接给当前客服')
        }

        this.$confirm(`是否将用户转接到"${this.engineerName}(${this.engineerCode})"`, '', {
          confirmButtonText: '转接',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          const transferPromise = this.transferSession({
            session: this.currentSession,
            toSkill: this.perTransNum,
            toEngineerCode: this.engineerCode
          })
          this.handleTransfer(transferPromise)
        }).catch(() => {
        })
      },
      handleTransfer(promise) {
        promise.then(() => {
          this.$message.success(`转接成功`)
        }).catch(error => {
          this.$message.error(`转接失败，${error}`)
        })
      },
      returnVisible() {
        this.busListVisibile = true
        this.queueListVisibile = false
        this.queueCrumbs = false
        this.engVisible = false
        this.engListVib = false
        this.clearSel()
      },
      returnPerson() {
        this.searchVisible = true
      },
      returnList() {
        this.bigBusVisbible = true
        this.bigQueueVisibile = false
        this.listQueueVisible = false
        this.returnQueue = false
        this.clearSel()
      },
      returnQueueList() {
        this.busListVisibile = false
        this.queueListVisibile = true
        this.engListVib = false
        this.engVisible = false
        this.clearSel()
      },
      clearSel() {
        this.busIndex = -1
        this.queue = -1
        this.engI = -1
        this.busIndex = -1
        this.active = -1
      }
    }
  }
</script>
<style rel="stylesheet/scss" lang="scss" scoped>
  @import "../scss/rules";

  .to-center {
    text-align: center;
  }

  .engineer-list {
    margin: 0 0 20px 0;
    color: #606266;
    font-size: 14px;

    li {
      height: 34px;
      line-height: 34px;

      .status {
        float: right;
      }

      .ready {
        color: #6ABF4A;
      }

      .busy {
        color: #F37261;
      }
    }

    li:hover, .selected {
      cursor: pointer;
      background: #F5F7FA;
    }
  }

  .trans-list,
  .queue-list {
    margin-bottom: 30px;
    color: #606266;
    font-size: 14px;

    li {
      height: 34px;
      line-height: 34px;

      .recommend,
      .right-arrow {
        float: right;
        font-weight: bold;
      }

      .right-arrow {
        font-size: 10px;
      }

      .strong {
        font-weight: bold;
      }
    }

    li:hover, .selected {
      background: #F5F7FA;
      cursor: pointer;
      color: $link;
    }
  }

  .crumbs {
    margin: 20px 0 10px 0;

    span {
      cursor: pointer;
    }

    .toRight {
      float: right;
    }
  }

  .search-englist {
    margin-bottom: 30px;
    width: 100%;

    li {
      height: 34px;
      line-height: 34px;

      .status {
        float: right;
      }

      .ready {
        color: #6ABF4A;
      }

      .busy {
        color: #F37261;
      }

      .search-name {
        height: 34px;
        line-height: 34px;
        width: 240px;
        display: inline-block;
        overflow: hidden;
        text-overflow: ellipsis;
        white-space: nowrap;
      }
    }

    li:hover, .selected {
      background: #F5F7FA;
      cursor: pointer;
      color: $link;
    }
  }

  .transfer-wrap {
    position: relative;
    max-height: 90vh;

    .list-height {
      max-height: calc(90vh - 240px);
      overflow: auto;

      li {
        text-overflow: ellipsis;
        overflow: hidden;
      }
    }

    .list-height::-webkit-scrollbar {
      display: none;
    }
  }
</style>
