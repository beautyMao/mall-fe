<template>
  <div class="right-side flex-wrp">
    <div class="content" :style="{width: '444px'}">
      <keep-alive>
        <component
          :is="currentTab"
          ref="currentCom"
          class="w100 content-wrapper"
          @toggleTab="toggleTab"
        />
      </keep-alive>
    </div>

    <el-menu
      background-color="#727c9b"
      text-color="#bfcbd9"
      active-text-color="#fff"
      :default-active="currentTab"
      :collapse="true"
      @select="handleMenuClick"
    >
      <el-menu-item
        v-for="tab in tabs"
        v-show="tab.visible"
        :key="tab.name"
        class="submenu-title-noDropdown"
        :index="tab.name"
      >
        <svg-icon :icon-class="tab.icon" />
        <span slot="title">{{ tab.title }}</span>
      </el-menu-item>
    </el-menu>
  </div>
</template>

<script type="text/ecmascript-6">
  import { FunctionTab } from '@/store/modules/call-center/enum'
  import Functionals from '@/views/call-center/components/functional'

  import { mapActions, mapGetters } from 'vuex'
  import { ClientType } from '@call/enum'

  // 未接入会话时的显示的tab
  const showTabsWithoutUser = [
    FunctionTab.Msg, FunctionTab.Search
  ]
  // 默认的用户tab
  const defaultUserTab = FunctionTab.User
  const defaultNoneUserTab = FunctionTab.Msg

  export default {
    components: Functionals.components,
    data() {
      return {
        tabs: Functionals.tabs,
        queryTab: ''
      }
    },
    computed: {
      currentTab() {
        return this.$route.query.tab || this.queryTab || defaultNoneUserTab
      },
      ...mapGetters('call', [
        'currentSession',
        'currentSessionID',
        'sessions',
        'currentSessionOrDefault',
        'hasVoicePermission'
      ])
    },
    watch: {
      currentSession(session, prevSession) {
        // 不在当前页下时，不做路由push
        if (this.$route.name === 'call-center') {
          const nextTabRoute = session ? session.rightRoute || defaultUserTab : defaultNoneUserTab
          this.$router.push({
            path: this.$route.path,
            query: { tab: nextTabRoute }
          })
        } else if (session && !session.rightRoute) {
          // 在后台时，也争取的做session tab 跳转
          this.changeRightRouter({ tabName: defaultUserTab })
        }

        // 未接入时隐藏部分tab
        if (!session) {
          this.tabs.forEach(tab => {
            tab.visible = showTabsWithoutUser.includes(tab.name) && tab.originVisible
          })
          return
        }

        // 恢复为原始的显隐状态
        this.tabs.forEach(tab => {
          tab.visible = tab.originVisible
        })

        // 在电话台中，如果没有指向某个会话，会默认显示voice placeholder session
        // 这个虚拟占位session 可以看做是一个ClientType.Telephone 类型，需要隐藏右侧解决方案tab
        if (this.hasVoicePermission && session.client_type === ClientType.Telephone) {
          const caseTab = this.tabs.find(item => item.name === FunctionTab.Case)
          caseTab.visible = false
        }
      }
    },
    activated() {
      // 避免在后台创建的会话，切回来时功能区不响应问题
      if (this.currentSession) {
        this.$router.push({ path: this.$route.path, query: { tab: this.currentSession.rightRoute }})
      }
    },
    mounted() {
      if (!this.currentSession) {
        this.$router.push({ path: this.$route.path, query: { tab: FunctionTab.Msg }})

        this.tabs.forEach(tab => {
          tab.visible = showTabsWithoutUser.includes(tab.name) && tab.originVisible
        })
      }
    },
    methods: {
      ...mapActions('call', [
        'changeRightRouter'
      ]),
      handleMenuClick(tab) {
        this.toggleTab(tab)
      },
      // tab切换
      toggleTab(tab, data, fromPageName) {
        const jumpTo = tab
        if (this.currentSessionOrDefault) {
          this.changeRightRouter({ tabName: jumpTo })
        }
        this.$router.push({ path: this.$route.path, query: { tab: jumpTo }})
        // 如果有额外数据，尝试将数据传入组件
        // 这里不用route params 传递data，是因为route 会被tag 组件存储到sessionStorage 里
        // 会导致刷新页面之后，sessionStorage 里的param data 被错误的应用在另一个用户会话上
        // example：服务记录里有对case 追加功能
        if (data !== undefined) {
          this.$nextTick(() => {
            this.$refs.currentCom.setPageExtData(data, fromPageName)
          })
        }
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";
  @import "./functional/asserts/index";

  .right-side {
    width: 480px;
    height: 100%;
    background-color: $bg-light-blue;
    border-left: 1px solid $borderColor;

    .el-tabs__item.is-top.is-active {
      border-bottom-color: #f0f4fb;
      background: white;
      color: #3E8DDD;
    }

    .el-tabs__nav.is-top.is-stretch {
      border: none;
    }

    .el-tabs.el-tabs--top.el-tabs--border-card {
      border: none;
      box-shadow: none;
      background: none;
    }

    .el-tabs__item.is-top {
      color: #303133;
    }

    .el-menu {
      border-right: none;

      &.el-menu--collapse {
        width: 50px;
      }

      .el-menu-item {
        text-align: center;
      }

      .el-menu-item:hover {
        font-size: 20px;
        color: #fff !important;
      }
    }

    .is-active > .el-submenu__title {
      color: #f4f4f5 !important;
    }

    .submenu-title-noDropdown {
      padding-left: 10px !important;
      position: relative;
      font-size: 15px;

      .el-tooltip {
        padding: 0 10px !important;
      }
    }

    .content {
      position: relative;
    }
  }
</style>
