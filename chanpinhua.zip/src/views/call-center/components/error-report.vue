<template>
  <div class="error-button">
    <el-tooltip effect="dark" content="会话中心：反馈问题" placement="top">
      <el-button type="success" icon="el-icon-bell" circle @click="prepareReport" />
    </el-tooltip>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex'
  import { report } from '@/utils/error-report'

  export default {
    name: 'ErrorReport',
    computed: {
      ...mapGetters([
        'visitedViews',
        'allInfo'
      ]),
      ...mapGetters('call', [
        'currentSessionOrDefault',
        'currentSessionID',
        'sessions'
      ])
    },
    methods: {
      prepareReport() {
        this.$prompt('请简述遇到的问题', '呼叫中心页面，问题反馈', {
          confirmButtonText: '提交反馈',
          cancelButtonText: '取消'
        }).then(({ value }) => {
          report({
            feedback: value || '无反馈内容',
            visitedViews: this.visitedViews,
            allInfo: this.allInfo,
            currentSessionID: this.currentSessionID,
            currentSessionOrDefault: this.currentSessionOrDefault,
            sessions: this.sessions
          }, 'call-center')

          this.$message.success('已反馈，感谢您帮助魔方成长')
        }).catch(() => {
        })
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .error-button {
    position: absolute;
    bottom: 20px;
    left: 20px;
  }
</style>
