<template>
  <div class="chat-window help-info">
    <h1>快速开始</h1>
    <ul>
      <li>截图，并直接在输入框中粘贴</li>
      <li>Enter或Ctrl+Enter 发送消息</li>
      <li>方向上下键在会话之间切换</li>
      <li>ESC 关闭图片查看器</li>
    </ul>
  </div>
</template>

<script type="text/ecmascript-6">
  export default {}
</script>

<style lang='scss' type="text/scss" scoped>
  .chat-window {
    flex: 1;
    display: flex;
    flex-direction: column;
    height: calc(100vh - (34px + 50px));

    &.help-info {
      justify-content: center;
      align-items: center;
      //color: $ldark;
      background-color: white;
      font-size: 16px;
      line-height: 32px;

      a {
        color: dodgerblue;
      }
    }
  }
</style>
