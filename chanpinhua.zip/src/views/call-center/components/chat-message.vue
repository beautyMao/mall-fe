<template>
  <li
    class="chat-item clearfix"
    :class="[message.isEngineer ? 'chat-engineer' : 'chat-user']"
    @mouseleave="showOperationIcon = false"
    @mouseenter="showOperationIcon = true"
  >
    <p v-if="message.sendTime && message.distance === 0" class="chat-timestamp">
      <span v-if="!message.isEngineer">{{ message.authorName }} | </span>
      {{ message.sendTime }}
      <span v-if="message.isEngineer">| {{ message.authorName }} | {{ session.engineer_code }}</span>
    </p>
    <img v-if="!message.isEngineer && message.content" :src="message.avatar" :style="{backgroundColor: session.user_color}" class="chat-head">

    <img v-if="message.isEngineer" :src="message.avatar" class="chat-head">

    <div class="chat-msg-content">
      <i
        v-if="message.error === 'error'"
        class="el-icon el-icon-warning"
        :title="[message.isEngineer ? '重新发送' : '重新获取图片']"
        @click="resendErrorMessage($event)"></i>
      <i v-if="message.error === 'presending'" class="el-icon el-icon-loading"></i>

      <i
        v-if="message.recommendData"
        class="el-icon"
        @click="gotoRecommendPage"
      >
        <img
          v-if="message.isEngineer === true"
          class="bulb"
          src="/static/call-center/img/bulbred.png"
        >
        <img v-else class="bulb" src="/static/call-center/img/bulb.png">
      </i>

      <p
        v-if="message.type === MESSAGE_TYPE.Text"
        :class="{'robot': message.recommendData}"
        class="chat-content"
        v-html="message.safeContent"></p>

      <p v-if="message.type === MESSAGE_TYPE.Image" class="chat-content chat-content-img">
        <span v-if="imageLoading" class="loading">
          图片加载中
          <i class="fa fa-spinner fa-spin msg-state-icon" />
        </span>
        <a v-if="showOperation" :href="imageDownloadURL" title="下载图片" :download="imageDownloadName">
          <i class="link el-icon el-icon-download" />
        </a>

        <img
          v-show="!imageLoading"
          ref="image"
          :src="imageSrc"
          :alt="`查看图片`"
          :title="`查看图片`"
          @click="imageView($event, message.content)"
          @error="imageError($event)"
          @load="imageLoad($event)"
        >
      </p>

      <chat-message-audio
        v-if="message.type === MESSAGE_TYPE.Voice"
        :message="message"
        class="chat-content"
        :class="{'robot': message.recommendData}"
      />

      <chat-message-video
        v-if="message.type === MESSAGE_TYPE.Video"
        :message="message"
        class="chat-content"
      />
    </div>

    <p v-if="message.type === 'more'" class="chat-split">
      <a class="link" data-eslog @click="more">加载更多</a>
    </p>
    <p v-if="message.type === 'split'" class="chat-split">{{ message.text }}</p>
  </li>
</template>

<script type="text/babel">
  import { mapActions } from 'vuex'
  import { MESSAGE_TYPE } from '@/store/modules/call-center/msg-util'
  import ChatMessageAudio from './chat-message-audio'
  import ChatMessageVideo from './chat-message-video'
  import { QINIU_HOST, QINIU_IMAGEVIEW } from '@/api/qiniu'

  const BROKEN_URL = 'static/call-center/img/image-broken.png'

  export default {
    components: { ChatMessageAudio, ChatMessageVideo },
    // 注意这里的session 是当前会话的session
    props: ['message', 'session'],
    data() {
      return {
        imageLoading: true,
        error: false,
        showOperationIcon: false,

        MESSAGE_TYPE
      }
    },
    computed: {
      showOperation() {
        return this.showOperationIcon && !this.message.isEngineer && !this.message.error
      },
      imageSrc() {
        // 只针对存储在七牛上的内容做图片处理： cube.lenovo
        // https://developer.qiniu.com/dora/manual/1279/basic-processing-images-imageview2
        if (this.message.content.includes(QINIU_HOST)) {
          return this.message.content + QINIU_IMAGEVIEW
        }
        return this.message.content
      },
      imageDownloadURL() {
        if (process.env.VUE_APP_ENV_CONFIG === 'dev') {
          return this.message.content
        } else {
          return '/api/csc/resource/download?link=' + this.message.content
        }
      },
      imageDownloadName() {
        return this.message.authorName + this.message.timestamp + '.jpg'
      }
    },
    methods: {
      ...mapActions('call', [
        'loadMoreMessages',
        'sendImage',
        'sendMessage',
        'deleteMessageFromList',
        'customerImageLoadError',
        'reloadCustomerImage',
        'customerImageLoadSuccess'
      ]),
      // Click for send error image
      resendErrorMessage(e) {
        const msg = this.message
        const errorHandle = ({ error, message }) => {
          this.$report(error, message)
          this.$notify.error({
            title: '重发消息失败',
            message: `错误信息：${message}`,
            position: 'bottom-right'
          })
        }

        if (msg.isEngineer) {
          this.deleteMessageFromList({ id: msg.id, session: this.session })
          if (msg.type === MESSAGE_TYPE.Image) {
            this.sendImage({ base64: msg.content, session: this.session }).catch(errorHandle)
          } else if (msg.type === MESSAGE_TYPE.Text) {
            this.sendMessage({ text: msg.content, session: this.session }).catch(errorHandle)
          }
        } else if (msg.type === MESSAGE_TYPE.Image) {
          this.reloadCustomerImage({ message: msg, session: this.session })
        }
      },
      imageView(e, contentSrc) {
        if (this.message.error) {
          return
        }
        this.$emit('image', contentSrc)
        // this.$refs.viewer.showViewer()
      },
      imageLoad(e) {
        this.imageLoading = false
        if (e.currentTarget.src.indexOf(BROKEN_URL) === -1) {
          this.customerImageLoadSuccess({ message: this.message, session: this.session })
        }
      },
      imageError(e) {
        // todo 针对现有的图片reload 机制
        e.currentTarget.src = BROKEN_URL
        this.customerImageLoadError({ message: this.message, session: this.session })
      },
      more() {
        const nextData = {
          session: this.session,
          nextSessionId: this.message.next
        }
        this.loadMoreMessages(nextData).catch((error) => {
          this.$report(error, nextData)
        })
      },
      gotoRecommendPage() {
        this.$router.push({
          path: this.$route.path,
          query: {
            tab: 'recommend',
            id: this.message.id
          }
        })
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .chat-item {
    margin-top: 10px;

    .chat-head {
      width: 34px;
      height: 34px;
      border-radius: 5px;
      margin-left: 20px;
      margin-right: 10px;
      float: left;
    }

    .chat-timestamp {
      font-size: 11px;
      color: $chat-timestamp;
      display: block;
      text-align: left;
      padding-left: 70px;
      padding-right: 70px;
      margin-bottom: 5px;
      clear: both;
    }

    .chat-content {
      /*max-width: 90%;*/
      font-size: 14px;
      line-height: 20px;
      padding: 6px 8px;
      margin: 0;
      background-color: $message-user-bg;
      border: 1px solid darken($message-user-bg, $message-border-darken);
      float: left;
      border-radius: 5px;
      position: relative;
      cursor: default;
      color: $message-user-content;
      word-break: break-word;

      transition: background-color 200ms, border-color 200ms;

      /deep/ .emoji-icon {
        width: 24px;
        vertical-align: middle;
        margin-top: -2px;
        margin-right: 2px;
      }

      p > a {
        color: #00CCFF !important;
      }

      // 角标基础样式
      &:before {
        content: "";
        width: 0;
        height: 0;
        border: 6px solid transparent;
        position: absolute;
        top: 10px;
        z-index: 1;
      }

      &:after {
        content: "";
        width: 0;
        height: 0;
        border: 6px solid transparent;
        position: absolute;
        top: 10px;
        z-index: 2;
      }

      a {
        color: blue;
      }
    }

    .chat-msg-content {
      position: relative;
      display: inline-block;
      max-width: 80%;

      p > a {
        color: #00CCFF !important;
      }

      .msg-state-icon {
        font-size: 18px;
        position: absolute;
        right: 100%;
        top: 50%;
        width: 18px;
        height: 18px;
        margin-top: -11px;
        margin-right: 9px;
        vertical-align: middle;
      }

      .el-icon {
        font-size: 22px;
        width: 22px;
        height: 22px;
        position: absolute;
        left: -30px;
        top: 50%;
        margin-top: -11px;
        cursor: pointer;

        &.el-icon-warning {
          color: $warnColor;
        }

        &.el-icon-engineer {
          color: $recommend-engineer-bg-color;
        }

        &.el-icon-customer {
          color: $recommend-customer-bg-color;
        }
      }
    }

    .chat-content-img {
      padding: 0;
      border-radius: 3px;
      line-height: 0;

      img {
        height: 100px;
        max-width: 400px;
        cursor: pointer;
        border-radius: 5px;
      }

      .loading {
        display: inline-block;
        cursor: pointer;
        width: 100px;
        height: 100px;
        line-height: 90px;
        border-radius: 5px;
        text-align: center;
        vertical-align: middle;
        color: $ldark;
        background-color: #fff;
      }
    }

    &.chat-user {

      .chat-content {
        &:hover {
          background: darken($message-user-bg, $message-hover-darken);
        }

        // :before style display like border
        &:before {
          border-right-color: darken($message-user-bg, $message-border-darken);
          left: -13px;
        }

        &:after {
          border-right-color: $message-user-bg;
          left: -12px;
        }

        // https://stackoverflow.com/questions/5777210/how-to-write-hover-condition-for-abefore-and-aafter
        &:hover::after {
          border-right-color: darken($message-user-bg, $message-hover-darken);
        }

        // user trigger robot
        &.robot {
          background: $recommend-engineer-bg-color;
          border-color: darken($recommend-engineer-bg-color, $message-border-darken);

          // :before style display like border
          &:before {
            border-right-color: darken($recommend-engineer-bg-color, $message-border-darken);
          }

          &:after {
            border-right-color: $recommend-engineer-bg-color;
          }

          &:hover {
            background: darken($recommend-engineer-bg-color, $message-hover-darken);
          }

          &:hover::after {
            border-right-color: darken($recommend-engineer-bg-color, $message-hover-darken);
          }
        }
      }

      .chat-head {
        &.el-icon {
          top: 0;
          display: block;
          line-height: 34px;
          font-size: 20px;
          text-align: center;
          color: $white;
        }
      }

      .chat-msg-content {
        float: left;

        .el-icon {
          left: 100%;
          right: auto;
          margin-left: 9px;

          &.link {
            color: $link;
          }
        }
      }
    }

    &.chat-engineer {
      .chat-head {
        float: right;
        margin-left: 10px;
        margin-right: 20px;
      }

      .chat-timestamp {
        text-align: right;
      }

      .chat-content {
        float: right;
        background-color: $message-engineer-bg;
        border: 1px solid darken($message-engineer-bg, $message-border-darken);
        color: #000;

        & a a:focus, a:hover {
          color: #00CCFF;
        }

        /deep/ a {
          color: blue;
        }

        &.robot {
          background: $recommend-customer-bg-color;
          border: 1px solid $recommend-customer-bg-color;

          &:after {
            border-left-color: $recommend-customer-bg-color;
          }
        }

        &:hover {
          background: darken($message-engineer-bg, $message-hover-darken);
        }

        // :before style display like border
        &:before {
          border-left-color: darken($message-engineer-bg, $message-border-darken);
          right: -13px;

          a {
            color: #00CCFF;
          }
        }

        &:after {
          border-left-color: $message-engineer-bg;
          right: -12px;
        }

        &:hover::after {
          border-left-color: darken($message-engineer-bg, $message-hover-darken);
        }

        // engineer trigger robot
        &.robot {
          background: $recommend-customer-bg-color;
          border-color: darken($recommend-customer-bg-color, $message-border-darken);

          // :before style display like border
          &:before {
            border-left-color: darken($recommend-customer-bg-color, $message-border-darken);
          }

          &:after {
            border-left-color: $recommend-customer-bg-color;
          }

          &:hover {
            background: darken($recommend-customer-bg-color, $message-hover-darken);
          }

          &:hover::after {
            border-left-color: darken($recommend-customer-bg-color, $message-hover-darken);
          }
        }

        &.violate {
          background: #F0F4FB;
          border-color: #f55b53;
          color: #f55b53;

          &:before {
            border-left-color: #f55b53;
          }
        }

      }

      .chat-msg-content {
        float: right;
      }

      .bulbcss {
        position: absolute;
        left: -30px;
      }

    }

    .chat-split {
      color: $chat-timestamp;
      font-size: 12px;
      text-align: center;
      display: block;

      .link {
        color: $chat-timestamp;
      }
    }

    &.robot {
      .chat-content {
        border: 1px solid darken($recommend-customer-bg-color, 10%);
      }
    }

    a:-webkit-any-link {
      color: #00CCFF !important;
    }

  }

  .bulb {
    width: 19px;
    // margin-left:3px;
    // vertical-align: -webkit-baseline-middle;
  }

  .bulbcss {
    cursor: pointer;
  }
</style>
