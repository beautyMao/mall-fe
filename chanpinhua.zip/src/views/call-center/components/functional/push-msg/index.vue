<template>
  <div class="func-panel">
    <el-tabs v-model="pageData.activeName" type="card" :stretch="true">
      <el-tab-pane v-if="permissionMsg" label="短信" name="sms">
        <h2>短信工具 <a @click="confirmShortURL">插入短链接</a></h2>
        <el-form ref="sms" label-position="left" label-width="80px" :rules="smsFormRules" :model="pageData.sms">
          <el-form-item label="手机号码" prop="toUserPhone">
            <el-input v-model="pageData.sms.toUserPhone" clearable></el-input>
          </el-form-item>
          <el-form-item label="短信内容" prop="content">
            <el-input
              v-model="pageData.sms.content"
              maxlength="200"
              show-word-limit
              type="textarea"
              rows="10"
              placeholder="请填写短信内容，最多200字"></el-input>
          </el-form-item>
          <p class="text-center">
            <el-button type="primary" @click="sendMsg">发送短信</el-button>
          </p>
        </el-form>
      </el-tab-pane>

      <el-tab-pane label="邮件" name="email">
        <h2>邮件工具</h2>

        <el-form ref="email" label-position="left" label-width="80px" :rules="emailFormRules" :model="pageData.email">
          <el-form-item label="接收邮箱" prop="toUserEmail">
            <el-input v-model="pageData.email.toUserEmail" placeholder="邮箱" clearable></el-input>
          </el-form-item>
          <el-form-item label="邮件主题" prop="subject">
            <el-input v-model="pageData.email.subject" placeholder="邮件主题" clearable></el-input>
          </el-form-item>
          <el-form-item label="邮件内容" prop="content">
            <el-input
              v-model="pageData.email.content"
              rows="10"
              type="textarea"
              placeholder="请输入邮件内容">
            </el-input>
          </el-form-item>
          <p class="text-center">
            <el-button type="primary" @click="sendEmail">发送邮件</el-button>
          </p>
        </el-form>
      </el-tab-pane>

    </el-tabs>
  </div>
</template>

<script type="text/ecmascript-6">
  import funcCommon from '../func-common'
  import { createIR, sendEmail, sendMsg, transferShortURL } from '@/api/call-center/call-center'
  import { mapGetters } from 'vuex'
  import { getDateFormat } from '@/utils'
  import { RegexUtil } from '@/utils/validate'
  import { CUBE } from '@/configuration'

  export default {
    // 用于标记
    meta: {
      title: '消息推送',
      icon: 'email',
      visible: true,
      name: 'push'
    },
    mixins: [funcCommon],
    data() {
      return {
        // 检测是否有短信推送权限
        permissionMsg: CUBE.permission.engineer_helper.send_short_message,
        smsFormRules: {
          toUserPhone: [
            { required: true, pattern: /^1\d{10}$/, message: '请输入正确的手机号码', trigger: ['blur', 'change'] }
          ],
          content: [
            { required: true, message: '请输入短信内容', trigger: 'blur' },
            { min: 1, max: 200, message: '请输入短信内容', trigger: 'blur' }
          ]
        },
        emailFormRules: {
          toUserEmail: [
            { required: true, message: '请输入邮件地址', trigger: 'blur' },
            { type: 'email', message: '请输入正确的邮箱地址', trigger: 'blur' }
          ],
          subject: [
            { required: true, message: '请输入邮件主体', trigger: 'blur' },
            { min: 1, max: 20, message: '长度在20个字符以内', trigger: 'blur' }
          ],
          content: [
            { required: true, message: '请输入邮件内容', trigger: 'blur' },
            { min: 1, max: 5000, message: '长度在5000个字符以内', trigger: 'blur' }
          ]
        }
      }
    },
    computed: {
      ...mapGetters('call', [
        'phoneNumber'
      ])
    },
    methods: {
      // 长连接转短连接
      confirmShortURL() {
        this.$prompt('请输入待插入的链接', '提示', {
          inputPattern: RegexUtil.url,
          inputErrorMessage: '链接格式不正确'
        }).then(({ value }) => {
          const pageData = this.getPageData()
          transferShortURL(value).then(res => {
            if (pageData.sms.content.length + res.data.url.length > 200) {
              this.$message.warning('没有足够的短信字数插入短链接')
            } else {
              pageData.sms.content += res.data.url
            }
          }).catch(error => {
            this.$message.error('长连接转短连接失败' + error)
          })
        }).catch(() => {})
      },
      // 发送短信
      sendMsg() {
        const formValidation = this.$refs.sms.validate().catch(() => {
          this.$message.error('请填写必要项目')
          return Promise.reject()
        })
        const data = this.pageData.sms

        formValidation.then(() => {
          return this.$confirm(`将为用户“${data.toUserPhone}”推送以下内容“${data.content.slice(0, 50)}...”？`)
        }).then(() => {
          this.handleAfterSend(sendMsg(data), 'sms')
        }).catch(() => {})
      },
      // 发送邮件
      sendEmail() {
        const formValidation = this.$refs.email.validate().catch(() => {
          this.$message.error('请填写必要项目')
          return Promise.reject()
        })
        const data = this.pageData.email

        formValidation.then(() => {
          return this.$confirm(`将为用户“${data.toUserEmail}”推送以下内容“${data.subject}”“${data.content.slice(0, 50)}...”？`)
        }).then(() => {
          this.handleAfterSend(sendEmail(data), 'email')
        }).catch(() => {})
      },
      handleAfterSend(sendPromise, type) {
        sendPromise.then(() => {
          // 仅在接入用户时，发送接触记录
          if (this.currentSession) {
            createIR({
              uid: this.currentSession.cube_uid,
              nickName: this.currentSession.user_name,
              userName: this.currentSession.user_name,
              clientType: type,
              phone: type === 'sms' ? this.pageData.sms.toUserPhone : '',
              engineerCode: this.currentSession.engineer_code,
              engineerName: this.currentSession.engineer_name,
              startTalkingTime: getDateFormat(),
              endTalkingTime: getDateFormat()
            })
          }

          this.$refs[type].resetFields()
          this.$message.success('发送成功')
        }).catch((error) => {
          this.$message.error('发送失败，' + error)
        })
      },
      initPageData() {
        return {
          activeName: this.permissionMsg ? 'sms' : 'email',

          url: {
            long: '',
            short: ''
          },
          sms: {
            toUserPhone: '',
            content: ''
          },
          email: {
            toUserEmail: '',
            subject: '',
            content: ''
          }
        }
      },
      setPageExtData(content) {
        this.pageData.sms.content = content
        this.pageData.email.content = content
      },
      onPageDataInit(session, pageData) {
        pageData.sms.toUserPhone = this.phoneNumber
      }
    }
  }
</script>
