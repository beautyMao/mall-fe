<template>
  <div class="func-panel">
    <el-tabs type="card" v-model="pageData.activeName" :stretch="true">
      <el-tab-pane label="用户信息" name="first">
        <h2>
          客户信息
          <a v-if="isInitUser" @click="gotoPage('user-register', pageData.userInfo)">编辑用户</a>
          <a v-if="isInitUser" @click="refresh" title="当客户源发生变化，可以通过这里刷新一下">
            <i class="el-icon-refresh"></i>刷新
          </a>
          <a v-if="!isInitUser" @click="gotoPage('user-register', false)">注册用户</a>
          <a v-if="!isInitUser" @click="gotoPage('user-query')">查询用户</a>
        </h2>
        <el-form
          v-if="isInitUser"
          label-position="left"
          class="form-table-display"
          label-width="80px">
          <el-form-item label="姓名">
            {{pageData.userInfo.name}}
            {{pageData.userInfo.sex === 1 ? '先生' : ''}}
            {{pageData.userInfo.sex === 2 ? '女士' : ''}}
          </el-form-item>
          <el-form-item label="电话">
            <div v-for="phone in pageData.userInfo.phone">{{phone}}</div>
          </el-form-item>
          <el-form-item label="邮箱">
            <div v-for="email in pageData.userInfo.email">{{email}}</div>
          </el-form-item>
          <el-form-item v-show="pageData.moreInfo" label="公司">
            {{pageData.userInfo.company_name}}
          </el-form-item>
          <el-form-item v-show="pageData.moreInfo" label="客户ID">
            <router-link :to="'/crm/detail?cid=' + pageData.userInfo.customer_uid">
              <i class="el-icon-link"></i>
              {{pageData.userInfo.customer_uid}}
            </router-link>
          </el-form-item>
          <el-form-item v-show="pageData.moreInfo" label="地址">
            {{pageData.userInfo.address}}
          </el-form-item>
<!--          <el-form-item v-show="pageData.moreInfo" label="证件类型">-->
<!--            {{pageData.userInfo.credentials_type}}-->
<!--          </el-form-item>-->
          <el-form-item v-show="pageData.moreInfo" label="证件号码">
            {{pageData.userInfo.credentials_number}}
          </el-form-item>
          <el-form-item v-show="pageData.moreInfo" label="备注信息">
            {{pageData.userInfo.remarks}}
          </el-form-item>
          <p v-if="pageData.moreInfo" class="text-right">
            <el-button type="text" @click="pageData.moreInfo = false">收起</el-button>
          </p>
          <p v-else class="text-center">
            <el-button type="text" @click="pageData.moreInfo = true">查看更多</el-button>
          </p>
        </el-form>
        <el-form
            v-else
            label-position="left"
            class="form-table-display"
            label-width="80px">
          <el-form-item label="姓名">游客</el-form-item>
          <el-form-item label="电话"></el-form-item>
        </el-form>

        <h2 v-if="permissionTag">
          用户标签
          <el-popover
            placement="left"
            trigger="click">
            <a slot="reference">添加标签</a>
            <cascader
              :tree="userTagsData"
              @change="handleUserTagChange"></cascader>
          </el-popover>
        </h2>
        <div v-if="permissionTag">
          <div v-if="pageData.tags.length" class="tag-group">
            <div class="tag-group-item clearfix" v-for="(tagGroup, key) in displayUserTags">
              <span class="tag-group-item__name" :title="key">{{key}}</span>
              <div class="tag-group-item__tags">
                <el-tag
                  v-for="tag in tagGroup"
                  :title="tag.label"
                  :key="tag.id"
                  closable
                  size="medium"
                  @close="handleTagRemove(tag)">{{displayUserTagLabel(tag.label)}}</el-tag>
              </div>
            </div>
          </div>
          <p v-else class="empty">没有标签信息</p>
        </div>

        <h2>上次服务记录</h2>
        <el-form v-if="pageData.caseData.list.length" label-position="left" class="form-table-display" label-width="80px">
          <el-form-item label="记录时间">
            {{pageData.lastCase.created_at}}
          </el-form-item>
          <el-form-item label="工程师">
            {{pageData.lastCase.engineer_name}}({{pageData.lastCase.engineer_code}})
          </el-form-item>
          <el-form-item label="问题分类">
            {{pageData.lastCase.classified_problem_id}}
          </el-form-item>
          <el-form-item label="问题描述">
            <el-popover
              placement="left"
              width="400"
              trigger="hover">
              <div>
                <p><b>问题描述</b></p>
                <p>{{pageData.lastCase.problem_description}}</p>
              </div>
              <span class="case-desc" slot="reference">{{pageData.lastCase.problem_description}}</span>
            </el-popover>
          </el-form-item>
          <p class="text-center mb10">
            <el-button type="text" @click="gotoCaseDetail(pageData.lastCase.id)">查看详情</el-button>
            <el-button type="text" @click="editCase(pageData.lastCase.id)">追加</el-button>
          </p>
        </el-form>
        <p v-else class="empty">没有服务记录</p>

        <h2>聊天记录</h2>
        <el-table
          :data="displayChatIRList"
          v-if="chatIRList.length"
          style="width: 100%">
          <el-table-column type="expand">
            <template slot-scope="props">
              <el-form label-position="left" class="table-expand">
                <el-form-item label="接触记录">
                  <router-link :to="`history?id=${props.row.id}`">
                    <i class="el-icon-link"></i>
                    {{props.row.id}}
                  </router-link>
                </el-form-item>
                <el-form-item label="客服">{{props.row.engineer_name}} ({{ props.row.engineer_code }})</el-form-item>
                <el-form-item label="通路">{{ props.row.client_type }}</el-form-item>
                <el-form-item label="呼入/呼出">{{props.row.direction}}</el-form-item>
                <el-form-item label="主叫号码">{{props.row.phone}}</el-form-item>
                <el-form-item label="队列号">{{props.row.current_queue_code}}</el-form-item>
                <el-form-item label="队列名称">{{props.row.current_queue_name}}</el-form-item>
                <el-form-item label="开始时间">{{ props.row.start_talking_at }}</el-form-item>
                <el-form-item label="结束时间">{{ props.row.end_talking_at }}</el-form-item>
              </el-form>
            </template>
          </el-table-column>
          <el-table-column
            prop="id"
            label="接触记录"
            width="125">
            <router-link slot-scope="scope" :to="`history?id=${scope.row.id}`">
              {{scope.row.id}}
            </router-link>
          </el-table-column>
          <el-table-column
            label="服务记录ID"
            width="100">
            <template slot-scope="scope">
              <span v-for="caseid in displayCaseId(scope.row.case_id)" class="block">
                <a @click="gotoCaseDetail(caseid)">{{ caseid }}</a>
              </span>
            </template>
          </el-table-column>
          <el-table-column
            prop="start_talking_at"
            label="开始时间">
          </el-table-column>
        </el-table>
        <p v-else class="empty">没有聊天记录信息</p>
        <el-pagination
          v-if="chatIRList.length"
          layout="prev, pager, next"
          :page-size="5"
          :current-page.sync="pageData.currentPage"
          :total="chatIRList.length">
        </el-pagination>
      </el-tab-pane>

      <el-tab-pane v-loading="loading('/case/search')" label="历史服务" name="second">
        <el-form :inline="true" @submit.native.prevent>
          <el-input
            v-model="pageData.caseData.query"
            clearable
            placeholder="问题分类/关键词"
            @keydown.enter.native="handleCaseQuery">
            <el-button slot="append" type="primary" icon="el-icon-search" @click="handleCaseQuery">查询</el-button>
          </el-input>
        </el-form>

        <!-- 记录时间、Case ID、处理人、问题分类、问题描述、解决方案 -->
        <div v-if="pageData.caseData.list.length">
          <el-form
            v-for="(item, index) in displayCaseList"
            :key="new Date(item.created_at).getTime()"
            label-width="90px"
            class="form-table-display form-divided">
            <el-form-item label="服务记录ID">
              {{item.case_id}}
              <el-button type="text" icon="el-icon-link" @click="gotoCaseDetail(item.case_id)">查看详情</el-button>
              <el-button type="text" icon="el-icon-plus" @click="editCase(item.case_id)">追加</el-button>
            </el-form-item>
            <el-form-item label="处理人">
              {{item.engineer_name}}({{item.engineer_code}})
            </el-form-item>
            <el-form-item label="记录时间">
              {{item.created_at}}
            </el-form-item>
            <el-form-item label="问题分类">
              {{item.classified_problem_id}}
            </el-form-item>
            <el-form-item label="问题描述">
              <el-popover
                placement="left"
                width="400"
                trigger="hover">
                <div>
                  <p><b>问题描述</b></p>
                  <p>{{item.problem_description}}</p>
                </div>
                <span class="case-desc" slot="reference">{{item.problem_description}}</span>
              </el-popover>
            </el-form-item>
          </el-form>
          <p class="text-center" v-show="displayCaseList.length !== pageData.caseData.list.length">
            <el-button size="medium" type="primary" plain @click="pageData.caseData.currentPage += 1">查看更多</el-button>
          </p>
        </div>
        <p v-else class="empty">空空如也</p>
      </el-tab-pane>

      <el-tab-pane v-loading="loading('GetIRListByQC')" label="接触记录" name="third">
        <el-form :inline="true" label-width="120px">
          <el-select v-model="pageData.IRData.currentType" placeholder="请选择接触类型" @change="handleIRTypeChange">
            <el-option
              v-for="item in irTypes"
              :key="item.ParaCode"
              :label="item.ParaValue"
              :value="item.ParaCode"></el-option>
          </el-select>
        </el-form>

<!--        "id": "4qATShnE-Bu",-->
<!--        "client_type": "webchat",-->
<!--        "status": 9,-->
<!--        "engineer_code": "X25004",-->
<!--        "engineer_name": "骑个猪写代码",-->
<!--        "start_talking_at": "2019-06-05 11:58:17",-->
<!--        "end_talking_at": "2019-06-05 12:03:21",-->
<!--        "direction": "呼入"-->
<!--        IR ID、IR方式、呼入/呼出、主叫号码、被叫号码、队列ID、开始时间、结束时间、客服-->
        <div v-if="pageData.IRData.list.length">
          <el-form
            v-for="item in displayIRList"
            :key="item.id"
            label-width="100px"
            class="form-table-display form-divided">
            <el-form-item label="接触记录ID">
              <a @click="gotoIRDetail(item)">{{item.id}}</a>
<!--              <router-link slot-scope="scope" :to="`history?id=${item.id}`">-->
<!--                {{item.id}}-->
<!--              </router-link>-->
            </el-form-item>
            <el-form-item label="接触方式">
              {{item.client_type}}
            </el-form-item>
            <el-form-item label="呼入/呼出">
              {{item.direction}}
            </el-form-item>
            <el-form-item label="主叫号码">
              {{item.phone}}
            </el-form-item>
            <el-form-item label="队列号">
              {{item.current_queue_code}}
            </el-form-item>
            <el-form-item label="队列名称">
              {{item.current_queue_name}}
            </el-form-item>
            <el-form-item label="开始时间">
              {{item.start_talking_at}}
            </el-form-item>
            <el-form-item label="结束时间">
              {{item.end_talking_at}}
            </el-form-item>
            <el-form-item label="客服">
              {{item.engineer_name}}({{item.engineer_code}})
            </el-form-item>
          </el-form>
          <p class="text-center" v-show="displayIRList.length !== pageData.IRData.list.length">
            <el-button size="medium" type="primary" plain @click="pageData.IRData.currentPage += 1">查看更多</el-button>
          </p>
        </div>
        <p v-else class="empty">空空如也</p>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script type="text/ecmascript-6">
  import funcCommon from '../func-common'
  import Cascader from '@/components/Cascader'
  import {
    getCustomerLabel,
    getIRList,
    getUserCases,
    getUserInfo,
    giveCustomerLabel
  } from '@/api/call-center/call-center'
  import { getIRContactType } from '@/api/touch'
  import { mapGetters } from 'vuex'
  import { customerTagRestApi } from '@/api/tag-configuration'
  import { convertTreeData } from '@/utils/index'
  import { CUBE } from '@/configuration'

  export default {
    // 用于标记
    meta: {
      title: '用户信息',
      icon: 'peoples',
      visible: true,
      name: 'user'
    },
    components: { Cascader },
    mixins: [funcCommon],
    data() {
      return {
        // saas 客户标签管理
        permissionTag: CUBE.permission.tag.customer_manager,

        irTypes: [],
        userTagsData: [],
        flattenTreeData: []
      }
    },
    computed: {
      ...mapGetters('api', ['loading']),
      isInitUser() {
        return this.pageData.userInfo !== null
      },
      chatIRList() {
        // return this.currentSession ? this.currentSession.caseList : []
        return this.pageData.IRData.list
      },
      displayChatIRList() {
        if (!this.chatIRList.length) {
          return []
        }
        const start = (this.pageData.currentPage - 1) * 5
        return this.chatIRList.slice(start, start + 5)
      },
      displayCaseList() {
        if (!this.pageData.caseData.list.length) {
          return []
        }
        const start = (this.pageData.caseData.currentPage - 1) * 3
        return this.pageData.caseData.list.slice(0, start + 3)
      },
      displayIRList() {
        if (!this.pageData.IRData.list.length) {
          return []
        }
        const start = (this.pageData.IRData.currentPage - 1) * 3
        return this.pageData.IRData.list.slice(0, start + 3)
      },
      displayUserTags() {
        const reMap = {}
        // flattenTreeData 需要等待异步初始化
        if (!this.flattenTreeData.length) {
          return reMap
        }
        // 构建一个map<一级标签目录，[tags]>
        const tagsWithPath = this.pageData.tags.map(tagId => {
          const tagData = this.flattenTreeData.find(item => item.id === tagId)
          return tagData || {
            id: tagId,
            label: '未知标签',
            path: ['未知分类']
          }
        })
        tagsWithPath.forEach(tag => {
          if (!reMap[tag.path[0]]) {
            reMap[tag.path[0]] = []
          }
          reMap[tag.path[0]].push(tag)
        })
        return reMap
      }
    },
    mounted() {
      // "ParaCode": "wechat",
      // "ParaValue": "微信"
      getIRContactType().then(res => {
        this.irTypes = res.data
      })
      // 初始化标签树数据
      customerTagRestApi.list().then(res => {
        this.userTagsData = convertTreeData(res.data, this.flattenTreeData, {
          label: 'customer_label_name',
          children: 'children',
          value: 'id'
        })
      })
    },
    methods: {
      initPageData() {
        return {
          activeName: 'first',
          userInfo: null,
          moreInfo: false,
          lastCase: null,
          currentPage: 1,

          tags: [],
          caseData: {
            query: '',
            currentPage: 1,
            list: []
          },
          IRData: {
            currentType: 'webchat',
            currentPage: 1,
            list: []
          }
        }
      },
      // 确认用户传递来的数据，是原始的第三方系统用户数据（或内建CRM数据）
      setPageExtData(data) {
        if (data === 'register') {
          this._getUserInfo()
        } else if (data === 'refresh') {
          this.resetPageData()
        } else {
          this.pageData.userInfo = data
        }
      },
      // 目前仍然是根据会话session 里的id 进行的服务和接触记录查询
      onPageDataInit(session) {
        this._getUserInfo(session)

        const page = this.getPageData(session.id)
        // page.userInfo = convertCubeUserFromSession(session)

        getUserCases(session.cube_uid).then(res => {
          page.lastCase = this.$get(res, 'data.case_list[0]', null)
          page.caseData.list = this.$get(res, 'data.case_list', [])
        })

        page.IRData.currentType = session.client_type
        getIRList(session.cube_uid, session.client_type).then(res => {
          page.IRData.list = this.$get(res, 'data.case_info', [])
        })

        getCustomerLabel(session.cube_uid).then(res => {
          page.tags = this.$get(res, 'data.customer_label_id', [])
        })
      },
      // 当客户源发生变化，可以通过这里刷新一下
      refresh() {
        this._getUserInfo()
      },
      _getUserInfo(session = this.currentSession) {
        const page = this.getPageData(session.id)
        getUserInfo({ cube_uid: session.cube_uid }).then(res => {
          const userData = res.data
          // is_init 表示尚初始的客户信息，未做关联
          if (userData && userData.length !== 0 && !userData.is_init) {
            page.userInfo = userData
          } else {
            page.userInfo = null
            // 仅在当前会话跳转，否则会导致新入会话扰乱当前会话的active tab
            // this.gotoPage('user-query')
          }
        }).catch(() => {})
      },
      gotoCaseDetail(case_id) {
        this.$router.push({
          name: 'case-query-particulars',
          query: { case_id }
        })
      },
      gotoIRDetail({ id, client_type }) {
        this.$router.push({
          name: 'touch-particulars',
          query: { id, type: client_type }
        })
      },
      editCase(id) {
        this.gotoPage('case', id)
      },
      getIRTypeName(type) {
        const findType = this.irTypes.find(irType => irType.ParaCode === type)
        return findType ? findType.ParaName : '未知类型'
      },
      // tag max width 不好处理，采用截断字符的形式来满足需求
      displayUserTagLabel(tagLabel) {
        if (tagLabel.length > 6) {
          return tagLabel.substr(0, 6) + '..'
        }
        return tagLabel
      },
      displayCaseId(caseIdArr) {
        const re = []
        caseIdArr.forEach(id => {
          if (!re.includes(id)) re.push(id)
        })
        return re
      },
      handleCaseQuery() {
        if (!this.pageData.caseData.query) {
          this.$message.info('正在查询全部服务记录')
        }
        const page = this.getPageData()
        getUserCases(this.currentSession.cube_uid, this.pageData.caseData.query).then(res => {
          page.caseData.list = this.$get(res, 'data.case_list', [])
          page.caseData.currentPage = 1
        })
      },
      handleIRTypeChange(type) {
        const page = this.getPageData()
        getIRList(this.currentSession.cube_uid, type).then(res => {
          page.IRData.list = this.$get(res, 'data.case_info', [])
          page.IRData.currentPage = 1
        })
      },
      handleUserTagChange(tag) {
        const checkIndex = this.pageData.tags.findIndex(t => t === tag.id)
        if (checkIndex > -1) {
          return
        }

        // 检查是否在已有标签中有相同的一级分类（path）
        const tagNode = this.flattenTreeData.find(item => item.id === tag.id)
        const target = Object.keys(this.displayUserTags).find(path => path === tagNode.path[0])
        if (target) {
          this.displayUserTags[target].forEach(t => {
            const index = this.pageData.tags.indexOf(t.id)
            index > -1 && this.pageData.tags.splice(index, 1)
          })
        }

        this.pageData.tags.push(tag.id)
        giveCustomerLabel(this.currentSession.cube_uid, '', this.pageData.tags).then(res => {
          this.$message.success('添加标签成功')
        }).catch(this.$message.error)
      },
      handleTagRemove(tag) {
        const index = this.pageData.tags.indexOf(tag.id)
        if (index > -1) {
          this.pageData.tags.splice(index, 1)
          giveCustomerLabel(this.currentSession.cube_uid, '', this.pageData.tags).then(res => {
            this.$message.success('删除标签成功')
          }).catch(this.$message.error)
        }
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .tag-group {
    padding-left: 10px;
    padding-right: 10px;
    padding-bottom: 20px;
    display: flex;
    flex-wrap: wrap;
    max-height: 400px;

    .tag-group-item {
      width: 49%;

      .tag-group-item__name {
        display: inline-block;
        width: 70px;
        font-size: 14px;
        line-height: 24px;
        font-weight: 400;
        color: #303133;
        float: left;
        overflow: hidden;
        text-overflow: ellipsis;
        text-align: left;
        white-space: nowrap;
      }
      .tag-group-item__tags {
        margin-left: 75px;
      }
      /deep/ .el-tag {
        margin-bottom: 5px;
        width: 120px;
        text-align: center;

        .el-icon-close {
          float: right;
          top: 3px;
        }
      }
    }
  }

  .case-desc {
    display: inline-block;
    max-height: 200px;
    overflow: hidden;
    text-overflow: ellipsis;
    cursor: pointer;
  }
</style>
