<template>
  <div class="func-panel" v-loading="loading('case/create')">
    <h2>
      服务小记
      <a v-show="pageData.originCase.id" @click="resetPageData">
        <i class="el-icon-delete"></i>
        当前正在追加：{{pageData.originCase.id}}
      </a>
    </h2>
    <div v-for="(item, index) in pageData.list" :key="item.id" class="case-item">
      <el-form ref="forms" label-position="left" :rules="formRules" :model="item">
        <el-form-item label="问题分类" prop="tags">
          <el-popover
            placement="bottom"
            trigger="click">
            <el-button
              v-show="!pageData.originCase.data"
              @click="currentIndex = index"
              slot="reference"
              type="primary"
              icon="el-icon-plus"
              circle></el-button>
            <cascader :tree="options" @change="handleChangeProblem"></cascader>
          </el-popover>
          <el-tag
            v-if="pageData.originCase.data"
            v-for="(tag, tagIndex) in displayOriginTags"
            :key="pageData.originCase.id + tagIndex"
            size="medium"
          >{{tag}}</el-tag>
          <el-tag
            v-for="tag in displayTags(item.tags)"
            :key="tag.id"
            size="medium"
            @close="handleCloseTag(index, tag)"
            closable>
            {{tag.name}}
          </el-tag>
        </el-form-item>
        <el-form-item label="问题描述" prop="desc">
          <el-input
            v-model="item.desc"
            maxlength="500"
            show-word-limit
            type="textarea"
            rows="10"
            placeholder="请填写问题描述，最多500字"></el-input>
        </el-form-item>
        <el-upload
          :action="uploadAction"
          :data="uploadData"
          :headers="uploadHeader"
          :on-success="(response, file, fileList) => { handleFileListChange(fileList) }"
          :on-remove="(file, fileList) => { handleFileListChange(fileList) }"
          :before-upload="handleBeforeUpload"
          :on-error="handleErrorFileupload"
          :on-preview="handlePreview">
          <el-button type="text" icon="el-icon-paperclip">添加附件</el-button>
          <div slot="tip" class="el-upload__tip">支持Word，Excel、图片（png、jpg）、压缩文件的上传，大小不超过30M</div>
        </el-upload>
        <div v-show="pageData.list.length > 1" class="text-right pr20">
          <el-button type="text" @click="removeCase(index)" icon="el-icon-delete">移除记录</el-button>
        </div>
      </el-form>
    </div>
    <p class="text-right pr20">
      <!--<el-button @click="addCase">增加Case 记录</el-button>-->
      <el-button v-if="permissionOrder" type="primary" @click="saveAndCreateOrder">保存并创建工单</el-button>
      <el-button type="primary" @click="save">保存全部</el-button>
    </p>

    <image-viewer :src="imageSrc" ref="viewer"></image-viewer>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex'
  import funcCommon from '../func-common'
  import ImageViewer from '@/components/ImageViewer'
  import Cascader from '@/components/Cascader'
  import { uuid } from '@/utils'
  import { problemRestApi } from '@/api/problems'
  import { QINIU_ACTION, QINIU_IMAGEVIEW } from '@/api/qiniu'
  import { createCase, getUserCaseInfo } from '@/api/call-center/call-center'
  import { getToken } from '@/utils/auth'
  import { CUBE } from '@/configuration'

  // 默认使用了顿号，奇怪的分隔符
  const SPLIT_COMMA = '、'
  const PATH_COMMA = '>>'

  // 预处理级联选择器的数据
  const convertTreeData = function(data, path = []) {
    return data.map(item => {
      const nextPath = [...path, item.name]
      item.label = item.name
      item.value = item.id
      item.path = nextPath
      if (item.children.length) {
        item.children = convertTreeData(item.children, nextPath)
      }
      if (!item.children.length) {
        delete item.children
      }
      flattenTreeData.push({
        id: item.id,
        name: item.name,
        path: nextPath
      })
      return item
    })
  }

  // 为快速查找flatten 的数据
  const flattenTreeData = []
  const createEmptyData = function() {
    return {
      id: uuid('case'),
      tags: [],
      desc: '',
      files: []
    }
  }

  export default {
    // 用于标记
    meta: {
      title: '服务小记',
      icon: 'component',
      visible: true,
      name: 'case'
    },
    components: { ImageViewer, Cascader },
    mixins: [funcCommon],
    data() {
      return {
        // 工单权限
        permissionOrder: CUBE.permission.order,

        // 在处理级联选择的内容时，不能传递index，只能折中用临时变量处理
        currentIndex: 0,
        options: [],

        formRules: {
          tags: [{
            required: true, trigger: 'blur', validator: (rule, value, callback) => {
              // 如果是追加，则不做校验了
              if (this.pageData.originCase.data) {
                callback()
              } else {
                value.length ? callback() : callback(new Error('请选择问题分类'))
              }
            }
          }],
          desc: [{ required: true, message: '请填写问题描述', trigger: 'blur' }]
        },

        uploadData: {
          key: ''
        },
        uploadHeader: {
          'Authorization': `Bearer ${getToken()}`
        },
        uploadAction: QINIU_ACTION,
        imageSrc: ''
      }
    },
    computed: {
      ...mapGetters('call', ['currentSessionID']),
      ...mapGetters('api', ['loading']),
      displayOriginTags() {
        if (!this.pageData.originCase.data) {
          return []
        }
        return this.pageData.originCase.data.classified_problem_id.split(SPLIT_COMMA).map(tag => {
          const tagPath = tag.split(PATH_COMMA)
          return tagPath[tagPath.length - 1]
        })
      }
    },
    mounted() {
      problemRestApi.list().then(res => {
        this.options = convertTreeData(res.data)
      })
    },
    methods: {
      initPageData() {
        return {
          originCase: {
            id: '',
            data: null
          },
          list: [createEmptyData()]
        }
      },
      // 追加case
      setPageExtData(id) {
        let next = Promise.resolve('ok')
        if (this.pageData.list.length > 1) {
          next = this.$confirm('检查到当前会话存在未保存的服务Case 记录，是否舍弃？')
        }

        this.resetPageData()
        const page = this.getPageData()
        next.then(() => {
          getUserCaseInfo(id).then((res) => {
            const caseData = this.$get(res, 'data[0]')
            page.originCase.id = id
            page.originCase.data = caseData
            // 下方代码能支持编辑
            // page.list = [{
            //   id: uuid('case'),
            //   tags: caseData.classified_problem_id ? caseData.classified_problem_id.split(SPLIT_COMMA) : [],
            //   desc: caseData.problem_description,
            //   files: caseData.case_file.map(file => {
            //     return {
            //       name: file.file_name,
            //       url: file.file_url
            //     }
            //   })
            // }]
          })
        }).catch(() => {})
      },
      addCase() {
        this.pageData.list.push(createEmptyData())
      },
      removeCase(index) {
        this.$confirm('确认移除记录？').then(() => {
          this.pageData.list.splice(index, 1)
        }).catch(() => {})
      },
      save() {
        const validatePromises = this.$refs.forms.map($form => $form.validate())
        if (!validatePromises.length) {
          return Promise.reject()
        }

        return Promise.all(validatePromises).then(() => {
          const needRemoved = []
          let caseID = ''
          const createPromises = this.pageData.list.map((data, index) => {
            const tags = data.tags.map(tag => {
              return flattenTreeData.find(item => item.id === tag).path.join(PATH_COMMA)
            }).join(SPLIT_COMMA)
            const fileMeta = data.files.map(file => {
              return {
                file_name: file.name,
                file_url: file.url
              }
            })
            // 就是如果上传附件数量2个及以上接口才会去压缩文件
            let files = []
            if (data.files.length > 1) {
              files = data.files.map(file => {
                return file.raw
              })
            }

            const dataPrams = {
              session_id: this.currentSessionID,
              classified_problem_id: tags,
              problem_description: data.desc,
              fileMeta, files
            }
            if (this.pageData.originCase.id) {
              dataPrams.case_id = this.pageData.originCase.id
              dataPrams.classified_problem_id = this.pageData.originCase.data.classified_problem_id
            }
            return createCase(dataPrams).then((res) => {
              // this.$message.success(`第${index + 1}条服务记录创建成功`)
              caseID = res.data
              this.$message.success(`服务记录创建成功`)
              needRemoved.push(index)
              return res.data
            }).catch(error => {
              this.$message.error(`服务记录创建失败，` + error)
              return Promise.reject(error)
            })
          })

          // 如果都成功了，重置下数据
          return Promise.all(createPromises).then((createResArr) => {
            this.resetPageData()
            // 通知用户page 已经保存了新的服务记录
            this.gotoPage('user', 'refresh')
            return createResArr
          }).catch(() => {
            // 部分失败，只移除部分成功的记录
            needRemoved.forEach(index => this.pageData.list.splice(index, 1))
          })
        }).catch(() => {})
      },
      saveAndCreateOrder() {
        this.save().then(createResArr => {
          if (createResArr && createResArr.length) {
            // 等数据重置完成再跳转
            setTimeout(() => {
              this.$router.push({
                path: `/work-order/workorder/create`,
                // 带客户id 和 服务记录id
                query: { customer: this.currentSession.customer_id, case: createResArr[0] }
              })
            }, 500)
          }
        }).catch(() => {})
      },
      displayTags(tags) {
        return tags.map(tag => {
          return flattenTreeData.find(item => item.id === tag) || { id: -1, name: tag }
        })
      },
      handleChangeProblem(tag) {
        // 追加状态时检查以前的内容，仅能通过名字来区分了
        // 现在规则是追加状态下，不添加也不能删除，但这里的方案仍然保留，万一还有用呢╮(╯_╰)╭
        if (this.displayOriginTags.includes(tag.name)) {
          return
        }

        if (!this.pageData.list[this.currentIndex].tags.includes(tag.id)) {
          this.pageData.list[this.currentIndex].tags.push(tag.id)
          this.$refs.forms.map($form => $form.validateField('tags'))
        }
      },
      handleCloseTag(index, tag) {
        this.pageData.list[index].tags.splice(this.pageData.list[index].tags.indexOf(tag.id), 1)
      },
      // todo 功能区独立上传组件
      handleBeforeUpload(file) {
        const ext = file.name.split('.').reverse()[0].toLowerCase()
        if (!'png,jpeg,jpg,zip,doc,docx,xls,xlsx'.split(',').includes(ext)) {
          this.$message.error('仅支持Word，Excel、图片（png、jpg）、支持压缩文件上传')
          return false
        }
        if (file.size / 1024 / 1024 > 30) {
          this.$message.error('文件需要小于30MB')
          return false
        }
        // 自定义七牛文件上传路径
        const date = new Date()
        this.uploadData.key = `cube/Image/${date.getFullYear()}${(date.getMonth() + 1)}/${uuid('casefile')}.${ext}`
        return true
      },
      handleFileListChange(fileList) {
        this.pageData.list[this.currentIndex].files = fileList.map(file => {
          return {
            name: file.name,
            url: file.response.data.picUrl,
            raw: file.raw
          }
        })
      },
      handleErrorFileupload(err, file, fileList) {
        this.$message.warning(err.error || '上传失败')
      },
      handlePreview(file) {
        if (/\.png$|\.jpg$/.test(file.name)) {
          this.imageSrc = file.url || file.response.data.picUrl + QINIU_IMAGEVIEW
          this.$refs.viewer.showViewer()
        } else {
          this.$message.warning('非图片类型文件不能预览')
        }
      }
    }
  }
</script>

<style lang="scss" type="text/scss">
  .case-item {
    margin-bottom: 20px;
    padding-bottom: 20px;
    border-bottom: 1px solid #E4E7ED;
  }
</style>
