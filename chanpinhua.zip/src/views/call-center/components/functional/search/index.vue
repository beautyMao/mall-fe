<template>
  <div class="func-panel" v-loading="loading('searchArticleContent')">
    <h2>我的收藏/知识库</h2>

    <el-form :inline="true">
      <el-input ref="search" v-model="pageData.query" placeholder="查询关键词" @keydown.enter.native="search()">
        <el-button type="primary" slot="append" icon="el-icon-search" @click="search()">查询</el-button>
      </el-input>

      <p class="keywords" v-if="history.length">
        <el-tag @click="search(item)" v-for="(item, index) in history" :key="index">{{item}}</el-tag>
      </p>
    </el-form>

    <div v-if="pageData.result !== null">
      <ul v-if="pageData.result.length">
        <li class="text-nowrap" v-for="item in pageData.result" :key="item.id">
          <router-link :to="{name: 'article-info', query: {id: item.id}}">{{item.title}}</router-link>
        </li>
      </ul>
      <p class="empty" v-else>没有查到内容</p>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapGetters } from 'vuex'
  import funcCommon from '../func-common'
  import { knowledgeBaseSearch } from '@/api/call-center/call-center'
  import { getLocalStorage } from '@/utils/local-storage'

  const SEARCH_KEYS = 'SEARCH_KEYS'
  export default {
    // 用于标记
    meta: {
      title: '综合检索',
      icon: 'search',
      visible: true,
      name: 'search'
    },
    mixins: [funcCommon],
    data() {
      const searchHistorys = getLocalStorage().getItem(SEARCH_KEYS)
      let history = []
      if (searchHistorys) {
        try {
          history = JSON.parse(searchHistorys)
        } catch (e) {
          console.log(e)
        }
      }
      return {
        history
      }
    },
    computed: mapGetters('api', ['loading']),
    methods: {
      initPageData() {
        return {
          query: '',
          result: null
        }
      },
      search(query) {
        const queryStr = typeof query === 'string' ? query : this.pageData.query.trim()
        if (!queryStr) {
          return this.$message.warning('请输入查询关键词')
        }
        const page = this.getPageData()
        knowledgeBaseSearch(queryStr).then(res => {
          page.result = res.data
        }).catch(this.$message.error)

        // 保存查询关键词
        if (!this.history.includes(queryStr)) {
          this.history.push(queryStr)
          if (this.history.length > 5) {
            this.history.shift()
          }
          getLocalStorage().setItem(SEARCH_KEYS, JSON.stringify(this.history))
        }

        return false
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .keywords /deep/ {
    .el-tag {
      cursor: pointer;
      margin-right: 10px;
    }
  }

  .empty {
    margin-top: 200px;
  }

  ul {
    margin: 15px;
    background-color: #fff;
    border-radius: 5px;
    border: 1px solid lightgray;
    padding-top: 10px;
    padding-bottom: 10px;

    li {
      a {
        display: block;
        font-size: 14px;
        line-height: 30px;
        height: 30px;
        padding-left: 10px;
        padding-right: 10px;
        background-color: #fff;
        transition: background-color 200ms;

        &:hover {
          background-color: #f0f0f0;
        }
      }
    }
  }
</style>
