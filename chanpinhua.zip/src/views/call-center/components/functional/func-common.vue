<script type="text/ecmascript-6">
  import Vue from 'vue'
  import { mapGetters } from 'vuex'
  import { isProd } from '@/utils'

  const DEFAULT_KEY = 'default'

  export default {
    data() {
      return {
        data: {
          // 'sessionId1': { ...xxx},
          // 'sessionId2': { ...xxx},
          // 'sessionId3': { ...xxx},
        }
      }
    },

    computed: {
      ...mapGetters('call', [
        'currentSessionID', 'sessions', 'currentSession'
      ]),
      pageData() {
        return this.currentSessionID ? this.data[this.currentSessionID] : this.data[DEFAULT_KEY]
      }
    },
    watch: {
      'sessions': function(sessionsVal) {
        // compare session in val & session in this.data
        const newKeys = Object.keys(sessionsVal)
        const oldKeys = Object.keys(this.data)

        // 空框default key 保留
        newKeys.push(DEFAULT_KEY)

        const addSessions = []
        const removeIds = []
        for (let i = 0; i < newKeys.length; i++) {
          !oldKeys.includes(newKeys[i]) && addSessions.push(sessionsVal[newKeys[i]])
        }
        for (let i = 0; i < oldKeys.length; i++) {
          !newKeys.includes(oldKeys[i]) && removeIds.push(oldKeys[i])
        }

        // remove data
        removeIds.forEach(id => Vue.delete(this.data, id))
        // add data and invoke init process callback
        addSessions.forEach(session => {
          const pageData = this.initPageData(session.id)
          Vue.set(this.data, session.id, pageData)
          this.onPageDataInit(session, pageData)
        })
      }
    },
    beforeMount() {
      // 针对能够在空框下使用的组件，空框下共享一份数据
      const defaultPageData = this.initPageData(DEFAULT_KEY)
      Vue.set(this.data, DEFAULT_KEY, defaultPageData)
      this.onDefaultPageDataInit(defaultPageData)

      // 如果已经有进行中的会话，组件初始化之后需要批量初始化数据
      Object.values(this.sessions).forEach(session => {
        const pageData = this.initPageData(session.id)
        Vue.set(this.data, session.id, pageData)
        this.onPageDataInit(session, pageData)
      })
    },
    methods: {
      /**
       * 组件里需要覆盖并实现自己的初始化数据方法
       * @param id session id
       * @return {{}}
       */
      initPageData(id) {},
      /**
       * 为解决异步获取数据直接去修改pageData 可能错乱的问题
       * @param id session id
       * @return {*}
       */
      getPageData(id) {
        return this.data[id || this.currentSessionID || DEFAULT_KEY]
      },
      /**
       * 提供重置当前页面数据的方法
       * @param avoidPageDataInit 不触发page data init 事件
       */
      resetPageData(avoidPageDataInit) {
        const key = this.currentSessionID ? this.currentSessionID : DEFAULT_KEY
        const pageData = this.initPageData(key)
        Vue.set(this.data, key, pageData)
        if (!avoidPageDataInit) {
          this.onPageDataInit(this.currentSession, pageData)
        }
      },
      /**
       * 当新的会话（包括刷新页面后获取的会话）出现时，通知父级根据session id 可以做初始化
       * 由于存在这样的场景：刷新页面同时初始化多个session，如果在内要进行pageData 的赋值操作
       * 一定使用`getPageData(session.id)` 来获取当前的pageData
       * @param session
       * @param pageData
       */
      onPageDataInit(session, pageData) {},
      /**
       * 当空框（默认会话）出现时，通知父级根据DEFAULT_KEY 可以做初始化
       * @param pageData
       */
      onDefaultPageDataInit(pageData) {},
      /**
       * 前往下一个tab page，当然也可以在组件内容使用emit('toggleTab')
       * * 注意避免通过自动触发跳转动作，否则可能会否则会导致其他会话扰乱当前会话的active tab
       * @param name
       * @param data
       */
      gotoPage(name, data) {
        if (!isProd) {
          console.log('[Functional page]', 'goto', name, data)
        }
        this.$emit('toggleTab', name, data)
      },
      /**
       * 接收上一个tab page 跳转时传递的参数
       * @param data
       */
      setPageExtData(data) {}
    }
  }
</script>
