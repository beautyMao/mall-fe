<template>
  <div class="func-panel" v-loading="loading('/api/crm/customer')">
    <h2>{{ pageData.isEditing ? '更新用户' : '注册用户' }} <a @click="gotoPage('user')">关闭</a></h2>
    <crm-user-form ref="userForm"></crm-user-form>
    <p class="text-center">
      <el-button @click="handleRegistration" type="primary" size="medium">
        {{pageData.isEditing ? '更新用户' : '注册用户'}}
      </el-button>
    </p>
  </div>
</template>

<script type="text/ecmascript-6">
  import funcCommon from '../func-common'
  import CrmUserForm from '@/views/crm/components/crm-user-form'
  import { userRegistration, userUpdateInfo } from '@/api/call-center/call-center'
  import { mapGetters } from 'vuex'
  import { paramsShake } from '@/utils'
  import { ClientType } from '@call/enum'

  export default {
    // 用于标记
    meta: {
      title: '用户注册',
      icon: 'user',
      visible: false,
      name: 'user-register'
    },
    components: { CrmUserForm },
    mixins: [funcCommon],
    computed: {
      ...mapGetters('api', ['loading']),
      ...mapGetters('call', ['phoneNumber']),
      ...mapGetters(['engineerCode'])
    },
    methods: {
      initPageData() {
        return {
          formData: {},
          isEditing: false
        }
      },
      // 接受编辑用户的数据
      setPageExtData(formData) {
        const pageData = this.getPageData()
        if (formData) {
          pageData.formData = formData
          pageData.isEditing = true
        } else {
          pageData.formData = {}
          pageData.isEditing = false
        }

        this.insertExtraParam()

        // dialog form 显示之后再调用
        this.$nextTick(() => {
          if (pageData.isEditing) {
            this.$refs.userForm.edit(pageData.formData)
          } else {
            this.$refs.userForm.create(pageData.formData)
          }
        })
      },
      handleRegistration() {
        const nextOperation = this.pageData.isEditing ? userUpdateInfo : userRegistration
        this.$refs.userForm.validate().then(data => {
          const paramData = {
            cube_uid: this.currentSession.cube_uid,
            customer_id: data.customer_uid,
            ...data
          }
          // if (!this.pageData.isEditing) {
          //   paramData = paramsShake(paramData)
          // }
          nextOperation(paramsShake(paramData)).then(res => {
            this.$message.success(this.pageData.isEditing ? '更新用户成功' : '创建用户成功')
            this.resetPageData(true)
            this.gotoPage('user', 'register')
          }).catch(this.$message.error)
        })
      },
      insertExtraParam() {
        const formData = this.getPageData().formData
        // 如果是微信通路用户，填入openid ，注册和更新时会用到
        if (this.currentSession.client_type === ClientType.Wechat) {
          if (!formData.wechat_openid) {
            formData.wechat_openid = []
          }
          if (!formData.wechat_openid.includes(this.currentSession.open_id)) {
            formData.wechat_openid.push(this.currentSession.open_id)
          }
        }

        if (this.currentSession.client_type === ClientType.Telephone) {
          if (!formData.phone) {
            formData.phone = []
          }
          if (!formData.phone.includes(this.phoneNumber)) {
            formData.phone.push(this.phoneNumber)
          }
        }
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .multiple-input {
    margin-bottom: 5px;
  }
</style>
