<template>
  <div class="func-panel" v-loading="loading('/wb/user/select')">
    <h2>用户查询 <a @click="gotoPage('user-register', false)">新用户注册</a></h2>
    <el-form ref="form" label-width="90px" :rules="formRules" :model="pageData.query" @keydown.enter.native="query()">
      <el-form-item label="用户姓名" prop="name">
        <el-input v-model="pageData.query.name" clearable></el-input>
      </el-form-item>
      <el-form-item label="电话号码" prop="phone">
        <el-input v-model="pageData.query.phone" clearable></el-input>
      </el-form-item>
      <el-form-item label="用户邮箱" prop="email">
        <el-input v-model="pageData.query.email" clearable></el-input>
      </el-form-item>
    </el-form>
    <p class="text-center">
      <el-button type="primary" icon="el-icon-search" @click="query()">查 询</el-button>
    </p>

    <h2>用户列表</h2>
    <div v-if="pageData.result.length">
      <el-form v-for="(item, index) in pageData.result" :key="item.CustomerID" label-position="left" class="form-table-display form-divided">
        <el-form-item label="客户ID">
          {{item.customer_id}}
        </el-form-item>
        <el-form-item label="客户姓名">
          {{item.name}}
        </el-form-item>
        <el-form-item label="联系电话">
          <div v-for="phone in item.phone">{{phone}}</div>
        </el-form-item>
        <el-form-item label="公司名称">
          {{item.company_name}}
        </el-form-item>
        <p class="text-center">
          <el-button :disabled="!item.customer_id" @click="confirmAndBindUser(item.customer_id, index)">确认用户</el-button>
        </p>
      </el-form>
      <pagination
          layout="pager"
          :limit="10"
          :total="pageData.page.total"
          @pagination="pagination" />
    </div>
    <p v-else class="empty">没有更多内容了</p>
  </div>
</template>

<script type="text/ecmascript-6">
  import funcCommon from '../func-common'
  import Pagination from '@/components/Pagination'
  import { bindUserInfo, queryUserList } from '@/api/call-center/call-center'
  import { mapGetters } from 'vuex'
  import { ClientType } from '@call/enum'
  import { paramsShake } from '@/utils'
  import { RegexUtil } from '@/utils/validate'

  export default {
    // 用于标记
    meta: {
      title: '用户查询',
      icon: 'search',
      visible: false,
      name: 'user-query'
    },
    components: { Pagination },
    mixins: [funcCommon],
    data() {
      return {
        formRules: {
          phone: [{ pattern: RegexUtil.telephone, message: '请填写正确的电话号码', trigger: 'change' }],
          email: [{ type: 'email', message: '请填写正确的邮箱', trigger: 'change' }]
        }
      }
    },
    computed: {
      ...mapGetters('api', ['loading'])
    },
    activated() {
      // 如果已查询到并确认了用户，直接跳转
      // 还有一种情况是，需要重新确认用户的过程
    },
    methods: {
      initPageData() {
        return {
          query: {
            name: '',
            phone: '',
            email: ''
          },
          result: [],
          page: {
            current: 1,
            total: 0
          }
        }
      },
      pagination({ page, limit }) {
        this.pageData.page.current = page
        this.query(page)
      },
      query(page = 1, limit = 10) {
        const pageData = this.getPageData()
        const conditionCheck = paramsShake(pageData.query)
        if (!Object.keys(conditionCheck).length) {
          return this.$message.warning('请至少输入一个条件进行查询')
        }

        const queryParams = Object.assign({
          page,
          per_page: limit
        }, pageData.query)
        this.$refs.form.validate().then(() => {
          queryUserList(paramsShake(queryParams)).then(res => {
            // todo convertToCubeUser ?
            pageData.result = res.data.data
            pageData.page.total = res.data.total
            if (!pageData.result.length) {
              this.$message.warning('查询不到数据')
            }
          })
          // 如果结果是唯一的，直接确认
          // if (res.data.length === 1) {
          //   this.gotoPage('user', res.data[0])
          // } else {
          //   this.pageData.result = res.data
          // }
          // this.pageData.result = [convertToCubeUser(res.data)]
        })
      },
      onPageDataInit(session) {
        if (session.client_type === ClientType.Telephone) {
          this.pageData.query.phone = session.phone
        }

        // 因为现在新用户进入后默认的tab page 是查询页，所以有下述动作
        // 检测用户是否存在，如果存在则前往用户详情页面
        // TODO 存在问题，刷新有多个用户时，onPageDataInit gotoPage 仅在第一个用户身上生效一次
        // getUserInfo(session.cube_uid).then(res => {
        //   const userData = this.$get(res, 'data[0]')
        //   if (!userData) {
        //     this.gotoPage('user-register')
        //   } else {
        //     this.pageData.userInfo = userData
        //     this.gotoPage('user', userData)
        //   }
        // }).catch((error) => {
        //   this.$message.error(error + '')
        // })
      },
      // 将第三方用户和魔方用户进行绑定
      confirmAndBindUser(CustomerUID, index) {
        bindUserInfo(this.currentSession.cube_uid, CustomerUID).then((res) => {
          this.$message.success('绑定用户完成')
          this.gotoPage('user', res.data)
        }).catch(error => {
          this.$message.error('绑定失败：' + error)
        })
      }
    }
  }
</script>
