<template>
  <div class="func-panel">
    <el-tabs type="card" v-model="activeName" :stretch="true">
      <el-tab-pane label="用户管理" name="first">
        <h2>客户信息 <a @click="dialogFormVisible = true">打开侧边栏</a></h2>
        <el-form label-position="left" class="form-table-display">
          <el-form-item label="CASE ID">
            <span>props.row.id</span>
          </el-form-item>
          <el-form-item label="客服">
            <span>props.row.engineer_code</span>
          </el-form-item>
          <el-form-item label="通路">
            <span>props.row.access_name</span>
          </el-form-item>
          <el-form-item label="来自队列">
            <span>props.row.current_queue_code</span>
          </el-form-item>
          <el-form-item label="创建时间">
            <span>props.row.created_at</span>
          </el-form-item>
          <el-form-item label="结束时间">
            <span>props.row.end_talking_at</span>
          </el-form-item>
        </el-form>
        <p class="text-center">
          <el-button type="text">主要操作</el-button>
          <el-button type="text">次要操作</el-button>
        </p>

        <el-dialog title="收货地址" :visible.sync="dialogFormVisible" custom-class="el-dialog-aside">
          <el-form>
            <el-form-item label="活动名称" :label-width="formLabelWidth">
              <el-input auto-complete="off"></el-input>
            </el-form-item>
            <el-form-item label="活动区域" :label-width="formLabelWidth">
              <el-select placeholder="请选择活动区域">
                <el-option label="区域一" value="shanghai"></el-option>
                <el-option label="区域二" value="beijing"></el-option>
              </el-select>
            </el-form-item>
          </el-form>
          <div slot="footer" class="dialog-footer">
            <el-button @click="dialogFormVisible = false">取 消</el-button>
            <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
          </div>
        </el-dialog>

        <h2>标签 <a>操作</a></h2>
        <el-pagination
          layout="prev, pager, next"
          :total="50">
        </el-pagination>
        <h2>其他</h2>
        <p class="empty">没有更多内容了</p>
      </el-tab-pane>
      <el-tab-pane label="配置管理" name="second">
        <h2>用户信息 <a>更多操作</a></h2>
        <el-form ref="form" label-width="80px">
          <el-form-item label="活动名称">
            <el-input></el-input>
          </el-form-item>
          <el-form-item label="活动区域">
            <el-select placeholder="请选择活动区域">
              <el-option label="区域一" value="shanghai"></el-option>
              <el-option label="区域二" value="beijing"></el-option>
            </el-select>
          </el-form-item>
          <el-form-item label="活动时间" required>
            <el-col :span="11">
              <el-form-item>
                <el-date-picker type="date" placeholder="选择日期" style="width: 100%;"></el-date-picker>
              </el-form-item>
            </el-col>
            <el-col class="line" :span="2">-</el-col>
            <el-col :span="11">
              <el-form-item>
                <el-time-picker placeholder="选择时间" style="width: 100%;"></el-time-picker>
              </el-form-item>
            </el-col>
          </el-form-item>
          <el-form-item label="即时配送">
            <el-switch></el-switch>
          </el-form-item>
          <el-form-item label="活动性质">
            <el-checkbox-group>
              <el-checkbox label="美食/餐厅线上活动" name="type"></el-checkbox>
              <el-checkbox label="地推活动" name="type"></el-checkbox>
              <el-checkbox label="线下主题活动" name="type"></el-checkbox>
              <el-checkbox label="单纯品牌曝光" name="type"></el-checkbox>
            </el-checkbox-group>
          </el-form-item>
          <el-form-item label="特殊资源">
            <el-radio-group>
              <el-radio label="线上品牌商赞助"></el-radio>
              <el-radio label="线下场地免费"></el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="活动形式">
            <el-input type="textarea"></el-input>
          </el-form-item>
          <el-form-item>
            <el-button type="primary" @click="submitForm('ruleForm')">立即创建</el-button>
            <el-button @click="resetForm('ruleForm')">重置</el-button>
          </el-form-item>
        </el-form>
      </el-tab-pane>
    </el-tabs>
  </div>
</template>

<script type="text/ecmascript-6">
  import funcCommon from '../func-common'

  export default {
    // 用于标记
    meta: {
      title: 'Demo',
      icon: 'table',
      visible: false,
      name: 'example'
    },
    mixins: [funcCommon],
    data() {
      return {
        activeName: 'first',
        dialogFormVisible: false
      }
    },
    methods: {
      initPageData() {
        return {
          query: {
            name: '',
            tel: ''
          },
          result: [],
          pagination: {}
        }
      }
    }
  }
</script>
