const context = require.context('@/views/call-center/components/functional', true, /index\.vue$/)
const requireAll = context => context.keys().map(context)

const vueComponent = requireAll(context).map(item => {
  return item.default
})

// todo 如果被要求了顺序
const components = vueComponent
// const components = [
//   Demo, Search, User, ServiceRecord
// ]
const componentsObject = {}
components.forEach(item => {
  componentsObject[item.meta.name] = item
})

export default {
  tabs: components.map(item => {
    // 记录下原始的visible 信息
    return Object.assign({
      originVisible: item.meta.visible
    }, item.meta)
  }),
  components: componentsObject
}
