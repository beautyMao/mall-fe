<template>
  <div class="func-panel">
    <h2>服务记录</h2>

    <el-table
      :data="caseList"
      v-if="currentSessionID"
      style="width: 100%">
      <el-table-column type="expand">
        <template slot-scope="props">
          <el-form label-position="left" class="table-expand">
            <el-form-item label="CASE ID">
              <span>{{ props.row.id }}</span>
            </el-form-item>
            <el-form-item label="客服">
              <span>{{ props.row.engineer_code }}</span>
            </el-form-item>
            <el-form-item label="通路">
              <span>{{ props.row.access_name }}</span>
            </el-form-item>
            <el-form-item label="来自队列">
              <span>{{ props.row.current_queue_code }}</span>
            </el-form-item>
            <el-form-item label="创建时间">
              <span>{{ props.row.created_at }}</span>
            </el-form-item>
            <el-form-item label="结束时间">
              <span>{{ props.row.end_talking_at }}</span>
            </el-form-item>
          </el-form>
        </template>
      </el-table-column>
      <el-table-column
        prop="id"
        label="CASE ID"
        width="120">
        <router-link slot-scope="scope" :to="`history?id=${scope.row.id}`">
          <i class="el-icon-link"></i>
          {{scope.row.id}}
        </router-link>
      </el-table-column>
      <el-table-column
        prop="engineer.code"
        label="客服"
        width="100">
      </el-table-column>
      <el-table-column
        prop="created_at"
        label="创建时间">
      </el-table-column>
    </el-table>
    <p v-else>
    </p>
  </div>
</template>

<script type="text/ecmascript-6">
  import funcCommon from '../func-common'

  export default {
    // 用于标记
    meta: {
      title: '服务记录',
      icon: 'navRecord',
      visible: false,
      name: 'record'
    },
    mixins: [funcCommon],
    data() {
      return {
        other: 'ok'
      }
    },
    computed: {
      caseList() {
        return this.currentSession ? this.currentSession.caseList : []
      }
    },
    // watch: {
    //   'pageData.result': function(result) {
    //   	if (!result.length) {
    //
    //     }
    //   }
    // },
    methods: {
      initPageData() {
        return {
          result: []
        }
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped></style>
