<template>
  <div class="func-panel">
    <h2>
      智能推荐
      <a v-show="!pageData.result && hasNext" @click="next">下一条</a>
      <a v-show="!pageData.result && hasPrev" @click="prev">上一条</a>
      <a v-show="pageData.result" @click="pageData.result = null">清空查询</a>
    </h2>

    <el-form :inline="true" @submit.native.prevent>
      <el-input v-model.trim="pageData.query" placeholder="检索方案" @keydown.enter.native="handleRecommendQuery">
        <el-button slot="append" type="primary" icon="el-icon-search" @click="handleRecommendQuery">查询</el-button>
      </el-input>
    </el-form>

    <div v-if="displayItem" class="recommend-container">
      <h3>Q：{{displayItem.data.standard || pageData.query}}</h3>
      <div v-for="item in displayItem.data.recommends" class="recommend-item" :class="{'nsd': item.isNoSend}">
        <p v-html="item.content"></p>
        <p class="text-right recommend-action" v-if="!item.isNoSend && !currentSession.isVirtual">
          <el-button size="medium" type="text" @click="push(item.content)">推送</el-button>
          <el-button size="medium" type="text" @click="copy(item.content)">复制</el-button>
          <el-button size="medium" type="text" @click="send(item.content)">发送</el-button>
        </p>
        <p v-show="!item.isNoSend && currentSession.isVirtual" class="text-right disabled recommend-action">会话已关闭，不能操作</p>
      </div>
    </div>
    <p v-else class="empty">没有匹配到的推荐内容</p>
  </div>
</template>

<script type="text/ecmascript-6">
  import funcCommon from '../func-common'
  import { mapActions } from 'vuex'
  import { getAnswerRecommend } from '@/api/call-center/call-center'
  import { convertRecommendMessage } from '@call/convert'
  import { ClientType } from '@call/enum'

  export default {
    // 用于标记
    meta: {
      title: '智能推荐',
      icon: 'example',
      visible: true,
      name: 'recommend'
    },
    mixins: [funcCommon],
    computed: {
      recommends() {
        if (!this.currentSession) {
          return []
        }

        // 如果存在查询的结果，直接展示
        if (this.pageData.result) {
          return [this.pageData.result]
        }

        // 电话不显示消息体内的推荐信息
        if (this.currentSession.client_type === ClientType.Telephone) {
          return []
        }

        return this.currentSession.messages.filter(m => m.recommendData).map(m => {
          return {
            id: m.id,
            data: m.recommendData
          }
        })
      },
      displayItem() {
        // 如果存在查询的结果，直接展示
        if (this.pageData.result) {
          return {
            id: 'result',
            data: this.pageData.result
          }
        }

        const nextId = this.pageData.location
        if (nextId) {
          return this.recommends.find(item => item.id === nextId)
        } else {
          return this.recommends[this.recommends.length - 1]
        }
      },
      hasPrev() {
        if (!this.recommends.length) {
          return false
        }
        const currentMsgId = this.pageData.location || this.recommends[this.recommends.length - 1].id
        return this.recommends.findIndex(item => item.id === currentMsgId) > 0
      },
      hasNext() {
        if (!this.recommends.length) {
          return false
        }
        const currentMsgId = this.pageData.location || this.recommends[this.recommends.length - 1].id
        return this.recommends.findIndex(item => item.id === currentMsgId) < this.recommends.length - 1
      }
    },
    watch: {
      '$route.query.id': function(id) {
        this.pageData.location = id
        // 定位到指定话术时，清空已查询内容
        this.pageData.result = null
      }
    },
    activated() {
      if (this.$route.query.id) {
        this.pageData.location = this.$route.query.id
      }
    },
    methods: {
      ...mapActions('call', ['sendMessage']),
      initPageData() {
        return {
          location: '', // 为空就认为显示的最新一条

          query: '',
          result: null
        }
      },
      handleRecommendQuery() {
        if (!this.pageData.query) {
          return this.$message.warning('请输入查询方案关键字')
        }
        getAnswerRecommend(this.pageData.query, this.currentSession.id).then(res => {
          if (res.data.recommend && res.data.recommend.length) {
            const recommends = res.data.recommend.map(text => {
              return {
                content: convertRecommendMessage(text),
                html: text,
                isNoSend: text.indexOf('[nsd]') > -1
              }
            }).filter(item => item.content.trim() !== '')
            this.pageData.result = {
              standard: res.data.standard,
              recommends
            }
            this.pageData.query = ''
          }
        }).catch(() => {
          this.$message.warning('没有智能推荐方案')
        })
      },
      copy(content) {
        const el = document.getElementById('editor-content')
        el.innerText += content
        // 触发输入框的字数统计
        const e = document.createEvent('UIEvents')
        e.initUIEvent('keydown')
        el.dispatchEvent(e)
      },
      send(content) {
        // 信任机器人发送的内容，做标记safeMessage
        this.sendMessage({ text: content, session: this.currentSession, safeMessage: true })
      },
      push(content) {
        this.gotoPage('push', content)
      },
      prev() {
        const currentMsgId = this.pageData.location || this.recommends[this.recommends.length - 1].id
        const prevIndex = this.recommends.findIndex(item => item.id === currentMsgId) - 1
        this.pageData.location = this.recommends[prevIndex].id
      },
      next() {
        const nextIndex = this.recommends.findIndex(item => item.id === this.pageData.location) + 1
        this.pageData.location = this.recommends[nextIndex].id
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .recommend-container {
    margin-left: 20px;
    margin-right: 20px;
    padding-left: 20px;
    padding-right: 20px;
    margin-top: 20px;
    background-color: #fff;
    display: flow-root;
    border-radius: 5px;

    .disabled {
      color: darkgray;
    }

    h3 {
      font-size: 16px;
      font-weight: 600;
      color: #333;
    }
    .recommend-item {
      padding-top: 10px;
      border-bottom: 1px solid #f1f1f1;

      &.nsd {
        border-bottom: none;
        font-weight: 600;
        color: #999999;
      }

      p {
        margin-top: 5px;
        margin-bottom: 5px;
        font-size: 14px;
        line-height: 1.5;
      }
      &:last-child {
        border-bottom: none;
      }
    }
  }
</style>
