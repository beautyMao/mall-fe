<template>
  <li class="voice-item"
      :class="{active: isSessionActive, overtime: isSessionOvertime}"
      ref="contextMenuTarget"
      @click="switchClick">

    <div class="content flex-between flex-wrp">
      <i>{{this.session.phone}}</i>
      <i class="el-icon-phone-outlin"></i>
    </div>
    <div class="msg flex-between flex-wrp">
      <i>{{displayMainState}}</i>
      <i v-show="sessionActive > 0">{{sessionActive|time}}</i>
    </div>

    <context-menu class="context-menu"
                  :target="contextMenuTarget"
                  :show="contextMenuVisible"
                  @update:show="(show) => this.contextMenuVisible = show">
      <template v-if="isBadSession">
        <a @click="releaseSession">释放通话</a>
      </template>
      <template v-else>
        <a v-if="!session.isVirtual" @click="hangUpCall">挂断电话</a>
        <a v-else @click="remove">移除案面会话</a>
        <a @click="refresh">刷新会话列表</a>
        <!--<a @click="errorReport">反馈该会话的问题</a>-->
      </template>
      <a @click="removeAll" v-if="!isProd">批量移除会话</a>
    </context-menu>
  </li>
</template>

<script type="text/ecmascript-6">
  import ContextMenu from '@/components/ContextMenu'
  import { mapActions, mapGetters } from 'vuex'
  import {
    AgentState,
    CallState,
    CallType,
    MessageType
  } from '@/store/modules/call-center/voice/enum'
  import ws from '@/api/call-center/softphone-ws'
  import config from '@/store/modules/call-center/config'
  import { hangup } from '@/api/call-center/softphone'
  import { isProd } from '@/utils'

  const callStateNameMap = {
    // 由于是事件驱动建立session，所以session 组件无法收到第一个事件，这里默认为振铃中
    // 含糊一下，将呼入呼出都归结为振铃中
    [CallState.Ringing]: '振铃中',
    [CallState.Dialing]: '振铃中',
    [CallState.Established]: '通话中',
    [CallState.Released]: '已挂断',
    [CallState.Held]: '会话保持中',
    // 接到released 事件后，session 组件主动调用releaseConversion 并修改组件内sessionCallState 为acw
    [AgentState.AfterCallWork]: '案面'
  }

  // 避免初始的计时器数值错误，导致显示错误
  // todo 这里应该采用服务器时间，更加稳妥
  const getStartSec = (timeFromServer) => {
    let re = 0
    try {
      re = parseInt((Date.now() - Date.parse(timeFromServer)) / 1000)
    } catch (e) {
      console.log('voice session getStartSec error:', e)
    }

    if (re < 0 || Number.isNaN(re)) {
      re = 0
    }
    return re
  }

  export default {
    props: ['session'],
    data() {
      return {
        sessionActive: 0,
        isHangUp: false,
        // 由于是事件驱动建立session，所以session 组件无法收到第一个事件，这里默认为空
        sessionCallState: '',
        timers: [],

        contextMenuVisible: false,
        contextMenuTarget: null,
        isProd
      }
    },
    components: {
      // https://github.com/xunleif2e/vue-context-menu
      ContextMenu
    },
    computed: {
      ...mapGetters('call', ['currentSessionID']),
      ...mapGetters('call', [
        'agentState',
        'agentStateExt',
        'callState',
        'connId',
        'transferConnId'
      ]),
      isSessionActive() {
        return this.session.id === this.currentSessionID
      },
      isBadSession() {
        // 通话刷新会直接造成损坏session
        return !this.session.initCallState && !this.session.isVirtual
      },
      displayMainState() {
        if (this.session.isVirtual) {
          return '案面'
        }

        // 如果session 是通话页面刷新后获取的，那么已经不能正常操作它了
        if (!this.session.initCallState) {
          return '未知'
        }

        return callStateNameMap[this.sessionCallState || this.session.initCallState] || '未知'
      },
      // session 通话超时
      isSessionOvertime() {
        // 处于案面状态的会话框不需要变红色
        if (this.session.isVirtual) {
          return false
        }
        return this.sessionCallState !== CallState.Released && this.sessionActive > config.voiceOvertimeSetting.overActive
      }
    },
    watch: {
      'session.isVirtual': function(isVirtual) {
        if (isVirtual) {
          // 挂断后停止计时，进入案面状态计时
          this.stop()
          this.start()
          // 打个标记
          this.sessionCallState = AgentState.AfterCallWork
        }
      }
    },
    methods: {
      ...mapActions('call', [
        'switchSession',
        'refreshSessions',
        'removeVoiceSession',
        'releaseVoiceConversion',
        'closeVoiceConversion'
      ]),
      switchClick() {
        if (this.currentSessionID === this.session.id) {
          return
        }

        this.switchSession(this.session)
      },
      start(sec = 0) {
        this.sessionActive = sec
        // session 计时器独立出来运行
        this.timers.push(setInterval(() => {
          this.sessionActive += 1
        }, 1000))
      },
      stop() {
        this.timers.forEach(clearInterval)
        this.timers = []
      },
      // 挂断电话
      hangUpCall() {
        this.contextMenuVisible = false
        this.$confirm(`即将挂断与【${this.session.phone}】的通话，请确认。`, '注意', {
          confirmButtonText: '确定关闭',
          cancelButtonText: '取消',
          type: 'error'
        }).then(() => {
          // todo 转接和三方等的挂断，需要处理
          // todo session 里没有phone_conn_id 的也需要处理
          // 直接使用接口关闭会话，剩余动作交给事件函数来处理
          hangup(this.transactionId || this.session.phone_conn_id)
        }).catch(() => {})
      },
      remove(e) {
        this.contextMenuVisible = false
        this.removeVoiceSession(this.session)
        // 点穿菜单后导致switchSession action 被执行了
        e.stopPropagation()
      },
      // 释放损坏的会话
      releaseSession() {
        this.contextMenuVisible = false
        this.$confirm(`即将释放【${this.session.phone}】的通话，请确认已经在坐席话机上完成了该通话。`, '注意', {
          confirmButtonText: '确定释放',
          cancelButtonText: '取消'
        }).then(() => {
          this.releaseVoiceConversion({
            sessionId: this.session.id,
            type: this.session.callType === CallType.Inbound ? 'callin' : 'callout'
          }).then(() => {
            this.removeVoiceSession(this.session)
          })
        }).catch(() => {})
      },
      // 批量移除会话 only for dev&test
      removeAll() {
        this.contextMenuVisible = false
        const allSessions = this.$store.getters['call/sessions']
        const actionPromises = Object.values(allSessions).map(session => {
          return this.releaseVoiceConversion({
            sessionId: session.id,
            type: session.callType === CallType.Inbound ? 'callin' : 'callout'
          })
        })
        Promise.all(actionPromises).then((done) => {
          this.$confirm('批量移除会话操作完成，请刷新页面', '注意', {
            confirmButtonText: '刷新页面',
            cancelButtonText: '取消'
          }).then(() => {
            window.location.reload()
          }).catch(() => {})
        }).catch((error) => {
          this.$message.error('批量移除会话操作失败，' + error)
        })
      },
      refresh() {
        this.contextMenuVisible = false
        this.refreshSessions().then(doneContexts => {
          this.$message.success('会话列表刷新成功')
        }).catch(error => {
          this.$report(error, {
            msg: '会话列表刷新失败'
          })
          this.$message.error('会话列表刷新失败' + error)
        })
      },
      errorReport() {
        this.contextMenuVisible = false
        console.log('errorReport')
      },
      _messageHandle(message) {
        const { call: { connId, state }} = message.data
        // 被动关闭会话以及状态跟踪，当且仅当session connId === event data connId 时才执行
        if (this.session.phone_conn_id !== connId) {
          return
        }

        // 使用session 里独立的callState 会更准确
        this.sessionCallState = state
      }
    },
    beforeMount() {
      // 刷新页面后遗留的session 是没有voiceData 属性的
      // 可以通过这里来断定session 是不是出于‘未知’状态
      if (!this.$get(this.session, 'voiceData.messageType')) {
        this.sessionCallState = ''
      }
    },
    mounted() {
      // todo 是否考虑将魔方session api 挪到action 里，并在这里执行？
      // 使用的是创建会话的时间：created_at
      let startWithSec = 0
      if (this.session.created_at) {
        startWithSec = getStartSec(this.session.created_at)
      }
      // 目前全部在ws message handle 里
      if (this.callState !== CallState.Released) {
        this.start(startWithSec)
      }

      ws.addEventListener(MessageType.CallStateChange, this._messageHandle)

      // 初始化右键菜单
      this.contextMenuTarget = this.$refs.contextMenuTarget
    },
    beforeDestroy() {
      this.stop()
      ws.removeEventListener(MessageType.CallStateChange, this._messageHandle)
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";
  @import "../scss/context-menu";

  .voice-item {
    width: 100%;
    height: 90px;
    padding: 15px;
    overflow: hidden;
    cursor: pointer;
    background-color: $lightWhite;
    transition: background-color 200ms;
    border-bottom: 1px solid $borderColor;

    &:hover {
      background-color: #E2E4E6;
    }

    &.active {
      background-color: $session-active-bg;

      &:hover {
        background-color: darken($session-active-bg, 5%)
      }
    }

    &.overtime {
      background-color: $bg-danger;
      color: darken($color-danger, 10%);

      &:hover {
        background-color: darken($bg-danger, 5%);
      }
    }

    i {
      font-style: normal;
      flex: 0 1 auto;
    }

    .content {
      display: flex;
      margin-bottom: 10px;
      line-height: 22px;

      i {
        font-size: 16px;
        font-weight: 400;
      }

      i.el-icon-phone-outlin {
        font-size: 20px;
        margin-top: 4px;
        width: 20px;
        height: 20px;
        background: url(~@/assets/phone.png) no-repeat;
        :before {
          content: ''
        }
      }
    }

    .msg i {
      font-size: 12px;
      color: $ldark;
    }

  }
</style>
