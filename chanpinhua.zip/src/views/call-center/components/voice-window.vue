<template>
  <div class="voice-window">
    <voice-recorder />

    <transition name="fade">
      <div
        v-if="loginFail"
        class="voice-reconnect"
      >
        <el-button
          size="medium"
          type="text"
          @click="init(true)"
        >点击这里尝试重新连接
        </el-button>
      </div>
    </transition>

    <transition name="fade">
      <voice-service-volume
        v-show="!loginFail"
        class="voice-topbar-style"
      />
    </transition>

    <div
      v-loading="loginLoading"
      element-loading-text="软电话条自动登录中"
      class="voice-topbar voice-topbar-style"
      :class="{'voice-offline': (isOffline && !loginLoading)}"
    >
      <voice-console ref="vconsole"/>
    </div>

    <div class="voice-info">
      <case-recorder></case-recorder>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import ws from '@/api/call-center/softphone-ws'
  import { mapActions, mapGetters } from 'vuex'
  import { MessageType } from '@call/voice/enum'
  import { IMActionType } from '@/store/modules/call-center/enum'
  import VoiceServiceVolume from '@/views/call-center/components/voice-service-volume'
  import VoiceConsole from '@/views/call-center/components/voice-console'
  import CaseRecorder from '@/views/call-center/components/functional/case'
  import VoiceRecorder from '@/views/call-center/components/voice-util'
  import txim from '@/store/modules/call-center/im-tx'
  import { documentReminder } from '@/api/solution-management/solution'
  import { getDateFormat } from '@/utils'
  import { AgentState, EngineerStatus } from '@/store/modules/call-center/voice/enum'

  export default {
    components: {
      VoiceServiceVolume,
      VoiceConsole,
      VoiceRecorder,
      CaseRecorder
    },
    data() {
      return {
        loginLoading: true,
        loginFail: false,
        activeName: 'record',
        waitingQueue: [],

        // todo 冗余，仅用来做数据传递？
        addInfo: {}
      }
    },
    computed: {
      ...mapGetters('call', [
        'currentSessionOrDefault',
        'hasVoicePermission',
        'sessions',
        'currentSessionID',
        'currentSession',
        'system',
        'region'
      ]),
      ...mapGetters('call', [
        'agentState',
        'agentStateExt',
        'callState',
        'phoneNumber',
        'softPhoneStatus',
        'voiceCubeSession'
      ]),
      isOffline() {
        return this.agentStateExt === AgentState.Offline
      }
    },
    watch: {
      '$route.query.callback': function(callback) {
        if (callback === 'create-order') {
          this.getServiceProblem()

          // 移除query 参数
          // todo 这种传递方式有点恶心，在不借助全局eventBus 的前提下，似乎只有这个跨页传参方案了
          const query = { ...this.$route.query || {}}
          delete query.callback
          this.$router.replace({
            path: this.$route.path,
            query
          })
        }
      },
      // 如果客服正在忙碌，等待客服案面后，调起拨号盘
      agentStateExt: function(agentStateExt) {
        if (this.waitingQueue.length && [AgentState.AfterCallWork, AgentState.Ready].includes(agentStateExt)) {
          // const query = { ...this.$route.query || { callNumber: this.waitingQueue.pop() }}
          const query = { ...this.$route.query }
          query.callNumber = this.waitingQueue.pop()
          // 打开拨号面板并传入号码
          this.$router.replace({
            name: 'call-center',
            query
          })
        }
      }
    },
    methods: {
      ...mapActions('call', ['initSoftphone', 'getServiceProblem', 'releaseAllVoiceConversion', 'switchSession']),
      switchUser() {
        // 切换电话工作台
        let id = null
        if (this.currentSession && this.currentSession.client_type !== 'wechat') {
          id = this.currentSession.id
        }
        this.switchSession({ id: id })
      },
      // 接受从其他tab 传过来的data
      setData(item) {
        this.addInfo = item
      },
      devicestatechange(message) {
        // this.$message.error(data.errorMessage)
        // 话机登出 退出魔方系统
        const agentState = this.$get(message, 'data.devices[0].userState.state')
        if (agentState === AgentState.LoggedOut) {
          this.$confirm('魔方或者坐席固机已经执行登出操作，请确认您的所有内容已保存', '即将退出魔方系统', {
            confirmButtonText: '退出',
            cancelButtonText: '取消',
            type: 'warning'
          }).then(() => {
            // 在Navbar 会处理这个路由事件
            this.$router.replace({
              query: {
                cubeLogout: 'confirm'
              }
            })
          }).catch(() => {
          })
        }
      },
      _resetReminder(message) {
        const extData = JSON.parse(message.text)
        const targetTime = Date.now() + 300 * 1000
        documentReminder({
          ...message,
          alert_date: getDateFormat('yyyy-MM-dd', new Date(targetTime)),
          alert_time: getDateFormat('hh:mm:ss', new Date(targetTime)),
          alert_minute: 0,
          document_code: extData.documentCode,
          document_type: 2,
          content: message.text,
          expect_time: 1,
          email: '',
          send_type: 3, // IM推送
          type: 1
        }).then(() => {
          this.$message.info('该首问单将在5分钟后再次提醒')
        })
      },
      _notificationHandle(message) {
        // const data = {
        //   chat_type: "Notification",
        //   customer_name: "张双双",
        //   engineer_code: "A06837",
        //   message_type: "FirstAskReminder",
        //   mobile: "18910860201",
        //   send_time: "2019-02-22 10:55:02",
        //   send_type: 500,
        //   text: "{message:我的提醒是啥样子呢,code: xxxx}"
        // }
        if (message.message_type !== 'FirstAskReminder') {
          return
        }
        const extData = JSON.parse(message.text)
        this.$msgbox({
          title: '首问单处理',
          message: `
            <div style="text-align: left">
              <p><b>客户姓名：</b> ${message.customer_name}</p>
              <p><b>客户电话：</b> ${message.mobile}</p>
              <p><b>预约时间：</b> ${message.recovery_time}</p>
              <p><b>解决方案：</b> ${extData.message}</p>
            </div>
          `,
          dangerouslyUseHTMLString: true,
          closeOnClickModal: false,
          closeOnPressEscape: false,
          showCancelButton: true,
          confirmButtonText: '立即处理',
          cancelButtonText: '稍后处理',
          type: 'warning',
          center: true
        }).then(() => {
          // 除了离线，正在通话中，hold三种情况，其他电话条的任意状态都可以外呼
          const callableStatus = [
            EngineerStatus.Offline,
            EngineerStatus.Logout,
            EngineerStatus.Callin,
            EngineerStatus.Callout,
            // hold 仅存在于通话中，这个时候按钮状态约束已经控制住不能外呼了
            // 但仍然要防止首问提醒的处理动作创建的外呼
            EngineerStatus.Hold
          ]

          // 立刻拨打电话
          if (!callableStatus.includes(this.softPhoneStatus)) {
            this.switchUser()
            const query = { ...this.$route.query || {}}
            query.callNumber = message.mobile
            this.$router.replace({
              path: this.$route.path,
              query
            })
            this.$refs.vconsole.phoneCall({
              tel: message.mobile
            })
          } else {
            this.$message.info('该首问单将在客服案面或就绪之后重新拨号')
            this.waitingQueue.push(message.mobile)
          }
        }).catch(() => {
          this._resetReminder(message)
        })
      },
      // 在部分情况下登录genesys 失败后，手动尝试重新连接
      init(reconnect = false) {
        this.loginFail = false
        this.loginLoading = true
        const initPromise = this.initSoftphone().catch((error) => {
          this.$message.error(error + '')
          this.loginFail = true
        }).finally(() => {
          this.loginLoading = false
        })

        // 重连成功后，尝试清空所有异常会话
        if (reconnect) {
          initPromise.then(() => {
            this.releaseAllVoiceConversion()
          })
        }

        return initPromise
      }
    },
    mounted() {
      // 初始化并且签入
      this.init().then(() => {
        // 执行完做个延迟，避开初始化时产生的Offline event
        setTimeout(() => {
          ws.addEventListener(MessageType.DeviceStateChange, this.devicestatechange)
        }, 5000)
      })

      // 首问提醒
      txim.addEventListener(IMActionType.Notification, this._notificationHandle)
    },
    beforeDestroy() {
      ws.removeEventListener(MessageType.DeviceStateChange, this.devicestatechange)
      txim.removeEventListener(IMActionType.Notification, this._notificationHandle)
    }
  }

</script>

<style lang='scss' type="text/scss" scoped>
  @import '../scss/rules';

  .voice-window {
    flex: 1;
    display: flex;
    flex-direction: column;
    height: calc(100vh - (34px + 50px));
    background-color: #fff;

    .voice-reconnect {
      text-align: center;
      background-color: $bg-light-blue;
      border-bottom: 1px solid $borderColor;
    }

    .voice-topbar.voice-offline:after {
      position: absolute;
      top: 0;
      left: 0;
      bottom: 0;
      right: 0;
      content: '软电话条处于离线状态';
      font-size: 14px;
      display: block;
      background-color: ghostwhite;
      color: $base;
      opacity: 0.92;
      z-index: 200;
      padding-top: 35px;
      text-align: center;
    }

    .voice-topbar-style /deep/ {
      position: relative;
      height: 93px;

      .tel-box {
        width: 80px;
        height: 82px;
        color: $base;

        .tel-button {
          &.disabled {
            color: $lldark;

            .tel-text {
              color: $lldark;
            }
          }

          &.active {
            background-color: $bg-light-blue;
          }

          .tel-text {
            color: $ldark;
          }

          &:hover {
            color: darken($base, 20%);

            .tel-text {
              color: $dark;
            }
          }
        }

        .content {
          position: absolute;
          top: 0;
          left: 0;
          width: 80px;
          max-height: 80px;
          overflow: hidden;
          z-index: 1;
          box-shadow: 0px 0px 0px 0px rgba(102, 102, 102, 0);
          border-radius: 4px;
          border: 1px solid rgba(228, 231, 237, 0);
          transition: all 0.3s;

          &:hover {
            border: 1px solid rgba(228, 231, 237, 1);
            box-shadow: 0px -2px 12px 0px rgba(102, 102, 102, 0.15);
            max-height: 1000px;
          }
        }

        &.tel-top-box {
          width: 60px;
          height: 62px;

          .content {
            width: 60px;
            max-height: 60px;
            z-index: 2;
            position: absolute;
            top: 0;
            left: 0;
            overflow: hidden;
            box-shadow: 0px 0px 0px 0px rgba(102, 102, 102, 0);
            border-radius: 4px;
            border: 1px solid rgba(228, 231, 237, 0);
            transition: all 0.3s;

            &:hover {
              border: 1px solid rgba(228, 231, 237, 1);
              box-shadow: 0px -2px 12px 0px rgba(102, 102, 102, 0.15);
              max-height: 1000px;
            }
          }
        }
      }
    }

    .voice-info {
      padding-left: 15px;
      padding-right: 15px;
      flex: 1;
      overflow-y: auto;

      /deep/ .el-tag {
        margin-right: 10px;
      }
    }
  }
</style>

