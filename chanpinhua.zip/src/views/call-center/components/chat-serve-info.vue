<template>
  <div class="serve-container">
    <el-popover
      placement="right-start"
      popper-class="serve-main-popper"
      width="300"
      trigger="hover"
      :visible-arrow="false"
      :offset="20"
    >
      <div class="serve-more">
        <div v-if="hasVoicePermission" class="serve-item">
          <h4>电话服务明细</h4>
          <div class="size14 color4 ptb5">在线时间 <span>{{ workStatus.phone.online|time }}</span></div>
          <div class="size14 color4 ptb5">休息时间 <span>{{ workStatus.phone.rest|time }}</span></div>
          <div class="flex-wrp flex-between">
            <div class="flex-wrp flex-between">
              <div>
                <div class="size14 color4 ptb5">呼出量</div>
                <div class="size14 color4 ptb5">呼入量</div>
              </div>
              <div class="pl15" :style="{width: '60px'}">
                <div class="size14 color4 ptb5">{{ workload.callout_num }}</div>
                <div class="size14 color4 ptb5">{{ workload.callin_num }}</div>
              </div>
            </div>
            <div class="flex-wrp flex-between">
              <div>
                <div class="size14 color4 ptb5">HOLD量</div>
                <div class="size14 color4 ptb5">AHT</div>
              </div>
              <div class="pl15" :style="{width: '70px'}">
                <div class="size14 color4 ptb5">{{ workload.hold_num }}</div>
                <div class="size14 color4 ptb5">{{ workload.call_avg_time }}</div>
              </div>
            </div>
          </div>
        </div>

        <div class="serve-item">
          <h4>文本服务明细</h4>
          <div class="size14 color4 ptb5">就绪时间 <span>{{ workStatus.text.online|time }}</span></div>
          <div class="size14 color4 ptb5">小休时间 <span>{{ workStatus.text.rest|time }}</span></div>
          <div class="size14 color4 ptb5">挂起时间 <span>{{ workStatus.text.hangup|time }}</span></div>
          <div class="size14 color4 ptb5">服务量 <span>{{ engineerQueue.totalService }}</span></div>
        </div>

      </div>
      <div slot="reference" class="serve-main">
        <h3 v-if="hasVoicePermission">呼入量： {{ workload.callin_num }} </h3>
        <h3 v-else>服务量： {{ engineerQueue.totalService }} </h3>
        <!--<ul>-->
        <!--<li>在线时间：{{workStatus[sessionType].online|time}}</li>-->
        <!--<li>休息时间：{{workStatus[sessionType].rest|time}}</li>-->
        <!--</ul>-->
      </div>
    </el-popover>

    <div class="serve-detail">
      <el-row class="serve-type">
        <el-col :span="12">文本服务</el-col>
        <el-col :span="12">电话服务</el-col>
      </el-row>
      <el-row class="serve-num">
        <el-col :span="12">大 {{ engineerQueue.publicQueue }} 个 {{ engineerQueue.privateQueue }}</el-col>
        <el-col :span="12">主 {{ engineerQueue.mainQueue }}</el-col>
      </el-row>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
  import { mapActions, mapGetters } from 'vuex'
  import { getEngStatusTime } from '@/api/public'
  import config from '@/store/modules/call-center/config'
  import { ClientType } from '@/store/modules/call-center/enum'

  const defaultStatus = {
    online: 0,
    rest: 0,
    hangup: 0,
    offline: 0
  }

  // 魔方电话状态映射到系统展示状态
  // todo 所以文档中的在线时间，是包含了acw、callin 等额外4种状态的合计？
  const sampleCubeStatusMap = {
    acw: 'online',
    callin: 'online',
    callout: 'online',
    hold: 'online',
    online: 'online',
    rest: 'rest',
    hangup: 'hangup',
    offline: 'offline'
  }

  export default {
    data() {
      return {
        tid: [],
        workStatus: {
          text: { ...defaultStatus },
          phone: { ...defaultStatus }
        }
        // publicQueue: 0,
        // privateQueue: 0
      }
    },
    computed: {
      ...mapGetters(['currentStatus', 'engineerCode']),
      ...mapGetters('call', [
        'currentSession',
        'currentSessionID',
        'engineerQueue',
        'workload'
      ]),
      ...mapGetters('call', ['hasVoicePermission', 'softPhoneStatus']),
      sessionType() {
        if (this.currentSession) {
          return this.currentSession.client_type === ClientType.Telephone ? 'phone' : 'text'
        }
        return 'text'
      }
    },
    methods: {
      ...mapActions('call', [
        'initEngineerServeNum'
      ])
    },
    mounted() {
      this.initEngineerServeNum(this.engineerCode).then(() => {
        // 轮询获取排队信息
        this.tid.push(setInterval(() => {
          this.initEngineerServeNum(this.engineerCode)
        }, config.system.queueQueryLoop * 1000))
      })
      // todo 用的地方多了，可以抽离为一个scoped slot component
      getEngStatusTime(this.engineerCode).then(response => {
        this.workStatus.text = { ...defaultStatus, ...response.data.text }
        this.workStatus.phone = { ...defaultStatus, ...response.data.phone }
        this.tid.push(setInterval(() => {
          this.workStatus.text[this.currentStatus]++
          this.workStatus.phone[sampleCubeStatusMap[this.softPhoneStatus]]++
        }, 1000))
      }).catch(error => {
        this.$message.error('获取客服累计工作时间失败' + error)
      })
    },
    beforeDestroy() {
      this.tid.length && this.tid.forEach(clearInterval)
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  @import "../scss/rules";

  .serve-container {
    background-color: $bg-light-blue;
    border-bottom: 1px solid $borderColor;
    display: flow-root;
    cursor: pointer;

    .serve-main {
      padding: 0px 15px;
      border-bottom: 1px solid $borderColor;
      height: 40px;
      transition: background-color 500ms ease;

      &:hover {
        background-color: darken($bg-light-blue, 10%);
      }

      h3 {
        font-size: 18px;
        font-weight: 500;
        margin: 0;
        line-height: 40px;
      }

      li {
        display: inline-block;
        font-size: 12px;
        float: left;
        width: 50%;
        color: $ldark;
      }
    }

    .serve-detail {
      height: 70px;
      text-align: center;
      display: flow-root;

      .serve-type {
        font-size: 14px;
        color: $ldark;
        margin-top: 10px;
        margin-bottom: 10px;
      }

      .serve-num {
        font-size: 16px;
        font-weight: 500;
      }
    }
  }

  .serve-more {
    padding-left: 10px;

    .serve-item {
      margin-bottom: 10px;
    }

    h4 {
      font-size: 16px;
      color: $dark;
      margin: 0;
    }

    span {
      margin-left: 10px;
    }
  }
</style>

<style lang="scss">
  .serve-main-popper {
    margin-top: -8px !important;
  }
</style>

