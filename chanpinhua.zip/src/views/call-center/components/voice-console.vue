<template>
  <div class="flex-wrp flex-between border-b pd5 console-container">
    <div class="flex-wrp flex-cell flex-between ptb5 plr10">
      <div class="flex-wrp">
        <div class="bold size18 color13">{{displayState}}</div>

        <el-popover placement="bottom-start"
                    v-if="currentSession && currentSession.region"
                    :title="`${currentSession.region.province} ${currentSession.region.city} 天气情况`"
                    trigger="hover">
          <el-table v-if="currentSession && currentSession.weather"
                    :data="currentSession.weather.weather_data"
                    style="width: 100%">
            <el-table-column prop="date"
                             label="日期">
            </el-table-column>
            <el-table-column prop="weather"
                             label="天气">
            </el-table-column>
            <el-table-column prop="wind"
                             label="风力">
            </el-table-column>
            <el-table-column prop="temperature"
                             label="温度">
            </el-table-column>
          </el-table>
          <div class="color14 size14 pl15 text-nowrap pointer"
               slot="reference">
            {{`${currentSession.region.province} ${currentSession.region.city}`}}
            <img width="24"
                 v-if="currentSession && currentSession.weather"
                 :src="$get(currentSession.weather, 'weather_data[0].dayPictureUrl')"
                 :alt="$get(currentSession.weather, 'weather_data[0].weather')">
          </div>
        </el-popover>
      </div>
      <div class="flex-wrp flex-align-center color14 size14 pt5"
           v-if="currentSession">
        <div :style="{width: '70px'}">随路数据</div>
        <div :style="{maxWidth: !isAcwSession ? `calc(100vw - 1290px)` : `calc(100vw - 990px)`, minWidth: '130px'}">
          <template v-if="alongRoadData === '-'">{{alongRoadData}}</template>
          <template v-else>
            <el-tooltip class="item"
                        effect="light"
                        popper-class="nbr bs-border"
                        placement="top"
                        :visible-arrow="false"
                        :content="alongRoadData">
              <div class="text-nowrap">{{alongRoadData}}</div>
            </el-tooltip>
          </template>
        </div>
        <!-- <div class="pt5 text-nowrap">当前情绪&nbsp;&nbsp;&nbsp;&nbsp;{{`2.5`}}</div> -->
      </div>
    </div>

    <div class="flex-wrp flex-bottom flex-align-center"
         v-if="!isAcwSession"
         :style="{minWidth: '400px'}">
      <!-- 正在通话：转接、多方通话、挂断、满意度 -->
      <!-- {{transferConnId + callState + callType + messageName}} -->
      <div class="plr5 tel-box relative"
           v-show="showButtons.transferStatus">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="transfer">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="zhuanjie"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center">转接</div>
          </div>
          <div class="pointer tel-button ptb5"
               @click="abroadTransfer">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="zhuanjie"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center">转接第三方</div>
          </div>
          <div class="pointer tel-button ptb5"
               @click="onLineTransfer">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="zhuanjie"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center">在线转接</div>
          </div>
        </div>
      </div>

      <!-- 完成转接（队列）（2步） -->
      <div class="plr5 tel-box relative"
           v-show="showButtons.completeTransferStatus">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="finishTransfer">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="guaduan"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">完成转接</div>
          </div>
        </div>
      </div>

      <!-- 完成会议（2步） -->
      <div class="plr5 tel-box relative"
           v-show="showButtons.completeMeetingStatus">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="api.completeConference(connId, transferConnId)">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="guaduan"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">完成会议</div>
          </div>
        </div>
      </div>
      <div class="plr5 tel-box relative"
           v-show="showButtons.satisfactionDegreeStatus">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="satisfactionDegree">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="manyidu"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">满意度</div>
          </div>
        </div>
      </div>
      <div class="plr5 tel-box relative"
           v-show="showButtons.satisfactionDegreeStatus">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="onWeChat">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="wechart"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">转微信</div>
          </div>
        </div>
      </div>
      <!-- 正在通话：保持和取回 -->
      <div class="plr5 tel-box relative"
           v-show="showButtons.holdStatus">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="onHold">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="hold"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">HOLD</div>
          </div>
        </div>
      </div>

      <div class="plr5 tel-box relative"
           v-show="showButtons.pickUpStatus">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="onReceive">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="jieqi"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">接起</div>
          </div>
        </div>
      </div>
      <!-- 外呼状态 -->
      <div class="plr5 tel-box relative"
           v-show="showButtons.hangUpStatus">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="hangUpCall">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="guaduan"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">挂断</div>
          </div>
        </div>
      </div>

      <!-- 就绪、小休、离线状态：拨号、多方通话 -->
      <div class="plr5 tel-box relative"
           v-show="showButtons.dialStatus">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="phoneCall">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="bohao"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">拨号</div>
          </div>
        </div>
      </div>

      <div class="plr5 tel-box relative"
           v-show="showButtons.meetingStatus">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="phonesCalls">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="duofangtonghua"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">多方通话</div>
          </div>
        </div>
      </div>

    </div>

    <!-- 案面默认只显示外呼按钮 -->
    <div class="flex-wrp flex-bottom flex-align-center" v-else>
      <!-- 振铃显示接听和挂断 -->
      <!--<div class="plr5 tel-box relative" v-show="showButtons.answer">-->
      <div class="plr5 tel-box relative" v-show="callState === CallState.Ringing">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="pickUp">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="jieqi"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">接听</div>
          </div>
        </div>
      </div>
      <!--<div class="plr5 tel-box relative" v-show="showButtons.hangUpStatus">-->
      <div class="plr5 tel-box relative"
           v-show="[CallState.Ringing, CallState.Established, CallState.Held].includes(callState)">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="hangUpCall">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="guaduan"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">挂断</div>
          </div>
        </div>
      </div>
      <div class="plr5 tel-box relative"
           v-show="![EngineerStatus.Offline, EngineerStatus.Callin, EngineerStatus.Callout, EngineerStatus.Hold].includes(softPhoneStatus)">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div class="pointer tel-button ptb5"
               @click="phoneCall">
            <div class="size36 flex-wrp flex-center">
              <svg-icon icon-class="bohao"></svg-icon>
            </div>
            <div class="size14 tel-text pt10 text-nowrap text-center lh100">拨号</div>
          </div>
        </div>
      </div>
    </div>

    <el-dialog :visible.sync="transferVisible"
               width="440px"
               title="转接"
               custom-class="dial"
               :show-close="false">
      <voice-transfer defaultActiveName="first"
                      :transfer="1"
                      @onsubmitqueue="onSubmitQueue"
                      @onsubmitpersonal="onSubmitPersonal"
                      :visible="transferVisible"/>
    </el-dialog>

    <el-dialog :visible.sync="onLineTransferVisible"
               width="440px"
               title="在线转接"
               custom-class="dial"
               :show-close="false">
      <voice-transfer defaultActiveName="second"
                      :transfer="2"
                      @onsubmitqueue="onTwoSubmitQueue"
                      @onsubmitpersonal="onTwoSubmitPersonal"
                      :visible="onLineTransferVisible"/>
    </el-dialog>

    <el-dialog :visible.sync="abroadTransferVisible"
               width="400px"
               title="转接第三方">
      <voice-dial @onsubmit="abroadTransferCall"
                  :visible="abroadTransferVisible"
                  :complete="showStatus.transferCompleted"
                  type="transfer"/>
    </el-dialog>

    <el-dialog :visible.sync="phoneCallVisible"
               width="400px"
               title="拨号">
      <voice-dial @onsubmit="dialCall"
                  :dialing="true"
                  :visible="phoneCallVisible"/>
    </el-dialog>

    <el-dialog :visible.sync="phonesCallsVisible"
               width="400px"
               title="多方通话">
      <voice-dial @onsubmit="multipartyTel"
                  :visible="phonesCallsVisible"
                  :complete="showStatus.meetingCompleted"
                  type="meeting"/>
    </el-dialog>

    <el-dialog
      :visible.sync="transferWechatStatus"
      :show-close="true"
      width="500px"
      custom-class=""
      :before-close="done => done()">
      <div class="flex-wrp flex-cell flex-center bg-white pb15">
        <div class="color2 bold size16">提醒用户关注“联想服务”公众号，并告知以下邀请码接入</div>
        <div class="flex-wrp flex-center size12 lh200 pt15">
          <div class="flex-wrp flex-cell">
            <div class="color2 bold flex-wrp flex-bottom">邀请码：</div>
            <div class="color2 bold">有效期剩余：</div>
          </div>
          <div class="flex-wrp flex-cell">
            <div class="color4 size14">{{transfer_code}}</div>
            <div :style="{color: 'red'}" v-if="typeof transferWechatTime === 'string'">{{transferWechatTime}}</div>
            <div :style="{color: 'red'}" v-else>{{transferWechatTime | time}}</div>
          </div>
        </div>
        <el-button @click="onWeChat" class="mt15" v-if="typeof transferWechatTime === 'string'">重新获取</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import * as api from '@/api/call-center/softphone'
  import { mapActions, mapGetters } from 'vuex'
  // import * as callApi from '@/api/call-center/call-center-phone'
  import VoiceDial from '@/views/call-center/components/voice-dial'
  import VoiceTransfer from '@/views/call-center/components/voice-transfer'
  import { AgentState, CallState, CallType, EngineerStatus, MessageName, ThirdPartyRole } from '@call/voice/enum'
  import { postApiWbPhoneRecordTransferCode } from '@/api/call-center/call-center-phone'

  export default {
    data() {
      return {
        CallState,
        CallType,
        MessageName,
        AgentState,
        EngineerStatus,
        ThirdPartyRole,
        phoneCallVisible: false,
        phonesCallsVisible: false,
        abroadTransferVisible: false,
        transferVisible: false,
        onLineTransferVisible: false,
        api,
        showStatus: {
          conference: false,
          transferCompleted: false,
          transferDialing: false,
          meetingCompleted: false
        },
        transferData: null,
        transferWechatStatus: false,
        transferWechatTime: 600,
        transfer_code: '',

        timer: {
          toWechat: false,
          autoPickup: false
        }
      }
    },
    components: {
      VoiceDial,
      VoiceTransfer
    },
    computed: {
      ...mapGetters('call', [
        'currentSession',
        'engineerCode'
      ]),
      ...mapGetters('call', [
        'voiceCubeSession',
        'agentState',
        'agentStateExt',
        'softPhoneStatus',
        'callState',
        'callType',
        'phoneNumber',
        'connId',
        'transferConnId',
        'userData',
        'showButtons',
        'g_sAni',
        'consultSession',
        'callMessage'
      ]),
      ...mapGetters(['allInfo', 'engineerCode']),
      isAcwSession() {
        if (this.currentSession) {
          return this.currentSession.isVirtual
        }
        return false
      },
      displayState() {
        if (this.consultSession.active) {
          return `[内部] ${this.consultSession.otherDn}`
        }

        if (this.currentSession) {
          if (this.currentSession.isVirtual) {
            return '案面'
          } else {
            return this.currentSession.phone || this.phoneNumber
          }
        }

        if (this.agentStateExt === AgentState.AfterCallWork) {
          return '案面'
        }

        if (this.agentState !== AgentState.Ready) {
          return '未就绪'
        }
        if (this.callState === CallState.Released) {
          return '等待接入'
        } else if (!this.currentSession) {
          return '获取会话信息中'
        }
      },
      alongRoadData() {
        // todo
        // 1. 确认用户后需通过发送 this.$store.commit('SET_VOICE_QUEUE_DATA', { id: session.id, queueData: this.currentSession.queueData.concat(newQueueData:String) }) 形式 向 this.currentSession.queueData 添加随路数据
        // 2. 然后发送 api.attachUserData(connId, { queueData: `${this.currentSession.queueData:String[]}` }) 通知易迅，后续会自动处理, 注意 newQueueData 为你要添加的字符串类型 队列
        // 3. 注意此处 conId 为 （this.connId）
        return (this.currentSession.queueData && this.currentSession.queueData.join(' / ')) || '-'
      }
    },
    watch: {
      // 就绪和案面时自动接起电话（not ready 下也然能被固话接起）
      // 这里做个延迟pickup ，避免组件实例化过程错过了Established 事件，从而导致session “振铃中” 问题
      callState(callState) {
        if (callState === CallState.Ringing && [AgentState.Ready, AgentState.AfterCallWork].includes(this.agentStateExt)) {
          const isInConsult = this.callType === CallType.Consult && this.consultSession.active && this.consultSession.connId !== this.connId

          this.timer.autoPickup = setTimeout(() => {
            // todo 需要验证下，当有第二个内部通话进来后，按钮状态是否在挂断之后恢复正常
            // 如果当前正在进行着内部通话，则挂断并给工程师提示
            if (isInConsult) {
              api.hangup(this.connId).catch(this._errorHandle).finally(() => {
                this.$message.info('当前已有正在进行中的内部通话。')
              })
            } else {
              this.pickUp()
            }
          }, 500)
        }

        // 针对abandon session，移除pickup 响应timer
        if (callState === CallState.Released && this.callMessage.messageName === MessageName.EventAbandoned) {
          clearTimeout(this.timer.autoPickup)
        }
      },
      // 路由唤起拨号盘
      '$route.query.callNumber': function(callNumber) {
        if (callNumber) {
          this.phoneCallVisible = true
        }
      }
    },
    beforeDestroy() {
      this.timer.toWechat && clearInterval(this.timer.toWechat)
      this.timer.autoPickup && clearTimeout(this.timer.autoPickup)
    },
    methods: {
      ...mapActions('call', [
        'makeDialCall',
        'makeConference',
        'makeTransfer',
        'transferTelQueue',
        'conference',
        'twoTransferTelQueue',
        'twoConference',
        'removeAllVirtualVoiceConversion'
      ]),
      satisfactionDegree() {
        api.satisfactionDegree(this.connId, {
          g_sAni: this.g_sAni,
          CALLID: this.voiceCubeSession.call_id,
          AgentID: this.engineerCode,
          strCustomerID: this.$get(this.voiceCubeSession, 'details.CustomerID'),
          // todo 可能需要取最后一个queue data
          strAgentgroupName: this.$get(this.voiceCubeSession, 'queueData[0]')
        }).catch(this._errorHandle)
      },
      dialCall(phones) {
        // 除了离线，正在通话中，hold三种情况，其他电话条的任意状态都可以外呼
        const callableStatus = [
          EngineerStatus.Offline,
          EngineerStatus.Logout,
          EngineerStatus.Callin,
          EngineerStatus.Callout,
          // hold 仅存在于通话中，这个时候按钮状态约束已经控制住不能外呼了
          // 但仍然要防止首问提醒的处理动作创建的外呼
          EngineerStatus.Hold
        ]
        if (callableStatus.includes(this.softPhoneStatus)) {
          const errorMsg = `电话台现在处于${this.softPhoneStatus}，不能进行外呼操作`
          this.$message.warning(errorMsg)
          return Promise.reject(errorMsg)
        }
        // 外呼前移除所有案面电话会话
        // this.removeAllVirtualVoiceConversion()
        // 外拨分机号，本地加前缀9，外地加前缀90
        // 提供给首问处理用
        return this.makeDialCall(phones).then(res => {
          this.phoneCallVisible = false
        })
      },
      publicAddQueueData(skill) {
        // 工程师光标不确定在哪个session 上，currentSession 可能为空
        // const connId = this.currentSession.phone_conn_id
        const connId = this.connId || this.voiceCubeSession.phone_conn_id
        const queueData = this.voiceCubeSession.queueData
        const thatQueueData = this.$get(this.voiceCubeSession, 'voiceData.call.userData.queueData')
        // 存储随路数据
        let afterAttachPromise
        if (thatQueueData !== undefined) {
          if (queueData instanceof Array) {
            afterAttachPromise = api.updateUserData(connId, { queueData: `${queueData.concat(skill)}` })
          } else {
            afterAttachPromise = api.updateUserData(connId, { queueData: skill })
          }
        } else {
          if (queueData instanceof Array) {
            afterAttachPromise = api.attachUserData(connId, { queueData: `${queueData.concat(skill)}` })
          } else {
            afterAttachPromise = api.attachUserData(connId, { queueData: skill })
          }
        }
        return afterAttachPromise
      },
      onSubmitQueue(data) { // 1步转接队列
        this.publicAddQueueData(data.skill).then(res => {
          return this.transferTelQueue(data)
        }).catch(this._errorHandle).finally(() => {
          this.transferVisible = false
        })
      },
      finishTransfer() {
        this.publicAddQueueData(this.transferData.skill).then(() => {
          return api.finishConference(this.connId, this.transferConnId)
        }).catch(this._errorHandle)
      },
      onSubmitPersonal(data) { // 1步转接个人
        this.publicAddQueueData(data.skill).then(() => {
          return this.conference(data)
        }).finally(() => {
          this.transferVisible = false
        }).catch(this._errorHandle)
      },
      onTwoSubmitQueue(data) { // 2步转接队列
        this.twoTransferTelQueue(data).then(res => {
          this.onLineTransferVisible = false
          this.transferData = data
        })
      },
      onTwoSubmitPersonal(data) { // 2步转接个人
        this.twoConference(data).then(res => {
          this.onLineTransferVisible = false
          this.transferData = data
        })
      },
      // 多方通话
      multipartyTel(phones) {
        this.makeConference(phones.tel).then(res => {
          this.phonesCallsVisible = false
        })
      },
      // 挂断电话
      hangUpCall() {
        api.hangup(this.transferConnId || this.connId).catch(this._errorHandle)
        if (this.connId && !this.transferConnId) {
          this.showStatus.conference = false
        }
      },
      phoneCall() {
        this.phoneCallVisible = true
      },
      // 接起电话
      pickUp() {
        api.answerCall(this.connId).catch(this._errorHandle)
      },
      phonesCalls() {
        this.phonesCallsVisible = true
      },
      onHold() {
        this.showhold = !this.showhold
        api.holdCall(this.transferConnId || this.connId).catch(this._errorHandle)
      },
      onReceive() {
        api.retrieveCall(this.transferConnId || this.connId).catch(this._errorHandle)
      },
      // 转接第三方
      abroadTransferCall(phones) {
        this.makeTransfer(phones.tel).then(res => {
          this.abroadTransferVisible = false
        })
      },
      // 转接微信
      onWeChat() {
        const { lenovo_id, id, phone } = this.currentSession
        postApiWbPhoneRecordTransferCode(lenovo_id, id, phone).then(res => {
          // this.$message.success('转接成功！')
          if (this.timer.toWechat) {
            clearInterval(this.timer.toWechat)
            this.transferWechatTime = 600
          }
          this.transferWechatStatus = true
          this.transfer_code = res.data.transfer_code
          this.timer.toWechat = setInterval(() => {
            if (this.transferWechatTime > 0) {
              this.transferWechatTime -= 1
            } else {
              clearInterval(this.timer.toWechat)
              this.transferWechatTime = '邀请码已失效'
            }
          }, 1000)
        }).catch(msg => {
          this.$message.error(msg || '转接失败')
          if (this.timer.toWechat && msg === '10分钟之内只能获取一次转接码') {
            this.transferWechatStatus = true
          } else {
            if (this.timer.toWechat) {
              clearInterval(this.timer.toWechat)
            }
          }
        })
      },
      abroadTransfer() {
        this.abroadTransferVisible = true
      },
      transfer() {
        this.transferVisible = true
      },
      onLineTransfer() {
        this.onLineTransferVisible = true
      },
      _errorHandle(error) {
        // this.$report(error)
        this.$message.error(error)
      }
    }
  }
</script>

<style lang="scss" scoped>
  .console-container {
    background-color: #fff;
    height: 95px;
  }

  /deep/ .dial {
    background: none;

    .el-dialog__header {
      display: none;
    }

    .el-dialog__body {
      padding: 0;
    }
  }
</style>
