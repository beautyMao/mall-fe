<template>
  <div class="flex-wrp flex-between border-b pr5" v-loading="agentOperationLoading">
    <div class="ptb10 pl15 flex-wrp flex-center">
      <div class="flex-wrp flex-between" style="width: 260px;">
        <div class="flex-wrp flex-between" style="width: 100px;">
          <div>
            <div class="size14 color2 bold" style="line-height: 30px;">呼出</div>
            <div class="size14 color2 bold" style="line-height: 30px;">呼入</div>
          </div>
          <div class="pl10" style="width: 70px;">
            <div class="size14 color4" style="line-height: 30px;">{{workload.callout_num}}</div>
            <div class="size14 color4" style="line-height: 30px;">{{workload.callin_num}}</div>
          </div>
        </div>
        <div class="flex-wrp flex-between" style="width: 160px;">
          <div>
            <div class="size14 color2 bold" style="line-height: 30px;">HOLD量</div>
            <div class="size14 color2 bold" style="line-height: 30px;">AHT</div>
          </div>
          <div class="pl10" style="width: 100px;">
            <div class="size14 color4" style="line-height: 30px;">{{workload.hold_num}}</div>
            <div class="size14 color4" style="line-height: 30px;">{{workload.call_avg_time}}</div>
          </div>
        </div>
      </div>
    </div>

    <div class="flex-wrp flex-bottom flex-align-center" style="min-width: 300px;">
      <div class="plr5 tel-box tel-top-box relative">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div
            @click="ready"
            :class="!isReady || isAcw ? 'disabled' : ''"
            class="pointer tel-button ptb5">
            <div class="size24 flex-wrp flex-center">
              <svg-icon v-if="isReady && !isAcw" icon-class="telzaixianfocus"></svg-icon>
              <svg-icon v-else icon-class="telzaixian"></svg-icon>
            </div>
            <div
              v-if="isReady && !isAcw"
              class="size12 tel-text pt5 text-nowrap text-center lh100 blue"
            >{{workStatus.phone.online|time}}</div>
            <div v-else class="size12 tel-text pt5 text-nowrap text-center lh100">就绪</div>
          </div>
        </div>
      </div>
      <div class="plr5 tel-box tel-top-box relative">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <div
            @click="onRest"
            class="pointer tel-button ptb5"
            :class="!isRest || isAcw ? 'disabled' : ''">
            <div class="size24 flex-wrp flex-center">
              <svg-icon v-if="isRest && !isAcw" icon-class="telxiaoxiufocus"></svg-icon>
              <svg-icon v-else icon-class="telxiaoxiu"></svg-icon>
            </div>
            <div
              v-if="isRest && !isAcw"
              class="size12 tel-text pt5 text-nowrap text-center lh100 blue"
            >{{workStatus.phone.rest|time}}</div>
            <div v-else class="size12 tel-text pt5 text-nowrap text-center lh100">小休</div>
          </div>
        </div>
      </div>
      <div class="plr5 tel-box tel-top-box relative">
        <div class="content ptb5 bg-white flex-wrp flex-cell flex-between flex-middle">
          <el-popover
            width="160"
            placement="bottom"
            v-model="offlinePopoverVisible"
            trigger="click">
            <p>确定要离线么？</p>
            <div class="text-right">
              <el-button size="mini" type="text" @click="offlinePopoverVisible = false">取消</el-button>
              <el-button type="primary" size="mini" @click="offLine">确定</el-button>
            </div>
            <div
              slot="reference"
              :class="!isOffline || isAcw ? 'disabled' : ''"
              class="pointer tel-button ptb5">
              <div class="size24 flex-wrp flex-center">

                <svg-icon v-if="isOffline" icon-class="tellixianfocus"></svg-icon>
                <svg-icon v-else icon-class="tellixian"></svg-icon>
              </div>
              <div class="size12 tel-text pt5 text-nowrap text-center lh100">离线</div>
            </div>
          </el-popover>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { mapActions, mapGetters } from 'vuex'
  import * as api from '@/api/call-center/softphone'
  import { AgentState, CallState, EngineerStatus } from '@/store/modules/call-center/voice/enum'
  import { getEngStatusTime } from '@/api/public'

  const defaultStatus = {
    online: 0,
    rest: 0,
    hangup: 0,
    offline: 0
  }

  // 魔方电话状态映射到系统展示状态
  // todo 所以文档中的在线时间，是包含了acw、callin 等额外4种状态的合计？
  const sampleCubeStatusMap = {
    acw: 'online',
    callin: 'online',
    callout: 'online',
    hold: 'online',
    online: 'online',
    rest: 'rest',
    hangup: 'hangup',
    offline: 'offline'
  }

  export default {
    data() {
      return {
        tid: [],
        workStatus: {
          phone: { ...defaultStatus }
        },

        offlinePopoverVisible: false,
        // 电话的坐席状态操作，避免连续点击造成重复ready 和双进线问题
        agentOperationLoading: false,
        timer: null
      }
    },
    computed: {
      ...mapGetters('call', [
        'agentState',
        'callState',
        'callMessage',
        'workload',
        'voiceCubeSession',
        'softPhoneStatus',
        'agentStateExt'
      ]),
      ...mapGetters(['engineerCode']),
      isOffline() {
        return this.agentStateExt === AgentState.Offline
      },
      isReady() {
        return this.agentStateExt !== AgentState.AfterCallWork &&
          this.agentState === AgentState.Ready &&
          sampleCubeStatusMap[this.softPhoneStatus] === EngineerStatus.Online
      },
      isRest() {
        return this.agentStateExt === AgentState.AuxWork
      },
      isReleaseed() {
        return this.callState === CallState.Released
      },
      isAcw() {
        return this.softPhoneStatus === EngineerStatus.Acw
      }
    },
    watch: {
      // 就绪即取消loading
      agentStateExt(agentStateExt) {
        if ([AgentState.Ready, AgentState.AuxWork, AgentState.Offline].includes(agentStateExt)) {
          this.agentOperationLoading = false
          clearTimeout(this.timer)
        }
      }
    },
    methods: {
      ...mapActions('call', [
        'removeAllVirtualVoiceConversion',
        'initSoftphone',
        'logoutSoftphone'
      ]),
      _errorHandle(error) {
        // 如果判断出是电话session 失效，给出提示并重新登录
        if (typeof error === 'string') {
          this.$alert('电话登录状态失效，点击确定后将自动重连', '提示', {
            confirmButtonText: '确定',
            callback: action => {
              this.initSoftphone()
            }
          })
        } else {
          this.$message.error(error)
        }
      },
      // 确保坐席的几个操作有序进行
      _agentOperation() {
        clearTimeout(this.timer)
        this.agentOperationLoading = true
        // 为避免事件丢失导致持续的loading
        this.timer = setTimeout(() => {
          this.agentOperationLoading = false
          this.$message.warning('服务器未及时响应坐席的操作，请重试一次')
        }, 10 * 1000)
      },
      _preAction() {
        this._agentOperation()
        let preActionPromise = Promise.resolve('ok')
        if (this.isOffline) {
          preActionPromise = this.initSoftphone()
        }
        return preActionPromise
      },
      // 就绪 在线
      ready() {
        const preActionPromise = this._preAction()

        if (!this.isReady) {
          if (!this.isReleaseed) {
            return this.$message('正在通话中，不能切换状态')
          }
          preActionPromise.then(() => {
            return api.ready()
          }).then(() => {
            // 就绪之后将尝试移除虚拟会话（案面状态）
            return this.removeAllVirtualVoiceConversion()
          }).catch(this._errorHandle)
        }
      },
      // 未就绪 小休
      onRest() {
        const preActionPromise = this._preAction()

        if (!this.isReleaseed) {
          return this.$message('正在通话中，不能切换状态')
        }
        preActionPromise.then(() => {
          return api.auxWork()
        }).then(() => {
          // 小休之后将尝试移除虚拟会话（案面状态）
          return this.removeAllVirtualVoiceConversion()
        }).catch(this._errorHandle)
      },
      // 就绪 离线
      offLine() {
        this.offlinePopoverVisible = false

        if (!this.isReleaseed) {
          return this.$message('正在通话中，不能切换状态')
        }
        // api.notReady().catch(this._errorHandle)
        // api.offline().catch(this._errorHandle)
        this._agentOperation()
        this.logoutSoftphone().catch(this._errorHandle)
      }
    },
    mounted() {
      getEngStatusTime(this.engineerCode).then(response => {
        this.workStatus.phone = { ...defaultStatus, ...response.data.phone }
        this.tid.push(setInterval(() => {
          this.workStatus.phone[sampleCubeStatusMap[this.softPhoneStatus]]++
        }, 1000))
      }).catch(error => {
        this.$message.error('获取工程师累计工作时间失败' + error)
      })
    },
    beforeDestroy() {
      this.tid.length && this.tid.forEach(clearInterval)
      clearTimeout(this.timer)
    }
  }
</script>

<style lang="scss" scoped>
  .blue {
    color: #F37261 !important;
  }
</style>
