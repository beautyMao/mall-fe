<template>
  <div id="Enterprise" class="Enterprise">
    <div class="box">
      <h4 class="title">
        <span>企业logo</span>
        <span class="hint">(50kb以内，支持png/jpg)</span>
      </h4>
      <el-upload class="avatar-uploader" :action="uploadUrl()" :show-file-list="false" :before-upload="beforeAvatarUpload" :on-success="handleAvatarSuccess">
        <img v-if="avatar" :src="avatar" class="avatar">
        <i v-else class="el-icon-plus avatar-uploader-icon" />
      </el-upload>
      <h4 class="title">企业名称</h4>
      <el-input
        v-model="name"
        placeholder="最多20个字，支持中、英文及数字，不支持特殊符号"
        maxlength="20"
        clearable
        class="input"
      />
      <h4 class="title">企业简介</h4>
      <!--<div style="margin: 20px 0;"></div>-->
      <el-input
        v-model="intro"
        type="textarea"
        placeholder="请输入企业简介，最多支持500字"
        maxlength="500"
        show-word-limit
        class="intro"
      />
      <div class="button">
        <el-button type="primary" class="btn" @click="handleBtnClick">保存</el-button>
      </div>
    </div>
  </div>
</template>

<script>
  import { getConfigCompanyInfo, getConfigCompanyInfo1 } from '@/api/enterprise'
  import { getToken } from '@/utils/auth'

  export default {
    name: 'company-management',
    data() {
      return {
        name: '',
        intro: '',
        avatar: '',
        reg: /^[\w\u4E00-\u9FA5]{1,20}$/
      }
    },
    mounted() {
      getConfigCompanyInfo1().then(res => {
        if (res.statusCode === 200) {
          this.name = res.data.company_name
          this.intro = res.data.company_info
          this.avatar = res.data.company_logo
        }
      })
    },
    methods: {
      handleBtnClick() {
        if (!this.reg.test(this.name)) {
          this.$message({
            message: '请输入正确的企业名称',
            type: 'warning'
          })
          return
        }
        if (!this.intro) {
          this.$message({
            message: '请输入正确的企业简介',
            type: 'warning'
          })
          return
        }
        const data = {
          company_name: this.name.replace(/(^\s*)|(\s*$)/g, ''),
          company_info: this.intro.replace(/(^\s*)|(\s*$)/g, ''),
          company_logo: this.avatar
        }
        getConfigCompanyInfo(data).then(res => {
          this.$message({
            message: '保存成功',
            type: 'success'
          })
        })
      },
      uploadUrl() { // 上传图片地址
        if (document.domain === 'localhost') {
          return `https://imccdev.lenovo.com.cn/api/wb/image/up?token=${getToken()}`
        } else {
          return `https://${document.domain}/api/wb/image/up?token=${getToken()}`
        }
      },
      handleAvatarSuccess(res, file) {
        this.avatar = res.data.picUrl
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg' || file.type === 'image/png'
        console.log(file.size)
        const isLt = file.size / 1024 < 200

        if (!isJPG) {
          this.$message.error('上传图片只能是 JPG或PNG 格式!')
        }
        if (!isLt) {
          this.$message.error('上传图片大小不能超过 200KB!')
        }
        return isJPG && isLt
      }
    }
  }
</script>

<style scoped lang="scss">
  .Enterprise {
    padding: 20px;
    margin: 20px;
    overflow: hidden;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
    background: #fff;
    .box {
      & /deep/ .el-input__inner {
        height: 40px;
        line-height: 40px;
      }
      & /deep/ .el-input__count {
        bottom: 5px;
      }
    }
    .title {
      margin: 10px 0;
      .hint {
        font-size: 12px;
        font-weight: 100;
      }
    }
    .input {
      width: 400px;
    }
    .button {
      position: fixed;
      left: 0;
      right: 0;
      bottom: 0;
      height: 64px;
      box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
      background: #fff;
      .btn {
        float: right;
        width: 150px;
        height: 40px;
        margin-top: 12px;
        margin-right: 35px;
      }
    }
  }
  .intro /deep/ .el-textarea__inner {
    border: 1px solid #DCDFE6!important;
    min-height: 240px!important;
  }
</style>
<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 200px;
    height: 70px;
    line-height: 178px;
    text-align: center;
  }
  .avatar {
    width: 200px;
    height: 70px;
    display: block;
  }
</style>
