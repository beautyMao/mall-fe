<template>
  <div class="app-container">
    <h1 class="title">常见问题维护</h1>
    <el-card class="box-card">
      <h4>
        <span>常见问题</span>
        <span class="hint">(最多120个字，支持中、英文及数字，不支持特殊符号，最多可添加五条)</span>
      </h4>
      <el-button type="primary" plain class="add" @click="addFAQ">新 增</el-button>
      <div v-for="(item, index) in listData.common_problem" class="list">
        <el-input
          v-model="item.problem"
          type="textarea"
          placeholder="请输入常见问题名称"
          maxlength="120"
          resize="none"
          show-word-limit
          clearable
          class="input"
          @blur="inputBlur(item.problem, $event)"
        />
        <el-input
          v-model="item.answer"
          type="textarea"
          placeholder="请输入对应的答案"
          maxlength="120"
          resize="none"
          show-word-limit
          clearable
          class="input"
          @blur="inputBlur(item.answer, $event)"
        />
        <el-button type="text" @click="delFAQ(index)">删除</el-button>
      </div>
      <h4>
        <span>推荐话术</span>
        <span class="hint">(最多50个字，支持中、英文及数字，不支持特殊符号)</span>
      </h4>
      <el-input
        v-model="listData.speech"
        type="textarea"
        placeholder="请输入内容"
        maxlength="50"
        resize="none"
        show-word-limit
        clearable
        class="input1"
        @blur="inputBlur(listData.speech, $event)"
      />
    </el-card>
    <div class="button">
      <el-button type="primary" class="btn" @click="handleBtnClick">保存</el-button>
    </div>
  </div>
</template>

<script>
  import { getCommonProblem, postCommonProblem } from '@/api/enterprise'
  const regEn = /[`~@#$%^&*()_+<>?:"{}\/'[\]]/im
  const regCn = /[#￥（——）：“”‘’|《》【】[\]]/im
  // /[`~!@#$%^&*()_+<>?:"{},.\/;'[\]]/im，/[·！#￥（——）：；“”‘、，|《。》？、【】[\]]/im
  export default {
    name: 'frequently-asked-question',
    data() {
      return {
        listData: {
          speech: '',
          common_problem: []
        }
      }
    },
    mounted() {
      getCommonProblem().then(res => {
        this.listData = res.data
      })
    },
    methods: {
      addFAQ() {
        if (this.listData.common_problem.length < 5) {
          this.listData.common_problem.push({
            problem: '',
            answer: ''
          })
        } else {
          this.$message.warning('最多可添加五条')
        }
      },
      delFAQ(index) {
        this.listData.common_problem.splice(index, 1)
      },
      inputBlur(data, _this) {
        // if (data === '' || regEn.test(data) || regCn.test(data)) {
        //   _this.target.style.borderColor = '#F37261'
        // } else {
        //   _this.target.style.borderColor = '#C0C4CC'
        // }
      },
      handleBtnClick() {
        if (!this.listData.speech) {
          this.$message.warning('请填写推荐话术')
          return
        }
        for (const item of this.listData.common_problem) {
          if (!(item.answer && item.problem)) {
            this.$message.warning('请填写问题或答案')
            return
          }
          if ((regEn.test(item.answer) || regCn.test(item.answer)) || regEn.test(item.problem) || regCn.test(item.problem)) {
            this.$message.warning('问题或答案不支持特殊符号')
            return
          }
        }
        postCommonProblem(this.listData).then(res => {
          this.$message.success('提交成功')
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  .title {
    margin: 0;
    margin-bottom: 20px;
  }
  .list {
    display: flex;
    justify-content: space-between;
    padding-bottom: 20px;
    .input {
      width: 48%;
      height: 90px;
      & /deep/ .el-textarea__inner {
        height: 100%;
      }
      & /deep/ .el-input__count {
        bottom: 5px;
      }
    }
  }
  .input1 {
    height: 110px;
    padding-bottom: 20px;
    & /deep/ .el-textarea__inner {
      height: 100%;
    }
    & /deep/ .el-input__count {
      bottom: 25px;
    }
  }
  .hint {
    font-size: 12px;
    font-weight: 100;
  }
  .button {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    height: 64px;
    box-shadow: 0 2px 12px 0 rgba(0, 0, 0, .1);
    background: #fff;
    .btn {
      float: right;
      width: 150px;
      height: 40px;
      margin-top: 12px;
      margin-right: 35px;
    }
  }
  .add {
    width: 150px;
    height: 40px;
    margin-bottom: 16px;
  }
</style>
