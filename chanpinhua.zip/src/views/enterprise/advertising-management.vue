<template>
  <div class="app-container">
    <h1 class="title">广告管理</h1>
    <el-card class="box-card">
      <h4>
        <span>广告轮播图</span>
        <span class="hint">(最多120个字，支持中、英文及数字，不支持特殊符号，最多可添加三条)</span>
      </h4>
      <el-button type="primary" plain class="add" @click="addSlideshow">新 增</el-button>
      <el-table :data="listData" style="width: 100%" tooltip-effect="light" class="tab">
        <el-table-column type="index" label="序号" width="100" />
        <el-table-column prop="title" label="标题" />
        <el-table-column prop="target_url" label="链接" />
        <el-table-column prop="created_at" label="创建时间" />
        <el-table-column prop="" label="操作" width="100">
          <template slot-scope="scope">
            <el-button type="text" @click="itemRedact(scope.row)">编辑</el-button>
            <el-button type="text" @click="itemDelete(scope.row)">删除</el-button>
          </template>
        </el-table-column>
      </el-table>
    </el-card>
    <dialog-create-advertising
      :dialog-create-advertising="dialogCreateAdvertising"
      :data1="data"
      @changeDialog="changeDialog"
    />
  </div>
</template>

<script>
  import dialogCreateAdvertising from './components/dialog-create-advertising'
  import { getBanner, getDelBanner } from '@/api/enterprise'
  export default {
    name: 'advertising-management',
    components: { dialogCreateAdvertising },
    data() {
      return {
        listData: [],
        dialogCreateAdvertising: false,
        data: { status: 'add' }
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      init() {
        getBanner().then(res => {
          this.listData = res.data
        })
      },
      addSlideshow() {
        if (this.listData.length < 3) {
          this.dialogCreateAdvertising = true
        } else {
          this.$message({
            message: '广告已满，请删除一条后，再进行维护',
            type: 'warning'
          })
        }
      },
      changeDialog(val) {
        if (val === 'add-succ') {
          this.$message({
            message: '创建成功',
            type: 'success'
          })
          this.init()
        }
        if (val === 'redact-succ') {
          this.$message({
            message: '编辑成功',
            type: 'success'
          })
          this.init()
        }
        this.data = { status: 'add' }
        this.dialogCreateAdvertising = false
      },
      itemRedact(row) {
        this.dialogCreateAdvertising = true
        this.data = {
          id: row.id,
          title: row.title,
          image_url: row.image_url,
          target_url: row.target_url
        }
      },
      itemDelete(row) {
        this.$confirm(`此操作将删除 ${row.title} 且无法撤销，是否继续？`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          getDelBanner(row.id).then(res => {
            this.$message({
              message: '删除成功',
              type: 'success'
            })
            this.init()
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消删除'
          })
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  .title {
    margin: 0;
    margin-bottom: 20px;
  }
  .hint {
    font-size: 12px;
    font-weight: 100;
  }
  .add {
    width: 150px;
    height: 40px;
    margin-bottom: 16px;
  }
</style>
