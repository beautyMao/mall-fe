<template>
  <div class="app-container">
    <h1 class="title">公共维护</h1>
    <el-card class="box-card">
      <div class="box">
        <h4>公告内容</h4>
        <el-input
          v-model="content"
          type="textarea"
          placeholder="支持汉字、英文、数字的输入，最多100个字符"
          maxlength="100"
          resize="none"
          show-word-limit
          clearable
          class="input"
        />
      </div>
    </el-card>
    <div class="button">
      <el-button type="primary" class="btn" @click="handleBtnClick">保存</el-button>
    </div>
  </div>
</template>

<script>
  import { postNoticeMaintain, getNoticeMaintain } from '@/api/enterprise'

  export default {
    name: 'notice-maintain',
    data() {
      return {
        content: ''
      }
    },
    mounted() {
      getNoticeMaintain().then(res => {
        this.content = res.data.content
      })
    },
    methods: {
      handleBtnClick() {
        const data = {
          content: this.content
        }
        postNoticeMaintain(data).then(res => {
          this.$message.success('提交成功')
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  .title {
    margin: 0;
    margin-bottom: 20px;
  }
  .box {
    height: 400px;
    padding: 20px;
    .input {
      width: 100%;
      height: 240px;
      & /deep/ .el-textarea__inner {
        height: 100%;
      }
      & /deep/ .el-input__count {
        bottom: 5px;
      }
    }
  }
  .button {
    position: fixed;
    left: 0;
    right: 0;
    bottom: 0;
    height: 64px;
    box-shadow: 0 2px 12px 0 rgba(0,0,0,.1);
    background: #fff;
    .btn {
      float: right;
      width: 150px;
      height: 40px;
      margin-top: 12px;
      margin-right: 35px;
    }
  }
</style>
