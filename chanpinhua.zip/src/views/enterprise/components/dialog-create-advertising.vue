<template>
  <el-dialog :visible.sync="dialog" title="创建轮播图" custom-class="el-dialog-aside" class="wrapper">
    <el-form :model="listData" :rules="rules" size="medium" label-width="110px" class="demo-ruleForm">
      <el-form-item label="标题" prop="title">
        <el-input v-model="listData.title" />
      </el-form-item>
      <el-form-item label="跳转链接" prop="target_url">
        <el-input v-model="listData.target_url" />
      </el-form-item>
      <el-form-item class="upload" label="轮播图">
        <el-upload class="avatar-uploader" :action="uploadUrl()" :show-file-list="false" :before-upload="beforeAvatarUpload" :on-success="handleAvatarSuccess">
          <img v-if="image_url" :src="image_url" class="avatar">
          <i v-else class="el-icon-plus avatar-uploader-icon" />
          <div slot="tip" class="el-upload__tip">(建议上传420*260px，jpg、png格式）</div>
        </el-upload>
      </el-form-item>
    </el-form>
    <div slot="footer">
      <el-button @click="dialog = false">取 消</el-button>
      <el-button type="primary" @click="submitForm">提交</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import { getToken } from '@/utils/auth'
  import { putChangeBanner, postAddBanner } from '@/api/enterprise'
  export default {
    name: 'dialog-create-advertising',
    props: {
      dialogCreateAdvertising: {
        type: Boolean,
        default: false
      },
      data1: {
        type: Object,
        default: function() {
          return {}
        }
      }
    },
    data() {
      return {
        listData: {},
        rules: {},
        dialog: false,
        image_url: ''
      }
    },
    watch: {
      dialogCreateAdvertising() {
        this.dialog = this.dialogCreateAdvertising
      },
      dialog() {
        if (!this.dialog) {
          this.image_url = ''
          this.$emit('changeDialog')
        } else {
          this.image_url = this.data1.image_url
          this.listData = this.data1
        }
      }
    },
    methods: {
      uploadUrl() { // 上传图片地址
        if (document.domain === 'localhost') {
          return `https://imccdev.lenovo.com.cn/api/wb/image/up?token=${getToken()}`
        } else {
          return `https://${document.domain}/api/wb/image/up?token=${getToken()}`
        }
      },
      handleAvatarSuccess(res, file) {
        this.image_url = URL.createObjectURL(file.raw)
        this.listData.image_url = res.data.picUrl
      },
      beforeAvatarUpload(file) {
        const isJPG = file.type === 'image/jpeg' || file.type === 'image/png'
        // const isLt2M = file.size / 1024 / 1024 < 2

        if (!isJPG) {
          this.$message.error('上传头像图片只能是 JPG或PNG 格式!')
        }
        // if (!isLt2M) {
        //   this.$message.error('上传头像图片大小不能超过 2MB!')
        // }
        return isJPG
      },
      submitForm() {
        const reg = /^[\u4E00-\u9FA5]{1,20}$/
        const parse_url = /^(?:([A-Za-z]+):)?(\/{0,3})([0-9.\-A-Za-z]+)(?::(\d+))?(?:\/([^?#]*))?(?:\?([^#]*))?(?:#(.*))?$/
        if (!reg.test(this.listData.title)) {
          this.$message({
            message: '标题只可输入20位以内的汉字',
            type: 'warning'
          })
          return
        }
        if (!parse_url.test(this.listData.target_url)) {
          this.$message({
            message: '跳转链接输入错误',
            type: 'warning'
          })
          return
        }
        if (!this.listData.target_url) {
          delete this.listData.target_url
        }
        if (this.data1.status === 'add') {
          postAddBanner(this.listData).then(res => {
            this.$emit('changeDialog', 'redact-succ')
          })
        } else {
          putChangeBanner(this.listData.id, this.listData).then(res => {
            this.$emit('changeDialog', 'redact-succ')
          })
        }
      }
    }
  }
</script>

<style scoped lang="scss">
  .avatar {
    display: block;
    width: 178px;
    height: 178px;
    line-height: 178px;
  }
  .avatar-uploader /deep/ .avatar-uploader-icon {
    line-height: 178px!important;
  }
</style>
<style>
  .avatar-uploader .el-upload {
    border: 1px dashed #d9d9d9;
    border-radius: 6px;
    cursor: pointer;
    position: relative;
    overflow: hidden;
  }
  .avatar-uploader .el-upload:hover {
    border-color: #409EFF;
  }
  .avatar-uploader-icon {
    font-size: 28px;
    color: #8c939d;
    width: 178px;
    height: 178px;
    line-height: 178px;
    text-align: center;
  }
</style>
