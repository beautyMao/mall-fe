<template>
  <el-form ref="form" label-width="80px" :rules="formRules" :model="pageData">
    <el-form-item label="姓名" prop="name">
      <el-input v-model="pageData.name" placeholder="请填写姓名" maxlength="10" />
    </el-form-item>
    <el-form-item label="性别">
      <el-radio-group v-model="pageData.sex">
        <el-radio :label="1">先生</el-radio>
        <el-radio :label="2">女士</el-radio>
      </el-radio-group>
    </el-form-item>
    <el-form-item label="电话" prop="phone">
      <el-input
        v-for="(phoneNumber, index) in pageData.phone"
        :key="index"
        v-model="pageData.phone[index]"
        maxlength="15"
        class="multiple-input"
        placeholder="请填写手机号或者固定号码"
      />
      <el-button v-show="!hasPhoneError && pageData.phone.length < 3" type="text" icon="el-icon-plus" @click="pageData.phone.push('')">添加新电话</el-button>
      <el-button v-show="pageData.phone.length > 1" type="text" icon="el-icon-delete" @click="pageData.phone.splice(-1, 1)">移除电话</el-button>
    </el-form-item>
    <el-form-item label="邮箱" prop="email">
      <el-input
        v-for="(email, index) in pageData.email"
        :key="index"
        v-model="pageData.email[index]"
        maxlength="30"
        class="multiple-input"
        placeholder="请填写邮箱"
      />
      <el-button v-show="!hasEmailError && pageData.email.length < 3" type="text" icon="el-icon-plus" @click="pageData.email.push('')">添加新的邮箱</el-button>
      <el-button v-show="pageData.email.length > 1" type="text" icon="el-icon-delete" @click="pageData.email.splice(-1, 1)">移除邮箱</el-button>
    </el-form-item>
    <el-form-item v-if="isEdit" label="OpenID">
      <div v-for="(item, index) in pageData.wechat_openid" :key="index">{{ item }}</div>
    </el-form-item>
    <el-form-item label="企业名称">
      <el-input v-model="pageData.company_name" maxlength="30" placeholder="请填写企业名称" />
    </el-form-item>
    <el-form-item label="行业">
      <el-input v-model="pageData.industry" maxlength="30" placeholder="请填写行业" />
    </el-form-item>
    <el-form-item label="职业">
      <el-input v-model="pageData.job" maxlength="10" placeholder="请填写职业" />
    </el-form-item>
    <el-form-item label="证件类型">
      <el-select v-model="pageData.credentials_type" placeholder="请选择证件类型">
        <el-option v-if="!pageData.credentials_number" label="无" value="" />
        <el-option label="身份证" value="id_card" />
        <el-option label="护照" value="passport" />
        <el-option label="军官证" value="officer_card" />
        <el-option label="其他" value="other" />
      </el-select>
    </el-form-item>
    <el-form-item v-show="pageData.credentials_type" label="证件号码" prop="credentials_number">
      <el-input v-model="pageData.credentials_number" maxlength="30" placeholder="请填写证件号码" />
    </el-form-item>
    <el-form-item label="所在地">
      <region-picker
        v-model="region"
        placeholder="请选择所在地"
      />
    </el-form-item>
    <el-form-item label="详细地址">
      <el-input
        v-model="pageData.address"
        type="textarea"
        rows="2"
        maxlength="200"
        placeholder="请填写详细地址"
      />
    </el-form-item>
    <el-form-item label="备注">
      <el-input
        v-model="pageData.remarks"
        type="textarea"
        show-word-limit
        rows="4"
        maxlength="200"
        placeholder="请填写备注"
      />
    </el-form-item>
  </el-form>
</template>

<script type="text/ecmascript-6">
  import RegionPicker from '@/components/RegionPicker'
  import { RegexUtil } from '@/utils/validate'
  import { paramsShake, snakecase } from '@/utils'

  const initData = function(external) {
    const result = Object.assign({
      name: '',
      sex: 1,
      phone: [''],
      email: [''],
      wechat_openid: [],
      company_name: '',
      job: '',
      industry: '',
      credentials_type: '',
      credentials_number: '',
      province_code: '',
      city_code: '',
      district_code: '',
      address: '',
      remarks: ''
    }, paramsShake(external))
    const check = ['phone', 'email']
    check.forEach(item => {
      if (!Array.isArray(result[item]) || !result[item].length) {
        result[item] = ['']
      }
    })
    // object assign 并不对数组进行拷贝，会导致form 编辑电话和邮箱时，被父级的响应式监听到
    return JSON.parse(JSON.stringify(result))
  }

  /**
   * 整个form 组件将被用于以下几个位置：
   * - 功能区右侧，注册&编辑
   * - 客户中心index 页面，新增&编辑
   * - 客户详情页面，编辑
   * 常规的注册&编辑，需要form 拥有以下能力：
   * - 注册：validation，form data output
   * - 编辑：validation，data input
   * 加上功能区
   * - 注册和编辑同步pageData
   */
  export default {
    name: 'crm-user-form',
    components: { RegionPicker },
    data() {
      const that = this
      return {
        pageData: initData(),
        region: [],
        formRules: {
          name: [{ required: true, message: '请填写用户姓名', trigger: 'blur' }],
          phone: [{
            trigger: 'blur',
            validator: function(rule, value, callback) {
              if (value.some(v => !v)) { // 非必填项
                return callback()
              }
              if (that.hasRepeatItem(value)) {
                that.hasPhoneError = true
                return callback(new Error(`该电话号码已填写`))
              }
              if (value.some(v => !RegexUtil.telephone.test(v) && !RegexUtil.hotline.test(v))) {
                that.hasPhoneError = true
                return callback(new Error('请填写正确的电话号码'))
              }
              callback()
              that.hasPhoneError = false
            }
          }],
          email: [{
            trigger: 'blur',
            validator: function(rule, value, callback) {
              if (value.some(v => !v)) { // 非必填项
                return callback()
              }
              if (that.hasRepeatItem(value)) {
                that.hasEmailError = true
                return callback(new Error(`该邮箱地址已填写`))
              }
              if (value.some(v => v.length && !RegexUtil.email.test(v))) {
                that.hasEmailError = true
                return callback(new Error('请填写正确的邮箱'))
              }
              callback()
              that.hasEmailError = false
            }
          }],
          credentials_number: [{
            trigger: 'blur',
            validator: function(rule, value, callback) {
              if (that.pageData.credentials_type !== '' && !value) {
                return callback('请输入证件号码')
              }
              callback()
            }
          }]
        },
        hasPhoneError: false,
        hasEmailError: false,
        isEdit: false
      }
    },
    watch: {
      // 证件类型切换为“其他”，清空证件号码，避免触发校验
      'pageData.credentials_type': function(type) {
        if (!type) {
          this.pageData.credentials_number = ''
        }
      }
    },
    methods: {
      validate() {
        return this.$refs.form.validate().then(vali => {
          if (this.pageData.phone.some(p => !p) && this.pageData.email.some(e => !e)) {
            return { error: '电话、邮箱请至少输入一项' }
          }
          const re = {}
          Object.keys(this.pageData).forEach(key => {
            re[snakecase(key)] = this.pageData[key]
          })
          const region = this.region
          if (region.length) {
            re.province_code = region[0]
            re.city_code = region[1]
            re.district_code = region[2]
          }
          return re
        })
      },
      edit(user) {
        this.$nextTick(() => {
          this.$refs.form.resetFields()
          this.isEdit = true
          this.region = [user.province_code, user.city_code, user.district_code]
          this.pageData = initData(user)
        })
      },
      create(extraData = {}) {
        this.isEdit = false
        this.pageData = initData(extraData)
        this.region = []
        this.$nextTick(() => {
          this.$refs.form.clearValidate()
          // this.$refs.form.resetFields()
        })
      },
      hasRepeatItem(array) {
        const len = array.length
        for (let i = 0; i < len; i++) {
          for (let j = len - 1; j > i; j--) {
            if (array[i] === array[j]) {
              return true
            }
          }
        }
        return false
      }
    }
  }
</script>
