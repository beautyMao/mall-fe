<template>
  <el-dialog
    :title="isEditing ? '编辑客户信息' : '新建客户'"
    custom-class="el-dialog-aside"
    :visible.sync="dialogFormVisible"
  >
    <crm-user-form ref="userForm" v-loading="loading('/api/crm/customer')" />
    <span slot="footer" class="dialog-footer">
      <el-button :disabled="loading('/api/crm/customer')" @click="dialogFormVisible = false">取 消</el-button>
      <el-button :disabled="loading('/api/crm/customer')" type="primary" @click="createOrEditUser">确 定</el-button>
    </span>
  </el-dialog>
</template>

<script type="text/ecmascript-6">
  import CrmUserForm from './crm-user-form'
  import { customerRestApi } from '@/api/crm'
  import { paramsShake } from '@/utils'
  import { mapGetters } from 'vuex'

  export default {
    name: 'crm-user-form-dialog',
    components: { CrmUserForm },
    props: {
      visible: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        isEditing: false,
        dialogFormVisible: false,
        formData: null
      }
    },
    computed: {
      ...mapGetters('api', ['loading'])
    },
    watch: {
      visible(val) {
        if (val) {
          this.dialogFormVisible = true
        }
      },
      dialogFormVisible(val) {
        !val && this.$emit('update:visible', false)
      }
    },
    methods: {
      show(initFormData) {
        if (initFormData) {
          this.formData = initFormData
          this.isEditing = true
        } else {
          this.formData = null
          this.isEditing = false
        }
        this.dialogFormVisible = true

        // dialog form 显示之后再调用
        this.$nextTick(() => {
          if (this.isEditing) {
            this.$refs.userForm.edit(this.formData)
          } else {
            this.$refs.userForm.create()
          }
        })
      },
      createOrEditUser() {
        const nextOperation = this.isEditing ? this._apiUpdate : customerRestApi.post
        this.$refs.userForm.validate().then(data => {
          if (data.error) {
            return this.$message.error(data.error)
          }
          nextOperation(paramsShake(data)).then(response => {
            this.$message.success(this.isEditing ? '更新用户成功' : '创建用户成功')
            this.dialogFormVisible = false
            this.$emit('update:visible', false)
            this.$emit('done', {
              response, isEditing: this.isEditing
            })
          }).catch(this.$message.error)
        })
      },
      _apiUpdate(data) {
        return customerRestApi.update(data.id, data)
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>

</style>
