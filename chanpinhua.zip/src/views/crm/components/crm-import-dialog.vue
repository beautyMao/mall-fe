<template>
  <el-dialog
    title="批量导入客户"
    :visible.sync="dialogImportVisible"
    center
    :close-on-click-modal="false"
    :show-close="showClose"
    :close-on-press-escape="false"
    width="512px"
    @close="close"
  >
    <div class="import-container">
      <el-steps finish-status="success" :active="step" simple>
        <el-step title="上传文件"><span slot="icon">1</span></el-step>
        <el-step title="导入数据"><b slot="icon">2</b></el-step>
        <el-step title="完成"><b slot="icon">3</b></el-step>
      </el-steps>
      <div v-show="step === 0">
        <p>1.请按照模板格式准备需要导入的数据</p>
        <p>
          <i class="el-icon-document" />
          <a href="https://cube-resources.lenovo.com.cn/cube/客户中心导入模板.xlsx" download target="_blank" class="link">导入模板.xlsx 下载</a>
        </p>
        <p>2. 选择需要导入的文件</p>
        <form ref="form">
          <label for="excel" class="upload">
            <span style="width:188px;overflow:hidden;color:#303133;text-overflow:ellipsis;white-space:nowrap;">
              <i class="el-icon-paperclip" />
              {{ filename || '请选择文件……' }}
            </span>
            <span>支持xls、xlsx文件，文件不得大于20M</span>
            <input
              id="excel"
              ref="importFile"
              accept="application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              type="file"
              name="excel"
              @change="handleFileChange"
            >
          </label>
        </form>
      </div>
      <div v-show="step === 1" class="text-center">
        <p><i class="el-icon-loading" /></p>
        <p>正在导入，请稍后……</p>
      </div>
      <div v-show="step === 2" class="text-center">
        <p style="font-size:14px;font-weight:400;color:#303133;line-height:20px;">
          导入成功<span class="text-success">&nbsp;{{ importResult.success }}&nbsp;</span>条数据，失败<span class="text-error">&nbsp;{{ importResult.error }}&nbsp;</span>条数据
        </p>
        <ul v-if="importResult.errorMsgs.length">
          <!-- <li v-for="(msg,index) in importResult.errorMsgs" :key="index">{{ msg }}</li> -->
          <li><a class="link" download @click="downloadErrorReport"><i class="el-icon-download" /> 点击下载错误报告</a></li>
        </ul>
      </div>
    </div>
    <div v-show="!hideButton" slot="footer" class="dialog-footer">
      <el-button :disabled="step === 1" @click="close">取 消</el-button>
      <el-button :disabled="step === 1" type="primary" @click="startImport">导 入</el-button>
    </div>
  </el-dialog>
</template>

<script type="text/ecmascript-6">
  import { customerImport, getErrorReportLink } from '@/api/crm'
  import { handleDownload } from '@/utils'

  export default {
    name: 'crm-import-dialog',
    props: {
      visible: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        dialogImportVisible: false,
        step: 0,
        filename: '',
        importResult: {
          key: '',
          success: 0,
          error: 0,
          errorMsgs: []
        },
        hideButton: false,
        showClose: false
      }
    },
    computed: {
      errorReportLink() {
        return getErrorReportLink(this.importResult.key)
      }
    },
    watch: {
      visible(val) {
        if (val) {
          this.dialogImportVisible = true
        }
      },
      dialogImportVisible(val) {
        !val && this.$emit('update:visible', false)
      }
    },
    methods: {
      startImport() {
        if (this.$refs.importFile.files.length === 0) {
          return this.$message.warning('请选择文件')
        }
        const file = this.$refs.importFile.files[0]
        const ext = file.name.split('.').reverse()[0].toLowerCase()
        if (!'xls,xlsx'.split(',').includes(ext)) {
          this.$message.error('仅支持Excel文件上传')
          return false
        }
        if (file.size / 1024 / 1024 > 20) {
          this.$message.error('文件需要小于20MB')
          return false
        }
        this.hideButton = true
        // created_at: "2019-08-16 16:06:45"
        // error: 1
        // error_message: "["第2行，添加客户失败创建用户失败"]"
        // id: 7
        // key: "3dcd69f16c3678f5ba67bad5f1d84400"
        // success: 1
        // total: 2
        this.step = 1
        customerImport(file).then(res => {
          this.step = 2
          this.importResult.key = res.data.key
          this.importResult.success = res.data.success
          this.importResult.error = res.data.total - res.data.success
          try {
            this.importResult.errorMsgs = JSON.parse(res.data.error_message)
          } catch (e) {
            console.log(e)
          }
          this.showClose = true
        }).catch(error => {
          this.$message.error(error)
          this.showClose = true
        })
      },
      close() {
        this.$refs.form.reset()
        this.step = 0
        this.dialogImportVisible = false
        this.filename = ''
        this.hideButton = false
        this.$emit('update:visible', false)
        this.$emit('close')
      },
      handleFileChange() {
        const file = this.$refs.importFile.files[0]
        if (file) {
          this.filename = file.name
        }
      },
      downloadErrorReport() {
        // 返回的data中没有statusCode 故在catch中处理响应
        getErrorReportLink(this.importResult.key).catch((response) => {
          const blob = new Blob([response.data], { type: 'text/txt,charset=UTF-8' })
          handleDownload(`${this.importResult.key}.txt`, blob)
        })
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  /deep/ .import-container {
    min-height:202px;
    .upload {
      padding-left: 15px;
      padding-right: 15px;
      height:40px;
      line-height: 40px;
      display: flex;
      border-radius:4px;
      border:1px solid #ccc;
      color: #ccc;
      justify-content: space-between;
      cursor: pointer;

      span {
        line-height: 40px;
      }

      input {
        display: none;
      }
      ul {
        min-height: 300px;
        color: #ccc;
      }
    }
  }

  .text-center{
    line-height: 50px;
  }

  .text-success{
    color:#7AC3BE;
  }

  .text-error{
    color:#E89081;
  }
</style>
