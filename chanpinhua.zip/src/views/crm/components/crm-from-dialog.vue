<template>
  <el-dialog title="收货地址" :visible.sync="dialogFormVisible">
    <el-form ref="form" label-width="80px" :rules="formRules" :model="pageData">
      <el-form-item label="姓名" prop="name">
        <el-input v-model="pageData.name" placeholder="请填写姓名" maxlength="50" />
      </el-form-item>
      <el-form-item label="性别">
        <el-radio-group v-model="pageData.sex">
          <el-radio label="1" value="1">先生</el-radio>
          <el-radio label="0" value="0">女士</el-radio>
        </el-radio-group>
      </el-form-item>
      <el-form-item label="电话" prop="phoneNumbers">
        <el-input
          v-for="(phoneNumber, index) in pageData.phoneNumbers"
          :key="index"
          v-model="pageData.phoneNumbers[index]"
          maxlength="50"
          class="multiple-input"
          placeholder="请填写手机号或者固定号码"
        />
        <el-button type="text" icon="el-icon-plus" @click="pageData.phoneNumbers.push('')">添加新电话</el-button>
        <el-button v-show="pageData.phoneNumbers.length > 1" type="text" icon="el-icon-delete" @click="pageData.phoneNumbers.splice(-1, 1)">移除电话</el-button>
      </el-form-item>
      <el-form-item label="邮箱" prop="emails">
        <el-input
          v-for="(email, index) in pageData.emails"
          :key="index"
          v-model="pageData.emails[index]"
          maxlength="100"
          class="multiple-input"
          placeholder="请填写邮箱"
        />
        <el-button type="text" icon="el-icon-plus" @click="pageData.emails.push('')">添加新的邮箱</el-button>
        <el-button v-show="pageData.emails.length > 1" type="text" icon="el-icon-delete" @click="pageData.emails.splice(-1, 1)">移除邮箱</el-button>
      </el-form-item>
      <el-form-item label="企业名称">
        <el-input v-model="pageData.companyName" maxlength="100" placeholder="请填写企业名称" />
      </el-form-item>
      <el-form-item label="证件类型" hidden>
        <el-select v-model="pageData.identifierType" placeholder="请选择证件类型">
          <el-option label="身份证" value="身份证" />
          <el-option label="护照" value="护照" />
          <el-option label="军官证" value="军官证" />
          <el-option label="其他" value="其他" />
        </el-select>
      </el-form-item>
      <el-form-item label="证件号码" hidden>
        <el-input v-model="pageData.identifierID" maxlength="50" placeholder="请填写证件号码" />
      </el-form-item>
      <el-form-item label="所在地" hidden>
        <el-cascader
          v-model="pageData.region"
          :options="regionData"
          placeholder="请选择所在地"
          @change="handleChange"
        />
      </el-form-item>
      <el-form-item label="详细地址" hidden>
        <el-input
          v-model="pageData.address"
          type="textarea"
          rows="2"
          maxlength="500"
          placeholder="请填写详细地址"
        />
      </el-form-item>
      <el-form-item label="备注" hidden>
        <el-input
          v-model="pageData.memo"
          type="textarea"
          show-word-limit
          rows="4"
          maxlength="5000"
          placeholder="请填写备注"
        />
      </el-form-item>
      <el-form-item label="是否通知">
        <el-switch v-model="pageData.notify" active-text="注册成功通知" />
      </el-form-item>
    </el-form>
    <div slot="footer" class="dialog-footer">
      <el-button @click="dialogFormVisible = false">取 消</el-button>
      <el-button type="primary" @click="dialogFormVisible = false">确 定</el-button>
    </div>
  </el-dialog>
</template>

<script type="text/ecmascript-6">
  export default {
    name: 'crm-from-dialog',
    props: {
      edit: {
        type: Boolean,
        default: false
      },
      pageData: {
        type: Object,
        default: function() {
          return {}
        }
      }
    },
    data() {
      return {
        dialogFormVisible: false
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>

</style>
