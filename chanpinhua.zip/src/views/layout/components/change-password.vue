<template>
  <div class="change-password-wrapper">
    <div class="change-password">
      <div class="title">
        <span>修改密码</span>
      </div>
      <div class="list">
        <el-form ref="ruleForm" :model="data" :rules="rules" label-width="80px" class="demo-ruleForm">
          <el-form-item label="旧密码" prop="oldpwd" class="item">
            <el-input v-model="data.oldpwd" placeholder="请输入原密码" :type="passwordType1" class="input" :class="{ borderColor: isInfo }" @change="changeOldpwd" />
            <span class="show-pwd" @click="showPwd1">
              <svg-icon v-if="eye1" icon-class="eye" />
              <svg-icon v-else icon-class="eyeOpen" />
            </span>
            <span v-if="isInfo" class="info">旧密码输入错误</span>
          </el-form-item>
          <el-form-item label="新密码" prop="newpwd" class="item">
            <el-input v-model="data.newpwd" placeholder="请输入新密码8-20位字母、英文组合" :type="passwordType2" class="input" />
            <span class="show-pwd" @click="showPwd2">
              <svg-icon v-if="eye2" icon-class="eye" />
              <svg-icon v-else icon-class="eyeOpen" />
            </span>
          </el-form-item>
          <el-form-item label="确认密码" prop="againNewpwd" class="item">
            <el-input v-model="data.againNewpwd" placeholder="请再次确认密码" :type="passwordType3" class="input" />
            <span class="show-pwd" @click="showPwd3">
              <svg-icon v-if="eye3" icon-class="eye" />
              <svg-icon v-else icon-class="eyeOpen" />
            </span>
          </el-form-item>
        </el-form>
        <div class="right">
          <el-button @click="close">取消</el-button>
          <el-button type="primary" :disabled="isSubmit" @click="onSubmit">保存</el-button>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
  import { getAccountChangePassword } from '@/api/account-info.js'
  import { MessageBox } from 'element-ui'
  import store from '@/store'
  export default {
    name: 'change-password',
    data() {
      const checkNewpwd = (rule, value, callback) => {
        if (value) {
          const reg = /^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z._!@#$%]{8,20}$/
          if (reg.test(value)) {
            callback()
          } else {
            return callback(new Error('请输入8-20位字母、英文组合'))
          }
        }
      }
      const checkOldpwd = (rule, value, callback) => {
        if (value) {
          const reg = /^[0-9A-Za-z._!@#$%]{8,20}$/
          if (reg.test(value)) {
            callback()
          } else {
            return callback(new Error('请输入8-20位字母、英文'))
          }
        }
      }
      const checkNewpwd1 = (rule, value, callback) => {
        if (value === this.data.newpwd) {
          callback()
        } else {
          return callback(new Error('两次密码输入不一致'))
        }
      }
      return {
        data: {
          oldpwd: '',
          newpwd: '',
          againNewpwd: ''
        },
        rules: {
          oldpwd: [
            { required: true, message: '请输入旧密码', trigger: 'blur' },
            { validator: checkOldpwd, trigger: 'blur' }
          ],
          newpwd: [
            { required: true, message: '请输入8-20位字母、英文组合', trigger: 'blur' },
            { validator: checkNewpwd, trigger: 'blur' }
          ],
          againNewpwd: [
            { required: true, message: '请再次确认密码', trigger: 'blur' },
            { validator: checkNewpwd1, trigger: 'blur' }
          ]
        },
        isInfo: false,
        isSubmit: false,
        passwordType1: 'password',
        passwordType2: 'password',
        passwordType3: 'password',
        eye1: true,
        eye2: true,
        eye3: true
      }
    },
    methods: {
      close() {
        this.$emit('closeAlert')
      },
      showPwd1() {
        if (this.passwordType1 === 'password') {
          this.eye1 = false
          this.passwordType1 = ''
        } else {
          this.eye1 = true
          this.passwordType1 = 'password'
        }
      },
      showPwd2() {
        if (this.passwordType2 === 'password') {
          this.eye2 = false
          this.passwordType2 = ''
        } else {
          this.eye2 = true
          this.passwordType2 = 'password'
        }
      },
      showPwd3() {
        if (this.passwordType3 === 'password') {
          this.eye3 = false
          this.passwordType3 = ''
        } else {
          this.eye3 = true
          this.passwordType3 = 'password'
        }
      },
      changeOldpwd() {
        if (this.isInfo) {
          this.isInfo = false
        }
      },
      onSubmit() {
        if (this.isInfo) return
        this.data.oldpwd.replace(/\s+/g, '')
        this.data.newpwd.replace(/\s+/g, '')
        this.data.againNewpwd.replace(/\s+/g, '')
        this.$refs.ruleForm.validate((valid) => {
          if (valid) {
            this.isSubmit = true
            const data = {
              password: this.data.oldpwd,
              new_password: this.data.newpwd,
              new_password_confirmation: this.data.againNewpwd
            }
            getAccountChangePassword(data).then(res => {
              this.isSubmit = false
              if (res.message.info === 'Success') {
                this.$emit('closeAlert')
                this.$message({
                  message: '密码修改成功',
                  type: 'success'
                })
                MessageBox.alert('您的密码已修改成功，请重新登录', '修改成功', {
                  confirmButtonText: '重新登录',
                  customClass: 'warning-pwd',
                  type: 'success',
                  center: true,
                  showClose: false,
                  callback: () => {
                    store.dispatch('FedLogOut').then(() => {
                      location.href = '/#/login'
                      location.reload() // 为了重新实例化vue-router对象 避免bug
                    })
                  }
                })
              }
            }).catch(res => {
              this.isSubmit = false
              if (res === '旧密码不正确') {
                this.isInfo = true
              }
            })
          } else {
            console.log('error submit!!')
            return false
          }
        })
        // if (!this.data.oldpwd) {
        //   this.info = '请输入旧密码'
        //   return
        // }
        // var reg = /^(?=.*[a-zA-Z])(?=.*[\W_]).{8,20}$/
        // if (!reg.test(this.data.newpwd)) {
        //   this.info = '请输入8-20位数字字母特殊字符组合'
        //   return
        // }
        // if (this.data.newpwd !== this.data.againNewpwd) {
        //   this.info = '两次密码输入不一致'
        //   return
        // }
        // if (this.data.newpwd === this.data.oldpwd) {
        //   this.info = '新旧密码不能相同'
        //   return
        // }
      }
    }
  }
</script>

<style scoped lang="scss">
  .change-password-wrapper {
    position: fixed;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    background: rgba(0,0,0,0.5);
    z-index:2000;
  }
  .change-password {
    position: absolute;
    left: 0;
    top: 0;
    right: 0;
    bottom: 0;
    margin: auto;
    width: 420px;
    height: 304px;
    padding: 10px;
    z-index: 100;
    border-radius: 10px;
    background: #fff;
    .title {
      padding: 0 10px;
      text-align: center;
    }
    .list {
      position: relative;
      overflow: hidden;
      font-size: 12px;
      .show-pwd {
        position: absolute;
        right: 30px;
        top: 7px;
        color: #889aa4;
        font-size: 14px;
        cursor: pointer;
        user-select: none;
        z-index: 9999;
      }
      .item {
        position: relative;
        margin-bottom: 22px;
        .info {
          position: absolute;
          left: 0;
          bottom: -28px;
          font-size: 12px;
          color: #F37261;
        }
        & /deep/ .el-form-item__error {
          margin-top: 4px;
        }
      }
      .borderColor {
        /deep/ .el-input__inner {
          border-color: #F37261;
        }
      }
      .input {
        width: 300px;
        height: 40px;
        line-height: 40px;
        & /deep/ .el-form-item__error {
          margin-top: 5px;
        }
        & /deep/ .el-input__inner {
          height: 100%;
        }
      }
      & /deep/ .el-form-item__label {
        height: 40px;
        line-height: 40px;
      }
      .right {
        display: block;
        text-align: center;
        .el-button {
          width: 77px;
          height: 28px;
          padding: 0;
        }
      }
    }

  }
  .warning1 {
    background: #ccc;
  }
</style>
<style lang="scss">
  .warning-pwd {
    position: absolute;
    right: 10px;
    top: 10px;
    width: 290px!important;
    & /deep/ .el-message-box__btns {
      text-align: center;
    }
  }
</style>
