<template>
  <div class="navbar flex-wrp flex-between flex-align-center">
    <div class="flex-wrp flex-align-center pl10">
      <hamburger :toggle-click="toggleSideBar" :is-active="sidebar.opened" class="flex-wrp flex-align-center" />
      <span class="brand">
        <svg-icon icon-class="logo" />
        <span class="font">魔方</span>
      </span>
      <span class="version pointer" @click="versionCheck">{{ version }}</span>
      <span v-show="newVisible" class="new-icon"><span>new</span></span>
    </div>
    <el-dialog
      width="30%"
      title=""
      :visible.sync="aboutDialogVisible"
      class="about-cube"
      center
    >
      <div class="version-wrap">
        <div v-for="(item, i) in historyVersion" :key="i">
          <p class="title">{{ item.title }} {{ item.version }}</p>
          <p class="time">更新时间: {{ item.version_time }}</p>
          <ul class="version-list">
            <li v-for="(list, index) in item.all_children" :key="index">
              {{ index+1 }}.{{ list.title }}
            </li>
          </ul>
        </div>
      </div>
      <span slot="footer" class="dialog-footer">
        <el-button type="primary" @click="aboutDialogVisible = false">我知道了</el-button>
      </span>
    </el-dialog>

    <div class="right-menu flex-wrp flex-align-center">
      <el-dropdown trigger="click" class="status-change" @command="handleCommand">
        <div class="pointer flex-wrp flex-center status">
          <i v-show="loading('api/csc/workUpdate')" class="el-icon-loading" />
          <svg-icon
            class-name="size34"
            icon-class="userStatus"
            :style="{marginRight: '-10px', color: currentStatusColor}"
          />
          {{ currentStatusName }}<i class="el-icon-caret-bottom" />
        </div>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item command="online"> 就 绪 </el-dropdown-item>
          <el-dropdown-item command="rest"> 小 休 </el-dropdown-item>
          <el-dropdown-item command="hangup"> 挂 起 </el-dropdown-item>
          <el-dropdown-item command="offline"> 离 线 </el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>

      <el-dropdown trigger="hover">
        <span class="pointer">
          {{ info.name }} | {{ info.code }} <i class="el-icon-caret-bottom" />
        </span>
        <el-dropdown-menu slot="dropdown">
          <el-dropdown-item disabled>登录时间：{{ info.last_login_time }}</el-dropdown-item>
          <el-dropdown-item icon="el-icon-setting" @click.native="settingDialogVisible = true">偏好设置</el-dropdown-item>
          <el-dropdown-item icon="el-icon-document" @click.native="messageLogDialogVisible = true">魔方日志</el-dropdown-item>
          <el-dropdown-item icon="el-icon-user" divided @click.native="changePassword">修改密码</el-dropdown-item>
          <el-dropdown-item icon="el-icon-switch-button" @click.native="logout"><span class="danger">退出登录</span></el-dropdown-item>
        </el-dropdown-menu>
      </el-dropdown>

      <!-- <el-popover
        placement="top-start"
        title="Network Status"
        width="240"
        trigger="hover"
      >
        <div>
          至服务器延迟： {{ serverPing }}ms
        </div>
        <div>
          服务器至外部延迟： {{ externalPing }}ms
        </div>
        <div slot="reference" class="size18 plr10 pointer">
          <svg-icon :color="pingStatusColor" icon-class="wifiCommon" />
        </div>
      </el-popover> -->

      <!-- <div class="color2 size14 pl10 pr20">
        <i class="el-icon-time" />
        {{ time | parseTime('{h}:{i}') }}
      </div> -->

      <message-log :dialog-visible="messageLogDialogVisible" @on-close="messageLogDialogVisible = false" />
    </div>
    <ChangePassword
      v-if="showChangePassword"
      @closeAlert="closeAlert"
    />

    <el-dialog
      title="偏好设置"
      :visible.sync="settingDialogVisible"
      custom-class="el-dialog-aside"
    >
      <el-form>
        <el-form-item label="新用户提示音">
          <el-switch v-model="sound" active-text="开启" @change="soundChange" />
        </el-form-item>
      </el-form>
      <span slot="footer" class="dialog-footer">
        <el-button @click="settingDialogVisible = false">好 的</el-button>
      </span>
    </el-dialog>
  </div>
</template>

<script type="application/ecmascript">
  import { mapActions, mapGetters } from 'vuex'
  import { getVersionHistory } from '@/api/public'
  import Hamburger from '@/components/Hamburger'
  import MessageLog from '@/components/MessageLog'
  import ChangePassword from './change-password'
  import { isProd } from '@/utils'
  import config from '@/store/modules/call-center/config'
  import { IMActionType, IMEventType, IMNotifyType } from '@call/enum'
  import get from 'lodash.get'
  import { getLocalStorage } from '@/utils/local-storage'

  const statusMap = {
    online: '就绪',
    rest: '小休',
    hangup: '挂起',
    offline: '离线'
  }

  const statusColorMap = {
    online: '#33FF99',
    rest: '#FF9966',
    hangup: '#0099FF',
    offline: '#CC0066'
  }

  const pingColorMap = {
    fast: '#50C1B9',
    slow: '#FFCC00',
    verySlow: '#CC0066'
  }

  // session key
  const STATUS_BEFORE_REFRESH = 'STATUS_BEFORE_REFRESH'

  const beforeUnloadNotify = function(e) {
    // Cancel the event as stated by the standard.
    e.preventDefault()
    // Chrome requires returnValue to be set.
    e.returnValue = '确认离开'
  }

  export default {
    components: {
      Hamburger,
      MessageLog,
      ChangePassword
    },
    data() {
      return {
        // defined in webpack git plugin
        // VERSION: VERSION,
        // DEPLOYDATE: DEPLOYDATE,
        aboutDialogVisible: false,
        settingDialogVisible: false,
        messageLogDialogVisible: false,
        time: new Date(),

        serverPing: 0,
        externalPing: 0,
        pingFlag: false,

        timer: [],

        sound: false, // 提示音开关
        newVisible: false, // new icon
        version: '', // 版本号
        historyVersion: [], // 历史版本
        showChangePassword: false,
        password: ''
      }
    },
    computed: {
      ...mapGetters([
        'sidebar',
        'user',
        'engineerCode',
        'currentStatus'
      ]),
      ...mapGetters({
        info: 'allInfo'
      }),
      ...mapGetters('api', ['loading']),
      ...mapGetters('call', ['sessions']),
      currentStatusName() {
        const re = statusMap[this.currentStatus]
        return re || statusMap.hangup
      },
      currentStatusColor() {
        const re = statusColorMap[this.currentStatus]
        return re || statusColorMap.hangup
      },
      pingStatusColor() {
        let state = 'verySlow'
        if (this.serverPing < 5000) {
          state = 'fast'
        } else if (this.serverPing < 20000) {
          state = 'slow'
        }
        return pingColorMap[state]
      }
    },
    watch: {
      // 提供一个通过路由的退出功能，避免多次被调起弹框
      '$route.query.cubeLogout': function(isLogout) {
        if (isLogout === 'confirm') {
          this._logoutAction()
        }
      }
    },
    mounted() {
      this.getEngSound()

      // 初始化 store 客服状态
      const initEngPromise = this.initEngStatus()

      // 初始化im event listeners
      this.initIMListener()

      if (process.env.VUE_APP_ENV_CONFIG !== 'dev') {
        window.addEventListener('beforeunload', beforeUnloadNotify)
      }

      // 实验特性 先做个配置进行保留
      if (config.system.logoutBeforeUnload) {
        initEngPromise.then((currentStatus) => {
          const sessionCurrentStatus = sessionStorage.getItem(STATUS_BEFORE_REFRESH) ? JSON.parse(sessionStorage.getItem(STATUS_BEFORE_REFRESH)) : null
          // 如果检测到session status 并且时间记录小于定值，则去恢复原有状态
          const hasRevertStatus = sessionCurrentStatus && (new Date().getTime() - sessionCurrentStatus.time < 60 * 1000)
          if (hasRevertStatus && sessionCurrentStatus.status !== currentStatus) {
            this.changeWorkStatus(sessionCurrentStatus.status)
          }
          sessionStorage.removeItem(STATUS_BEFORE_REFRESH)
        })

        // 关闭浏览器时，logout，发起同步请求
        window.addEventListener('unload', () => {
          sessionStorage.setItem(STATUS_BEFORE_REFRESH, JSON.stringify({
            time: new Date().getTime(),
            status: this.currentStatus
          }))
          this.logoutSoftphone(true)
        }, false)
      }
    },
    beforeDestroy() {
      this.timer.forEach(clearInterval)
    },
    methods: {
      ...mapActions(['changeWorkStatus', 'LogOut', 'initEngStatus']),
      ...mapActions('call', ['initIM', 'logoutSoftphone']),
      toggleSideBar() {
        this.$store.dispatch('toggleSideBar')
      },
      initIMListener() {
        // 整个App 只初始化一次im
        this.initIM().then(txim => {
          txim.addEventListener(IMActionType.Notification, (message, messageType, bodyType) => {
            try {
              console.log('收到通知消息：', isProd ? JSON.stringify(message) : message)
            } catch (e) {
              console.log(e)
            }
            if (bodyType === IMNotifyType.Appraise) {
              this.$notify({
                title: '',
                center: true,
                dangerouslyUseHTMLString: true,
                duration: 60000,
                message: `<div style="width: 270px; text-align: center">
                            <h4>${message.Body.Content.Title}</h4>
                            <div style="margin-bottom: 10px">${message.Body.Content.Content}</div>
                            <a style="color: #4A90E2">查看详情</a>
                            <div style="margin-top: 20px; text-align: right">${message.SendTime}</div>
                          </div>`,
                position: 'bottom-right',
                onClick: () => {
                  this.$router.push({
                    path: '/demand/record/particulars',
                    query: { id: message.Body.Content.ID }
                  })
                }
              })
            }
            if (bodyType === IMNotifyType.CreateSession && this.$route.name !== 'call-center') {
              // 当不在呼叫中心界面下时，收到用户会话，给出提醒
              this.$notify.info({
                title: '新用户进入通知',
                message: '有新用户进入会话，点击前往',
                duration: '10000',
                iconClass: 'el-icon-message',
                onClick: () => {
                  this.$router.push({ name: 'call-center' })
                }
              })
            }

            if (bodyType === IMNotifyType.CreateSession) {
              this.soundEvent()
            }

            if (bodyType === IMNotifyType.UserCloseSession) {
              const target = this.sessions[message.session_id]
              if (target) {
                this.$notify.info({
                  title: '用户关闭会话通知',
                  message: `用户【${target.user_name}】已主动关闭了会话`,
                  duration: '10000',
                  iconClass: 'el-icon-message'
                })
              }
            }

            // 跨天工程师的0点状态自动处理
            if (bodyType === IMNotifyType.CheckStatus) {
              const statusBeforeAutochange = this.currentStatus
              this.initEngStatus().then(() => {
                return this.changeWorkStatus(statusBeforeAutochange)
              }).then(() => {
                this.$message.success('切换状态成功')
              }).catch(err => {
                this.$message.error('切换工作状态失败' + err)
              })
            }
          })
          txim.addEventListener(IMActionType.ChatMessage, message => {
            console.log('收到的聊天消息：', get(message, 'Body.Content.Text'))
          })
          txim.addEventListener(IMEventType.LOGIN, message => {
            this.$message.success('IM 登录成功')
          })
          txim.addEventListener(IMEventType.RECONNECT, message => {
            // this.$message.warning('IM 可能是当前网络问题，或者长轮询接口报错引起')
            this.$notify.error({
              title: 'IM 已经离线',
              message: '可能是当前网络问题，或者长轮询接口报错引起，刷新页面重新连接。',
              duration: 0
            })
          })
          txim.addEventListener(IMEventType.CONNECTRET, message => {
            this.$message.success('IM 已连接')
          })
          txim.addEventListener(IMEventType.KICKOFF, message => {
            this.$notify.error({
              title: 'IM 被踢出',
              message: 'IM 已经离线，当前无法收到用户发来的消息，请确保账户没有被重复登录之后，刷新页面重新连接。',
              duration: 0
            })
          })
        }).catch(error => {
          this.$report(error, {
            message: '登录IM失败'
          })
          this.$message.error('登录IM失败' + this.$get(error, 'ErrorInfo', ''))
        })
      },
      _logoutAction() {
        // 改为通用的logout reset 接口，同时尝试处理电话和文本客服状态
        // todo 名字修改一下，太不通用了
        this.logoutSoftphone().finally(() => {
          window.removeEventListener('beforeunload', beforeUnloadNotify)
          this.LogOut().then(() => {
            // 为了重新实例化vue-router对象 避免bug
            location.reload()
          })
        })
      },
      logout() {
        this.$confirm('请确认您的所有操作已保存', '即将退出魔方系统', {
          confirmButtonText: '退出',
          cancelButtonText: '取消',
          type: 'warning'
        }).then(() => {
          this._logoutAction()
        }).catch(() => {
        })
      },
      handleCommand(command) {
        // 相同状态下不做切换
        if (this.currentStatus === command) {
          return
        }

        this.changeWorkStatus(command).then(response => {
          this.$message.success('切换状态成功')
        }).catch(err => {
          this.$message.error('切换工作状态失败')
          this.$report(err, {
            message: '切换工作状态失败'
          })
        })
      },
      soundEvent() {
        if (this.sound) {
          const soundUrl = `https://cube-resources.lenovo.com.cn/sound/sound.mp3`
          const audio = new Audio(soundUrl)
          audio.play()
        }
      },
      versionHistoryList() {
        getVersionHistory().then(response => {
          this.historyVersion = response.data.versions
        }).catch(err => {
          console.log(err)
        })
      },
      versionCheck() {
        this.versionHistoryList()
        this.aboutDialogVisible = true
        this.newVisible = false
      },
      soundChange(val) {
        getLocalStorage().setItem('SOUND', val)
      },
      getEngSound() {
        const sound = getLocalStorage().getItem('SOUND')
        if (sound === 'true') {
          this.sound = true
        }
      },
      changePassword() {
        this.showChangePassword = true
      },
      closeAlert() {
        this.showChangePassword = false
      }
    }
  }
</script>

<style rel="stylesheet/scss" lang="scss" scoped>
  .navbar {
    height: 50px;
    line-height: 50px;
    border-radius: 0px !important;
    padding-right: 30px;

    .brand {
      padding-left: 15px;
      cursor: default;
      font-size: 20px;
      overflow: auto;

      svg {
        font-size: 30px;
        float: left;
        margin: 10px 5px 0 0;
      }

      .font {
        float: left;
      }
    }

    .version {
      color: #3E8DDD;
      font-size: 12px;
      padding-left: 10px;
      margin-top: 10px;
      cursor: default;
    }

    .status {
      font-size: 14px;
      font-weight: normal;
      color: #606266;
      margin-right: 15px;

      &:hover {
        color: #409EFF;
      }
    }

    .new-icon {
      margin: 5px;
      padding: 7px 0 0;

      span {
        background-color: #F37261;
        color: #fff;
        font-size: 12px;
        padding: 0 5px;
        border-radius: 10px;
      }
    }
  }

  .more-ul {
    font-size: 12px;
    margin-right: 15px;

    li {
      padding: 5px;
    }

    li:last-child {
      border-top: 1px solid #ebeef5;
    }

    .hover-bg:hover {
      background-color: #e5f2ff;
    }
  }

  .about-cube {
    p {
      line-height: 1.5;
      font-size: 14px;
      margin: 0;
    }

    /deep/ .el-dialog__body {
      padding-top: 0;
      padding-bottom: 0;
    }
  }

  .alertBox {
    position: fixed;
    bottom: 15px;
    right: 20px;
    z-index: 11111;
  }

  .version-wrap {
    max-height: calc(100vh - 300px);
    font-size: 14px;
    overflow: auto;

    .title {
      text-align: center;
      font-size: 16px;
      color: #303133;
      font-weight: bold;
    }

    .time {
      text-align: center;
      color: #909399;
    }

    .version-list {
      margin: 20px 0 30px 20px;

      li {
        line-height: 26px;
      }
    }
  }

  .status-change {
    width: 100px;
  }
</style>
<style>
  .openNotification { /* openNotification事件 */
    width: 345px;
  }
</style>

