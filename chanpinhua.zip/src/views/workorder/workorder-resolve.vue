<template>
  <div class="app-container">
    <header class="list">
      <h1>工单处理</h1>
      <p class="text-right">
        <!--<el-button plain type="primary" @click="create">新建工单</el-button>-->
        <!--<el-button plain type="primary" @click="batchMakeOver">批量转派</el-button>-->
      </p>
    </header>
    <el-card>
      <header>
        <h2>条件查询</h2>
        <el-form ref="ruleForm" :model="ruleForm" label-width="100px" :inline="true">
          <el-form-item prop="order_id">
            <el-input v-model="ruleForm.order_id" clearable placeholder="工单ID" />
          </el-form-item>
          <el-form-item prop="status">
            <el-select v-model="ruleForm.status" multiple collapse-tags value="" clearable placeholder="工单状态" @change="statusChange">
              <el-option
                v-for="item in workorderState"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
          <el-form-item prop="create_code">
            <el-select
              v-model="ruleForm.create_code"
              filterable
              remote
              clearable
              reserve-keyword
              placeholder="创建人ID/姓名"
              :remote-method="remoteMethod"
              :loading="loading"
              @change.native="handleUserChange"
              @click.native="handleUserClick('create_code')"
            >
              <el-option v-for="item in user" :key="item.code" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>
          <el-form-item prop="customer_name">
            <el-select
              v-model="ruleForm.customer_name"
              filterable
              remote
              clearable
              reserve-keyword
              placeholder="客户ID/姓名"
              :remote-method="remoteMethod1"
              :loading="loading"
              @change.native="handleUserChange1"
              @click.native="handleUserClick1('customer_name')"
            >
              <el-option v-for="item in user1" :key="item.code" :label="item.name" :value="item.code" />
            </el-select>
          </el-form-item>
          <el-form-item prop="customer_phone">
            <el-input v-model="ruleForm.customer_phone" clearable placeholder="手机号码" />
          </el-form-item>
          <el-form-item prop="urgencyLevel">
            <el-select v-model="ruleForm.urgencyLevel" value="" clearable placeholder="优先级">
              <el-option
                v-for="item in priority"
                :key="item.id"
                :label="item.name"
                :value="item.id"
              />
            </el-select>
          </el-form-item>
          <el-form-item prop="fault_label_name">
            <el-cascader
              v-model="ruleForm.fault_label_name"
              :options="options"
              :show-all-levels="false"
              :props="cascaderAlias1"
              placeholder="故障类型"
              clearable
            />
          </el-form-item>
          <el-form-item prop="case_id">
            <el-input v-model="ruleForm.case_id" clearable placeholder="服务记录ID" />
          </el-form-item>
          <el-form-item label-width="160px" prop="value1">
            <ext-date-picker
              ref="time"
              v-model="value1"
              size="large"
              type="daterange"
              placehoder="创建时间"
              start-placeholder="开始时间"
              end-placeholder="结束日期"
              :picker-options="pickerOptions2"
              format="yyyy 年 MM 月 dd 日"
              value-format="yyyy-MM-dd"
              @change="hanleTiemScope"
            />
          </el-form-item>
        </el-form>
        <p class="text-right">
          <el-button plain type="primary" @click="submitConditionForm('ruleForm')">查 询</el-button>
          <el-button plain @click="resetConditionForm('ruleForm')">重 置</el-button>
        </p>
      </header>
      <footer v-if="listData.length">
        <div ref="ele">
          <header>
            <h2>查询结果</h2>
          </header>
          <el-table :data="listData" style="width: 100%" :default-sort="sortRule" tooltip-effect="light" class="tab" @sort-change="sortChange">
            <el-table-column prop="order_id" label="工单ID" width="150">
              <template slot-scope="scope">
                <a style="color:#4A90E2" @click="skipParticulars(scope.$index, scope.row)">{{ scope.row.order_id }}</a>
              </template>
            </el-table-column>
            <el-table-column prop="customer_name" label="客户姓名" min-width="108" />
            <el-table-column prop="case_id" label="服务记录ID" min-width="100">
              <template slot-scope="scope">
                <a style="color:#4A90E2" @click="skipService(scope.$index, scope.row)">{{ scope.row.case_id }}</a>
              </template>
            </el-table-column>
            <el-table-column prop="status" label="工单状态">
              <template slot-scope="scope">
                <div v-if="scope.row.status === 1">待派单</div>
                <div v-if="scope.row.status === 2">待处理</div>
                <div v-if="scope.row.status === 3">处理中</div>
                <div v-if="scope.row.status === 4">已完成</div>
              </template>
            </el-table-column>
            <el-table-column prop="created_at" label="创建时间" sortable width="140" />
            <el-table-column prop="clientDate" label="期望回复时间" sortable width="120">
              <template slot-scope="scope">
                <span>{{ scope.row.clientDate && scope.row.clientDate.substring( 0, scope.row.clientDate.indexOf(' ')) }}</span>
              </template>
            </el-table-column>
            <el-table-column prop="urgencyLevel" label="优先级">
              <template slot-scope="scope">
                <div v-if="scope.row.urgencyLevel === 1">高</div>
                <div v-if="scope.row.urgencyLevel === 2">中</div>
                <div v-if="scope.row.urgencyLevel === 3">低</div>
              </template>
            </el-table-column>
            <el-table-column prop="engineer_code" label="创建人" width="108">
              <template slot-scope="scope">
                {{ scope.row.engineer_code }}
                <span v-if="scope.row.engineer_code && scope.row.engineer_name">/</span>
                {{ scope.row.engineer_name }}
              </template>
            </el-table-column>
            <el-table-column prop="handlers" label="处理人" width="120">
              <!--<template slot-scope="scope">
                <div v-if="scope.row.handlers.indexOf(',') === -1"> {{ scope.row.handlers }}</div>
                <el-popover v-else width="150" placement="bottom" title="处理人:" trigger="hover" popper-class="accountPopover">
                  &lt;!&ndash;<div v-for="item in handleHandlersDeWeight(scope.row.handlers)" class="popoverHeight">{{ item }}</div>&ndash;&gt;
                  <div v-for="item in scope.row.handlers.split(',')" class="popoverHeight">{{ item }}</div>
                  <span slot="reference" type="text">{{ scope.row.handlers && scope.row.handlers.substring( 0, scope.row.handlers.indexOf(',')) }}...</span>
                </el-popover>
              </template>-->
              <template slot-scope="scope">
                <div v-if="handleHandlersDeWeight(scope.row.handlers).length < 2"> {{ handleHandlersDeWeight(scope.row.handlers)[0] }}</div>
                <el-popover v-else width="150" placement="bottom" title="处理人:" trigger="hover" popper-class="accountPopover">
                  <div v-for="item in handleHandlersDeWeight(scope.row.handlers)" class="popoverHeight">{{ item }}</div>
                  <span slot="reference" type="text">{{ handleHandlersDeWeight(scope.row.handlers)[0] }}...</span>
                </el-popover>
              </template>
            </el-table-column>
            <el-table-column fixed="right" label="操作" width="188">
              <template slot-scope="scope">
                <a v-if="scope.row.status !== 4" style="color: #3E8DDD;" @click="batchMakeOver(scope.row)">转派</a>
                <a v-if="scope.row.status !== 4 && scope.row.order_group_Id !== 3" style="color: #3E8DDD;" @click="upWorkorder(scope.row)">升级</a>
                <a v-if="scope.row.status === 2 && scope.row.status !== 4" style="color: #3E8DDD;" @click="dispose(scope.$index, scope.row)">处理</a>
                <a v-if="scope.row.status === 3 && scope.row.status !== 4" style="color: #3E8DDD;" @click="finish(scope.$index, scope.row)">完成</a>
              </template>
            </el-table-column>
          </el-table>
        </div>
        <el-pagination
          class="page"
          background
          :page-sizes="[10, 20, 30]"
          :current-page="list.page_index"
          :page-size="list.page_size"
          layout="total, sizes, prev, pager, next, jumper"
          :total="total"
          @size-change="handleSizeChange"
          @current-change="handleCurrentChange"
        />
      </footer>
      <footer v-if="!listData.length">
        <h2>查询说明</h2>
        <ul style="color: #666">
          <li>A. 不支持无条件查询；</li>
          <!--<li>B. 创建时间为必填字段，整体时间跨度不超过31天；</li>-->
          <li>B. 创建时间默认为从今日开始往前推7日的时间段；</li>
          <li>C. 条件查询中的各个查询条件之间是“与”的关系，即输入信息越多，结果越准确；</li>
          <li>D. 点击“重置”按钮，会重置所有输入框的状态。</li>
        </ul>
      </footer>
    </el-card>
    <dialogRedeploy :dialog-redeploy="dialogRedeploy" :list="dialogList" :row="row" @changeDialog="changeDialog" />
    <dialogAddScheme :dialog-add-scheme="dialogAddScheme" @changeDialog="changeDialog" />
  </div>
</template>

<script>
  import ExtDatePicker from '@/components/ExtDatePicker'
  import dialogRedeploy from './components/dialog-redeploy'
  import dialogAddScheme from './components/dialog-add-scheme'
  import { getListMatching, getWorkorderList, getListCustomer, getRedeployList, getStatusChange, postHTMLEmail, postUpWorkorder, getAddScheme } from '@/api/workorder'
  import { getSearchEngineer } from '@/api/touch'
  import { getAccountSearch } from '@/api/account-info'
  const convertTreeData = function(data) {
    return data.map(item => {
      item.label = item.fault_label_name
      if (item.children.length) {
        item.children = convertTreeData(item.children)
      } else {
        delete item.children
      }
      return item
    })
  }
  export default {
    name: 'workorder-resolve',
    components: { ExtDatePicker, dialogRedeploy, dialogAddScheme },
    data() {
      return {
        ruleForm: {
          order_id: '',
          status: '',
          create_code: '',
          start_time: '',
          end_time: '',
          customer_name: '',
          urgencyLevel: '',
          customer_phone: '',
          fault_label_name: '',
          case_id: '',
          handler: this.$store.getters.allInfo.code,
          source: 2
        },
        debounceQuery: null,
        loading: false,
        sortRule: {
          prop: null,
          order: null
        },
        user: [],
        user1: [],
        container: [],
        workorderState: [
          { id: 'Check All', name: 'Check All' },
          { id: 2, name: '待处理' },
          { id: 3, name: '处理中' },
          { id: 4, name: '已完成' }
        ],
        priority: [
          { id: 1, name: '高' },
          { id: 2, name: '中' },
          { id: 3, name: '低' }
        ],
        cascaderAlias1: {
          value: 'fault_label_name',
          label: 'fault_label_name',
          children: 'children'
        },
        options: [],
        value1: null,
        row: {},
        dialogList: [],
        type: [],
        pickerOptions2: { // 禁止选择未来时间
          disabledDate(time) {
            return time.getTime() > Date.now()
          }
        },
        isActivated: false,
        listData: [],
        listData1: [],
        list: {
          page_index: 1,
          page_size: 10
        },
        total: 0,
        dialogRedeploy: false, // 转派
        dialogAddScheme: false // 方案
      }
    },
    activated() {
      if (this.isActivated) this.submitConditionForm()
    },
    mounted() {
      this.defaultTime(6)
      this.init()
    },
    methods: {
      init() {
        getListMatching().then(res => { // 类别匹配
          this.options = convertTreeData(res.data)
          for (const one in this.options) {
            if (!this.options[one].children) {
              this.options[one].disabled = true
            } else {
              this.options[one].disabled = false
              for (const two in this.options[one].children) {
                if (!this.options[one].children[two].children) {
                  this.options[one].children[two].disabled = true
                } else {
                  this.options[one].children[two].disabled = false
                }
              }
            }
          }
        })
      },
      statusChange(val) {
        this.selectAll(val)
      },
      submitConditionForm(val) {
        if (val === 'ruleForm') { // 确认是否为点击查询
          this.list.page_index = 1
          this.list.page_size = 10
        }
        if (this.value1) {
          this.ruleForm.start_time = this.value1[0]
          this.ruleForm.end_time = this.value1[1]
        } else {
          this.ruleForm.start_time = ''
          this.ruleForm.end_time = ''
        }
        if (!(this.ruleForm.order_id || this.ruleForm.status.length || this.ruleForm.create_code || this.ruleForm.start_time || this.ruleForm.end_time || this.ruleForm.customer_name || this.ruleForm.urgencyLevel || this.ruleForm.customer_phone || this.ruleForm.fault_label_name.length || this.ruleForm.case_id)) {
          this.$message.warning('请至少输入一个查询条件')
          return
        }
        let data = ''
        for (const i in this.ruleForm) {
          if (i === 'fault_label_name') {
            this.ruleForm.fault_label_name.length ? data += i + '=' + this.ruleForm.fault_label_name[this.ruleForm.fault_label_name.length - 1] + '&' : data += i + '=' + '' + '&'
          } else {
            data += i + '=' + this.ruleForm[i] + '&'
          }
        }
        data += `&size=${this.list.page_size}&page=${this.list.page_index}`
        this.listData = []
        getWorkorderList(data).then(res => {
          if (!res.data.data.length) {
            this.$message.warning('查询不到数据')
          }
          this.isActivated = true
          this.listData = res.data.data
          this.listData1 = res.data.data
          this.total = res.data.total
        })
      },
      resetConditionForm(formName) { // 重置数据
        this.$refs[formName].resetFields()
        this.defaultTime(6)
      },
      changeDialog(val) {
        if (val) {
          this.submitConditionForm()
        }
        this.dialogRedeploy = false
      },
      sortChange(val) {
        if (val.prop === 'clientDate') {
          const data = []
          if (val.order === 'ascending') {
            for (const i in this.listData) {
              if (this.listData[i].clientDate === null) {
                data.push(this.listData[i])
              } else {
                data.unshift(this.listData[i])
              }
            }
          }
          if (val.order === 'descending') {
            for (const i in this.listData) {
              if (this.listData[i].clientDate === null) {
                data.unshift(this.listData[i])
              } else {
                data.push(this.listData[i])
              }
            }
          }
          this.listData = data
        }
        if (val.prop === 'created_at') {
          const data = []
          if (val.order === 'ascending') {
            for (const i in this.listData) {
              if (this.listData[i].created_at === null) {
                data.push(this.listData[i])
              } else {
                data.unshift(this.listData[i])
              }
            }
          }
          if (val.order === 'descending') {
            for (const i in this.listData) {
              if (this.listData[i].created_at === null) {
                data.unshift(this.listData[i])
              } else {
                data.push(this.listData[i])
              }
            }
          }
          this.listData = data
        }
        // 如果不排序恢复
        if (val.order === null) {
          this.listData = this.listData1
        }
        this.sortRule.order = val.order
        this.sortRule.prop = val.prop
      },
      handleUserChange() {},
      handleUserClick(val) {
        this.ruleForm[val] = ''
        this.user = []
      },
      handleUserChange1() {},
      handleUserClick1(val) {
        this.ruleForm[val] = ''
        this.user1 = []
      },
      create() {
        this.$router.push({
          path: `workorder/create`
        })
      },
      skipParticulars(id, row) {
        this.$router.push({
          path: `workorder/particulars`,
          query: {
            id: row.order_id
          }
        })
      },
      skipService(id, row) { // 跳转服务记录详情页
        this.$router.push({
          path: `/demand/case-query/particulars`,
          query: {
            case_id: row.case_id
          }
        })
      },
      defaultTime(val) {
        const now = new Date()
        const start = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate() - val)).toISOString().slice(0, 10)
        const end = new Date(Date.UTC(now.getFullYear(), now.getMonth(), now.getDate())).toISOString().slice(0, 10)
        this.value1 = [start, end]
      },
      hanleTiemScope() { // 设置时间跨度
        // if (this.value1 === null) return
        // let a = this.value1[0]
        // let b = this.value1[1]
        // a = new Date(a.replace(/-/g, '/')).getTime()
        // b = new Date(b.replace(/-/g, '/')).getTime()
        // if (b - a > 2592000000) {
        //   this.$message({
        //     message: '整体时间跨度不超过31天',
        //     type: 'warning'
        //   })
        //   this.value1 = null
        //   this.ruleForm.start_time = ''
        //   this.ruleForm.end_time = ''
        //   this.defaultTime(6)
        // }
      },
      handleHandlersDeWeight(row) {
        const arr = []
        for (const i in row.split(',')) {
          arr.push(row.split(',')[i])
        }
        const newArr = [arr[0]]
        for (let i = 1; i < arr.length; i++) {
          if (arr[i] !== newArr[newArr.length - 1]) {
            newArr.push(arr[i])
          }
        }
        return newArr
      },
      remoteMethod(query) { // 模糊查询 客服
        this.loading = true
        this.fuzzyEngineerSearch(query)
      },
      remoteMethod1(query) { // 模糊查询 客户
        this.loading = true
        this.fuzzyEngineerSearch1(query)
      },
      fuzzyEngineerSearch(query) {
        if (query !== '') {
          getSearchEngineer(query).then((res) => {
            var data = []
            for (const i in res.data) {
              data.push(res.data[i])
            }
            this.user = data.map(item => {
              return {
                code: item.code,
                name: item.code + ' / ' + item.name
              }
            })
            this.loading = false
          }).catch(() => {
            this.user = []
            this.loading = false
          })
        }
      },
      fuzzyEngineerSearch1(query) {
        if (query !== '') {
          getListCustomer(query).then((res) => {
            var data = []
            for (const i in res.data) {
              data.push(res.data[i])
            }
            this.user1 = data.map(item => {
              return {
                code: item.customer_id,
                name: item.customer_id + ' / ' + item.name
              }
            })
            this.loading = false
          }).catch(() => {
            this.user1 = []
            this.loading = false
          })
        }
      },
      ruleFormData(row, type, change) {
        return {
          order_id: row.order_id,
          engineer_code: this.$store.getters.allInfo.code,
          engineer_name: this.$store.getters.allInfo.name,
          solution: type,
          order_fault_id: row.fault_label_id,
          order_group_id: row.order_group_Id,
          is_show: change,
          file: [],
          files: ''
        }
      },
      batchMakeOver(row) { // 转派
        getRedeployList(row.order_group_Id, row.fault_label_id).then(res => {
          this.dialogList = res.data
          for (const i in this.dialogList) {
            if (this.dialogList[i].engineerCode === row.handle_code) {
              this.dialogList.splice(i, 1)
            }
          }
        })
        this.row = row
        this.dialogRedeploy = true
      },
      dispose(index, row) { // 处理工单
        const data = {
          order_id: row.order_id,
          status: 3
        }
        getAddScheme(this.ruleFormData(row, '处理中', 1)).then(() => {
          getStatusChange(data).then(res => {
            this.listData[index].status = 3
            this.$router.push({
              path: `workorder/particulars`,
              query: {
                id: row.order_id
              }
            })
          })
        })
      },
      finish(index, row) { // 完成按钮
        this.$confirm(`此操作将关闭【${row.order_id}】工单, 是否继续?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          const data = {
            order_id: row.order_id,
            status: 4
          }
          getAddScheme(this.ruleFormData(row, '提交完成', 2)).then(() => { // 添加‘提交完成’处理记录
            getStatusChange(data).then(res => { // 修改工单状态
              const val = {
                input: row.engineer_code,
                is_page: true,
                page: 1,
                per_page: 1,
                total: 1
              }
              this.$message({
                message: '关单成功',
                type: 'success'
              })
              getAccountSearch(val).then(res => { // 获取账号信息 然后发送邮件
                const emailContent = {
                  subject: '工单完成',
                  toUserEmail: res.data.data[0].email,
                  content: `<div>
                        <span>亲爱的【工程师${row.engineer_code}/${row.engineer_name}】，</span>
                        <p style="margin-left: 30px">您好！您创建的工单【<a href="https://imccdev.lenovo.com.cn/#/work-order/workorder/particulars?id=${row.order_id}">${row.order_id}</a>】已由工程师【${this.$store.getters.allInfo.code}/${this.$store.getters.allInfo.name}】解决，请查看。谢谢！</p>
                        <span>本邮件为系统自动产生，请勿回复！</span>
                      </div>`
                }
                postHTMLEmail(emailContent).then(res => {})
              })
              this.listData[index].status = 4
            })
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消关单'
          })
        })
      },
      upWorkorder(row) { // 升级工单
        this.$confirm(`此操作将升级【${row.order_id}】工单, 是否继续?`, '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          const data = {
            order_id: row.order_id,
            order_group_Id: row.order_group_Id,
            fault_label_id: row.fault_label_id,
            engineer_code: this.$store.getters.allInfo.code,
            engineer_name: this.$store.getters.allInfo.name,
            handle_code: row.handle_code,
            handle_name: row.handle_name
          }
          postUpWorkorder(data).then(res => { // 升级
            const data = {
              order_id: row.order_id,
              status: 3
            }
            getStatusChange(data).then(() => { // 改变工单状态
              this.submitConditionForm()
            })
            this.$message({
              message: '升级成功',
              type: 'success'
            })
          }).catch((err) => {
            this.$message({
              message: err,
              type: 'warning'
            })
          })
          // getAddScheme(this.ruleFormData(row, '升级', 2)).then(() => { // 添加‘提交完成’处理记录
          // })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消升级'
          })
        })
      },
      handleSizeChange(val) { // 条数切换
        this.list.page_size = val
        this.list.page_index = 1
        this.listData = []
        let data = ''
        for (const i in this.ruleForm) {
          data += i + '=' + this.ruleForm[i] + '&'
        }
        data += `source=1&size=${this.list.page_size}&page=${this.list.page_index}`
        getWorkorderList(data).then(res => {
          this.listData = res.data.data
          this.listData1 = res.data.data
        })
      },
      handleCurrentChange(val) { // 分页切换
        this.list.page_index = val
        this.listData = []
        let data = ''
        for (const i in this.ruleForm) {
          data += i + '=' + this.ruleForm[i] + '&'
        }
        data += `source=1&size=${this.list.page_size}&page=${this.list.page_index}`
        getWorkorderList(data).then(res => {
          this.listData = res.data.data
          this.listData1 = res.data.data
        })
      },
      selectAll(val) {
        const allValues = []
        for (const item of this.workorderState) allValues.push(item.id) // 保留所有值
        const oldVal = this.container.length === 1 ? this.container[0] : [] // 用来存储上一次值，可以进行对比
        if (val.includes('Check All')) this.ruleForm.status = allValues
        if (oldVal.includes('Check All') && !val.includes('Check All')) this.ruleForm.status = []
        if (oldVal.includes('Check All') && val.includes('Check All')) {
          const index = val.indexOf('Check All')
          val.splice(index, 1)
          this.ruleForm.status = val
        }
        if (!oldVal.includes('Check All') && !val.includes('Check All')) {
          if (val.length === allValues.length - 1) this.ruleForm.status = ['Check All'].concat(val)
        }
        this.container[0] = this.ruleForm.status
      }
    }
  }
</script>

<style scoped lang="scss">
  .app-container {
    & /deep/ .ext-date-container {
      height: 40px;
    }
    & /deep/ .placehoder {
      height: 38px;
    }
    & /deep/.el-date-editor {
      height: 37px!important;
    }
  }
  .list {
    overflow: hidden;
    border-top: 1px solid #eee;
    h1 {
      float: left;
    }
    .text-right {
      float: right;
      margin: 0;
    }
  }
</style>
