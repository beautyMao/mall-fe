<template>
  <!-- 产品化顶层容器 div，curd 模块的话需要加上 .app-container 统一间距 -->
  <div class="app-container">
    <el-card class="box-card">
      <div slot="header" class="clearfix">
        <span class="title">类别匹配</span>
        <a href="javascript:;" @click="openAll">
          <span class="header-btn">
            <svg-icon icon-class="open-all" />  全部展开</span>
        </a>
        <a href="javascript:;" @click="packAll">
          <span class="header-btn">
            <svg-icon icon-class="pack-all" />  全部收起</span>
        </a>

        <el-input
          v-model.trim="searchText"
          prefix-icon="el-icon-search"
          placeholder="请输入标签名称"
          :style="{width: '300px'}"
          style="float: right"
          @keyup.enter.native="onSearch(searchText)"
        >
          <!--<el-button slot="append" icon="el-icon-search" @click="onSearch(searchText)" />-->
        </el-input>
        <div v-if="data1.length" class="table-header">
          <ul>
            <li>节点名称</li>
            <li>
              <span style="margin-right: 68px">更新账号</span>
              <span style="margin-right: 75px">最新时间</span>
              <span style="margin-right: 65px">操作</span>
            </li>
          </ul>
        </div>
      </div>
      <div v-if="!data1.length" class="nodata">
        <svg-icon icon-class="null" class="null" />
        <span>暂无任何问题分类，您可以在左侧进行添加~</span>
      </div>
      <div v-if="data1.length" ref="contextMenuTarget" class="body">
        <el-tree
          ref="tree"
          :data="data1"
          default-expand-all
          node-key="id"
          :props="{ label: 'fault_label_name' }"
          :expand-on-click-node="false"
          :filter-node-method="filterNode"
        >
          <span slot-scope="{ node, data }" class="custom-tree-node" :class="{ 'top-title': node.level ? node.level === 1 : '' }">
            <span :class="{ 'top-title-text': node.level ? node.level === 1 : '' }">{{ substring(node.label, 10) }}</span>
            <span>
              <span style="padding-right: 30px">
                <span style="padding-right: 30px">{{ substring(data.operator_name, 4) + ' / ' + data.operator_code }}</span>
                <span>{{ data.updated_at.substr(0, data.updated_at.length - 3) }}</span>
              </span>
              <el-button
                type="text"
                size="mini"
                @click="() => append(data)"
              >
                编辑
              </el-button>
              <el-button
                type="text"
                size="mini"
                class="delete"
                style="margin-right: 15px"
                @click="() => remove(node, data)"
              >
                删除
              </el-button>
            </span>
          </span>
        </el-tree>
      </div>
    </el-card>

    <add-problem :select-data="data1" @addProblem="addProblem" />

    <edit-dialog
      :visible.sync="dialogFormVisible"
      :select-data="data1"
      :select-node.sync="selectNode"
      @close="dialogFormVisible = false"
      @getDataList="getDataList"
      @addProblem="addProblem"
    />

  </div>
</template>

<script type="text/jsx">
  import { getListMatching, delItemDelete } from '@/api/workorder'
  import addProblem from './components/add-problem' // 新增类别信息
  import editDialog from './components/edit-dialog' // 编辑

  // eslint-disable-next-line no-unused-vars
  const convertTreeData = function(data) {
    return data.map(item => {
      item.label = item.fault_label_name
      if (item.children.length) {
        item.children = convertTreeData(item.children)
      } else {
        delete item.children
      }
      return item
    })
  }

  // 计算节点的最大深度
  // eslint-disable-next-line no-unused-vars
  const computeMaxDeep = function(data, deep = 1) {
    if (!data.children.length) {
      return 1
    }
    return data.children.map(item => computeMaxDeep(item, deep)).sort().reverse()[0] + deep
  }

  export default {
    name: 'engineer-tag',
    components: { addProblem, editDialog },
    data() {
      return {
        data1: [],
        form: {
          name: '',
          pid: []
        },
        searchText: '',
        draggingNodeLevel: 1,
        dropNodeLevel: 1,
        deepestDraggingNodeLevel: 1,
        deepestDropNodeLevel: 1,
        selectNode: {},
        dialogFormVisible: false,
        formatData: [],
        contextMenuVisible: false,
        contextMenuTarget: null
      }
    },
    watch: {
      searchText(val) { // 搜索框
        this.$refs.tree.filter(val)
      }
    },
    mounted() {
      this.getDataList()
    },
    methods: {
      substring(data, len) {
        return (data.length > len ? data.substring(0, len) + '...' : data)
      },
      getDataList() { // 列表展示
        getListMatching().then(response => {
          this.data1 = convertTreeData(response.data)
        })
      },
      filterNode(value, data) { // 搜索框
        if (!value) return true
        return data.label.indexOf(value) !== -1
      },
      addProblem() {
        this.getDataList()
      },
      getNodeDataById(data, node) { // 查询id节点，并将数据压入
        return data.map(item => {
          if (item.id === node.parent_id) {
            if (item.children) {
              item.children.push(node)
            } else {
              this.$nextTick(() => {
                this.$set(item, 'children', []) // 同步刷新
                item.children.push(node)
              })
            }
            return
          }
          if (item.children) {
            this.getNodeDataById(item.children, node)
          }
        })
      },
      getTargetNodeId(data, dropNode) {
        return data.map(item => {
          this.formatData.push(item)
          if (item.children && item.children.length) {
            item.children = this.getTargetNodeId(item.children, dropNode)
          }
          return item
        })
      },
      append(data, parentNode) {
        this.$nextTick(() => {
          this.dialogFormVisible = true
          this.selectNode = data
        })
      },
      remove(node, data) {
        this.$confirm(`是否删除类别节点【 ` + data.fault_label_name + ` 】若该节点下包含子节点，则将被全部删除。`, '删除类别', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          center: true
        }).then(() => {
          const val = {
            parent_id: data.id,
            fault_label_name: data.fault_label_name
          }
          delItemDelete(data.id, val).then(response => {
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
            const parent = node.parent
            const children = parent.data.children || parent.data
            const index = children.findIndex(d => d.id === data.id)
            children.splice(index, 1)
          }).catch(this.$message.error)
        }).catch(() => {})
      },
      openAll() {
        for (let i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
          this.$refs.tree.store._getAllNodes()[i].expanded = true
        }
      },
      packAll() {
        for (let i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
          this.$refs.tree.store._getAllNodes()[i].expanded = false
        }
      },
      onSearch() {
        console.log('search')
      }
    }
  }
</script>
<style lang="scss" type="text/scss" scoped>
  .delete {
    color: #F37261 !important;
  }
  .delete:hover {
    color: #F37261 !important;
  }
  .app-container {
    display: flex;
    justify-content: space-between;
    padding-right: 10px;
    .box-card {
      position: relative;
      width: 66%;
      padding-left: 20px;
      padding-right: 5px;
      height: calc(100vh - 140px);
      /deep/ .el-card__header {
        padding-bottom: 0 !important;
        border-bottom: 0;
      }
      /deep/ .el-card__body {
        padding-top: 10px;
        padding-right: 0 !important;
        overflow-y: hidden;
        .body {
          overflow-y: scroll;
          height: calc(100vh - 260px);
          margin-left: 16px;
          /deep/ .el-tree>.el-tree-node {
            border-bottom: 1px solid #EBEEF5;
            padding-bottom: 5px;
            padding-top: 5px;
            margin-right: 20px;
          }
          /deep/ .el-tree {
            /deep/ .el-tree-node {
              /deep/ .el-tree-node__content{
              }
              .top-title {
                color: #303133;
                .top-title-text {
                  font-weight: 700 !important;
                }
              }
            }
          }
        }
        .nodata {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          position: absolute;
          left: 0;
          right: 0;
          top: 50px;
          bottom: 0;
          color: #606266;
          font-size: 14px;
          .null {
            width: 92px;
            height: 62px;
            margin-bottom: 20px;
          }
        }
      }
      .clearfix{
        .title {
          font-size: 20px;
          color: #222222;
          font-weight: bolder;
        }
        .header-btn {
          font-size: 14px;
          color: #1890FF;
          font-weight: bolder;
          margin-left: 20px;
        }
      }
      .table-header {
        height: 30px;
        width: 100%;
        margin-top: 30px;
        font-weight: 500 !important;
        ul {
          display: flex;
          align-items: center;
          justify-content: space-between;
          height: 30px;
          width: 100%;
          li {
            font-size: 16px;
            font-weight: 700 !important;
            line-height: 16px;
          }
        }
      }

    }
  }
  .custom-tree-node {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 14px;
    padding-right: 8px;
    .edit-icon {
      font-size: 16px;
    }
  }
</style>
