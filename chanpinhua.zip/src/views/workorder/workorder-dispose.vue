<template>
  <div class="app-container wrapper">
    <div class="left">
      <h4 class="title">处理人组织</h4>
      <el-tree
        ref="tree1"
        :data="data"
        :props="defaultProps"
        node-key="id"
        :highlight-current="true"
        @node-click="handleNodeClick"
      />
    </div>
    <div class="main">
      <h3 class="title">{{ handler }}</h3>
      <div class="right">
        <div class="list">
          <div slot="header" class="clearfix">
            <span class="title">类别匹配</span>
            <a href="javascript:;" @click="openAll">
              <span class="header-btn">
                <svg-icon icon-class="open-all" />  全部展开</span>
            </a>
            <a href="javascript:;" @click="packAll">
              <span class="header-btn">
                <svg-icon icon-class="pack-all" />  全部收起</span>
            </a>
            <el-input
              v-model.trim="searchText"
              prefix-icon="el-icon-search"
              placeholder="请输入标签名称"
              style="float: right; width: 200px"
              @keyup.enter.native="onSearch(searchText)"
            >
              <!--<el-button slot="append" icon="el-icon-search" @click="onSearch(searchText)" />-->
            </el-input>
            <div v-if="data1.length" ref="contextMenuTarget" class="body">
              <div class="title">节点名称</div>
              <el-tree
                ref="tree"
                :data="data1"
                default-expand-all
                node-key="id"
                :highlight-current="true"
                :props="{ label: 'fault_label_name' }"
                :expand-on-click-node="false"
                :filter-node-method="filterNode"
                @node-click="handleNodeClick1"
              >
                <!--<span slot-scope="{ node, data }" class="custom-tree-node" :class="{ 'top-title': node.level === 1 }">
                  <span :class="{ 'top-title-text': node.level === 1 }">{{ node.label }}</span>
                </span>-->
              </el-tree>
            </div>
          </div>
          <div v-if="!data1.length" class="nodata">
            <svg-icon icon-class="null" class="null" />
            <span>暂无任何问题分类~</span>
          </div>
        </div>
        <div v-if="handler1" class="item">
          <h4 class="title">
            <span>{{ handler1 }} - 处理人员 {{ TotalNumber }}人</span>
          </h4>
          <div class="button">
            <el-button plain type="primary" class="btn" @click="handleCreateClick">新增人员</el-button>
          </div>
          <el-table :data="listData" style="width: 100%" tooltip-effect="light" :header-cell-style="getRowClass">
            <el-table-column align="center" type="index" label="序号" width="100" />
            <el-table-column align="center" prop="engineer_code" label="人员ID" />
            <el-table-column align="center" prop="engineer_name" label="人员姓名" />
            <el-table-column align="center" label="操作">
              <template slot-scope="scope">
                <el-button type="text" style="color: #F37261" @click="handleDeleteClick(scope.row, scope.$index)">删 除</el-button>
              </template>
            </el-table-column>
          </el-table>
          <el-pagination
            class="page"
            background
            :page-sizes="[10, 20, 30]"
            :current-page="page"
            :page-size="size"
            layout="total, sizes, prev, pager, next, jumper"
            :total="TotalNumber"
            @size-change="handleSizeChange"
            @current-change="handleCurrentChange"
          />
        </div>
      </div>
    </div>
    <dialogCreateCustomer
      :dialog-create-customer="dialogCreateCustomer"
      @changeDialog="changeDialog"
      @selectCustomer="selectCustomer"
    />
  </div>
</template>

<script>
  import { getOrganizationList, getListMatching, getConductorList, postAddPerson, delDeletePerson } from '@/api/workorder'
  import dialogCreateCustomer from './components/dialog-create-customer'
  // eslint-disable-next-line no-unused-vars
  const convertTreeData = function(data) {
    return data.map(item => {
      item.label = item.fault_label_name
      if (item.children.length) {
        item.children = convertTreeData(item.children)
      } else {
        delete item.children
      }
      return item
    })
  }
  export default {
    name: 'workorder-dispose',
    components: { dialogCreateCustomer },
    data() {
      return {
        data: [],
        defaultProps: {
          children: 'children',
          label: 'name'
        },
        dialogCreateCustomer: false,
        group_id: '',
        problem_id: '',
        handler: 'L1处理组',
        handler1: '',
        searchText: '',
        data1: [],
        listData: [],
        page: 1,
        size: 10,
        TotalNumber: 0
      }
    },
    watch: {
      searchText(val) { // 搜索框
        this.$refs.tree.filter(val)
      },
      group_id() {
        getConductorList(this.group_id, this.problem_id, 10, 1).then(res => {
          this.listData = res.data.data
          this.TotalNumber = res.data.total
        })
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      getRowClass({ row, column, rowIndex, columnIndex }) { // 设置table 标题背景色
        if (rowIndex === 0) { return 'background:#F0F4FB' } else { return '' }
      },
      init() {
        getOrganizationList().then(res => { // 处理人组织
          this.data = res.data
          this.group_id = res.data[0].id
          this.$nextTick(() => {
            this.$refs.tree1.setCurrentKey(this.group_id)
          })
          getListMatching().then(response => { // 类别匹配
            this.data1 = convertTreeData(response.data)
            this.findLastStage()
          })
        })
      },
      handleCreateClick() {
        this.dialogCreateCustomer = true
      },
      changeDialog() {
        this.dialogCreateCustomer = false
      },
      selectCustomer(val) {
        this.dialogCreateCustomer = false
        const data = {
          group_id: this.group_id,
          problem_id: this.problem_id,
          engineer_code: val
        }
        postAddPerson(data).then(res => {
          getConductorList(this.group_id, this.problem_id, this.size, this.page).then(res => {
            this.listData = res.data.data
            this.TotalNumber = res.data.total
          })
        }).catch((err) => {
          this.$message.warning(err)
        })
      },
      handleDeleteClick(val, index) {
        this.$confirm(`是否删除处理人${val.engineer_name}`, '确认删除', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          center: true
        }).then(() => {
          const data = {
            group_id: this.group_id,
            problem_id: this.problem_id,
            engineer_code: val.engineer_code
          }
          delDeletePerson(data).then(response => {
            this.listData.splice(index, 1)
            this.TotalNumber = this.TotalNumber - 1
            this.$message({
              type: 'success',
              message: '删除成功!'
            })
          }).catch(this.$message.error)
        })
      },
      handleSizeChange(val) {
        this.size = val
        getConductorList(this.group_id, this.problem_id, this.size, this.page).then(res => {
          this.listData = res.data.data
          this.TotalNumber = res.data.total
        })
      },
      handleCurrentChange(val) {
        this.page = val
        getConductorList(this.group_id, this.problem_id, this.size, this.page).then(res => {
          this.listData = res.data.data
          this.TotalNumber = res.data.total
        })
      },
      handleNodeClick(data) {
        this.group_id = data.id
        this.handler = data.name
      },
      handleNodeClick1(data) {
        if (data.depth === 2) {
          this.handler1 = data.label
          this.problem_id = data.id
          getConductorList(this.group_id, this.problem_id, this.size, this.page).then(res => {
            this.listData = res.data.data
            this.TotalNumber = res.data.total
          })
        } else {
          this.$message.warning('请选择第三级类别')
        }
      },
      openAll() {
        for (let i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
          this.$refs.tree.store._getAllNodes()[i].expanded = true
        }
      },
      packAll() {
        for (let i = 0; i < this.$refs.tree.store._getAllNodes().length; i++) {
          this.$refs.tree.store._getAllNodes()[i].expanded = false
        }
      },
      filterNode(value, data) { // 搜索框
        if (!value) return true
        return data.label.indexOf(value) !== -1
      },
      findLastStage() {
        const arr = []
        this.data1.forEach(item1 => { // 找到第一个三级数据
          if (item1.children) {
            item1.children.forEach(item2 => {
              if (item2.children) {
                item2.children.forEach(item3 => {
                  arr.push(item3)
                  if (arr.length === 1) {
                    this.problem_id = arr[0].id
                    this.handler1 = arr[0].label
                    this.$nextTick(() => {
                      this.$refs.tree.setCurrentKey(this.problem_id)
                    })
                    getConductorList(this.group_id, this.problem_id, this.size, this.page).then(res => {
                      this.listData = res.data.data
                      this.TotalNumber = res.data.total
                    })
                  }
                })
              }
            })
          }
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  .wrapper {
    display: flex;
    min-height: calc(100vh - 84px);
    .left {
      width: 210px;
      margin-right: 20px;
      box-shadow:0 2px 10px 0 rgba(208,219,238,0.5);
      border-radius:4px;
      background: #fff;
      .title {
        height: 54px;
        line-height: 54px;
        padding-left: 20px;
        margin: 0;
        margin-bottom: 20px;
        background: #F0F4FB;
      }
      & /deep/ .el-tree-node__content{
        height: 40px;
      }
    }
    .main {
      display: flex;
      flex: 1;
      flex-direction: column;
      .title {
        height: 40px;
        margin: 0;
      }
      .right {
        display: flex;
        flex: 1;
      }
      .list {
        position: relative;
        flex: 1;
        padding: 25px 30px;
        box-shadow:0 2px 10px 0 rgba(208,219,238,0.5);
        border-radius:4px;
        background: #fff;
        .title {
          font-weight: 700;
          line-height: 32px;
        }
        .header-btn {
          font-size: 14px;
          color: #1890FF;
          font-weight: bolder;
          margin-left: 20px;
        }
        .nodata {
          display: flex;
          flex-direction: column;
          justify-content: center;
          align-items: center;
          position: absolute;
          left: 0;
          right: 0;
          top: 50px;
          bottom: 0;
          color: #606266;
          font-size: 14px;
          .null {
            width: 92px;
            height: 62px;
            margin-bottom: 20px;
          }
        }
        .body {
          font-size: 14px;
          .title {
            height: 34px;
            line-height: 34px;
            padding-left: 20px;
            margin-top: 28px;
            color: #303133;
            background: #F0F4FB;
          }
        }
      }
      .item {
        width: 500px;
        margin-left: 20px;
        box-shadow:0 2px 10px 0 rgba(208,219,238,0.5);
        border-radius:4px;
        background: #fff;
        .title {
          height: 70px;
          line-height: 70px;
          padding-left: 30px;
          margin: 0;
        }
        .button {
          float: right;
          margin-right: 30px;
          margin-bottom: 24px;
          .btn {
            width: 150px;
            height: 40px;
          }
        }
        .page {
          float: right;
          margin-top: 30px;
        }
      }
    }
  }
</style>
