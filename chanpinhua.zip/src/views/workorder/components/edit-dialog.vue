<template>
  <div class="my-dialog">
    <!-- Form -->
    <el-dialog
      ref="my-dialog"
      custom-class="el-dialog-body-center"
      width="440px"
      :visible.sync="visible"
      :close-on-click-modal="false"
      :before-close="() => void $emit('close')"
    >
      <div slot="title" class="dialog-footer el-dialog-body-center">编辑类别</div>
      <el-form ref="form" :model="form">
        <el-form-item label="节点名称" required>
          <el-input
            v-model.trim="form.fault_label_name"
            auto-complete="off"
            placeholder="请输入问题名称，最多20个字符"
            maxlength="20"
            :show-all-levels="false"
          />
        </el-form-item>
      </el-form>
      <div slot="footer" class="dialog-footer">
        <el-button @click="$emit('close')">取 消</el-button>
        <el-button type="primary" @click="submitData">提 交</el-button>
      </div>
    </el-dialog>
  </div>
</template>

<script>
  import { putItemChange } from '@/api/workorder'

  export default {
    name: 'edit-dialog',
    props: {
      visible: {
        type: Boolean,
        default: false
      },
      selectData: {
        type: Array
      },
      selectNode: {
        type: Object
      }
    },
    data() {
      return {
        form: {
          fault_label_name: '',
          pid: []
        },
        choosedNode: {}
      }
    },
    watch: {
      'selectNode': function() {
        if (this.selectNode.parent_id === null) {
          this.selectNode.parent_id = 0
        }
        this.form.pid = []
        this.form.pid.unshift(this.selectNode.parent_id)
        this.form.fault_label_name = this.selectNode.fault_label_name
        this.choosedNode = this.selectNode
        this.checkChoose(this.choosedNode, true)
      },
      'visible': function() {
        if (this.selectNode.parent_id === null) {
          this.selectNode.parent_id = 0
        }
        this.form.pid = []
        this.form.pid.unshift(this.selectNode.parent_id)
        this.form.fault_label_name = this.selectNode.fault_label_name
        this.choosedNode = this.selectNode
        if (!this.visible) {
          this.checkChoose(this.choosedNode, false)
        }
      }
    },
    methods: {
      checkChoose(selectNode, flag) {
        if (flag) {
          selectNode.disabled = flag
        } else {
          delete selectNode.disabled
        }

        if (selectNode.children) {
          selectNode.children.forEach(item => {
            this.checkChoose(item, flag)
          })
        }
      },
      // formatData(data) {
      //   data.disabled = false
      //   if (data.children) {
      //     data.children.forEach(item => {
      //       this.checkChoose(item)
      //     })
      //   }
      // },
      submitData() {
        if (!/^[a-zA-Z0-9\u4E00-\u9FA5]{1,20}$/.test(this.form.fault_label_name)) {
          this.$message.warning('节点名称只能输入字母数字汉字')
          return
        }
        this.$refs.form.validate(valid => {
          if (valid) {
            if (this.form.pid && this.form.pid.length) {
              // 以下为二级节点，父ID为null
              if (this.form.pid.length === 1 && this.form.pid[0] === null) {
                const parm = {
                  parent_id: 0,
                  fault_label_name: this.form.fault_label_name
                }
                putItemChange(this.choosedNode.id, parm).then(res => {
                  if (res.statusCode === 200) {
                    this.$message({
                      type: 'success',
                      message: '修改成功!'
                    })
                    this.$emit('close')
                    this.$emit('getDataList')
                  }
                }).catch(err => {
                  if (err.errorOrRes === '问题分类重复，请重新填写') {
                    this.isDuplicate = true
                  } else {
                    this.$message({
                      message: err,
                      type: 'warning'
                    })
                  }
                })
              } else {
                const index = this.form.pid.length - 1
                const parm = {
                  parent_id: this.form.pid[index],
                  fault_label_name: this.form.fault_label_name
                }
                putItemChange(this.choosedNode.id, parm).then(res => {
                  if (res.statusCode === 200) {
                    this.$message({
                      type: 'success',
                      message: '修改成功!'
                    })
                    this.$emit('close')
                    this.$emit('getDataList')
                  }
                }).catch(err => {
                  if (err.errorOrRes === '问题分类重复，请重新填写') {
                    this.isDuplicate = true
                  } else {
                    this.$message({
                      message: err,
                      type: 'warning'
                    })
                  }
                })
              }
            }
          } else {
            return false
          }
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  /deep/ .el-input--mini{
    width: 270px !important;
  }
  /deep/ .el-cascader {
    height: 40px;
  }
  /deep/ .el-cascader__label {
    height: 40px;
  }
  /deep/ .el-input {
    height: 40px;
    width: 300px !important;
  }
  /deep/ .el-input__inner {
    height: 40px;
    width: 300px !important;
  }
  /deep/ .el-form-item__content {
    display: flex;
    justify-content: flex-start;
  }
  /deep/ .el-form-item__label {
    line-height: 40px;
    padding-right: 20px;
    vertical-align: middle;
  }
</style>
