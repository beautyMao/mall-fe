<template>
  <div class="app-container">
    <header>
      <h1>新建工单</h1>
    </header>
    <el-card>
      <header>
        <el-form ref="ruleForm" :model="ruleForm" :rules="rules" label-width="100px" size="medium" class="ruleForm">
          <div class="list">
            <h2>客户信息</h2>
            <p class="text">
              <el-button v-if="isSelectClient" plain type="primary" @click="selectClient">选择客户</el-button>
            </p>
          </div>
          <div style="display: flex; flex-wrap: wrap;">
            <el-form-item label="客户ID:" prop="customer_id">
              <span style="color: #606266">{{ ruleForm.customer_id }}</span>
              <!--<el-input v-model="ruleForm.customer_id" :disabled="true" clearable placeholder="请输入客户ID" />-->
            </el-form-item>
            <el-form-item label="客户姓名:" prop="customer_name">
              <span style="color: #606266">{{ ruleForm.customer_name }}</span>
              <!--<el-input v-model="ruleForm.customer_name" clearable placeholder="输入客户姓名" />-->
            </el-form-item>
            <el-form-item label="手机号码:" prop="customer_phone">
              <span style="color: #606266">{{ ruleForm.customer_phone }}</span>
              <!--<el-input v-model="ruleForm.customer_phone" clearable placeholder="输入手机号码" />-->
            </el-form-item>
            <el-form-item label="邮箱:" prop="customer_email">
              <span style="color: #606266">{{ ruleForm.customer_email }}</span>
              <!--<el-input v-model="ruleForm.customer_email" clearable placeholder="输入邮箱" />-->
            </el-form-item>
          </div>
          <h2 class="border-top">工单信息</h2>
          <el-form-item label="优先级:" prop="urgencyLevel">
            <el-radio-group v-model="ruleForm.urgencyLevel">
              <el-radio :label="1">高</el-radio>
              <el-radio :label="2">中</el-radio>
              <el-radio :label="3">低</el-radio>
            </el-radio-group>
          </el-form-item>
          <el-form-item label="期望回复时间:">
            <el-date-picker
              v-model="ruleForm.clientDate"
              type="date"
              format="yyyy 年 MM 月 dd 日"
              value-format="yyyy-MM-dd"
              :picker-options="pickerOptions1"
              placeholder="请输入时间"
            />
          </el-form-item>
          <el-form-item />
          <el-form-item label="联系人姓名:" prop="contact_name">
            <el-input v-model="ruleForm.contact_name" clearable placeholder="请输入联系人姓名" />
          </el-form-item>
          <el-form-item label="联系人电话:" prop="contact_phone">
            <el-input v-model="ruleForm.contact_phone" clearable placeholder="请输入联系人电话" />
          </el-form-item>
          <el-form-item label="备注:" prop="remarks" class="multi-row">
            <el-input v-model="ruleForm.remarks" type="textarea" placeholder="请输入备注信息" maxlength="500" show-word-limit resize="none" />
          </el-form-item>
          <h2 class="border-top">故障信息</h2>
          <el-form-item label="服务记录ID:" prop="case_id">
            <el-input v-model="ruleForm.case_id" disabled placeholder="无" maxlength="20" />
          </el-form-item>
          <el-form-item label="故障类型:" prop="fault_label_id">
            <el-cascader
              ref="cascader"
              v-model="ruleForm.fault_label_id"
              :options="options"
              :props="cascaderAlias1"
              placeholder="请输入故障类型"
              clearable
            />
          </el-form-item>
          <el-form-item label="故障描述:" prop="fault_describe" class="multi-row">
            <el-input v-model="ruleForm.fault_describe" type="textarea" placeholder="请输入故障描述" maxlength="500" show-word-limit resize="none" />
          </el-form-item>
          <el-form-item label="建议解决方案:" prop="cotent" class="multi-row">
            <el-input v-model="ruleForm.cotent" type="textarea" placeholder="请输入建议解决方案" maxlength="500" show-word-limit resize="none" />
          </el-form-item>
          <el-form-item label="上传附件:" prop="file" style="display: block; width: 500px;">
            <el-upload
              :action="uploadAction"
              :data="uploadData"
              :file-list="fileList"
              :headers="uploadHeader"
              :limit="1"
              :on-exceed="handleExceed"
              :on-success="(response, file, fileList) => { handleFileListChange(fileList) }"
              :on-remove="(file, fileList) => { handleFileListChange(fileList) }"
              :before-upload="handleBeforeUpload"
              :on-error="handleErrorFileupload"
              :on-preview="handlePreview"
            >
              <el-button type="text" icon="el-icon-paperclip">添加附件</el-button>
              <div slot="tip" class="el-upload__tip">支持Word、Excel、图片（png、jpg）、压缩文件的上传，大小不超过30M</div>
            </el-upload>
          </el-form-item>
        </el-form>
        <p class="center border-top">
          <el-button type="primary" :disabled="!isSubmit" @click="submitConditionForm(ruleForm)">提 交</el-button>
        </p>
      </header>
    </el-card>
    <dialogSelectCustomer :dialog-select-customer="dialogSelectCustomer" @changeDialog="changeDialog" @register="register" />
    <crm-dialog ref="userDialog" @done="handleUserDone" />
  </div>
</template>

<script>
  import dialogSelectCustomer from './dialog-select-customer'
  import CrmDialog from '@/views/crm/components/crm-user-form-dialog'
  import { getListMatching, postAddWorkorder, getSelectCustomer, postHTMLEmail } from '@/api/workorder'
  import { getAccountSearch } from '@/api/account-info'
  import { QINIU_ACTION } from '@/api/qiniu'
  import { getToken } from '@/utils/auth'
  import { uuid } from '@/utils'
  import { RegexUtil } from '@/utils/validate'

  const convertTreeData = function(data) {
    return data.map(item => {
      item.label = item.fault_label_name
      if (item.children.length) {
        item.children = convertTreeData(item.children)
      } else {
        delete item.children
      }
      return item
    })
  }
  export default {
    name: 'create-workorder',
    components: { dialogSelectCustomer, CrmDialog },
    data() {
      const name = (rule, value, callback) => {
        if (value) {
          const reg = /^[a-zA-Z0-9\u4E00-\u9FA5]{0,50}$/
          if (reg.test(value)) {
            callback()
          } else {
            return callback(new Error('请输入50位以内中英文及数字'))
          }
        }
      }
      const mobile = (rule, value, callback) => {
        if (value) {
          if (RegexUtil.mobile.test(value)) {
            callback()
          } else {
            return callback(new Error('请输入正确的手机号码'))
          }
        }
      }
      return {
        ruleForm: {
          session_id: '',
          ir_id: '',
          order_group_Id: 1,
          customer_id: '',
          customer_name: '',
          customer_phone: '',
          customer_email: '',
          contact_name: '',
          contact_phone: '',
          clientDate: '',
          urgencyLevel: 3,
          engineer_code: this.$store.getters.allInfo.code,
          engineer_name: this.$store.getters.allInfo.name,
          remarks: '',
          case_id: '',
          fault_label_id: '',
          fault_label_name: '',
          fault_describe: '',
          cotent: '',
          file: [],
          files: []
        },
        rules: {
          contact_name: [
            { validator: name, trigger: 'blur' }
          ],
          contact_phone: [
            { validator: mobile, trigger: 'blur' }
          ],
          urgencyLevel: [
            { required: true, message: '请输入优先级', trigger: 'blur' }
          ],
          fault_label_id: [
            { required: true, message: '请输入故障类型', trigger: 'change' }
          ],
          fault_describe: [
            { required: true, message: '请输入故障描述', trigger: 'blur' }
          ]
        },
        uploadAction: QINIU_ACTION,
        uploadData: {
          key: ''
        },
        uploadHeader: {
          'Authorization': `Bearer ${getToken()}`
        },
        currentIndex: 0,
        imageSrc: '',
        value1: '',
        pickerOptions1: { // 禁止选择以前时间
          disabledDate(time) {
            return time.getTime() < (Date.now() - 86400000)
          }
        },
        cascaderAlias1: {
          value: 'id',
          label: 'fault_label_name',
          children: 'children'
        },
        options: [],
        type: [],
        fileList: [],
        isSubmit: true, // 提交按钮
        isSelectClient: true, // 选择客户按钮
        dialogSelectCustomer: false,
        dialogImportVisible: false // 创建客户
      }
    },
    mounted() {
      this.init()
      if (this.$route.query.customer) {
        this.isSelectClient = false
        const data = {
          customer_id: this.$route.query.customer,
          name: '',
          phone: '',
          email: '',
          perPage: 10,
          page: 1
        }
        getSelectCustomer(data).then(res => {
          this.ruleForm.customer_id = res.data.data[0].customer_id
          this.ruleForm.customer_name = res.data.data[0].name
          this.ruleForm.customer_phone = res.data.data[0].phone && res.data.data[0].phone[0]
          this.ruleForm.customer_email = res.data.data[0].email && res.data.data[0].email[0]
        })
      }
      if (this.$route.query.case) {
        this.ruleForm.case_id = this.$route.query.case
      }
    },
    methods: {
      init() {
        getListMatching().then(res => { // 类别匹配
          this.options = convertTreeData(res.data)
          for (const one in this.options) {
            if (!this.options[one].children) {
              this.options[one].disabled = true
            } else {
              this.options[one].disabled = false
              for (const two in this.options[one].children) {
                if (!this.options[one].children[two].children) {
                  this.options[one].children[two].disabled = true
                } else {
                  this.options[one].children[two].disabled = false
                }
              }
            }
          }
        })
      },
      selectClient() {
        this.dialogSelectCustomer = true
      },
      changeDialog(row) {
        if (row) {
          this.ruleForm.customer_id = row.customer_id
          this.ruleForm.customer_name = row.name
          this.ruleForm.customer_phone = row.phone && row.phone[row.phone.length - 1]
          this.ruleForm.customer_email = row.email && row.email[row.email.length - 1]
        }
        this.dialogSelectCustomer = false
      },
      register() {
        // this.dialogSelectCustomer = false
        this.$refs.userDialog.show()
      },
      handleUserDone(val) {
        const data = {
          customer_id: val.response.data.customer_id,
          name: '',
          phone: '',
          email: '',
          perPage: 10,
          page: 1
        }
        getSelectCustomer(data).then(res => {
          this.ruleForm.customer_id = res.data.data[0].customer_id
          this.ruleForm.customer_name = res.data.data[0].name
          this.ruleForm.customer_phone = res.data.data[0].phone && res.data.data[0].phone[0]
          this.ruleForm.customer_email = res.data.data[0].email && res.data.data[0].email[0]
          this.dialogSelectCustomer = false
        })
      },
      handleExceed(files, fileList) {
        this.$message.warning('最多上传一条数据')
      },
      handleBeforeUpload(file) {
        const ext = file.name.split('.').reverse()[0].toLowerCase()
        if (!'png,jpeg,jpg,zip,doc,docx,xls,xlsx'.split(',').includes(ext)) {
          this.$message.error('仅支持Word，Excel、图片（png、jpg）、支持压缩文件上传')
          return false
        }
        if (file.size / 1024 / 1024 > 30) {
          this.$message.error('文件需要小于30MB')
          return false
        }
        // 自定义七牛文件上传路径
        const date = new Date()
        this.uploadData.key = `cube/Image/${date.getFullYear()}${(date.getMonth() + 1)}/${uuid('casefile')}.${ext}`
        return true
      },
      handleFileListChange(fileList) {
        if (fileList.length) {
          this.ruleForm.file = []
          this.ruleForm.file.push({
            file_name: fileList[0].name,
            file_url: fileList[0].response.data.picUrl
          })
        } else {
          this.ruleForm.file = []
        }
      },
      handleErrorFileupload(err, file, fileList) {
        this.$message.warning(err.error || '上传失败')
      },
      handlePreview(file) {
        // if (/\.png$|\.jpg$/.test(file.name)) {
        //   this.imageSrc = file.url || file.response.data.picUrl + QINIU_IMAGEVIEW
        //   this.$refs.viewer.showViewer()
        // } else {
        //   this.$message.warning('非图片类型文件不能预览')
        // }
      },
      toSearchPage() { // 关闭页面
        this.ruleForm = {
          session_id: '',
          ir_id: '',
          order_group_Id: 1,
          customer_id: '',
          customer_name: '',
          customer_phone: '',
          customer_email: '',
          contact_name: '',
          contact_phone: '',
          clientDate: '',
          urgencyLevel: 3,
          engineer_code: this.$store.getters.allInfo.code,
          engineer_name: this.$store.getters.allInfo.name,
          remarks: '',
          case_id: '',
          fault_label_id: '',
          fault_label_name: '',
          fault_describe: '',
          cotent: '',
          file: [],
          files: []
        }
        this.fileList = []
        const currentPath = this.$route.path
        for (const [i, v] of this.$store.getters.visitedViews.entries()) {
          if (v.path === currentPath) {
            this.$store.getters.visitedViews.splice(i, 1)
            // const latestView = this.$store.getters.visitedViews.slice(-1)[0]
            // if (latestView) {
            //   return this.$router.back(-1)
            // } else {
            //   this.$router.push('/')
            // }
          }
        }
      },
      submitConditionForm() {
        if (!this.ruleForm.customer_id) {
          this.$message.warning('请输入客户信息')
          return
        }
        if (this.ruleForm.contact_name && !/^[a-zA-Z0-9\u4E00-\u9FA5]{1,50}$/.test(this.ruleForm.contact_name)) {
          this.$message.warning('请输入正确的联系人姓名')
          return
        }
        if (this.ruleForm.contact_phone && !RegexUtil.mobile.test(this.ruleForm.contact_phone)) {
          this.$message.warning('请输入正确的手机号码')
          return
        }
        this.$refs['ruleForm'].validate((valid) => {})
        if (!this.ruleForm.fault_label_id) {
          this.$message.warning('请输入故障类型')
          return
        }
        if (!this.ruleForm.fault_describe) {
          this.$message.warning('请输入故障描述')
          return
        }
        const valid = (!!this.ruleForm.fault_label_id && !!this.ruleForm.fault_describe)
        if (valid) {
          this.ruleForm.fault_label_name = this.$refs.cascader.inputValue.replace(/\//g, '>')
          // if (this.ruleForm.fault.file.length > 1) {
          //   this.ruleForm.fault.files = this.ruleForm.fault.file.map(file => {
          //     return file.raw
          //   })
          // }
          if (this.ruleForm.fault_label_id instanceof Array) this.ruleForm.fault_label_id = this.ruleForm.fault_label_id.pop()
          this.isSubmit = false
          postAddWorkorder(this.ruleForm).then(res => {
            const val = {
              input: this.$store.getters.allInfo.code,
              is_page: true,
              page: 1,
              per_page: 1,
              total: 1
            }
            getAccountSearch(val).then(res1 => {
              const emailContent = {
                subject: '工单创建',
                toUserEmail: res1.data.data[0].email,
                content: `<div>
                        <span>亲爱的【工程师${this.$store.getters.allInfo.code}/${this.$store.getters.allInfo.name}】，</span>
                        <p style="margin-left: 30px">您好！您的工单【<a href="https://imccdev.lenovo.com.cn/#/work-order/workorder/particulars?id=${res.data.order_id}">${res.data.order_id}</a>】已创建。谢谢！</p>
                        <span>本邮件为系统自动产生，请勿回复！</span>
                      </div>`
              }
              postHTMLEmail(emailContent).then(res => {})
            })
            this.toSearchPage()
            this.$router.push({
              path: `/work-order/workorder/particulars`,
              query: {
                id: res.data.order_id
              }
            })
          }).catch(() => {
            this.isSubmit = true
            this.$message.warning('添加失败')
          })
        } else {
          // this.$message.warning('请填写必填项')
          return false
        }
      }
    }
  }
</script>

<style scoped lang="scss">
  .app-container {
    & /deep/ .el-form-item__label {
      text-align: left;
    }
    & /deep/ .el-textarea {
      width: 260px;
    }
    & /deep/ .el-input__count {
      line-height: normal;
    }
    & /deep/ .upload-demo {
      display: inline-block;
    }
    .ruleForm {
      max-width: 100% !important;
      & /deep/ .el-form-item {
        display: inline-block;
        width: 33%;
      }
      .multi-row {
        width: 66%;
        & /deep/ .el-textarea {
          width: 94%;
          height: 120px;
          .el-textarea__inner {
            height: 100%;
          }
        }
      }
    }
    .border-top {
      padding-top: 14px;
      border-top: 1px solid #E4E7ED;
    }
    .center {
      text-align: center;
    }
  }
  .list {
    overflow: hidden;
    h2 {
      float: left;
      margin-right: 20px;
    }
  }
</style>
