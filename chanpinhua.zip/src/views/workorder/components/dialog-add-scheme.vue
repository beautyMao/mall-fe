<template>
  <el-dialog :visible.sync="dialog" :title="tit" custom-class="el-dialog-aside" class="wrapper">
    <el-form ref="ruleForm" :model="ruleForm" label-width="100px" size="medium" class="ruleForm">
      <el-form-item :label="title" prop="solution">
        <el-input
          v-model="ruleForm.solution"
          type="textarea"
          :placeholder="placeholder"
          maxlength="500"
          show-word-limit
        />
      </el-form-item>
      <el-form-item label="上传附件:" prop="file" style="display: block; width: 100%;">
        <el-upload
          :action="uploadAction"
          :data="uploadData"
          :file-list="fileList"
          :headers="uploadHeader"
          :limit="1"
          :on-exceed="handleExceed"
          :on-success="(response, file, fileList) => { handleFileListChange(fileList) }"
          :on-remove="(file, fileList) => { handleFileListChange(fileList) }"
          :before-upload="handleBeforeUpload"
          :on-error="handleErrorFileupload"
          :on-preview="handlePreview"
        >
          <el-button type="text" icon="el-icon-paperclip">添加附件</el-button>
          <div slot="tip" class="el-upload__tip">支持Word、Excel、图片（png、jpg）、压缩文件的上传，大小不超过30M</div>
        </el-upload>
      </el-form-item>
    </el-form>
    <div slot="footer" class="btn-wapper">
      <el-button plain type="primary" class="btn" @click="addScheme">确 认</el-button>
      <el-button class="btn btn1" @click="close">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import { getAddScheme, getStatusChange, postHTMLEmail } from '@/api/workorder'
  import { getAccountSearch } from '@/api/account-info'
  import { QINIU_ACTION } from '@/api/qiniu'
  import { uuid } from '@/utils'
  import { getToken } from '@/utils/auth'

  export default {
    name: 'dialog-add-scheme',
    props: {
      row: {
        type: Object,
        default: function() {
          return {}
        }
      },
      title: {
        type: String,
        default: '添加方案'
      },
      dialogAddScheme: {
        type: Boolean,
        default: false
      },
      replaceData: {
        type: String,
        default: ''
      }
    },
    data() {
      return {
        ruleForm: {
          order_id: '',
          engineer_code: '',
          engineer_name: '',
          solution: '',
          order_fault_id: '',
          order_group_id: '',
          is_show: '',
          id: '',
          file: [],
          files: ''
        },
        tit: '',
        placeholder: '',
        dialog: false,
        textarea: '',
        fileList: [],
        uploadAction: QINIU_ACTION,
        uploadData: {
          key: ''
        },
        uploadHeader: {
          'Authorization': `Bearer ${getToken()}`
        },
        currentIndex: 0,
        imageSrc: ''
      }
    },
    watch: {
      dialogAddScheme() {
        this.dialog = this.dialogAddScheme
      },
      dialog() {
        this.tit = `当前正在${this.title}：工单 ${this.row.order_id}`
        this.placeholder = this.title === '添加方案' ? '在此填写解决方案' : '在此填写重新打开原因'
        if (!this.dialog) {
          this.ruleForm = {
            order_id: '',
            engineer_code: '',
            engineer_name: '',
            solution: '',
            order_fault_id: '',
            order_group_id: '',
            is_show: '',
            id: '',
            file: [],
            files: ''
          }
          this.fileList = []
          this.$emit('changeDialog')
        }
      }
    },
    methods: {
      close() {
        this.ruleForm = {
          order_id: '',
          engineer_code: '',
          engineer_name: '',
          solution: '',
          order_fault_id: '',
          order_group_id: '',
          is_show: '',
          id: '',
          file: [],
          files: ''
        }
        this.fileList = []
        this.$emit('changeDialog')
      },
      handleExceed(files, fileList) {
        this.$message.warning('最多上传一条数据')
      },
      handleBeforeUpload(file) {
        const ext = file.name.split('.').reverse()[0].toLowerCase()
        if (!'png,jpeg,jpg,zip,doc,docx,xls,xlsx'.split(',').includes(ext)) {
          this.$message.error('仅支持Word，Excel、图片（png、jpg）、支持压缩文件上传')
          return false
        }
        if (file.size / 1024 / 1024 > 30) {
          this.$message.error('文件需要小于30MB')
          return false
        }
        // 自定义七牛文件上传路径
        const date = new Date()
        this.uploadData.key = `cube/Image/${date.getFullYear()}${(date.getMonth() + 1)}/${uuid('casefile')}.${ext}`
        return true
      },
      handleFileListChange(fileList) {
        if (fileList.length) {
          this.ruleForm.file = []
          this.ruleForm.file.push({
            file_name: fileList[0].name,
            file_url: fileList[0].response.data.picUrl
          })
        } else {
          this.ruleForm.file = []
        }
      },
      handleErrorFileupload(err, file, fileList) {
        this.$message.warning(err.error || '上传失败')
      },
      handlePreview(file) {
        // if (/\.png$|\.jpg$/.test(file.name)) {
        //   this.imageSrc = file.url || file.response.data.picUrl + QINIU_IMAGEVIEW
        //   this.$refs.viewer.showViewer()
        // } else {
        //   this.$message.warning('非图片类型文件不能预览')
        // }
      },
      addScheme() {
        this.ruleForm.order_id = this.row.order_id
        this.ruleForm.engineer_code = this.$store.getters.allInfo.code
        this.ruleForm.engineer_name = this.$store.getters.allInfo.name
        this.ruleForm.order_fault_id = this.row.order_fault.fault_id
        this.ruleForm.is_show = 2
        this.ruleForm.id = this.replaceData
        this.ruleForm.order_group_id = this.row.order_group_Id
        if (this.title === '重新打开') this.ruleForm.order_group_id = 4
        if (!this.ruleForm.solution) {
          const tit = this.title === '添加方案' ? '解决方案' : '重新打开原因'
          this.$message.warning(`请填写${tit}`)
          return
        }
        if (!this.ruleForm.id) delete this.ruleForm.id
        getAddScheme(this.ruleForm).then(() => {
          if (this.title === '重新打开') {
            const ruleForm1 = {
              order_id: this.row.order_id,
              engineer_code: this.row.handle_code,
              engineer_name: this.row.handle_name,
              order_fault_id: this.row.order_fault.fault_id,
              is_show: 1,
              order_group_id: this.row.order_group_Id,
              solution: '处理中'
            }
            getAddScheme(ruleForm1).then(() => { // 重新打开记录
              const data = {
                order_id: this.$route.query.id,
                status: 3
              }
              getStatusChange(data).then(res => { // 修改工单状态
                const val = {
                  input: this.row.handle_code,
                  is_page: true,
                  page: 1,
                  per_page: 1,
                  total: 1
                }
                getAccountSearch(val).then(res => { // 获取员工信息
                  this.ruleForm = {
                    order_id: '',
                    engineer_code: '',
                    engineer_name: '',
                    solution: '',
                    order_fault_id: '',
                    order_group_id: '',
                    is_show: '',
                    id: '',
                    file: [],
                    files: ''
                  }
                  this.fileList = []
                  this.$message.success('重新打开成功！')
                  this.$emit('changeDialog', true)
                  const emailContent = {
                    subject: '工单重新打开',
                    toUserEmail: res.data.data[0].email,
                    content: `<div>
                      <span>亲爱的【工程师${this.row.handle_code}/${this.row.handle_name}】，</span>
                      <p style="margin-left: 30px">您好！工单【<a href="https://imccdev.lenovo.com.cn/#/work-order/workorder/particulars?id=${this.$route.query.id}">${this.$route.query.id}</a>】已由工程师【${this.$store.getters.allInfo.code}/${this.$store.getters.allInfo.name}】重新打开，请尽快处理。谢谢！</p>
                      <span>本邮件为系统自动产生，请勿回复！</span>
                    </div>`
                  }
                  postHTMLEmail(emailContent).then(res => {})
                })
              })
            })
          } else {
            const data = {
              order_id: this.$route.query.id,
              status: 3
            }
            getStatusChange(data).then(() => { // 修改工单状态
              this.ruleForm = {
                order_id: '',
                engineer_code: '',
                engineer_name: '',
                solution: '',
                order_fault_id: '',
                order_group_id: '',
                is_show: '',
                id: '',
                file: [],
                files: ''
              }
              this.fileList = []
              this.$message.success('添加方案成功！')
              this.$emit('changeDialog', true)
            })
          }
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  .wrapper {
    padding: 20px;
    & /deep/ .el-form-item__label {
      text-align: left;
    }
    & /deep/ .el-textarea {
      width: 98%;
      & /deep/ .el-textarea__inner {
        min-height: 200px!important;
      }
    }
    & /deep/ .el-input__count {
      line-height: normal;
    }
    & /deep/ .upload-demo {
      display: inline-block;
    }
    h2 {
      font-size: 18px;
      color: #303133;
      font-weight: 500;
    }
    .btn-wapper {
      display: flex;
      justify-content: center;
      padding: 20px 0;
      .btn {
        min-width: 150px;
        height: 40px;
        font-size: 14px;
        font-weight: 600;
        color: #3E8DDD;
        background: #ecf4fc;
        border-color: #b2d1f1;
      }
      .btn1 {
        background: #fff;
      }
    }
  }
</style>
