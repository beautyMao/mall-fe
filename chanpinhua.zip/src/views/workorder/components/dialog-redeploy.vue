<template>
  <el-dialog :visible.sync="dialog" :title="tit" width="590px" custom-class="el-dialog-aside" class="wrapper">
    <div>
      <h2>人员列表</h2>
      <el-table :data="list">
        <el-table-column property="engineerCode" label="人员ID" />
        <el-table-column property="engineerName" label="姓名" />
        <el-table-column property="groupName" label="所属处理人组织" />
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" size="small" @click="selectEngineer(scope.row)">选择</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </el-dialog>
</template>

<script>
  import { getStatusChange, getRedeployEngineer, postHTMLEmail, getAddScheme } from '@/api/workorder'
  import { getAccountSearch } from '@/api/account-info'
  export default {
    name: 'dialog-redeploy',
    props: {
      dialogRedeploy: {
        type: Boolean,
        default: false
      },
      row: {
        type: Object,
        default: function() {
          return {}
        }
      },
      list: {
        type: Array,
        default: function() {
          return []
        }
      }
    },
    data() {
      return {
        dialog: false,
        tit: ''
      }
    },
    watch: {
      dialogRedeploy() {
        this.dialog = this.dialogRedeploy
      },
      dialog() {
        this.tit = `当前正在转派：工单 ${this.row.order_id}`
        if (!this.dialog) {
          this.$emit('changeDialog')
        }
      }
    },
    methods: {
      selectEngineer(row) {
        this.$confirm('此操作将转派单据, 是否继续?', '提示', {
          confirmButtonText: '确定',
          cancelButtonText: '取消',
          type: 'warning',
          center: true
        }).then(() => {
          const ruleForm = {
            order_id: this.row.order_id,
            engineer_code: this.$store.getters.allInfo.code,
            engineer_name: this.$store.getters.allInfo.name,
            solution: '转派',
            order_fault_id: this.row.fault_label_id,
            order_group_id: this.row.order_group_Id,
            is_show: 2,
            id: '',
            file: [],
            files: ''
          }
          if (this.row.is_show === 1) {
            ruleForm.id = this.row.handle_id
          } else {
            delete ruleForm.id
          }
          getAddScheme(ruleForm).then(() => {
            const data = {
              order_id: this.row.order_id,
              order_fault_id: this.row.fault_label_id,
              engineer_code: row.engineerCode,
              engineer_name: row.engineerName
            }
            getRedeployEngineer(data).then(res => {
              const data = {
                order_id: this.row.order_id,
                status: 3
              }
              getStatusChange(data).then()
              const val = {
                input: row.engineerCode,
                is_page: true,
                page: 1,
                per_page: 1,
                total: 1
              }
              getAccountSearch(val).then(res => {
                const emailContent = {
                  subject: '工单转派',
                  toUserEmail: res.data.data[0].email,
                  content: `<div>
                        <span>亲爱的【工程师${row.engineerCode}/${row.engineerName}】，</span>
                        <p style="margin-left: 30px">您好！工单【<a href="https://imccdev.lenovo.com.cn/#/work-order/workorder/particulars?id=${this.row.order_id}">${this.row.order_id}</a>】已由工程师【${this.row.handle_code}/${this.row.handle_name}】转派给您，请尽快处理。谢谢！</p>
                        <span>本邮件为系统自动产生，请勿回复！</span>
                      </div>`
                }
                postHTMLEmail(emailContent).then(res => {})
              })
              this.$emit('changeDialog', true)
            })
          })
          this.$message({
            type: 'success',
            message: '转派成功!'
          })
        }).catch(() => {
          this.$message({
            type: 'info',
            message: '已取消转派'
          })
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  .wrapper {
    padding: 20px;
    & /deep/ .el-dialog {
      left: auto;
    }
    & /deep/ .el-form-item {
      margin-bottom: 10px!important;
      .el-input__inner {
        width: 260px;
      }
    }
    h2 {
      font-size: 18px;
      color: #303133;
      font-weight: 500;
    }
    .btn-wapper {
      float: right;
      .btn {
        min-width: 150px;
        height: 40px;
        font-size: 14px;
        font-weight: 600;
        color: #3E8DDD;
        background: #ecf4fc;
        border-color: #b2d1f1;
      }
      .btn1 {
        background: #fff;
      }
    }
  }
</style>
