<template>
  <el-card class="add-problem">
    <div slot="header" class="clearfix">
      <span class="add-title">新增类别信息</span>
    </div>
    <el-form ref="form" :model="form">
      <el-form-item label="上级节点" required>
        <el-cascader
          v-model="form.parent_id"
          :props="{ checkStrictly: true, value: 'id', label: 'fault_label_name' }"
          placeholder="请选择父级节点 "
          :options="problemData"
          @focus="getData"
          @change="handleNameChange"
        />
      </el-form-item>
      <el-form-item label="节点名称" required class="list">
        <el-input
          v-model.trim="form.fault_label_name"
          auto-complete="off"
          placeholder="请输入节点名称，不超过20字"
          maxlength="20"
          :class="{'duplicate-info': isDuplicate}"
          @input="handleNameChange"
        />
        <span v-if="isDuplicate" class="err-message">已有该标签，请勿重复创建</span>
      </el-form-item>
    </el-form>
    <ul class="btn-list">
      <li><el-button class="reset" @click="resetData">重置</el-button></li>
      <li><el-button class="submit" :class="{ 'submit-enable': isSubmit }" :disabled="!isSubmit" @click="submitData">提交</el-button></li>
    </ul>
  </el-card>
</template>

<script>
  import { postItemCreate } from '@/api/workorder'
  export default {
    name: 'add-problem',
    props: {
      selectData: {
        type: Array
      }
    },
    data() {
      return {
        form: {
          fault_label_name: '',
          parent_id: []
        },
        problemData: [{
          id: null,
          label: '问题分类一级',
          fault_label_name: '问题分类一级',
          children: []
        }],
        isSubmit: false,
        isDuplicate: false,
        duplicateText: ''
      }
    },
    mounted() {
    },
    methods: {
      formatData(data) {
        return data.map(item => {
          // item.label = item.fault_label_name
          if (item.depth === 2) {
            item.disabled = true
            this.$set(item, 'disabled', true) // 同步刷新
          }
          if (item.children && item.children.length) {
            item.children = this.formatData(item.children)
          } else {
            delete item.children
          }
          return item
        })
      },
      getData() {
        this.problemData[0].children = this.selectData
        this.formatData(this.problemData)
      },
      resetData() {
        this.form = {
          fault_label_name: '',
          parent_id: []
        }
        this.isSubmit = false
        this.isDuplicate = false
      },
      handleNameChange() {
        this.isDuplicate = false
        if (this.form.fault_label_name && this.form.parent_id.length) {
          this.isSubmit = true
        } else {
          this.isSubmit = false
        }
      },
      submitData() {
        if (!/^[a-zA-Z0-9\u4E00-\u9FA5]{1,20}$/.test(this.form.fault_label_name)) {
          this.$message.warning('节点名称只能输入字母数字汉字')
          return
        }
        if (this.form.parent_id && this.form.parent_id.length) {
          // 以下为二级节点，父ID为null
          if (this.form.parent_id.length === 1 && this.form.parent_id[0] === null) {
            const parm = {
              parent_id: 0,
              fault_label_name: this.form.fault_label_name
            }
            postItemCreate(parm).then(res => {
              if (res.statusCode === 200) {
                this.$message({
                  type: 'success',
                  message: '创建成功!'
                })
                this.resetData()
                this.$emit('addProblem', res.data)
                this.isDuplicate = false
              }
            }).catch(err => {
              console.log(err)
              if (err === '已有该标签，请勿重复创建') {
                this.isDuplicate = true
              } else {
                this.$message({
                  message: err,
                  type: 'warning'
                })
              }
            })
          } else {
            const index = this.form.parent_id.length - 1
            const parm = {
              parent_id: this.form.parent_id[index],
              fault_label_name: this.form.fault_label_name
            }
            postItemCreate(parm).then(res => {
              if (res.statusCode === 200) {
                this.$message({
                  type: 'success',
                  message: '添加成功!'
                })
                this.resetData()
                this.$emit('addProblem', res.data)
                this.isDuplicate = false
              }
            }).catch(err => {
              console.log(err)
              if (err === '已有该标签，请勿重复创建') {
                this.isDuplicate = true
              } else {
                this.$message({
                  message: err,
                  type: 'warning'
                })
              }
            })
          }
        }
      }
    }
  }
</script>

<style scoped lang="scss">
  .add-problem {
    width: 33%;
    .add-title {
      font-weight: bolder;
    }
    /deep/.el-card__header {
      border: none !important;
      font-size: 20px;
      padding: 20px 20px 30px 30px;
    }
    /deep/.el-card__body {
      padding: 0 30px 30px !important;
      /deep/ .el-form {
        /deep/ .el-form-item {
          /deep/ .el-form-item__label {
            height: 40px !important;
            line-height: 40px;
          }
        }
      }
    }
    /deep/ .el-form-item__content {
      display: flex;
      flex-wrap: nowrap;
      justify-content: flex-start;
      /deep/ .el-cascader {
        height: 40px;
        width: 100%;
      }
      /deep/ .el-cascader__label {
        height: 40px;
      }
      /deep/ .el-input {
        height: 40px;
      }
      /deep/ .el-input__inner {
        height: 40px;
      }
      /deep/ .el-cascader--mini {
        line-height: 40px;
      }
    }
    .list {
      position: relative;
      .err-message {
        position: absolute;
        top: 40px;
        left: 16px;
        font-size: 14px;
        color: #F37261;
      }
    }
    .duplicate-info {
      border-color: #F37261 !important;
      /deep/ .el-input__inner {
        border: 1px solid #F37261 !important;
      }
    }

    ul {
      color: #303133;
      li {
        display: flex;
        flex-wrap: nowrap;
        justify-content: flex-start;
        align-items: center;
        width: 100%;
        margin-top: 20px !important;
        .title {
          display: block;
          font-size: 14px;
          line-height: 14px;
          width: 80px !important;
        }
        span {
          font-size: 14px !important;
          font-weight: 500 !important;
          line-height: 14px;
        }
      }
      .err-message {
        font-size: 14px;
        color: #F37261;
        text-align: center;
        margin-bottom: 0;
      }
    }
    .problem {

    }
    .duplicate-info {
      border-color: #F37261 !important;
      /deep/ .el-input__inner {
        border: 1px solid #F37261 !important;
      }
    }
    .btn-list {
      margin: 0 auto;
      display: flex !important;
      width: 220px;
      justify-content: space-between !important;
      padding-left: 20px;
      li {
        margin: 0;
        .reset {
          width: 90px;
          height: 36px;
          border-radius: 4px;
          border: 1px solid #c0c4cc;
          color: #909399;
        }
        .submit {
          width: 90px;
          height: 36px;
          border-radius: 4px;
          background-color: #BDC6DF;
          color: #FFFFFF;
        }
        .submit-enable {
          background-color: #3E8DDD;
        }
      }
    }
  }
</style>
