<template>
  <el-dialog :visible.sync="dialog" title="新增人员" custom-class="el-dialog-aside" class="wrapper">
    <div>
      <h2>客户查询</h2>
      <header>
        <el-form ref="ruleForm" :model="ruleForm" :inline="true" class="ruleForm">
          <el-form-item prop="">
            <el-input v-model="ruleForm.code" clearable placeholder="人员ID" />
          </el-form-item>
          <el-form-item prop="">
            <el-input v-model="ruleForm.name" clearable placeholder="人员姓名" />
          </el-form-item>
          <div class="btn-wapper">
            <el-button plain type="primary" @click="query">查 询</el-button>
            <el-button class="btn" @click="reset">重 置</el-button>
          </div>
        </el-form>
      </header>
    </div>
    <div>
      <h2>查询结果</h2>
      <el-table :data="dataList">
        <el-table-column property="code" label="人员ID" />
        <el-table-column property="name" label="人员姓名" />
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" size="small" @click="selectCustomer(scope.row)">选择</el-button>
          </template>
        </el-table-column>
      </el-table>
    </div>
  </el-dialog>
</template>

<script>
  import { getConductor } from '@/api/workorder'
  export default {
    name: 'dialog-create-customer',
    props: {
      dialogCreateCustomer: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        ruleForm: {
          name: '',
          code: ''
        },
        dataList: [],
        dialog: false
      }
    },
    watch: {
      dialogCreateCustomer() {
        this.dialog = this.dialogCreateCustomer
      },
      dialog() {
        if (!this.dialog) {
          this.$emit('changeDialog')
        }
      }
    },
    methods: {
      query() {
        if (!this.ruleForm.name && !this.ruleForm.code) {
          this.$message.warning('请输入至少一个查询条件')
          return
        }
        getConductor(this.ruleForm).then(res => {
          this.dataList = res.data
          if (!res.data.length) {
            this.$message.warning('无查询结果')
          }
        })
      },
      reset() {
        this.ruleForm.name = ''
        this.ruleForm.code = ''
      },
      selectCustomer(data) {
        this.$emit('selectCustomer', data.code)
        this.ruleForm.name = ''
        this.ruleForm.code = ''
        this.dataList = []
      }
    }
  }
</script>

<style scoped lang="scss">
  .wrapper {
    padding: 20px;
    .ruleForm div:nth-child(1) {
      float: left;
    }
    .ruleForm div:nth-child(2) {
      float: right;
    }
    & /deep/ .el-form-item {
      margin-right: 0;
      margin-bottom: 22px!important;
      .el-input__inner {
        width: 240px;
      }
    }
    h2 {
      font-size: 18px;
      color: #303133;
      font-weight: 500;
    }
    .btn-wapper {
      float: right;
      .btn {
        border-color: #3E8DDD;
        color: #3E8DDD;
      }
    }
  }
</style>
