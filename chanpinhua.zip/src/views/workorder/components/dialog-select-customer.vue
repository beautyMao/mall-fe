<template>
  <el-dialog :visible.sync="dialog" title="选择客户" width="850px" custom-class="el-dialog-aside" class="wrapper">
    <div>
      <h2>客户查询</h2>
      <header>
        <el-form ref="ruleForm" :model="ruleForm" :inline="true">
          <el-form-item prop="" @keyup.enter.native="query">
            <el-input v-model="ruleForm.name" clearable placeholder="客户姓名" />
          </el-form-item>
          <el-form-item prop="" @keyup.enter.native="query">
            <el-input v-model="ruleForm.phone" clearable placeholder="手机号" />
          </el-form-item>
          <el-form-item prop="" @keyup.enter.native="query">
            <el-input v-model="ruleForm.email" clearable placeholder="邮箱" />
          </el-form-item>
          <div class="btn-wapper">
            <el-button plain type="primary" @click="register">注册用户</el-button>
            <el-button plain type="primary" @click="query">查 询</el-button>
            <el-button class="btn" @click="reset">重 置</el-button>
          </div>
        </el-form>
      </header>
    </div>
    <div>
      <h2>查询结果</h2>
      <el-table :data="dataList">
        <el-table-column property="customer_id" label="人员ID" />
        <el-table-column property="name" label="客户姓名" />
        <el-table-column property="liaisons.phone" label="手机号码">
          <template slot-scope="scope">
            <div v-if="scope.row.phone.length" title="手机号码:">
              <div v-for="item in scope.row.phone" :key="item" class="popoverHeight">{{ item }}</div>
            </div>
          </template>
        </el-table-column>
        <el-table-column property="liaisons.email" label="邮箱">
          <template slot-scope="scope">
            <div v-if="scope.row.email.length" title="邮箱:">
              <div v-for="item in scope.row.email" :key="item" class="popoverHeight">{{ item }}</div>
            </div>
          </template>
        </el-table-column>
        <el-table-column label="操作">
          <template slot-scope="scope">
            <el-button type="text" size="small" @click="selectCustomer(scope.row)">选择</el-button>
          </template>
        </el-table-column>
      </el-table>
      <el-pagination
        background
        :page-sizes="[10, 20, 30]"
        :current-page="ruleForm.page"
        :page-size="ruleForm.perPage"
        layout="total, sizes, prev, pager, next, jumper"
        :total="TotalNumber"
        @size-change="handleSizeChange"
        @current-change="handleCurrentChange"
      />
    </div>
  </el-dialog>
</template>

<script>
  import { getSelectCustomer } from '@/api/workorder'
  import { RegexUtil } from '@/utils/validate'

  export default {
    name: 'dialog-select-customer',
    props: {
      dialogSelectCustomer: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        ruleForm: {
          customer_id: '',
          name: '',
          phone: '',
          email: '',
          page: 1,
          perPage: 10
        },
        dataList: [],
        TotalNumber: 0,
        dialog: false
      }
    },
    watch: {
      dialogSelectCustomer() {
        this.dialog = this.dialogSelectCustomer
      },
      dialog() {
        if (!this.dialog) {
          this.$emit('changeDialog')
        }
      }
    },
    methods: {
      query() {
        if (this.ruleForm.phone.length && !RegexUtil.telephone.test(this.ruleForm.phone)) {
          this.$message.warning('请输入正确的电话号码')
          return
        }
        if (this.ruleForm.email.length && !RegexUtil.email.test(this.ruleForm.email)) {
          this.$message.warning('请输入正确的邮箱')
          return
        }
        if (!this.ruleForm.customer_id && !this.ruleForm.name && !this.ruleForm.phone && !this.ruleForm.email) {
          this.$message.warning('请输入至少一个查询条件')
          return
        }
        getSelectCustomer(this.ruleForm).then(res => {
          this.dataList = res.data.data
          this.TotalNumber = res.data.total
          if (!res.data.data.length) {
            this.$message.warning('查询成功无数据返回')
          }
        })
      },
      handleSizeChange(val) {
        this.ruleForm.perPage = val
        this.ruleForm.page = 1
        getSelectCustomer(this.ruleForm).then(res => {
          this.dataList = res.data.data
          this.TotalNumber = res.data.total
          if (!res.data.data.length) {
            this.$message.warning('查询成功无数据返回')
          }
        })
      },
      handleCurrentChange(val) {
        this.ruleForm.page = val
        getSelectCustomer(this.ruleForm).then(res => {
          this.dataList = res.data.data
          this.TotalNumber = res.data.total
          if (!res.data.data.length) {
            this.$message.warning('查询成功无数据返回')
          }
        })
      },
      reset() {
        this.ruleForm.customer_id = ''
        this.ruleForm.name = ''
        this.ruleForm.phone = ''
        this.ruleForm.email = ''
      },
      register() {
        this.$emit('register')
      },
      selectCustomer(row) {
        this.$emit('changeDialog', row)
        this.ruleForm.customer_id = ''
        this.ruleForm.name = ''
        this.ruleForm.phone = ''
        this.ruleForm.email = ''
        this.dataList = []
      }
    }
  }
</script>

<style scoped lang="scss">
  .wrapper {
    padding: 20px;
    & /deep/ .el-dialog {
      left: auto;
    }
    & /deep/ .el-form-item {
      margin-bottom: 10px!important;
      .el-input__inner {
        width: 250px;
      }
    }
    & /deep/ .el-pagination {
      float: right;
      margin-top: 10px;
    }
    h2 {
      font-size: 18px;
      color: #303133;
      font-weight: 500;
    }
    .btn-wapper {
      float: right;
      margin-top: 20px;
      padding-right: 28px;
      .btn {
        border-color: #3E8DDD;
        color: #3E8DDD;
      }
    }
  }
</style>
