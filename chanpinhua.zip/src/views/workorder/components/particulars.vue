<template>
  <div class="app-container">
    <header>
      <h1>工单详情 <span class="title"> - 工单 {{ this.$route.query.id }}</span></h1>
    </header>
    <el-card>
      <header class="list">
        <h2>客户信息</h2>
        <div v-for="(item, value) of listData.client" :key="value" class="list-item">
          <span class="key">{{ value }}</span>
          <span class="value">{{ item }}</span>
        </div>
      </header>
      <header v-if="malfunction" class="list">
        <h2>故障信息</h2>
        <div class="list-item">
          <span class="key">服务记录ID：</span>
          <span class="value">{{ malfunction.case_id }}</span>
        </div>
        <div class="list-item" style="width: 47%;">
          <div style="display: flex;">
            <span class="key">故障类型：</span>
            <span style="flex: 1">{{ malfunction.fault_label_name }}</span>
          </div>
        </div>
        <div class="list-item item1">
          <div style="display: flex;">
            <span class="key">故障描述：</span>
            <div style="display: flex; flex: 1; flex-direction: column;">
              <span v-for="item in malfunction.order_fault_describe" class="value" style="display: flex; margin-bottom: 10px">
                <span style="width: 100px">{{ item.engineer_name }}</span>
                <span style="flex: 1;">{{ item.content }}</span>
                <span style="width: 150px; text-align: right">{{ item.created_at }}</span>
              </span>
            </div>
          </div>
        </div>
        <div class="list-item item1">
          <div style="display: flex">
            <span class="key">建议解决方案：</span>
            <span style="flex: 1">{{ malfunction.order_solution }}</span>
          </div>
        </div>
        <div class="list-item item1">
          <div style="display: flex">
            <span class="key">附件：</span>
            <span v-if="dispose.length && dispose[0].order_file.length" class="value" style="flex: 1;">
              <span>{{ dispose[0].order_file[0].file_name }}</span>
              <a v-if="checkImg(dispose[0].order_file[0].file_url)" style="margin-left: 15px; color: #3E8DDD" @click="previewImg(dispose[0].order_file[0].file_url)">预览</a>
              <a style="margin-left: 15px; color: #3E8DDD" :href="handleDownload(dispose[0].order_file[0].file_url)">下载</a>
            </span>
          </div>
        </div>

      </header>
      <header class="list">
        <h2>工单信息</h2>
        <div v-for="(item, value) of listData.workorder" :key="value" class="list-item" :class="{ item1 : value === '备注：' } ">
          <div v-if="value === '联系人姓名：'" style="display: flex;">
            <span class="key">{{ value }}</span>
            <span style="flex: 1;">{{ item }}</span>
          </div>
          <div v-else-if="value === '备注：'">
            <div style="display: flex;">
              <span class="key">{{ value }}</span>
              <span style="flex: 1">{{ item }}</span>
            </div>
          </div>
          <div v-else>
            <span class="key">{{ value }}</span>
            <span class="value">{{ item }}</span>
          </div>
        </div>
      </header>
      <header class="list key1">
        <h2>处理记录</h2>
        <div v-for="(item, value) of dispose" v-if="item.is_show !== 0" :key="value" class="list-item" style="width: 100%;">
          <div v-if="item.order_group_id === 0" style="display: flex;">
            <div style="display: flex; width: 200px">
              <span class="key">创建人：</span>
              <span>{{ item.engineer_name }}</span>
            </div>
            <div style="display: flex;">
              <span class="key">创建时间：</span>
              <span>{{ item.updated_at }}</span>
            </div>
          </div>
          <div v-else style="display: flex;">
            <div v-if="item.order_group_id !== 4" style="display: flex; width: 200px">
              <span class="key">L{{ item.order_group_id }}处理人：</span>
              <span>{{ item.engineer_name }}</span>
            </div>
            <div v-else style="display: flex; width: 200px">
              <span class="key">重新打开提交人：</span>
              <span>{{ item.engineer_name }}</span>
            </div>
            <div v-if="item.order_group_id !== 4" style="display: flex;">
              <span class="key">L{{ item.order_group_id }}处理记录：</span>
              <span style="width: 250px">
                <span v-if="item.solution && item.solution.length < 16">{{ item.solution }}</span>
                <el-popover v-if="item.solution && item.solution.length > 16" width="500" placement="bottom" title="处理记录:" trigger="hover" popper-class="accountPopover">
                  <div class="popoverHeight">{{ item.solution }}</div>
                  <span slot="reference" type="text">{{ item.solution.substring( 0, 16) }}...</span>
                </el-popover>
              </span>
            </div>
            <div v-else style="display: flex;">
              <span class="key">重新打开原因：</span>
              <span style="width: 250px">
                <span v-if="item.solution && item.solution.length < 16">{{ item.solution }}</span>
                <el-popover v-if="item.solution && item.solution.length > 16" width="500" placement="bottom" title="重新打开原因:" trigger="hover" popper-class="accountPopover">
                  <div class="popoverHeight">{{ item.solution }}</div>
                  <span slot="reference" type="text">{{ item.solution.substring( 0, 16) }}...</span>
                </el-popover>
              </span>
            </div>
            <div style="display: flex;">
              <span class="key">创建时间：</span>
              <span>{{ item.updated_at }}</span>
            </div>
            <div v-if="item.solution !== '提交完成'" style="display: flex;">
              <span class="key" style="width: 60px">附件：</span>
              <span v-if="item.order_file && item.order_file.length" class="value">
                <span v-if="item.order_file[0].file_name.length < 5">{{ item.order_file[0].file_name }}</span>
                <el-popover v-if="item.order_file[0].file_name.length > 5" width="300" placement="bottom" title="附件:" trigger="hover" popper-class="accountPopover">
                  <div class="popoverHeight">{{ item.order_file[0].file_name }}</div>
                  <span slot="reference" type="text">{{ item.order_file[0].file_name.substring( 0, 5) }}...</span>
                </el-popover>
                <a v-if="checkImg(item.order_file[0].file_url)" style="margin-left: 15px; color: #3E8DDD" @click="previewImg(item.order_file[0].file_url)">预览</a>
                <a style="margin-left: 15px; color: #3E8DDD" :href="handleDownload(item.order_file[0].file_url)">下载</a>
              </span>
            </div>
          </div>
        </div>
        <header class="center border-top">
          <el-button v-if="status !== 4" type="primary" plain @click="addFault">追加信息</el-button>
          <el-button v-if="row.handle_code === this.$store.getters.allInfo.code && isAddScheme" type="primary" plain @click="addScheme">添加方案</el-button>
          <el-button v-if="status === 4" type="primary" plain @click="addScheme(4)">重新打开</el-button>
        </header>
      </header>
    </el-card>
    <image-viewer ref="imageView" :srcs="imageSrc" />
    <dialogAddFault :is-fault="isFault" :row="row" :title="title" @changeDialog1="changeDialog1" />
    <dialogAddScheme :dialog-add-scheme="dialogAddScheme" :row="row" :title="title" :replace-data="replaceData" @changeDialog="changeDialog" />
  </div>
</template>

<script>
  import { getWorkorderParticulars } from '@/api/workorder'
  import ImageViewer from '@/components/ImageViewer'
  import dialogAddFault from './dialog-add-fault'
  import dialogAddScheme from './dialog-add-scheme'
  export default {
    name: 'workorder-particulars',
    components: { ImageViewer, dialogAddFault, dialogAddScheme },
    data() {
      return {
        listData: {},
        row: {},
        malfunction: null,
        dispose: '',
        imageSrc: [],
        status: '',
        title: '',
        isFault: false,
        isAddScheme: true,
        dialogAddScheme: false,
        replaceData: ''
      }
    },
    watch: {
      status() {
        this._btnAuth()
      }
    },
    mounted() {
      this.init()
    },
    methods: {
      init() {
        getWorkorderParticulars(this.$route.query.id).then(res => {
          this.malfunction = {
            case_id: res.data.case_id,
            fault_label_name: res.data.fault_label_name,
            order_fault_describe: res.data.order_fault.order_fault_describe ? res.data.order_fault.order_fault_describe : '',
            order_solution: res.data.order_solution.length ? res.data.order_solution[0].solution : '',
            order_file: res.data.order_solution.length ? res.data.order_solution[0].order_file : ''
          }
          this.row = res.data
          this.dispose = res.data.order_solution
          this.replaceData = this.dispose[this.dispose.length - 1].is_show === 1 ? `${this.dispose[this.dispose.length - 1].id}` : ''
          this.status = res.data.status
          this.handle_code = res.data.handle_code
          this.listData = {
            client: {
              '客户ID：': res.data.customer_id,
              '客户姓名：': res.data.customer_name,
              '手机号码：': res.data.customer_phone,
              '邮箱：': res.data.customer_email
            },
            workorder: {
              '工单状态：': res.data.status === 1 ? '待派单' : res.data.status === 2 ? '待处理' : res.data.status === 3 ? '处理中' : '已完成',
              '优先级：': res.data.urgencyLevel === 1 ? '高' : res.data.urgencyLevel === 2 ? '中' : '低',
              '期望回复时间：': res.data.clientDate ? res.data.clientDate.substring(0, 10) : '',
              '联系人姓名：': res.data.contact_name,
              '联系人电话：': res.data.contact_phone,
              '备注：': res.data.remarks
            }
          }
          this._btnAuth()
        })
      },
      _btnAuth() {
        if (this.status === 2 || this.status === 3) {
          this.isAddScheme = true
        } else {
          this.isAddScheme = false
        }
      },
      checkImg(img_url) {
        if (img_url) {
          const suffix = img_url.substring(img_url.lastIndexOf('.'))
          if (suffix !== '.png' && suffix !== '.jpg' && suffix !== '.jpeg') {
            return false
          } else {
            return true
          }
        }
      },
      handleDownload(url) {
        if (this.checkImg(url)) {
          return `/api/csc/resource/download?link=${url}`
        } else {
          return url
        }
      },
      previewImg(url) {
        this.imageSrc = [url]
        this.$nextTick(() => {
          this.$refs.imageView.showViewer(0)
        })
      },
      addScheme(val) { // 添加方案
        this.title = '添加方案'
        if (val === 4) {
          this.title = '重新打开'
        }
        this.dialogAddScheme = true
      },
      changeDialog(val) {
        this.dialogAddScheme = false
        if (val) {
          this.replaceData = ''
          this.init()
        }
      },
      addFault() {
        this.title = '追加信息'
        this.isFault = true
      },
      changeDialog1(val) {
        this.isFault = false
        if (val) this.init()
      },
      handlePreview() {},
      handleRemove() {}
    }
  }
</script>

<style scoped lang="scss">
  .title {
    font-weight: normal;
    font-size: 16px;
  }
  .list-item {
    display: inline-block;
    width: 33%;
    min-height: 30px;
    line-height: 30px;
    margin-bottom: 10px;
    word-wrap: break-word;
    word-break: break-all;
    font-size: 14px;
    color: #606266;
    .key {
      display: inline-block;
      width: 120px;
      text-align: right;
    }
  }
  .item1 {
    width: 80%;
  }
  .key1 {
    .key {
      width: 126px;
    }
    }
  .center {
    text-align: center;
    padding-top: 20px;
  }
</style>
