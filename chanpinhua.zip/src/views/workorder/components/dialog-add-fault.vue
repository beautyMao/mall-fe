<template>
  <el-dialog :visible.sync="dialog" :title="tit" custom-class="el-dialog-aside" class="wrapper">
    <el-form ref="ruleForm" :model="ruleForm" label-width="100px" size="medium" class="ruleForm">
      <el-form-item label="追加信息" prop="content">
        <el-input
          v-model="ruleForm.content"
          type="textarea"
          placeholder="在此填写故障描述的内容"
          maxlength="500"
          show-word-limit
        />
      </el-form-item>
    </el-form>
    <div slot="footer" class="btn-wapper">
      <el-button plain type="primary" class="btn" @click="addFault">确 认</el-button>
      <el-button class="btn btn1" @click="dialog=false">取 消</el-button>
    </div>
  </el-dialog>
</template>

<script>
  import { getAddFault } from '@/api/workorder'
  export default {
    name: 'dialog-add-fault',
    props: {
      title: {
        type: String,
        default: '添加方案'
      },
      isFault: {
        type: Boolean,
        default: false
      },
      row: {
        type: Object,
        default: function() {
          return {}
        }
      }
    },
    data() {
      return {
        ruleForm: {
          engineer_code: '',
          engineer_name: '',
          content: '',
          order_fault_id: ''
        },
        dialog: false,
        tit: ''
      }
    },
    watch: {
      isFault() {
        this.dialog = this.isFault
      },
      dialog() {
        this.tit = `当前正在${this.title}：工单 ${this.row.order_id}`
        if (!this.dialog) {
          this.ruleForm = {
            engineer_code: '',
            engineer_name: '',
            content: '',
            order_fault_id: ''
          }
          this.$emit('changeDialog1')
        }
      }
    },
    methods: {
      close() {
        this.ruleForm = {
          engineer_code: '',
          engineer_name: '',
          content: '',
          order_fault_id: ''
        }
        this.$emit('changeDialog1')
      },
      addFault() {
        this.ruleForm.engineer_code = this.$store.getters.allInfo.code
        this.ruleForm.engineer_name = this.$store.getters.allInfo.name
        this.ruleForm.order_fault_id = this.row.order_fault.id
        if (!this.ruleForm.content) {
          this.$message.warning('请填写故障描述')
          return
        }
        getAddFault(this.ruleForm).then(res => {
          this.ruleForm = {
            engineer_code: '',
            engineer_name: '',
            content: '',
            order_fault_id: ''
          }
          this.$message.success('添加信息成功')
          this.$emit('changeDialog1', true)
        })
      }
    }
  }
</script>

<style scoped lang="scss">
  .wrapper {
    padding: 20px;
    & /deep/ .el-form-item__label {
      text-align: left;
    }
    & /deep/ .el-textarea {
      width: 98%;
      & /deep/ .el-textarea__inner {
        min-height: 200px!important;
      }
    }
    & /deep/ .el-input__count {
      line-height: normal;
    }
    & /deep/ .upload-demo {
      display: inline-block;
    }
    h2 {
      font-size: 18px;
      color: #303133;
      font-weight: 500;
    }
    .btn-wapper {
      display: flex;
      justify-content: center;
      padding: 20px 0;
      .btn {
        min-width: 150px;
        height: 40px;
        font-size: 14px;
        font-weight: 600;
        color: #3E8DDD;
        background: #ecf4fc;
        border-color: #b2d1f1;
      }
      .btn1 {
        background: #fff;
      }
    }
  }
</style>
