import Vue from 'vue'

// import Raven from 'raven-js'
// import RavenVue from 'raven-js/plugins/vue'
import get from 'lodash.get'
import { captureException } from '@/utils/error-report'
import InterceptMessage from '@/utils/message-intercept'
// import 'normalize.css/normalize.css' // A modern alternative to CSS resets
// import 'element-ui/lib/theme-chalk/index.css'
import ElementUI from 'element-ui'
import '../theme/index.css'
import '@/styles/index.scss' // global css

import App from './App'
import router from './router'
import store from './store'
// import './errorLog'// error log
import '@/icons' // icon
import '@/permission' // permission control
import '@/copyright' // copyright
import * as filters from './filters' // global filters
import drag from './directive/el-drag-dialog'

// if (process.env.VUE_APP_ENV_CONFIG !== 'dev') {
//   // 只有在prod 下输出tag name，其他仅输出branch
//   // webpack plugin defined，VERSION, COMMITHASH, BRANCH
//   let release = process.env.VUE_APP_BRANCH
//   if (process.env.VUE_APP_ENV_CONFIG === 'prod') {
//     release = process.env.VUE_APP_VERSION.split('-')[0]
//   }
//
//   const whiteApiList = ['webim.tim.qq.com', 'ping']
//
//   Raven.config('https://d52f3b0bb4d6426d99e67a2a89cc5dee@sentry.lenovo.com.cn/40', {
//     release,
//     environment: process.env.VUE_APP_ENV_CONFIG,
//     breadcrumbCallback: function(data) {
//       if (data.category === 'xhr') {
//         return !whiteApiList.some(api => data.data.url.indexOf(api) > -1)
//       }
//       return data
//     },
//     autoBreadcrumbs: {
//       xhr: true,
//       dom: false,
//       location: false
//     }
//   }).addPlugin(RavenVue, Vue).install()
// }

drag.install(Vue)

// if (process.env.VUE_APP_ENV_CONFIG !== 'prod') { // 发布 不支持 mock
//   require('./mock') // simulation data
// }

Vue.use(ElementUI, {
  size: 'small' // set element-ui default size
})

Object.keys(filters).forEach(key => {
  Vue.filter(key, filters[key])
})

Vue.config.productionTip = false

// safely property get
Vue.prototype.$get = get

// error report
Vue.prototype.$report = function(error, extraData) {
  captureException('VUE_ERROR_REPORT:' + this.$vnode.componentOptions.tag, error, extraData)
}

// 拦截$message 用于记录提示日志
Vue.prototype.$message = InterceptMessage

new Vue({
  router,
  store,
  render: (h) => h(App)
}).$mount('#app')
