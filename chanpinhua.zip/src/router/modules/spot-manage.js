const spot = (Layout) => ({
  path: '/spot',
  component: Layout,
  name: 'local-management',
  meta: {
    title: '现场管理'
  },
  children: [
    {
      path: '/spot/skill-group-management',
      component: () => import('@/views/skill-group-management/skill-group-management'),
      name: 'skill-management',
      meta: {
        title: '技能组管理',
        noCache: true
      }
    },
    {
      path: '/spot/skill-group-management/engineers',
      component: () => import('@/views/skill-group-management/skill-engineers/skill-engineers'),
      name: 'skill-engineers',
      hidden: true,
      meta: {
        title: '管理客服',
        icon: 'example',
        noCache: true
      }
    },
    {
      path: 'access',
      component: () =>
          import('@/views/queue-management/access/access'),
      name: 'access-management',
      meta: {
        title: '通路管理',
        noCache: true
      }
    },
    {
      path: '/spot/problems',
      component: () => import('@/views/problems'),
      name: 'problems-management',
      meta: {
        title: '问题分类管理',
        noCache: true
      }
    }
  ]
})

export default spot
