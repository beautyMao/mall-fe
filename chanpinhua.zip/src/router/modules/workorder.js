import RouterView from '../../views/layout/RouterView' // 显示子路由

const review = (Layout) => ({
  path: '/work-order',
  name: 'work-order',
  component: Layout,
  meta: {
    title: '工单管理',
    icon: 'fieldMonitoringFieldKanban'
  },
  children: [{
    path: 'workorder-resolve',
    component: () =>
      import('@/views/workorder/workorder-resolve'),
    name: 'workorder-resolve',
    meta: {
      title: '工单处理',
      noCache: false
    }
  },
  {
    path: 'workorder',
    component: () =>
      import('@/views/workorder/workorder'),
    name: 'workorder',
    meta: {
      title: '工单查询',
      noCache: false
    }
  },
  {
    path: 'workorder/particulars',
    component: () =>
      import('@/views/workorder/components/particulars'),
    name: 'workorder-particulars',
    hidden: true,
    meta: {
      title: '工单详情',
      noCache: true
    }
  },
  {
    path: 'workorder/create',
    component: () =>
      import('@/views/workorder/components/create-workorder'),
    name: 'create-workorder',
    hidden: true,
    meta: {
      title: '新建工单',
      noCache: false
    }
  },
  {
    path: 'matching',
    name: 'matching',
    component: RouterView,
    meta: { title: '工单配置' },
    children: [
      {
        path: 'sort',
        component: () =>
          import('@/views/workorder/workorder-sort'),
        name: 'workorder-sort',
        meta: {
          title: '工单列表配置',
          noCache: true
        }
      },
      {
        path: 'dispose',
        component: () =>
          import('@/views/workorder/workorder-dispose'),
        name: 'workorder-dispose',
        meta: {
          title: '工单处理人配置',
          noCache: true
        }
      }
    ]
  }]
})

export default review
