const knowledge = (Layout) => ({
  path: '/knowledge',
  component: Layout,
  name: 'knowledge-type-list',
  redirect: '/knowledge/type-list',
  meta: {
    title: '知识库管理'
  },
  children: [
    {
      path: 'knowledgeTypeList',
      component: () => import('@/views/knowledge/knowledge-type-list'),
      name: 'knowledge-type-list',
      meta: {
        title: '知识库管理',
        noCache: true,
        icon: 'tab'
      }
    },
    {
      path: 'knowledgeArticleList',
      component: () => import('@/views/knowledge/knowledge-article-list'),
      name: 'knowledge-article-list',
      hidden: true,
      meta: {
        title: '文章列表',
        noCache: true
      }
    },
    {
      path: 'edit',
      component: () =>
         import('@/views/knowledge/edit'),
      name: 'edit',
      hidden: true,
      meta: {
        title: '知识库编辑'
      }
    },
    {
      path: 'create',
      component: () =>
        import('@/views/knowledge/create'),
      name: 'create',
      hidden: true,
      meta: {
        title: '知识库创建'
      }
    },
    {
      path: 'article-info',
      component: () =>
        import('@/views/knowledge/article-info'),
      name: 'article-info',
      hidden: true,
      meta: {
        title: '文章详情',
        noCache: true
      }
    }
  ]
})

export default knowledge
