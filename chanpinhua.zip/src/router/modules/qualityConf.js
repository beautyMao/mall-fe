const qualityConf = (Layout) => ({
  path: '/qualityConf',
  component: Layout,
  name: 'quality-conf',
  redirect: '/qualityConf/quality-rule',
  meta: {
    title: '质检',
    icon: 'tab'
  },
  children: [
    {
      path: 'qualityRule',
      component: () => import('@/views/qualityConf/quality-rule'),
      name: 'quality-rule',
      meta: {
        title: '质检规则',
        noCache: true
      }
    },
    {
      path: 'create',
      component: () =>
        import('@/views/knowledge/create'),
      name: 'create',
      meta: {
        title: '知识库创建'
      }
    },
    {
      path: 'article-info',
      component: () =>
        import('@/views/knowledge/article-info'),
      name: 'article-info',
      meta: {
        title: '文章详情',
        noCache: true
      }
    }
  ]
})

export default qualityConf
