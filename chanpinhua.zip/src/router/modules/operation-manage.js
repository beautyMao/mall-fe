import RouterView from '../../views/layout/RouterView' // 显示子路由
import queue from './queue'
import spot from './spot-manage'
// import rollCall from './roll-call'

const operation = (Layout) => ({
  path: '/queue-management',
  component: Layout,
  name: 'operate-managment',
  meta: {
    title: '运营管理',
    icon: 'operationManage'
  },
  children: [
    queue(RouterView),
    spot(RouterView)
    // rollCall(RouterView) // 黑红名单
  ]
})

export default operation
