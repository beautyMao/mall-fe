const review = (Layout) => ({
  path: '/review',
  component: Layout,
  name: 'review',
  meta: {
    title: '点评查询'
  },
  children: [{
    path: 'record',
    component: () =>
      import('@/views/review/review-record'),
    name: 'Record',
    meta: {
      title: '点评查询',
      icon: 'fieldMonitoringFieldKanban',
      noCache: false
    }
  },
  {
    path: 'record/particulars',
    component: () =>
      import('@/views/review/components/particulars'),
    name: 'RecordParticulars',
    hidden: true,
    meta: {
      title: '点评详情',
      noCache: true
    }
  }]
})

export default review
