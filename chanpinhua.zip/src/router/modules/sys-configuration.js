const sysConf = (Layout) => ({
  path: '/sysConf',
  component: Layout,
  name: 'system-config',
  redirect: '/sys-conf/enterprise',
  meta: {
    title: '系统配置',
    icon: 'IPS'
  },
  children: [
    {
      path: 'enterprise',
      component: () => import('@/views/enterprise/enterprise'),
      name: 'company-management',
      meta: {
        title: '企业信息管理',
        noCache: true
      }
    },
    {
      path: 'maintain',
      component: () => import('@/views/enterprise/notice-maintain'),
      name: 'notice-maintain',
      meta: {
        title: '公告维护',
        noCache: true
      }
    },
    {
      path: 'FAQ',
      component: () => import('@/views/enterprise/FAQ'),
      name: 'frequently-asked-question',
      meta: {
        title: '常见问题维护',
        noCache: true
      }
    },
    {
      path: 'advertising-management',
      component: () => import('@/views/enterprise/advertising-management'),
      name: 'advertising-management',
      meta: {
        title: '广告管理',
        noCache: true
      }
    },
    {
      path: 'permission',
      component: () =>
        import('@/views/queue-management/permission/permission'),
      name: 'ccp-management',
      meta: {
        title: '看板权限配置',
        noCache: true
      }
    },
    {
      path: 'dashboard-config',
      component: () =>
        import('@/views/devccp/dashboard-config'),
      name: 'dashboard-config',
      meta: {
        title: '看板数据配置',
        noCache: false
      }
    },
    {
      path: 'reviewConf',
      component: () =>
        import('@/views/global-configuration/review-conf'),
      name: 'comment-management',
      meta: {
        title: '点评配置',
        noCache: false
      }
    }
  ]
})

export default sysConf
