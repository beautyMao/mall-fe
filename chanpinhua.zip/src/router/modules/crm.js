// CRM router
export default (Layout) => ({
  name: 'crm-index',
  path: '/crm',
  component: Layout,
  redirect: '/crm/index',
  children: [{
    path: 'index',
    component: () => import('@/views/crm/crm-index'),
    name: 'crm-index',
    meta: { title: '客户中心', icon: 'callcenter', noCache: false }
  }, {
    path: 'detail',
    component: () => import('@/views/crm/crm-detail'),
    name: 'crm-detail',
    hidden: true,
    meta: { title: '客户详情', icon: 'callCenter', noCache: true }
  }]
})
