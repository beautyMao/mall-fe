const label = (Layout) => ({
  path: '/rule-management',
  component: Layout,
  redirect: '/rule-management/matching',
  name: 'rule-management-matching',
  meta: {
    title: '标签匹配规则',
    icon: 'label'
  },
  children: [
    {
      path: 'recommend',
      component: () =>
              import('@/views/rule-management/recommend/recommend'),
      name: 'recommend',
      meta: {
        title: '标签匹配规则',
        noCache: true
      }
    }
  ]
})

export default label
