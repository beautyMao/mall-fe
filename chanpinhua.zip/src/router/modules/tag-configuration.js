const tagConf = (Layout) => ({
  path: '/tagConf',
  component: Layout,
  name: 'tag-route',
  meta: {
    title: '标签和路由'
  },
  children: [{
    path: 'customer',
    component: () =>
      import('@/views/tag-configuration/customer-tag-conf/index'),
    name: 'user-tag',
    meta: {
      title: '客户标签管理',
      noCache: false
    }
  },
  {
    path: 'service',
    component: () =>
      import('@/views/tag-configuration/service-tag-conf/index'),
    name: 'engineer-tag',
    meta: {
      title: '客服标签管理',
      noCache: true
    }
  },
  {
    path: 'labelRecommend',
    component: () =>
      import('@/views/rule-management/recommend/recommend'),
    name: 'tag-rule',
    meta: {
      title: '标签匹配规则',
      noCache: true
    }
  }]
})

export default tagConf
