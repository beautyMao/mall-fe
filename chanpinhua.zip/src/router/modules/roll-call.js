const rollCall = (Layout) => ({
  path: '/roll-call',
  component: Layout,
  meta: {
    title: '名单管理',
    noCache: false
  },
  children: [
    {
      path: 'red-list',
      component: () =>
        import('@/views/roll-call-management/red-list'),
      name: 'RedList',
      meta: {
        title: '红名单管理',
        noCache: false
      }
    },
    {
      path: 'black-list',
      component: () =>
        import('@/views/roll-call-management/black-list'),
      name: 'BlackList',
      meta: {
        title: '黑名单管理',
        noCache: true
      }
    }
  ]
})

export default rollCall
