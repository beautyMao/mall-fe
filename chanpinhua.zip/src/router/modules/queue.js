const queue = (Layout) => ({
  path: '/service',
  component: Layout,
  name: 'engineer-management',
  meta: {
    title: '客服管理'
  },
  children: [
    {
      path: 'account',
      component: () =>
          import('@/views/queue-management/account/account'),
      name: 'account-management',
      meta: {
        title: '账号管理',
        noCache: true
      }
    },
    {
      path: 'role',
      component: () =>
        import('@/views/queue-management/role/role'),
      name: 'role-management',
      meta: {
        title: '角色管理',
        noCache: true
      }
    },
    {
      path: 'organizational',
      component: () => import('@/views/organizational-structure/organizational-structure'),
      name: 'bussiness-management',
      meta: {
        title: '业务管理',
        noCache: true
      }
    }
  ]
})

export default queue
