import RouterView from '../../views/layout/RouterView' // 显示子路由
import tagConf from './tag-configuration'
import chat from './chat-conf'

const globalConf = (Layout) => ({
  path: '/globalConf',
  component: Layout,
  name: 'service-config',
  meta: {
    title: '服务配置',
    icon: 'serviceConf'
  },
  children: [
    tagConf(RouterView),
    chat(RouterView)
  ]
})

export default globalConf
