const ccp = (Layout) => ({
  path: '/devccp-management',
  component: Layout,
  name: 'devccp-management',
  redirect: '/devccp-management/actioncontrol',
  meta: {
    title: '数据看板',
    icon: 'monitoringPlatform'
  },
  children: [{
    path: 'actioncontrol',
    component: () => import('@/views/devccp/index'),
    name: 'ccp-dashboard',
    meta: {
      title: 'dashboard',
      icon: 'monitoringPlatform',
      noCache: false
    }
  }, {
    path: 'customer-info/:id',
    component: () =>
        import('@/views/devccp/otherpage-management/customer-info'),
    name: 'customer-info',
    hidden: true,
    meta: {
      title: '客服数据',
      noCache: true
    }
  }, {
    path: 'service-info/:id',
    component: () =>
        import('@/views/devccp/otherpage-management/service-info'),
    name: 'service-info',
    hidden: true,
    meta: {
      title: '服务数据',
      noCache: true
    }
  }, {
    path: 'service-volume-info/:id',
    component: () =>
        import('@/views/devccp/otherpage-management/service-volume-info'),
    name: 'service-volume-info',
    hidden: true,
    meta: {
      title: '业务趋势',
      noCache: false
    }
  }, {
    path: 'mapchart-info/:id',
    component: () =>
        import('@/views/devccp/otherpage-management/mapchart-info'),
    name: 'mapchart-info',
    hidden: true,
    meta: {
      title: '地域来电',
      noCache: true
    }
  }, {
    path: 'session-info',
    component: () =>
        import('@/views/devccp/otherpage-management/session-info'),
    name: 'session-info',
    // hidden: true,
    meta: {
      icon: 'monitoringPlatform',
      title: '会话查询',
      noCache: true
    }
  }, {
    path: 'session-detail/:id',
    component: () =>
        import('@/views/devccp/otherpage-management/session-detail'),
    name: 'session-detail',
    hidden: true,
    meta: {
      title: '会话详情',
      noCache: true
    }
  },
  {
    path: 'class-info',
    component: () =>
        import('@/views/devccp/otherpage-management/class-info'),
    name: 'devccp-management-class-info',
    hidden: true,
    meta: {
      title: '问题分类',
      noCache: true
    }
  },
  {
    path: 'emotion-info',
    component: () =>
        import('@/views/devccp/otherpage-management/emotion-info'),
    name: 'devccp-management-emotion-info',
    hidden: true,
    meta: {
      title: '情感监控',
      noCache: true
    }
  }
    // {
    //   path: 'engineer-manage/:id',
    //   component: () =>
    //     import('@/views/ccp/engineer-management/engineer-manage'),
    //   name: 'engineer-manage',
    //   hidden: true,
    //   meta: {
    //     title: '工程师管理',
    //     noCache: false
    //   }
    // },
    // {
    //   path: 'actioncontrol/bigQueue/:id',
    //   component: () => import('@/views/ccp/queue-management/bigQueue'),
    //   name: 'big-queue',
    //   hidden: true,
    //   meta: {
    //     title: '队列管理',
    //     noCache: false
    //   }
    // },
    // {
    //   path: 'usercall/:id',
    //   component: () =>
    //     import('@/views/ccp/usercall-management/usercall/usercall'),
    //   name: 'line-chart',
    //   hidden: true,
    //   meta: {
    //     title: '用户来电量',
    //     noCache: true
    //   }
    // },
    // {
    //   path: 'weather/:id',
    //   component: () => import('@/views/ccp/weather/weatherMap'),
    //   name: 'weather-map',
    //   hidden: true,
    //   meta: {
    //     title: '天气监控',
    //     noCache: true
    //   }
    // },
    // {
    //   path: 'actioncontrol/machine-change-manpower/:id',
    //   component: () => import('@/views/ccp/machine-change-manpower/index'),
    //   name: 'manpower',
    //   hidden: true,
    //   meta: {
    //     title: '机器人转人工',
    //     noCache: true
    //   }
    // },
    // {
    //   path: '/actioncontrol/setThreshold',
    //   component: () =>
    //     import('@/views/ccp/machine-change-manpower/components/setThreshold'),
    //   name: 'history',
    //   hidden: true,
    //   meta: {
    //     title: '历史数据',
    //     noCache: true
    //   }
    // },
    // {
    //   path: 'usersemotion-management/:id',
    //   component: () =>
    //     import('@/views/ccp/usersemotion-management/usersemotion-management/usersemotion-management'),
    //   name: 'mainhome',
    //   hidden: true,
    //   meta: {
    //     title: '用户情感监控',
    //     noCache: true
    //   }
    // },
    // {
    //   path: 'emotionsdetails/:emotiontype/:busnessaccessid',
    //   component: () =>
    //     import('@/views/ccp/usersemotion-management/emotion-detail/emotion-detail'),
    //   hidden: true,
    //   name: 'details',
    //   meta: {
    //     title: '情感详情',
    //     noCache: false
    //   }
    // }, {
    //   path: 'searchclassify/:cate/:from/:busnessaccessid',
    //   component: () =>
    //     import('@/views/ccp/usersemotion-management/search-classify/search-classify'),
    //   name: 'searchclassify',
    //   hidden: true,
    //   meta: {
    //     title: '分类查询',
    //     noCache: false
    //   }
    // },
    // {
    //   path: 'case/:id',
    //   component: () => import('@/views/user-manage/case-class/case'),
    //   name: 'class-manage',
    //   hidden: true,
    //   meta: {
    //     title: '分类管理',
    //     noCache: true
    //   }
    // }
  ]
})
export default ccp
