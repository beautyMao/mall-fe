const demand = Layout => ({
  path: '/demand',
  component: Layout,
  name: 'data-search',
  redirect: '/case-query/case-query',
  meta: {
    title: '数据查询',
    icon: 'dataQuery'
  },
  children: [
    {
      path: 'touch',
      component: () =>
        import('@/views/touch/touch'),
      name: 'touch-query',
      meta: {
        title: '接触记录查询',
        noCache: false
      }
    },
    {
      path: 'touch/particulars',
      component: () =>
        import('@/views/touch/components/particulars'),
      name: 'touch-particulars',
      hidden: true,
      meta: {
        title: '接触记录详情',
        noCache: true
      }
    },
    {
      path: 'case-query',
      component: () =>
        import('@/views/demand/case-query/case-query'),
      name: 'case-query',
      meta: {
        title: '服务记录查询',
        noCache: false
      }
    },
    {
      path: 'case-query/particulars',
      component: () =>
        import('@/views/demand/case-query/case-query-particulars'),
      name: 'case-query-particulars',
      hidden: true,
      meta: {
        title: '服务记录详情',
        noCache: true
      }
    },
    {
      path: 'record',
      component: () =>
        import('@/views/review/review-record'),
      name: 'record-query',
      meta: {
        title: '点评数据查询',
        noCache: false
      }
    },
    {
      path: 'record/particulars',
      component: () =>
        import('@/views/review/components/particulars'),
      name: 'record-particulars',
      hidden: true,
      meta: {
        title: '点评详情',
        noCache: true
      }
    }
  ]
})
export default demand
