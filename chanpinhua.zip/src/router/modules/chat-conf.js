const chat = (Layout) => ({
  path: '/chat-conf',
  component: Layout,
  name: 'chat-config',
  redirect: '/chat-conf',
  meta: {
    title: '话术管理'
  },
  children: [{
    path: 'speech',
    component: () => import('@/views/speech/speech'),
    name: 'chat-management',
    meta: {
      title: '话术配置',
      noCache: true
    }
  }, {
    path: 'chat-timeout',
    component: () => import('@/views/chat-conf/chat-timeout'),
    name: 'timeout-chat-management',
    meta: {
      title: '超时话术配置',
      noCache: true
    }
  }, {
    path: 'chat-empty',
    component: () => import('@/views/chat-conf/chat-timeout'),
    name: 'empty-chat-management',
    meta: {
      title: '空框话术配置',
      noCache: true
    }
  },
  {
    path: 'chat-system',
    component: () => import('@/views/chat-conf/chat-system'),
    name: 'system-chat-management',
    meta: {
      title: '系统话术配置',
      noCache: true
    }
  }]
})

export default chat
