import Vue from 'vue'
import Router from 'vue-router'
import Layout from '../views/layout/Layout'

import ccp from './modules/ccp'
import globalConf from './modules/global-configuration'
import demand from './modules/demand'
import operation from './modules/operation-manage'
import sysConf from './modules/sys-configuration'
import workorder from './modules/workorder'
import crm from './modules/crm'
import knowledge from './modules/knowledge'
import qualityConf from './modules/qualityConf'

Vue.use(Router)

/**
 * hidden: true                   if `hidden:true` will not show in the sidebar(default is false)
 * alwaysShow: true               if set true, will always show the root menu, whatever its child routes length
 *                                if not set alwaysShow, only more than one route under the children
 *                                it will becomes nested mode, otherwise not show the root menu
 * redirect: noredirect           if `redirect:noredirect` will no redirct in the breadcrumb
 * name:'router-name'             the name is used by <keep-alive> (must set!!!)
 * meta : {
    title: 'title'               the name show in submenu and breadcrumb (recommend set)
    icon: 'svg-name'             the icon show in the sidebar,
  }
 **/
export const constantRouterMap = [{
  path: '/redirect',
  component: Layout,
  hidden: true,
  children: [{
    path: '/redirect/:path*',
    component: () => import('@/views/redirect/index')
  }]
},
{
  path: '/login',
  component: () =>
      import('@/views/login/index'),
  hidden: true
},
{
  path: '/reset',
  component: () =>
    import('@/views/reset/index'),
  hidden: true
},
{
  path: '/404',
  component: () =>
      import('@/views/errorPage/404'),
  hidden: true
},
{
  path: '/401',
  component: () =>
      import('@/views/errorPage/401'),
  hidden: true
},
{
  path: '',
  component: Layout,
  redirect: 'home-page',
  hidden: true,
  children: [{
    path: 'home-page',
    component: () => import('@/views/home-page'),
    name: 'home-page',
    meta: { title: '欢迎页面', icon: 'callcenter', noCache: false }
  }]
}]

const asyncRouterMap = [
  {
    path: '/call-center',
    component: Layout,
    name: 'work-bench',
    redirect: '/call-center/index',
    children: [{
      path: 'index',
      component: () => import('@/views/call-center/chat-index'),
      name: 'call-center',
      meta: { title: '客服工作台', icon: 'callcenter', noCache: false }
    }, {
      path: 'history',
      component: () => import('@/views/call-center/chat-history'),
      name: 'call-history',
      hidden: true,
      meta: { title: '会话详情', icon: 'callCenter', noCache: true }
    }]
  }, {
    // todo 挪到知识库route module 下去
    path: 'knowledge',
    component: () =>
      import('@/views/call-center/components/knowledge-info'),
    name: 'info',
    meta: {
      title: '知识库文章详情',
      noCache: true
    },
    hidden: true
  },
  // ccp路由 数据看板
  ccp(Layout),
  // 数据查询
  demand(Layout),
  // 队列和账号管理
  operation(Layout),
  // 全局配置
  globalConf(Layout),
  // 系统配置
  sysConf(Layout),
  workorder(Layout),
  // 企业CRM 对接系统
  crm(Layout),
  // 知识库
  knowledge(Layout),
  // 质检
  qualityConf(Layout),
  {
    path: '*',
    redirect: '/404',
    hidden: true
  }
]

if (process.env.VUE_APP_ENV_CONFIG !== 'prod') {
  exports.asyncRouterMap = asyncRouterMap.concat({
    // curd 范例页面
    path: '/develop-guide',
    component: Layout,
    name: 'develop-guide',
    meta: {
      icon: 'infor',
      title: '开发者'
    },
    children: [{
      path: 'index',
      component: () =>
        import('@/views/public/demo'),
      name: 'page-demo',
      meta: {
        title: 'Cube page demo',
        noCache: true
      }
    }, {
      path: 'public',
      component: () =>
        import('@/views/public/public-view'),
      name: 'public-view',
      meta: {
        title: 'CURD 范例页面',
        noCache: true
      }
    }, {
      path: 'docs',
      meta: {
        title: '前端开发文档',
        httpLink: () => {
          window.open('http://cube.g.lenovo.com.cn/workbench/docs/')
        }
      }
    }, {
      path: 'icon',
      component: () =>
        import('@/views/icons/index'),
      name: 'icons',
      meta: {
        title: '图标',
        noCache: true
      }
    }]
  })
} else {
  exports.asyncRouterMap = asyncRouterMap
}

const router = new Router({
  scrollBehavior: () => ({
    y: 0
  }),
  routes: constantRouterMap
})
// 偶发的Loading chunk n failed 临时处理方式
// https://segmentfault.com/a/1190000016382323#articleHeader1
router.onError((error) => {
  const pattern = /Loading chunk (\d)+ failed/g
  const isChunkLoadFailed = error.message.match(pattern)
  // const targetPath = router.history.pending.fullPath
  if (isChunkLoadFailed) {
    // 这个时候无法使用element ui confirm 可能未被加载
    const approve = confirm('检测到页面模块加载失败，将会导致部分功能无法使用，是否允许重新加载？')
    if (approve) {
      location.reload(true)
    }
  }
})

// 用于处理浏览器刷新后，结合tags view 缓存的tag route and params，避免page component 二次init
const STORAGE_KEY = 'tag-view:views'
let isFirstLoad = true
let storeViews = sessionStorage.getItem(STORAGE_KEY)
try {
  if (storeViews) {
    storeViews = JSON.parse(storeViews)
  }
} catch (e) {
  sessionStorage.removeItem(STORAGE_KEY)
  console.log('views in local storage are broken.', e)
}
router.beforeEach((to, from, next) => {
  if (!isFirstLoad || !storeViews || !storeViews.length) {
    return next()
  }

  isFirstLoad = false
  const view = storeViews.find(v => v.path === to.path)
  if (view && Object.getOwnPropertyNames(view.params).length > 0) {
    next({
      ...view,
      path: '/redirect' + view.fullPath
    })
  } else {
    next()
  }
})

export default router
