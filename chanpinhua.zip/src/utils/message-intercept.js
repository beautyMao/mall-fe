import store from '@/store'
import { Message } from 'element-ui'

const InterceptMessage = function(options) {
  options = options || {}
  if (typeof options === 'string') {
    options = {
      message: options
    }
  }
  console.log('[InterceptMessage log]', options.message)
  store.dispatch('addMessageLog', {
    type: options.type || 'info',
    message: options.message
  })

  if (!options.hide) {
    return Message(options)
  }
}

'success,warning,info,error'.split(',').forEach(type => {
  InterceptMessage[type] = options => {
    if (typeof options === 'object') {
      options = options || {}
    } else {
      options = {
        message: options
      }
    }
    options.type = type
    console.log('[InterceptMessage log]', options.message)
    store.dispatch('addMessageLog', {
      type: options.type || 'info',
      message: options.message
    })

    if (!options.hide) {
      return Message(options)
    }
  }
})

export default InterceptMessage
