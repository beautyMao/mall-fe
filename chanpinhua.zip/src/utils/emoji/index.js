import emojiData from './encode-mapping.json'
import { convertXSS } from '@/utils/conver-util'

// 原始消息体内的表情转译符号，会被convertSafeContent 处理为safe html content
// 这里需要统一将< > 符号匹配下
emojiData.forEach(emoji => {
  emoji.char = convertXSS(emoji.char)
})

/**
 * emoji 配置
 * @type {{path: string, ext: string, data: *, excludeNums: *[]}}
 */
export const emojiOptions = {
  path: '/static/emoji/',
  data: emojiData,
  ext: '.png',
  // 要排除的表情文件集合。
  excludeNums: []
  // excludeNums: ['3', '7', '8', '10', '11', '18', '19', '22', '23', '24', '25', '26', '27', '31', '33', '34', '36', '37',
  //   '38', '40', '41', '43', '45', '46', '47', '48', '53', '55', '58', '59', '62', '64', '67', '69', '70', '71', '72', '73',
  //   '74', '80', '84', '85', '86', '88']
}

export const WEIXIN_QQ_TEXT_LIST = emojiData.map(emoji => `[${emoji.cn}]`)

const RegFaceStr = /\/:[\-:()@&$#|!<>;',?*~\w]{0,11}/g
const RegFaceText = /\[.{1,3}]/g

let imageTag = `<img src="${emojiOptions.path}{name}${emojiOptions.ext}" class="emoji-icon" title="{title}">`

/**
 * 对文本内表情符号转译，同时处理特殊符号
 * @param content
 * @param defaultPath 默认是static/call-center/img/faces/{index}.png
 * @returns {string|void|XML|*}
 */
export function convertEmoji(content, defaultPath) {
  if (!content || content.length < 1) {
    return ''
  }

  if (defaultPath) {
    imageTag = `<img src="${defaultPath}">`
  }

  if (content && RegFaceStr.test(content)) {
    content = content.replace(RegFaceStr, (match) => {
      emojiData.forEach(emoji => {
        if (!emoji.char) {
          return
        }
        match = match.replace(emoji.char, (m, t) => {
          return imageTag.replace('{name}', emoji.en).replace('{title}', emoji.cn)
        })
      })
      return match
    })
  }

  if (content && RegFaceText.test(content)) {
    content = content.replace(RegFaceText, (match) => {
      emojiData.forEach(emoji => {
        match = match.replace(`[${emoji.cn}]`, (m, t) => {
          return imageTag.replace('{name}', emoji.en).replace('{title}', emoji.cn)
        })
      })
      return match
    })
  }
  return content
}
