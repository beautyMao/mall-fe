/**
 * 生产环境标识
 * @type {boolean}
 */
export const isProd = process.env.VUE_APP_ENV_CONFIG === 'prod'
// export const isProd = false

/**
 * 获取格式化后的时间字符串
 * 默认为当前时间的yyyy-MM-dd hh:mm:ss
 * @param fmt
 * @param date
 * @return {string}
 */
export function getDateFormat(fmt = 'yyyy-MM-dd hh:mm:ss', date = new Date()) {
  const o = {
    'M+': date.getMonth() + 1, // 月份
    'd+': date.getDate(), // 日
    'h+': date.getHours(), // 小时
    'm+': date.getMinutes(), // 分
    's+': date.getSeconds(), // 秒
    'q+': Math.floor((date.getMonth() + 3) / 3), // 季度
    'S': date.getMilliseconds() // 毫秒
  }

  if (/(y+)/.test(fmt)) {
    fmt = fmt.replace(RegExp.$1, (`${date.getFullYear()}`).substr(4 - RegExp.$1.length))
  }

  for (const k in o) {
    if (new RegExp(`(${k})`).test(fmt)) {
      fmt = fmt.replace(RegExp.$1, (RegExp.$1.length === 1) ? (o[k]) : ((`00${o[k]}`).substr((`${o[k]}`).length)))
    }
  }
  return fmt
}

/**
 * 提供一个默认format 的时间字符串
 * yyyy-MM-ddThh:mm:ss
 * @return {*|void|string|never}
 */
export function getDatetime() {
  return getDateFormat('yyyy-MM-ddThh:mm:ss', new Date())
}

/**
 * 格式化时间
 * 例如：2018-12-12 0:0
 * @param time
 * @param cFormat
 * @return {*}
 */
export function parseTime(time, cFormat) {
  if (arguments.length === 0) {
    return null
  }
  const format = cFormat || '{y}-{m}-{d} {h}:{i}:{s}'
  let data
  if (typeof time === 'object') {
    data = time
  } else {
    if (('' + time).length === 10) time = parseInt(time) * 1000
    data = new Date(time)
  }
  const formatObj = {
    y: data.getFullYear(),
    m: data.getMonth() + 1,
    d: data.getDate(),
    h: data.getHours(),
    i: data.getMinutes(),
    s: data.getSeconds(),
    a: data.getDay()
  }
  const time_str = format.replace(/{(y|m|d|h|i|s|a)+}/g, (result, key) => {
    let value = formatObj[key]
    if (key === 'a') return ['一', '二', '三', '四', '五', '六', '日'][value - 1]
    if (result.length > 0 && value < 10) {
      value = '0' + value
    }
    return value || 0
  })
  return time_str
}

export function formatTime(time, option) {
  time = +time * 1000
  const d = new Date(time)
  const now = Date.now()

  const diff = (now - d) / 1000

  if (diff < 30) {
    return '刚刚'
  } else if (diff < 3600) { // less 1 hour
    return Math.ceil(diff / 60) + '分钟前'
  } else if (diff < 3600 * 24) {
    return Math.ceil(diff / 3600) + '小时前'
  } else if (diff < 3600 * 24 * 2) {
    return '1天前'
  }
  if (option) {
    return parseTime(time, option)
  } else {
    return d.getMonth() + 1 + '月' + d.getDate() + '日' + d.getHours() + '时' + d.getMinutes() + '分'
  }
}

export function getQueryObject(url) {
  url = url == null ? window.location.href : url
  const search = url.substring(url.lastIndexOf('?') + 1)
  const obj = {}
  const reg = /([^?&=]+)=([^?&=]*)/g
  search.replace(reg, (rs, $1, $2) => {
    const name = decodeURIComponent($1)
    let val = decodeURIComponent($2)
    val = String(val)
    obj[name] = val
    return rs
  })
  return obj
}

/**
 * 当前桌面窗口居中，打开一个浏览器窗口
 * @param url
 * @param title
 * @param w
 * @param h
 * @return {Window}
 */
export function windowOpenWithProperty(url, title, w = 640, h = 720) {
  // Fixes dual-screen position                            Most browsers       Firefox
  const dualScreenLeft = window.screenLeft !== undefined ? window.screenLeft : screen.left
  const dualScreenTop = window.screenTop !== undefined ? window.screenTop : screen.top

  const width = window.innerWidth ? window.innerWidth : document.documentElement.clientWidth ? document.documentElement.clientWidth : screen.width
  const height = window.innerHeight ? window.innerHeight : document.documentElement.clientHeight ? document.documentElement.clientHeight : screen.height

  const left = ((width / 2) - (w / 2)) + dualScreenLeft
  const top = ((height / 2) - (h / 2)) + dualScreenTop
  const newWindow = window.open(url, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=no, resizable=yes, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left)

  // Puts focus on the newWindow
  if (window.focus) {
    newWindow.focus()
  }
}

/**
 *get getByteLen
 * @param {Sting} val input value
 * @returns {number} output value
 */
export function getByteLen(val) {
  let len = 0
  for (let i = 0; i < val.length; i++) {
    if (val[i].match(/[^\x00-\xff]/ig) != null) {
      len += 1
    } else {
      len += 0.5
    }
  }
  return Math.floor(len)
}

export function cleanArray(actual) {
  const newArray = []
  for (let i = 0; i < actual.length; i++) {
    if (actual[i]) {
      newArray.push(actual[i])
    }
  }
  return newArray
}

/**
 * 获取form-url-encode string
 * @param json
 * @return {string}
 */
export function param(json) {
  if (!json) return ''
  return cleanArray(Object.keys(json).map(key => {
    if (json[key] === undefined) return ''
    return encodeURIComponent(key) + '=' +
      encodeURIComponent(json[key])
  })).join('&')
}

export function param2Obj(url) {
  const search = url.split('?')[1]
  if (!search) {
    return {}
  }
  return JSON.parse('{"' + decodeURIComponent(search).replace(/"/g, '\\"').replace(/&/g, '","').replace(/=/g, '":"') + '"}')
}

export function html2Text(val) {
  const div = document.createElement('div')
  div.innerHTML = val
  return div.textContent || div.innerText
}

export function objectMerge(target, source) {
  /* Merges two  objects,
     giving the last one precedence */

  if (typeof target !== 'object') {
    target = {}
  }
  if (Array.isArray(source)) {
    return source.slice()
  }
  Object.keys(source).forEach((property) => {
    const sourceProperty = source[property]
    if (typeof sourceProperty === 'object') {
      target[property] = objectMerge(target[property], sourceProperty)
    } else {
      target[property] = sourceProperty
    }
  })
  return target
}

export function capitalize(s) {
  return s.charAt(0).toUpperCase() + s.slice(1)
}

export function snakecase(s) {
  return s.replace(/\.?([A-Z]+)/g, function(x, y) {
    return '_' + y.toLowerCase()
  }).replace(/^_/, '')
}

export function scrollTo(element, to, duration, direction = 'top') {
  if (duration <= 0) return
  const directionName = 'scroll' + capitalize(direction)
  const difference = to - element[directionName]
  const perTick = difference / duration * 10
  setTimeout(() => {
    element[directionName] = element[directionName] + perTick
    if (element[directionName] === to) return
    scrollTo(element, to, duration - 10, direction)
  }, 10)
}

export function scrollToDelta(element, delta, duration = 200, direction = 'top') {
  const directionName = 'scroll' + capitalize(direction)
  const to = element[directionName] + delta
  scrollTo(element, to, duration, direction)
}

export function getTime(type) {
  if (type === 'start') {
    return new Date().getTime() - 3600 * 1000 * 24 * 90
  } else {
    return new Date(new Date().toDataString())
  }
}

export function debounce(func, wait, immediate) {
  let timeout, args, context, timestamp, result

  const later = function() {
    // 据上一次触发时间间隔
    const last = +new Date() - timestamp

    // 上次被包装函数被调用时间间隔last小于设定时间间隔wait
    if (last < wait && last > 0) {
      timeout = setTimeout(later, wait - last)
    } else {
      timeout = null
      // 如果设定为immediate===true，因为开始边界已经调用过了此处无需调用
      if (!immediate) {
        result = func.apply(context, args)
        if (!timeout) context = args = null
      }
    }
  }

  return function(...args) {
    context = this
    timestamp = +new Date()
    const callNow = immediate && !timeout
    // 如果延时不存在，重新设定延时
    if (!timeout) timeout = setTimeout(later, wait)
    if (callNow) {
      result = func.apply(context, args)
      context = args = null
    }

    return result
  }
}

/**
 * This is just a simple version of deep copy
 * Has a lot of edge cases bug
 * If you want to use a perfect deep copy, use lodash's _.cloneDeep
 */
export function deepClone(source) {
  if (!source && typeof source !== 'object') {
    throw new Error('error arguments', 'shallowClone')
  }
  const targetObj = source.constructor === Array ? [] : {}
  Object.keys(source).forEach((keys) => {
    if (source[keys] && typeof source[keys] === 'object') {
      targetObj[keys] = deepClone(source[keys])
    } else {
      targetObj[keys] = source[keys]
    }
  })
  return targetObj
}

/**
 * 生成唯一ID
 * @param prefix
 * @return {string}
 */
export function uuid(prefix = 'id') {
  return `${prefix}_${Math.random().toString(36).substr(2)}`
}

// 获取地址栏参数
export function getQueryString(name) {
  const after = window.location.hash.split('?')[1]
  if (after) {
    const reg = new RegExp('(^|&)' + name + '=([^&]*)(&|$)')
    const r = after.match(reg)
    if (r != null) {
      return decodeURIComponent(r[2])
    } else {
      return null
    }
  }
}

/**
 * 一个方便的延迟Promise
 * @param delay
 * @return {Promise<any>}
 */
export function sleep(delay) {
  return new Promise((resolve, reject) => {
    setTimeout(() => {
      resolve('timeup')
    }, delay || 1000)
  })
}

/**
 * 将Hash string 转为固定的随机值
 * @param str
 * @param upperbound
 * @param lowerbound
 * @return {number}
 */
export function stringToIntHash(str, upperbound = 10, lowerbound = 0) {
  let result = 0
  for (let i = 0; i < str.length; i++) {
    result = result + str.charCodeAt(i)
  }

  return (result % (upperbound - lowerbound)) + lowerbound
}

/**
 * 预处理级联选择器的数据
 * 同时能够构建一个展开flatten 的数据
 * @param data
 * @param flattenTreeData
 * @param config
 * @param path
 * @return {Array}
 */
export function convertTreeData(data, flattenTreeData, config = { label: 'label', value: 'value', children: 'children' }, path = []) {
  return data.map(item => {
    const re = {}
    const nextPath = [...path, item[config.label]]
    re.label = item[config.label]
    re.id = item[config.value]
    re.value = item[config.value]
    re.path = nextPath
    if (item[config.children] && item[config.children].length) {
      re.children = convertTreeData(item[config.children], flattenTreeData, config, nextPath)
    }
    flattenTreeData.push({
      id: item[config.value],
      value: item[config.value],
      label: item[config.label],
      path: nextPath
    })
    return re
  })
}

// 打开全屏模式
export function launchFullscreen(element) {
  if (element.requestFullscreen) {
    element.requestFullscreen()
  } else if (element.mozRequestFullScreen) {
    element.mozRequestFullScreen()
  } else if (element.webkitRequestFullscreen) {
    element.webkitRequestFullscreen()
  } else if (element.msRequestFullscreen) {
    element.msRequestFullscreen()
  }
}
// 退出全屏模式! 判断浏览器种类
export function exitFullscreen() {
  if (document.exitFullscreen) {
    document.exitFullscreen()
  } else if (document.mozCancelFullScreen) {
    document.mozCancelFullScreen()
  } else if (document.webkitExitFullscreen) {
    document.webkitExitFullscreen()
  }
}

/**
 * 参数的空值属性移除
 * 用于多条件查询，一般接口约定不传某属性参数即不根据该字段查询
 * @param paramsData
 * @return {*}
 */
export function paramsShake(paramsData) {
  const chekcTarget = Object.assign({}, paramsData)
  const keys = Object.keys(chekcTarget)
  keys.forEach((key) => {
    if (chekcTarget[key] === null || typeof chekcTarget[key] === undefined || (chekcTarget[key] + '').trim() === '') {
      delete chekcTarget[key]
    }
  })
  return chekcTarget
}

export function formatNumberRgx(num) {
  var parts = num.toString().split('.')
  parts[0] = parts[0].replace(/\B(?=(\d{3})+(?!\d))/g, ',')
  return parts.join('.')
}

export function handleDownload(filename, blob) {
  if (window.navigator.msSaveOrOpenBlob) {
    window.navigator.msSaveBlob(blob, filename)
  } else {
    const link = document.createElement('a')
    const evt = document.createEvent('HTMLEvents')
    evt.initEvent('click', false, false)
    link.href = window.URL.createObjectURL(blob)
    link.download = filename
    link.style.display = 'none'
    document.body.appendChild(link)
    link.click()
    window.URL.revokeObjectURL(link.href)
    document.body.removeChild(link)
  }
}
