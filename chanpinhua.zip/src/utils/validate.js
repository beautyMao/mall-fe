/* 合法uri*/
export function validateURL(textval) {
  return RegexUtil.url.test(textval)
}

/**
 * 提供常用的正则表达式
 * @type {{url: RegExp}}
 */
export const RegexUtil = {
  url: /(https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|www\.[a-zA-Z0-9][a-zA-Z0-9-]+[a-zA-Z0-9]\.[^\s]{2,}|https?:\/\/(?:www\.|(?!www))[a-zA-Z0-9]+\.[^\s]{2,}|www\.[a-zA-Z0-9]+\.[^\s]{2,})/,
  mobile: /^1[3456789]\d{9}$/,
  telephone: /^1[3456789]\d{9}$|^((0\d{2,3})-)(\d{7,8})(-(\d{3,}))?$/,
  hotline: /^400\d{7}$/,
  email: /^[a-z0-9]+([._\-]*[a-z0-9])*@([a-z0-9]+[-a-z0-9]*[a-z0-9]+.){1,63}[a-z0-9]+$/,
  externalProtocol: /^(https?:|mailto:|tel:)/
}
