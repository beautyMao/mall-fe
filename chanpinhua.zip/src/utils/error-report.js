import Raven from 'raven-js'

const extraData = []
const isDev = process.env.VUE_APP_ENV_CONFIG === 'dev'

/**
 * 在下一次报告前，暂存数据
 * @param data
 * @param msg
 */
export function addExtraErrorContext(data, msg) {
  extraData.push(data)
  if (msg) {
    Raven.captureMessage(msg)
  }
}

/**
 * 主动report error
 * @param data
 * @param errorMsg
 */
export function report(data, errorMsg) {
  Raven.setExtraContext()
  Raven.setExtraContext({
    ...data,
    extraData
  })
  Raven.setTagsContext({
    report: 'USER_ERROR_REPORT'
  })
  Raven.captureException(new Error('ERROR_REPORT:' + errorMsg + ' ' + data.feedback))

  extraData.length = 0
}

/**
 * 向sentry 报错，附加extra data
 * @param tag
 * @param error
 * @param extraData
 */
export function captureException(tag, error, extraData) {
  let tagContext = {}
  if (typeof tag === 'string') {
    tagContext.report = tag
  } else {
    tagContext = { ...tag }
  }

  if (isDev) {
    console.log(JSON.stringify(tagContext), error)
    extraData && console.log(extraData)
  } else {
    Raven.setTagsContext(tagContext)
    if (extraData) {
      Raven.setExtraContext()
      Raven.setExtraContext(extraData)
    }
    Raven.captureException(error)
  }
}
