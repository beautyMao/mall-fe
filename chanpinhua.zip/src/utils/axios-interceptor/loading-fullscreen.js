import { Loading } from 'element-ui'

let loading

function startLoading(text = '') {
  loading = Loading.service({
    lock: true,
    text: text,
    background: 'rgba(255, 255, 255, 0.6)'
  })
}

function endLoading() {
  loading.close()
}

let needLoadingRequestCount = 0

function showFullScreenLoading(text = '') {
  if (needLoadingRequestCount === 0) {
    startLoading(text)
  }
  needLoadingRequestCount++
}

function tryHideFullScreenLoading() {
  if (needLoadingRequestCount <= 0) return
  needLoadingRequestCount--
  if (needLoadingRequestCount === 0) {
    endLoading()
  }
}

/**
 * 拦截请求
 * 增加全屏loading 的能力
 * config 参数为：
 * defaultConfig = {
 *     showLoading: false,
 *     loadingText: ''
 * }
 * @param service
 */
export default function loadingFullscreenIntercept(service) {
  service.interceptors.request.use(config => {
    if (config.defaultConfig && config.defaultConfig.showLoading) {
      showFullScreenLoading(config.defaultConfig.loadingText || '')
    }
    return config
  })
  service.interceptors.response.use(response => {
    tryHideFullScreenLoading()
    return response
  }, (error) => {
    tryHideFullScreenLoading()
    return Promise.reject(error)
  })

  return service
}
