import store from '@/store'
import { getToken, setToken } from '@/utils/auth'
import Message from '@/utils/message-intercept'
import { MessageBox } from 'element-ui'

let reloadReset = true
let tokenError = false

const errorCodeMap = {
  // 10010401: '用户名或密码错误',
  10010402: '用户token缺失',
  10010403: '用户token过期',
  10010404: '未找到匹配用户',
  10010405: '用户token无效'
}
const errorCodeList = Object.keys(errorCodeMap)

/**
 * 让每个请求携带Bearer Token
 * @param service
 */
export default function authorizationCheckIntercept(service) {
  service.interceptors.request.use(config => {
    // token error 之后拦截所有请求
    if (tokenError) {
      return false
    }

    if (store.getters.token) {
      // 下两个应该由基础request 自行设置，减少侵入性
      // config.headers['Content-Type'] = 'application/json'
      // config.headers['charset'] = 'utf-8'
      config.headers['Authorization'] = `Bearer ${getToken()}`
    }

    return config
  })
  service.interceptors.response.use(response => {
    const res = response.data

    // todo 应该是特定某个接口返回了初始的token 无需每个接口都去拦截
    if (res && res.statusCode === 200 && response.headers && response.headers.authorization) {
      const token = response.headers.authorization.slice(7)
      setToken(token)
      store.commit('SET_TOKEN', token)
    }

    if (errorCodeList.includes(res.statusCode + '')) {
      // 标记tokenError 停止发送请求
      if (reloadReset) {
        tokenError = true
      }

      reloadReset && MessageBox.alert('你已被登出，可以取消继续留在该页面，或者重新登录', '确定登出', {
        confirmButtonText: '重新登录',
        showClose: false,
        callback: () => {
          store.dispatch('FedLogOut').then(() => {
            location.href = '/#/login'
            // 为了重新实例化vue-router对象 避免bug
            location.reload()
          })
        }
      })
      reloadReset = false
    } else if (res.statusCode === 10010401) {
      if (res.message.info !== '用户名或密码错误') {
        Message({
          message: res.message.info,
          type: 'warning'
        })
      }
    }

    return response
  })

  return service
}
