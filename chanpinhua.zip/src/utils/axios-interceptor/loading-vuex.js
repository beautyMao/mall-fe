import { captureException } from '@/utils/error-report'
import store from '@/store'

const baseURLRep = process.env.BASE_API

/**
 * 拦截请求并与vuex loading 绑定
 * 恩，看起来比直接用axios interceptors 方便一些
 *
 * 同时也做sentry api error log
 *
 * config 参数为：
 * vuexLoading = false，可以禁用某个请求的vuex loading
 * @param service {AxiosInstance}
 * @return {function(*=): Promise<any>}
 */
export default function loadingIntercept(service) {
  return config => {
    const api = config.url.replace(baseURLRep, '').split('?')[0]
    config.vuexLoading !== false && store.commit('api/START_LOADING', api)

    return service(config).catch((errorOrRes) => {
      let handleError = errorOrRes
      if (errorOrRes.message) {
        handleError = errorOrRes.message.info || errorOrRes.message
      } else if (errorOrRes.Message) {
        handleError = errorOrRes.Message
      }

      // 全新的错误提示信息，如果是Error 类型就继续
      // if (typeof handleError === 'string') {
      //   handleError += ' Cube API Error: ' + api
      // }

      captureException({
        report: 'REQUEST_ERROR',
        api: api
      }, handleError, {
        config,
        errorOrRes
      })
      // 将捕获的错误继续传递下去
      return Promise.reject(handleError)
    }).finally(p => {
      config.vuexLoading !== false && store.commit('api/STOP_LOADING', api)
    })
  }
}
