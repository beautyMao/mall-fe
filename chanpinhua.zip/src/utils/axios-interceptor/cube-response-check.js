import get from 'lodash.get'

/**
 * 魔方系统的接口标准响应码处理
 * @see http://rd.g.lenovo.com.cn/cube/apidoc/#api-_
 * @param service
 * @return {*}
 */
export default function cubeResponseCheckIntercept(service) {
  service.interceptors.response.use(response => {
    const isBlob = Object.prototype.toString.call(response.data) === '[object Blob]' // 是否为blob类型，如果是则忽略check
    if (isBlob) {
      response.data = {
        filename: decodeURI(response.headers['content-disposition'].replace(/attachment;\s+filename="/gi, '').replace('"', '')), // 后端需要解决文件名乱码的问题
        blob: response.data
      }
    } else if (response.data.statusCode !== 200) {
      const msg = get(response, 'data.message.info', '')
      const message = get(response, 'data.message', '')
      // 表单验证相关
      if (response.data.statusCode === 422) {
        return Promise.reject(Object.values(message).join(';'))
      }
      // return Promise.reject(msg || 'Cube API Error: ' + response.config.url)
      return Promise.reject(msg || message || response)
    }
    return response
  }, (error) => {
    return Promise.reject(error)
  })

  return service
}
