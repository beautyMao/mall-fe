// 处理超链接
const RegLink = /<a\s(?:\w*?=["'].*?["']\s)*?(?:href=["'])(.*?)(?:["'])(?:\s\w*?=["'].*?["'])*\s?>(.+?)<\/a>/g
// 这里曾经用到了反向预搜索，但是是ES2018 才将支持的内容
// 考虑到这里仅用于对工程师消息的处理，工程师消息里不会包含复杂的img src 信息（机器人智能推荐移除了复杂消息体）
const RegHttp = /(http:\/\/|https:\/\/)?[a-z0-9-]*\.?lenovo(.com)?(.cn)?[^\s"']*/gm

// XSS
const RegTags = /[<>&" \n]/g
const arrEntities = {
  '<': '&lt;',
  '>': '&gt;',
  '&': '&amp;',
  '"': '&quot;',
  ' ': '&nbsp;',
  '\n': '<br>'
}

/**
 * 查询出文本中所有的<a>标签，将<a>标签转化为class为'messageLink'的<a>标签。
 * 去掉href属性防止客服点击。添加data-link属性为超链接的真实连接地址
 * @attr
 *  class: messageLink
 *  data-link: $href
 *  $href: javascript:void(0)
 */
export function convertLink(content, isLink) {
  if (!content) {
    return content
  }

  let tmp = content; let res
  while ((res = RegLink.exec(content)) != null) {
    const con = isLink ? res[1] : res[2]
    tmp = tmp.replace(
      res[0],
      `<a class='message-link' data-link='${
        res[1]}'>${con}</a>`
    )
  }
  return tmp
}

/**
 * 移除内容里的a tag 的冗余属性，仅保留href
 * 避免微信下显示不正常问题
 * @param content
 * @return {*|void|string}
 */
export function convertToSimpleLink(content) {
  if (!content) {
    return content
  }

  let tmp = content; let res
  while ((res = RegLink.exec(content)) != null) {
    tmp = tmp.replace(res[0], `<a href='${res[1]}'>${res[2]}</a>`
    )
  }
  return tmp
}

/**
 * 将链接替换为可以让客服点击的a tag
 * 仅针对lenovo 域名的内容
 * @param content
 * @return {*}
 */
export function convertHttpLink(content) {
  return content.replace(RegHttp, '<a href="$&" target="_blank">$&</a>')
}

/**
 * 将\n改为<br>显示
 * @param content
 * @return {*}
 */
export function convertNewLine(content) {
  if (!content) {
    return content
  }
  content = content.replace(/\n/g, '<br>')
  return content
}

/**
 * 防止XSS攻击、正确的转译出用户表达的内容
 * @param content
 * @return {*|void|string|never}
 */
export function convertXSS(content) {
  return content.replace(RegTags, function(match) {
    return arrEntities[match]
  })
}
