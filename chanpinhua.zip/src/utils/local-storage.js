import cookie from 'js-cookie'

/**
 * 针对单个客服，可以做单独存储和读取，还有移除
 * 由于在个别浏览器隐身模式、高安全性模式下，localStorage 不可用
 */
class LStorage {
  constructor(engineer) {
    this.tokenKey = engineer || 'nokey'
    this.localMode = true
    this.coreKeyTest = /DONE|userCode|version|source/g
    try {
      localStorage.setItem('foobar', 'foobar')
      localStorage.removeItem('foobar')
    } catch (e) {
      // 如果 localStorage 无法访问，我们只能降级到cookie 存储
      // 并且在接下来的地方仅存储关键信息，如 cube uid 等关键信息
      // 降低 cookie 空间占用
      this.localMode = false
    }
  }

  getItem(itemKey) {
    const key = `${this.tokenKey}:${itemKey}`
    const re = this.localMode ? localStorage.getItem(key) : cookie.get(key)
    return re === 'undefined' ? '' : re
  }
  setItem(itemKey, value) {
    const key = `${this.tokenKey}:${itemKey}`
    if (this.localMode) {
      localStorage.setItem(key, value)
    } else if (this.coreKeyTest.test(itemKey)) {
      cookie.set(key, value)
    }
  }
  clear() {
    const readyRemove = []

    if (this.localMode) {
      for (let i = 0, _sizei = localStorage.length; i < _sizei; i++) {
        const key = localStorage.key(i)
        if (key && key.indexOf(this.tokenKey) > -1) {
          readyRemove.push(key)
        }
      }
    } else {
      cookie.keys().forEach(key => {
        if (key.indexOf(this.tokenKey) > -1) {
          readyRemove.push(key)
        }
      })
    }

    readyRemove.forEach(key => {
      if (this.localMode) {
        localStorage.removeItem(key)
      } else {
        cookie.remove(key)
      }
    })
  }
}
let lStorageInstance
/**
 * 我们针对每个用户，做了单独存储和读取，还有移除
 * @param engineer
 * @returns {LStorage}
 */
export const getLocalStorage = function(engineer = 'DEFAULT') {
  if (!lStorageInstance) {
    lStorageInstance = new LStorage(engineer)
  }
  return lStorageInstance
}
