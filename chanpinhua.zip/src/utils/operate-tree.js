// import Vue from 'vue'

export function cancelMove(data, dragNode, dropNode) {
  // 首先找到当前id所在位置，删掉
  console.log(11111, dropNode, dragNode)
  getNodeDataById(data, dragNode.data)

  const parent = dropNode.parent
  const children = parent.data.children || parent.data
  const index = children.findIndex(d => d.id === dragNode.data.id)
  children.splice(index, 1)
}

function getNodeDataById(data, node) { // 查询id节点，并将数据压入
  return data.map(item => {
    if (item.id === node.parent_id) {
      console.log(2222222, item)
      // Vue.set(item.children, 0, node)
      item.children.push(node)
      return item
    }
    if (item.children) {
      getNodeDataById(item.children, node)
    }
  })
}
