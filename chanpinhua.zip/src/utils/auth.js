import Cookies from 'js-cookie'

const TokenKey = 'Admin-Token'

export function getToken() {
  return Cookies.get(TokenKey)
}

export function setToken(token) {
  return Cookies.set(TokenKey, token)
}

export function removeToken() {
  return Cookies.remove(TokenKey)
}

// 七牛上传 token
const QiniuTokenKey = 'QiniuToken'

export function getQiniuToken() {
  return localStorage.getItem(QiniuTokenKey)
}

export function setQiniuToken(token) {
  return localStorage.setItem(QiniuTokenKey, token)
}

export function removeQiniuToken() {
  return localStorage.removeItem(QiniuTokenKey)
}

// 电话台，这里使用sessionStorage，保证session 不被刷新动作重置
const VoiceSessionKey = 'CUBE-VOICE-SESION'

// id: '', // gensys phone id
// place: '' // 物理机位置
export function getTelToken() {
  return JSON.parse(sessionStorage.getItem(VoiceSessionKey))
}

export function setTelToken(voiceSessionData) {
  return sessionStorage.setItem(VoiceSessionKey, JSON.stringify(voiceSessionData))
}

export function removeTelToken() {
  return sessionStorage.removeItem(VoiceSessionKey)
}

