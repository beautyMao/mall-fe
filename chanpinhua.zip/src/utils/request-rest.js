import requestBase from './request'

/**
 * 构建标准的Rest resource api
 * @param resource
 * @param requestConfig
 * @param request
 * @param resource
 * @param requestConfig
 * @param request
 * @return {Promise<any>|{post(*, *=): *, get(*): *, update(*, *=): *, list(): *, delete(*): *}}
 */
export const createResourceRequest = function(resource, requestConfig = {}, request = requestBase) {
  return {
    list(query = {}) {
      return request(Object.assign({
        url: resource,
        method: 'get',
        params: query
      }, requestConfig))
    },
    get(id) {
      return request(Object.assign({
        url: `${resource}/${id}`,
        method: 'get'
      }, requestConfig))
    },
    post(data = {}) {
      return request(Object.assign({
        url: `${resource}`,
        method: 'post',
        data
      }, requestConfig))
    },
    update(id, data = {}) {
      return request(Object.assign({
        url: `${resource}/${id}`,
        method: 'put',
        data
      }, requestConfig))
    },
    delete(id) {
      return request(Object.assign({
        url: `${resource}/${id}`,
        method: 'delete'
      }, requestConfig))
    }
  }
}
