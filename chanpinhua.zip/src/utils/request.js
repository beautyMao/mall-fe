import axios from 'axios'
import { authorizationCheck, cubeResponseCheck, loadingFullscreen, loadingVuex } from '@/utils/axios-interceptor/index'

const service = axios.create({
  timeout: 10 * 1000,
  headers: {
    'Content-Type': 'application/json',
    'charset': 'utf-8'
  }
})

// 这里的interceptors 是有顺序的
const interceptors = [loadingFullscreen, authorizationCheck, cubeResponseCheck]
interceptors.forEach(interceptor => {
  interceptor(service)
})

// 最后一个interceptors 方便接口响应使用数据
service.interceptors.response.use(response => {
  return response.data
})

/**
 * 提供一个标准的请求基类
 * 已经具备的interceptor 有：
 * - 魔方标准响应码处理
 * - Bearer Token 检测和处理
 * - 全屏loading 功能
 * - vuex api loading 功能
 *
 * 如果在业务场景下不需要某项操作，或者基本配置不满足要求（比如默认超时时间）
 * 请新建request axios service，或者重新覆盖request config
 */
export default loadingVuex(service)
