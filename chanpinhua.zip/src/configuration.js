import config from './configuration.default'

// 优先使用window 下的通过scripts 加载的属性
// 其次使用本地的env 配置信息
// 最后使用default configuration
// todo 单例模式，加载后即固定内容
// todo 对内容进行校验
export const CUBE = Object.assign(config, {
  im: { appid: process.env.VUE_APP_IM_APP_ID },
  api: {
    base: process.env.VUE_APP_BASE_API,
    cti: process.env.VUE_APP_CTI_API,
    oss: process.env.VUE_APP_QINIU_HOST,
    upload: process.env.VUE_APP_UPLOAD_ACTION,
    domain: process.env.VUE_APP_DOMAIN_PATH
  }
// eslint-disable-next-line no-undef
}, CUBE_APP || {})
