/* eslint-disable */
import router from './router'
import store from './store'
import { Message } from 'element-ui'
import NProgress from 'nprogress' // progress bar
import 'nprogress/nprogress.css' // progress bar style
import { getToken } from '@/utils/auth' // getToken from cookie
// import { isProd } from '@/utils'

// todo 开发阶段临时移除权限判定，现在RD对菜单的权限接口还没有ready
const isProd = false

NProgress.configure({ showSpinner: false })// NProgress Configuration

// permission judge function
function hasPermission(permissionList, route) {
  if (whiteList.includes(route.path) || route.path.startsWith('/redirect/')) {
    return true
  }

  if (route.name) {
    return permissionList.includes(route.name)
  }

  return false
}

// 判断是否可以跳转到呼叫中心页面
function isJumpToCallCenter(permissionList, from, to) {
  return from.path === '/login' && to.name === 'home-page' && permissionList.includes('call-center')
}

const whiteList = [
  '/',
  '/login',
  '/reset',
  '/401',
  '/404',
  '/icon',
  '/authredirect'
]// no redirect whitelist

router.beforeEach((to, from, next) => {
  NProgress.start() // start progress bar
  if (getToken()) { // determine if there has token
    /* has token*/
    if (to.path === '/login') {
      next({ path: '/' })
      NProgress.done() // if current page is dashboard will not trigger	afterEach hook, so manually handle it
    } else {
      if (!store.state.user.permission) { // 判断当前用户是否已拉取完user_info信息
        store.dispatch('GetInfo').then(permissionList => { // 拉取user_info
          // 根据roles权限生成可访问的路由表
          return store.dispatch('GenerateRoutes', permissionList)
        }).then(() => {
          router.addRoutes(store.getters.addRouters) // 动态添加可访问路由表
          next({ ...to, replace: true }) // hack 方法 确保addRoutes已完成 ,set the replace: true so the navigation will not leave a history record
        }).catch((err) => {
          store.dispatch('FedLogOut').then(() => {
            Message.error(err || 'Verification failed, please login again')
            next({ path: '/' })
          })
        })
      } else if (isProd) {
        if (hasPermission(store.state.user.permission, to)) {
          // 判断是否是登录页面跳转，并且确认是否有呼叫中心权限
          if (isJumpToCallCenter(store.state.user.permission, from, to)) {
            next({ path: '/call-center' })
          } else {
            next()
          }
        } else {
          next({ path: '/401', replace: true, query: { noGoBack: true } })
        }
      } else {
        next()
      }
    }
  } else {
    /* has no token*/
    if (whiteList.indexOf(to.path) !== -1) { // 在免登录白名单，直接进入
      next()
    } else {
      next('/login') // 否则全部重定向到登录页
      NProgress.done() // if current page is login will not trigger afterEach hook, so manually handle it
    }
  }
})

router.afterEach(() => {
  NProgress.done() // finish progress bar
})
