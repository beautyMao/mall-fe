# 生成区域信息（适用于el-cascader组件数据格式）

``` js

node regionTreeUtil.js > data.js

```