<template>
  <el-cascader
      v-bind="$attrs"
      v-on="$listeners"
      :options="options"
      @change="handleChange"></el-cascader>
</template>

<script type="text/ecmascript-6">
  import regionData from './data'

  export default {
    name: 'region-picker',
    data() {
      return {
        options: regionData
      }
    },
    methods: {
      handleChange(item) {
        // 触发父级的v-modal 变更
        this.$emit('input', item)
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>

</style>
