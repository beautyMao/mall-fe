<template>
  <div
    v-show="show"
    :style="style"
    style="display: block;"
    class="context-menu"
    @mousedown.stop
    @contextmenu.prevent
  >
    <slot />
  </div>
</template>

<script>
  export default {
    name: 'context-menu',
    props: {
      target: null,
      show: Boolean
    },
    data() {
      return {
        triggerShowFn: () => {
        },
        triggerHideFn: () => {
        },
        x: null,
        y: null,
        style: {},
        binded: false
      }
    },
    watch: {
      show(show) {
        if (show) {
          this.bindHideEvents()
        } else {
          this.unbindHideEvents()
        }
      },
      target(target) {
        this.bindEvents()
      }
    },
    mounted() {
      this.target && this.bindEvents()
    },
    methods: {
      // 初始化事件
      bindEvents() {
        this.$nextTick(() => {
          if (!this.target || this.binded) return
          this.triggerShowFn = this.contextMenuHandler.bind(this)
          this.target.addEventListener('contextmenu', this.triggerShowFn)
          this.binded = true
        })
      },

      // 取消绑定事件
      unbindEvents() {
        if (!this.target) return
        this.target.removeEventListener('contextmenu', this.triggerShowFn)
      },

      // 绑定隐藏菜单事件
      bindHideEvents() {
        this.triggerHideFn = this.clickDocumentHandler.bind(this)
        document.addEventListener('mousedown', this.triggerHideFn)
        document.addEventListener('mousewheel', this.triggerHideFn)
      },

      // 取消绑定隐藏菜单事件
      unbindHideEvents() {
        document.removeEventListener('mousedown', this.triggerHideFn)
        document.removeEventListener('mousewheel', this.triggerHideFn)
      },

      // 鼠标按压事件处理器
      clickDocumentHandler(e) {
        this.$emit('update:show', false)
      },

      // 右键事件事件处理
      contextMenuHandler(e) {
        this.x = e.clientX
        this.y = e.clientY
        this.layout()
        this.$emit('update:show', true)
        e.preventDefault()
        e.stopPropagation()
      },

      // 布局
      layout() {
        this.style = {
          left: this.x + 'px',
          top: this.y + 'px'
        }
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .context-menu {
    position: fixed;
    background: #fff;
    z-index: 999;
    display: none;
    border: 1px solid #DCDFE6;
    box-shadow: 2px 2px 3px 0 rgba(0, 0, 0, .3);
    border-radius: 5px;
    padding: 5px 0;
    font-size: 12px;

    a {
      padding: 0 10px;
      margin: 0;
      min-width: 110px;
      height: 27px;
      line-height: 27px;
      display: block;
      color: #303133;
      text-decoration: none;

      transition: all 100ms;
    }

    a.disabled {
      color: #909399;
    }

    a.disabled:hover {
      background-color: #fff;
    }

    a:hover {
      background: #eee;
    }
  }
</style>
