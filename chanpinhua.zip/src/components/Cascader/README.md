# Cascader

> 占UI空间更小的级联选择框

## 使用

## Props

| 参数                    | 说明  | 类型 | 可选值 | 默认值 |
|-------------------------|-------|------|--------|--------|
| tree | 级联树的原始数据  | Array | -      | -      |
| confirm | 是否显示确认按钮  | Boolean | -      | false    |
| confirmText | 确认按钮的文本内容  | String | -      | '添加标签'      |
| splitComma | 显示父子连接的分隔符  | String | -      | '/'      |
| props | 请参考配置项说明  | Object | -      | -      |

## Events

| 事件名                    | 说明  | 事件参数
|-------------------------|-------|------|
|change| 末级节点选择时触发  | node |
|confirm| 确认按钮点击时触发  | node |

```typescript
interface Node {
  label: string,
  id: string,
  value: string,
  path: Array<string>
}
```

## 在模板中使用

```vue
<el-popover
  placement="bottom"
  trigger="click">
  <el-button
    slot="reference"
    type="primary"
    icon="el-icon-plus"
    circle></el-button>
  <cascader :tree="options" @change="handleChangeProblem"></cascader>
</el-popover>
```

## License

[MIT](http://opensource.org/licenses/MIT)

Copyright (c) XCube Lenovo
