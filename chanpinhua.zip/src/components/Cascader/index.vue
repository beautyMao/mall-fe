<template>
  <div class="cascader-container border" tabindex="100" @keydown="handleKeydown">
    <el-input
      v-model.trim="query"
      clearable
      placeholder="搜索关键词"
      prefix-icon="el-icon-search"
      @keydown.enter.native="handleQuery"
    />
    <h3 v-if="result">搜索结果："{{ query }}"</h3>
    <el-breadcrumb v-else separator-class="el-icon-arrow-right">
      <el-breadcrumb-item @click.native="steps = []">全部</el-breadcrumb-item>
      <el-breadcrumb-item
        v-for="step in steps"
        :key="step.id"
        :title="step.label"
        @click.native="switchNode(step)"
      >{{ step.label }}</el-breadcrumb-item>
    </el-breadcrumb>
    <ul v-if="listNodes.length">
      <li
        v-for="node in listNodes"
        :key="node.id"
        :class="{'checked': isChecked(node), 'hover': hoverNode && hoverNode.id === node.id}"
        @mouseenter="handleNodeHover(node)"
        @click="switchNode(node)"
      >
        {{ node.label }}
        <i v-if="node.children" class="el-icon el-icon-arrow-right" />
        <i v-show="isChecked(node)" class="el-icon el-icon-check" />
      </li>
    </ul>
    <p v-else class="empty">没有标签数据</p>
    <p v-if="confirm" class="text-center">
      <el-button type="primary" size="small" @click="handleConfirm">{{ confirmText }}</el-button>
    </p>
  </div>
</template>

<script type="text/ecmascript-6">
  /* eslint-disable vue/script-indent */

  export default {
    name: 'cube-cascader',
    props: {
      tree: {
        type: Array,
        default: function() {
          return []
        }
      },
      confirm: {
        type: Boolean,
        default: false
      },
      confirmText: {
        type: String,
        default: '添加标签'
      },
      splitComma: {
        type: String,
        default: '/'
      },
      props: {
        type: Object,
        default: function() {
          return {
            children: 'children',
            label: 'label',
            value: 'value',
            showCheck: false
          }
        }
      }
    },
    data() {
      return {
        query: '',
        selectNode: null,
        hoverNode: null,
        steps: [],
        result: null,
        treeData: [],
        flattenTreeData: []
      }
    },
    computed: {
      listNodes() {
        // 如果有搜索结果
        if (this.result) {
          return this.result
        }

        let treeNodes = this.treeData
        this.steps.forEach(step => {
          treeNodes = treeNodes.find(node => node.id === step.id).children
        })
        return treeNodes
      }
    },
    watch: {
      tree(tree) {
        this.initData(tree)
      },
      query(query) {
        if (!query.length) {
          this.result = null
        }
      }
    },
    mounted() {
      this.initData(this.tree)
    },
    methods: {
      switchNode(node) {
        if (!node) {
          return
        }
        // 末级节点的处理
        if (!node.children) {
          this.selectNode = node
          return this.$emit('change', node)
        }

        // 节点点击切换或者切换父级
        const index = this.steps.findIndex(step => step.id === node.id)
        if (index > -1) {
          this.steps.splice(index + 1)
        } else {
          this.steps.push(node)
        }
      },
      handleConfirm() {
        this.$emit('confirm', this.selectNode)
      },
      handleQuery() {
        if (!this.query) {
          return this.$message.warning('请输入正确的查询关键词')
        }
        this.result = this.flattenTreeData.filter(node => node.label.indexOf(this.query) > -1 && !node.leaf)
      },
      // 上下左右和enter处理
      handleKeydown(e) {
        if (!this.listNodes.length) {
          return
        }

        const allowKeys = ['ArrowUp', 'ArrowLeft', 'ArrowRight', 'ArrowDown', 'Enter']
        if (!allowKeys.includes(e.code)) {
          return
        }

        const index = this.hoverNode ? this.listNodes.findIndex(node => node.id === this.hoverNode.id) : -1
        switch (e.code) {
          case 'ArrowUp':
            if (index === 0 || index === -1) {
              this.hoverNode = this.listNodes[this.listNodes.length - 1]
            } else {
              this.hoverNode = this.listNodes[index - 1]
            }
            break
          case 'ArrowDown':
            if (index === -1 || index === this.listNodes.length - 1) {
              this.hoverNode = this.listNodes[0]
            } else {
              this.hoverNode = this.listNodes[index + 1]
            }
            break
          case 'ArrowLeft':
            if (this.steps.length > 1) {
              this.switchNode(this.steps[this.steps.length - 2])
            } else {
              this.steps = []
            }
            this.$nextTick(() => {
              this.hoverNode = this.listNodes.length ? this.listNodes[0] : null
            })
            break
          case 'ArrowRight':
            this.switchNode(this.hoverNode)
            this.$nextTick(() => {
              this.hoverNode = this.listNodes.length ? this.listNodes[0] : null
            })
            break
          case 'Enter':
            if (this.hoverNode && !this.hoverNode.children) {
              this.$emit('change', this.hoverNode)
            } else {
              this.switchNode(this.hoverNode)
              this.$nextTick(() => {
                this.hoverNode = this.listNodes.length ? this.listNodes[0] : null
              })
            }
        }
      },
      handleNodeHover(node) {
        this.hoverNode = node
      },
      isChecked(node) {
        if (!this.props.showCheck) {
          return false
        }
        return this.selectNode && this.selectNode.id === node.id
      },
      initData(tree) {
        if (tree && tree.length > 0) {
          this.flattenTreeData = []
          this.treeData = this._convertTreeData(tree)
        }
      },
      _convertTreeData(data, path = []) {
        return data.map(item => {
          const re = {}
          const nextPath = [...path, item[this.props.label]]
          re.label = item[this.props.label]
          re.id = item[this.props.value]
          re.value = item[this.props.value]
          re.path = nextPath
          if (item[this.props.children] && item[this.props.children].length) {
            re.children = this._convertTreeData(item[this.props.children], nextPath)
          }
          // if (!re.children.length) {
          //   delete re.children
          // }
          this.flattenTreeData.push({
            id: item[this.props.value],
            label: item[this.props.label],
            path: nextPath,
            leaf: re.children !== undefined
          })
          return re
        })
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .cascader-container {
    background-color: #fff;
    min-width: 340px;
    min-height: 320px;
    padding: 20px 20px 0;
    font-size: 14px;

    h3 {
      font-size: 14px;
      line-height: 1;
      margin: 0 0 10px;
      color: #7D87A5;
    }

    &.borderd {
      border: 1px solid #ccc;
    }

    /deep/ .el-input {
      margin-bottom: 20px;
    }
    /deep/ .el-breadcrumb {
      margin-bottom: 10px;
    }
    /deep/ .el-breadcrumb__inner {
      display: inline-block;
      max-width: 80px;
      overflow: hidden;
      text-overflow: ellipsis;
      white-space: nowrap;
      cursor: pointer;
      color: #7D87A5 !important;
    }

    // 当处于form item 时的双icon bug
    /deep/ .el-input__validateIcon {
      display: none;
    }

    ul {
      margin-left: -20px;
      margin-right: -20px;
      max-height: 400px;
      overflow-y: auto;

      li {
        display: block;
        height: 34px;
        line-height: 34px;
        cursor: pointer;
        padding-left: 20px;
        padding-right: 20px;

        &.checked {
          color: #1989FA;
          font-weight: 600;
        }

        i.el-icon {
          float: right;
          height: 34px;
          line-height: 34px;
        }

        &:hover, &.hover {
          color: #1989FA;
          background-color: #F5F7FA;
        }
      }
    }
  }
</style>
