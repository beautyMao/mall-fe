<template>
  <div class="ext-date-container" :class="{'is-focus': isFocus}">
    <span v-show="placehoder" class="placehoder">{{ placehoder }}</span>
    <el-date-picker
      v-bind="$attrs"
      @focus="isFocus = true"
      @blur="isFocus = false"
      v-on="$listeners"
      @change="handleChange"
    />
  </div>
</template>

<script type="text/ecmascript-6">
  import { getDateFormat } from '@/utils'

  // 获得范围日期
  const getRangeDate = function(span, fmt = 'yyyy-MM-dd') {
    const end = new Date()
    const start = new Date(end.getTime() - (span * 24 * 3600 * 1000))
    return [getDateFormat(fmt, start), getDateFormat(fmt, end)]
  }
  export default {
    name: 'ex-date-picker',
    props: {
      // 前缀提示文案
      placehoder: {
        type: String,
        default: ''
      },
      // 所允许的时间跨度，默认是0， 不做跨度设置
      span: {
        type: Number,
        default: 0
      }
    },
    data() {
      return {
        isFocus: false
      }
    },
    mounted() {
      if (this.span > 0) {
        // 触发父级的v-modal 变更
        // this.$emit('input', getRangeDate(this.span, this.$attrs.valueFormat))
      }
    },
    methods: {
      handleChange(dateArr) {
        if (this.span !== 0 && dateArr) {
          if (new Date(dateArr[1]) - new Date(dateArr[0]) > this.span * 24 * 3600 * 1000) {
            this.$emit('input', getRangeDate(this.span, this.$attrs.valueFormat))
            this.$emit('range-error', this.span)
          }
        }

        this.$emit('change', dateArr)
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .ext-date-container {
    display: inline-block;
    border-radius: 4px;
    border: 1px solid #C0C4CC;
    transition: border-color 500ms;
    line-height: 40px;
    height: 40px;

    &.is-focus {
      border-color: #3E8DDD;
    }

    .placehoder {
      padding-right: 15px;
      padding-left: 15px;
      line-height: 38px;
      display: inline-block;
      background-color: #f3f6f9;
      color: #909399;
      border-top-left-radius: 4px;
      border-bottom-left-radius: 4px;
      float: left;
      cursor: pointer;
    }

    .el-input__inner {
      border: none;
      float: right;
      line-height: 38px !important;
      height: 38px !important;
    }
  }
</style>
