<template>
  <header>
    <h1>当前现场：{{ business }} {{ access }}</h1>
  </header>
</template>
<script>
  export default {
    data() {
      return {
        business: '',
        access: ''
      }
    },
    mounted() {
      this.business = this.$route.query.business
      this.access = this.$route.query.access
    }
  }
</script>
