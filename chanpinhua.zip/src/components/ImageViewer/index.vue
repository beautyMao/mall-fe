<template>
  <div>
    <div @click="showViewer"><slot /></div>
    <el-card
      v-show="show"
      ref="card"
      v-el-drag-dialog="{header: '.el-card__header', edge: false}"
      tabindex="0"
      shadow="always"
      class="viewer-card"
      :class="isFullscreen ? 'fullscreen' : ''"
    >
      <div slot="header" class="clearfix viewer-card-head" @dblclick="fullscreenToggle">
        <span><i class="el-icon-picture" /> 图片查看器（ESC 关闭）</span>
        <el-button class="fr pd5" type="text" @click="imageViewClose">关闭</el-button>
        <el-button class="fr pd5" type="text" @click="fullscreenToggle">{{ isFullscreen ? '还原' : '全屏' }}</el-button>
      </div>
      <div class="viewer-card-content">
        <img ref="imageInline" tabindex="1" style="display: none;" :src="src" alt="查看图片">
        <div ref="imageList">
          <img
            v-for="(image, index) in srcs"
            v-if="srcs.length"
            :tabindex="index"
            style="display: none;"
            :src="image"
            alt="查看图片"
          >
        </div>
      </div>
    </el-card>
  </div>
</template>

<script type="text/ecmascript-6">
  import 'viewerjs/dist/viewer.css'
  import Viewer from 'viewerjs'

  export default {
    name: 'image-viewer',
    props: {
      src: {
        type: String,
        default: ''
      },
      srcs: {
        type: Array,
        default: function() {
          return []
        }
      }
    },
    data() {
      return {
        show: false,
        isFullscreen: false,
        viewer: null
      }
    },
    mounted() {
      window.addEventListener('keydown', this._keydownHandle, true)
    },
    beforeDestroy() {
      // todo 需要测试下，切换session 后，相应的viewer 有没有被正确的销毁
      this.viewer && this.viewer.destroy()
      window.removeEventListener('keydown', this._keydownHandle)
    },
    methods: {
      destroy() {
        this.viewer && this.viewer.destroy()
      },
      showViewer(index = 0) {
        this.show = true
        this._setToCenter()

        this.$nextTick(() => {
          if (!this.viewer) {
            const targetContainer = this.srcs.length ? this.$refs.imageList : this.$refs.imageInline
            this.viewer = new Viewer(targetContainer, {
              inline: true,
              navbar: true,
              button: false,
              fullscreen: false,
              initialViewIndex: index
            })
          }
          this.viewer.update()
          this.viewer.view(index)
        })
      },
      fullscreenToggle() {
        this.isFullscreen = !this.isFullscreen
        if (this.isFullscreen) {
          this.viewer.full()
        } else {
          this.viewer.exit()
          this._setToCenter()
        }
      },
      imageViewClose() {
        this.show = false
        this.isFullscreen = false
        if (this.viewer) {
          this.viewer.exit()
          this.viewer.hide(true)
          this.viewer.destroy()
          this.viewer = null
        }
      },
      // 居中定位
      _setToCenter() {
        this.$nextTick(() => {
          const $el = this.$refs.card.$el
          const dragDomWidth = $el.offsetWidth
          const dragDomheight = $el.offsetHeight
          const screenWidth = document.body.clientWidth
          const screenHeight = document.body.clientHeight
          $el.style.top = (screenHeight - dragDomheight) / 2 + 'px'
          $el.style.left = (screenWidth - dragDomWidth) / 2 + 'px'
        })
      },
      _keydownHandle(e) {
        if (!this.show) {
          return
        }
        if (e.code === 'Escape') {
          this.imageViewClose()
        } else if (e.code === 'ArrowLeft') {
          this.viewer.prev()
        } else if (e.code === 'ArrowRight') {
          this.viewer.next()
        }
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .viewer-card {
    position: fixed;
    transform: none;
    width: 60vw;
    min-width: 400px;
    z-index: 20000;

    &.fullscreen {
      width: 100vw;
      height: 100vh;
      top: 0 !important;
      left: 0 !important;
    }

    .viewer-card-content {
      min-height: 500px;
      height: 70vh;
    }
  }

  .viewer-card /deep/ {
    .viewer-container.viewer-fixed {
      top: 45px;
    }

    .el-card__body {
      padding: 5px;
      height: 100%;
    }

    .el-card__header {
      padding: 8px 20px;
      line-height: 25px;
      font-size: 14px;
    }
  }
</style>
