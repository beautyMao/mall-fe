<template>
  <div class="message-container">
    <el-dialog :show-close="false" :visible="dialogVisible" width="50%" @close="$emit('on-close')">
      <el-tabs v-model="activeName">
        <el-tab-pane label="全部" name="all" />
        <el-tab-pane label="data" name="info" />
        <el-tab-pane label="Success" name="success" />
        <el-tab-pane label="Warning" name="warning" />
        <el-tab-pane label="Error" name="error" />
        <el-tab-pane label="软电话" name="softphone" />
      </el-tabs>
      <ul>
        <li v-for="message in messageLogs" :key="message.id">
          <span class="log-tag">
            <el-tag :type="typeMap[message.type]">{{ message.type }}</el-tag>
          </span>
          {{ message.time }}：<span v-html="message.message" />
        </li>
      </ul>
    </el-dialog>
  </div>
</template>

<script>
  export default {
    name: 'message-log',
    props: {
      dialogVisible: {
        type: Boolean,
        default: false
      }
    },
    data() {
      return {
        activeName: 'all',
        dialogTableVisible: false,
        typeMap: {
          'error': 'danger',
          'info': 'info',
          'softphone': 'info',
          'success': 'success',
          'warning': 'warning'
        }
      }
    },
    computed: {
      messageLogs() {
        if (this.activeName === 'all') {
          return this.$store.getters.messageLogs
        } else {
          return this.$store.getters.messageLogs.filter(m => m.type === this.activeName)
        }
      }
    },
    methods: {
      handleClose() {
        this.$emit('on-close')
      }
    }
  }
</script>

<style lang='scss' type="text/scss" scoped>
  .message-container /deep/ {
    .el-dialog__header {
      display: none;
    }

    .el-dialog__body {
      padding: 0 20px 10px;
    }
  }

  .message-container {
    .log-tag {
      width: 60px;
      display: inline-block;
      text-align: right;
    }

    ul {
      max-height: 500px;
      overflow: auto;

      li {
        line-height: 30px;
      }
    }
  }
</style>
