import 'normalize.css/normalize.css' // A modern alternative to CSS resets
import '@/copyright' // copyright
