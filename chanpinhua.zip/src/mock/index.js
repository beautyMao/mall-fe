import Mock from 'mockjs'

import suAPI from './queue-management/su'
import pondAPI from './queue-management/pond'
import review from './review/review'

// SU 批量修改 SU
Mock.mock(/\/mock\/api\/wb\/channel/, 'put', suAPI.getList)

// 过去队列人员组织信息
Mock.mock(/\/mock\/api\/wb\/business\/queues\/\.*/, 'get', pondAPI.getList)

// 获取服务方式下通路
Mock.mock(/\/mock\/api\/wb\/business\/type\/\.*/, 'get', pondAPI.getTypeList)

// 获取点评列表
Mock.mock(/\/api\/csc\/evaluation/, 'get', review.getList)

// 获取客服点评信息
// Mock.mock(/\/api\/csc\/evaluation\/todaycount/, 'get', review.getEngineerReviewInfo)

export default Mock
