import Mock from 'mockjs'

const List = []
const count = 65
const user = Mock.mock({
  code: 'A06892',
  name: '@cname',
  avatar: 'http://thirdwx.qlogo.cn/mmopen/toKG1l2YpQgbymr9OWtAiarH70fSvakicMvInpyhVt4eibIQY3hHviaVdpEpaFo5Rzwy3gjNYuR4D0RLxb0wZoDaGcPpKEW4C8yO/132'
})
const evaluation = Mock.mock({
  text: '今日累计点评信息数量',
  'count|10-30': 0
})

const current_page = Mock.mock({
  'current_page|1-4': 1
})
for (let i = 0; i < 20; i++) {
  List.push(Mock.mock({
    'session_id|1-1': '4phLywbN-Dh',
    'star|1-5': 1,
    'favorites|0-1': 1,
    'share|0-1': 1,
    'rewarded|0-10': 0,
    'content|1-10': '还不赖，态度挺好，技术也还行',
    dp_time: '',
    wechat_user_info: {
      nickname: '@cname',
      headimgurl: 'http://thirdwx.qlogo.cn/mmopen/toKG1l2YpQgbymr9OWtAiarH70fSvakicMvInpyhVt4eibIQY3hHviaVdpEpaFo5Rzwy3gjNYuR4D0RLxb0wZoDaGcPpKEW4C8yO/132'
    },
    group: '@county',
    place: '@county(true)'
  }))
}

export default {
  getList: () => {
    return {
      statusCode: 200,
      data: {
        data: List,
        total: count,
        current_page: current_page.current_page
      },
      message: {
        info: '成功'
      }
    }
  },
  getEngineerReviewInfo: () => {
    return {
      statusCode: 200,
      data: {
        user: user,
        evaluation: evaluation
      },
      message: {
        info: '成功'
      }
    }
  }
}
