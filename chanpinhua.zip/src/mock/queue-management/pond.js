import Mock from 'mockjs'

const List = []
const count = 20

for (let i = 0; i < count; i++) {
  List.push(Mock.mock({
    account: '@email',
    name: '@cname',
    business: '@csentence(2, 8)',
    group: '@county',
    role: '@pick(["管理员", "超级管理员", "主管", "经理", "CEO"])',
    place: '@county(true)'
  }))
}

const TypeList = []

for (let i = 0; i < count; i++) {
  TypeList.push(Mock.mock({
    id: '@natural(1, 100)',
    name: '@pick(["管理员", "超级管理员", "主管", "经理", "CEO"])',
    type: '@natural(1, 2)'
  }))
}

export default {
  getList: () => {
    return {
      statusCode: 200,
      data: List,
      message: {
        info: '成功'
      }
    }
  },
  getTypeList: () => {
    return {
      statusCode: 200,
      data: TypeList,
      message: {
        info: '成功'
      }
    }
  }
}
