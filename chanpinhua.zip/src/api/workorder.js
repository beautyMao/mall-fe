import request from '@/utils/request'

// 单据-故障标签-【列表展示】
export function getListMatching() {
  return request({
    url: `/api/wb/orderFaultLabel`,
    method: 'get'
  })
}

// 单据-故障标签-【修改】
export function putItemChange(id, data) {
  return request({
    url: `/api/wb/orderFaultLabel/${id}`,
    method: 'put',
    data
  })
}
// 全局配置-客户标签-【删除】
export function delItemDelete(id, data) {
  return request({
    url: `/api/wb/orderFaultLabel/${id}`,
    method: 'delete',
    data
  })
}

// 单据-故障标签-【创建】
export function postItemCreate(data) {
  return request({
    url: `/api/wb/orderFaultLabel`,
    method: 'post',
    data
  })
}

// 处理组【获取组织列表】
export function getOrganizationList() {
  return request({
    url: `/api/wb/handleGroup`,
    method: 'get'
  })
}

// 处理组【获取处理人员】
export function getConductor(data) {
  return request({
    url: `/api/wb/searchHandleEngineer?code=${data.code}&name=${data.name}`,
    method: 'get'
  })
}

// 处理组【添加人员】
export function postAddPerson(data) {
  return request({
    url: `/api/wb/handleGroup`,
    method: 'post',
    data
  })
}

// 处理组【删除组织问题分类下的配置人员】
export function delDeletePerson(data) {
  return request({
    url: `/api/wb/handleGroup/${data.group_id}`,
    method: 'delete',
    data
  })
}

// 处理组【获取组织问题分类下的配置人员】
export function getConductorList(group_id, problem_id, size, page) {
  return request({
    url: `/api/wb/handleGroup/${group_id}?group_id=${group_id}&problem_id=${problem_id}&size=${size}&page=${page}`,
    method: 'get'
  })
}
// 工单【工单列表】
export function getWorkorderList(data) {
  return request({
    url: `/api/wb/getOrderList?${data}`,
    method: 'get'
  })
}
//  工单【处理列表 查询客户】
export function getListCustomer(code) {
  return request({
    url: `/api/wb/serchCustom?code=${code}`,
    method: 'get'
  })
}

// 工单【工单详情】
export function getWorkorderParticulars(id) {
  return request({
    url: `/api/wb/workOrder/${id}`,
    method: 'get'
  })
}
// 工单【工单客户选择】
export function getSelectCustomer(data) {
  return request({
    url: `/api/wb/selectCustomer?customer_id=${data.customer_id}&name=${data.name}&phone=${data.phone}&email=${data.email}&perPage=${data.perPage}&page=${data.page}`,
    method: 'get'
  })
}
// 工单【添加工单】
export function postAddWorkorder(data) {
  // const data = new FormData()
  // for (const i in val) {
  //   if (i !== 'fault') {
  //     data.append(i, val[i])
  //   }
  // }
  // for (const i in val.fault) {
  //   //   if (i !== 'file' && i !== 'files') {
  //   //     data.append(i, val.fault[i])
  //   //   }
  //   //   if (i === 'files' && !val.fault[i].length) {
  //   //     data.append(i, val.fault[i])
  //   //   }
  //   //   if (i === 'file' && !val.fault[i].length) {
  //   //     data.append(i, val.fault[i])
  //   //   }
  //   // }
  // val.fault.file.forEach((item, index) => {
  //   data.append(`file[${index}][name]`, item.name)
  //   data.append(`file[${index}][url]`, item.url)
  // })
  // val.fault.files.forEach((item, index) => {
  //   data.append(`files[${index}]`, item)
  // })
  return request({
    url: `/api/wb/workOrder`,
    method: 'post',
    data
  })
}
// 工单【故障解决方案添加】
export function getAddScheme(data) {
  return request({
    url: `/api/wb/addSolution`,
    method: 'post',
    data
  })
}
// 工单【故障信息添加】
export function getAddFault(data) {
  return request({
    url: `/api/wb/addDescribe`,
    method: 'post',
    data
  })
}
// 工单【获取转派列表】
export function getRedeployList(order_group_Id, fault_label_id) {
  return request({
    url: `/api/wb/getTransferList?order_group_Id=${order_group_Id}&fault_label_id=${fault_label_id}`,
    method: 'get'
  })
}
// 工单【单据转派到工程师】/api/wb/transferOrderToEngineer
export function getRedeployEngineer(data) {
  return request({
    url: `/api/wb/transferOrderToEngineer`,
    method: 'post',
    data
  })
}
// 工单【单据 修改单据状态】
export function getStatusChange(data) {
  return request({
    url: `/api/wb/updateOrderStatus`,
    method: 'post',
    data
  })
}
// 工单【单据 升级单据】
export function postUpWorkorder(data) {
  return request({
    url: `/api/wb/upOrder`,
    method: 'post',
    data
  })
}
// 发送邮件
export function postHTMLEmail(data) {
  return request({
    url: `/api/wb/notification/htmlemail`,
    method: 'post',
    data
  })
}
