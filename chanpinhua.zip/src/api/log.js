import ElasticSearchClient from './elasticsearch'
import { getDatetime } from '../utils'
import jquery from 'jquery'

// ElasticSearchClient log
const esc = new ElasticSearchClient()
// defined in webpack git plugin
// const GIT_VERSION = VERSION.split('-')[0]
const GIT_VERSION = 'none'
const environment = process.env.VUE_APP_ENV_CONFIG

/**
 * es log
 * @param tag
 * @param data
 */
export function esLog(tag, data) {
  esc.push(tag, { data, version: GIT_VERSION, environment, post_date: getDatetime() })
}

export function initEsLog() {
  const $body = jquery('body')

  $body.on('click', '[data-eslog]', function() {
    let point = jquery(this).data('eslog') || jquery(this).attr('title') || jquery(this).text().trim()

    // 当埋点描述信息为空或者信息过长时
    if (!point && point.length > 20) {
      return
    }

    // 获取父级埋点定义，组合为 parent:subPoint
    const parentPoint = jquery(this).parents('[data-eslog-parent]').data('eslogParent')
    if (parentPoint && parentPoint.trim()) {
      point = `${point}:${parentPoint.trim()}`
    }
    esLog('click', { point })
  })
}
