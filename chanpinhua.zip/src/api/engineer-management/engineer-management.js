import request from '@/utils/request'

// 获取用图表
function getPiedata(businessID, accessID, cate, biz, channel, position) {
  return request({
    url: `/api/ccmc/engineer/breakdown?businessId=${businessID}&accessId=${accessID}&cate=${cate}&biz=${biz}&channel=${channel}&position=${position}`,
    method: 'get'
  })
}
// 获取工程师出勤状况
function getEngineerWorkStatus(businessID, accessID, cate, biz, channel, region, position) {
  return request({
    url: `/api/ccmc/engineer/attendance?businessId=${businessID}&accessId=${accessID}&cate=${cate}&biz=${biz}&channel=${channel}&region=${region}&position=${position}`,
    method: 'get'
  })
}
// 获取缺勤列表
function engineerAbsentList(businessID, accessID, cate, biz, channel, region, page, position) {
  return request({
    url: `/api/ccmc/engineer/absenteeism?businessId=${businessID}&accessId=${accessID}&cate=${cate}&biz=${biz}&channel=${channel}&region=${region}&page=${page}&page_size=4&position=${position}`,
    method: 'get'
  })
}
// 获取工程师的坐席状态
function getattendStatus(businessID, accessID, cate, biz, channel, region, position) {
  return request({
    url: `/api/ccmc/engineer/breakdown?businessId=${businessID}&accessId=${accessID}&cate=${cate}&biz=${biz}&channel=${channel}&region=${region}&position=${position}`,
    method: 'get'
  })
}
// 获取工程师信息
function getEngineerInfos(businessID, accessID, code) {
  return request({
    url: `/api/ccmc/engineer/profile?businessId=${businessID}&accessId=${accessID}&code=${code}`
  })
}
// 获取组的状态
function getGroupStatus(businessID, accessID, biz, channel, region, group, position) {
  return request({
    url: `/api/ccmc/engineer/breakdown?businessId=${businessID}&accessId=${accessID}&cate=status&biz=${biz}&channel=${channel}&region=${region}&group=${group}&position=${position}`
  })
}
// 获取缺勤列表
function getAbsenceList(businessID, accessID, page, strategy) {
  return request({
    url: `/api/ccmc/engineer/absenteeism_v?businessId=${businessID}&accessId=${accessID}&page=${page}&page_size=10&strategy=${strategy}`
  })
}
// 登记缺勤记录
function submitAbsenceList(businessID, accessID, param) {
  return request({
    url: `/api/ccmc/engineer/absenteeism_r?businessId=${businessID}&accessId=${accessID}`,
    method: 'post',
    data: param
  })
}
// 工程师名字搜索联动
function engineerNameSearch(businessID, accessID, q) {
  return request({
    url: `/api/ccmc/engineer/search?businessId=${businessID}&accessId=${accessID}&q=${q}`
  })
}
// 删除登记的工程师
function absenceEngineerDel(businessID, accessID, param) {
  return request({
    url: `/api/ccmc/engineer/absenteeism_d?businessId=${businessID}&accessId=${accessID}`,
    method: 'post',
    data: param
  })
}
// 配置计划在线人数
function setPlanPeople(businessID, accessID, param) {
  return request({
    url: `/api/ccmc/engineer/attendance_s?businessId=${businessID}&accessId=${accessID}`,
    method: 'post',
    data: param
  })
}
// 获取计划在线人数
function getPlanPeople(businessID, accessID) {
  return request({
    url: `/api/ccmc/engineer/attendance_p?businessId=${businessID}&accessId=${accessID}`
  })
}
export default {
  getPiedata,
  getEngineerWorkStatus,
  engineerAbsentList,
  getattendStatus,
  getEngineerInfos,
  getGroupStatus,
  getAbsenceList,
  submitAbsenceList,
  engineerNameSearch,
  absenceEngineerDel,
  setPlanPeople,
  getPlanPeople
}
