import { createResourceRequest } from '@/utils/request-rest'
import request from '@/utils/request'

/**
 * 标签管理api 客户标签
 * @type {Promise<any>|{post, (*, *=): *, get, (*): *, update, (*, *=): *, list, (): *, delete, (*): *}}
 */
export const customerTagRestApi = createResourceRequest('/api/wb/customerLabel')

export function putMoveNodeApi(id, data) {
  return request({
    url: `/api/wb/customerLabel/move/${id}`,
    method: 'put',
    data: data
  })
}

/**
 * 标签管理api  客服标签
 * @type {Promise<any>|{post, (*, *=): *, get, (*): *, update, (*, *=): *, list, (): *, delete, (*): *}}
 */
export const serviceTagRestApi = createResourceRequest('/api/wb/servicerLabel')

export function putServiceMoveNodeApi(id, data) {
  return request({
    url: `/api/wb/servicerLabel/move/${id}`,
    method: 'put',
    data: data
  })
}

// export function putAddNodeApi(data) {
//   return request({
//     url: `/api/wb/classifiedProblem`,
//     method: 'put',
//     data: data
//   })
// }
