// https://github.com/hmalphettes/log4js-elasticsearch/blob/master/lib/elasticsearch-client.js
// https://www.elastic.co/guide/en/elasticsearch/reference/current/docs-index_.html
import axios from 'axios'
import store from '@/store'

const ELASTICSEARCH_API_HOST = 'https://log.lenovo.com.cn'
const ELASTICSEARCH_API_PORT = '80'
const ELK_INDEX = 'engineer-client'

export default function ElasticSearchClient(options = {}) {
  this.host = options.host || ELASTICSEARCH_API_HOST
  this.port = options.port || ELASTICSEARCH_API_PORT
}

let numberOfErrorsReported = 5
// default error listener will report in the console 3 times
const errorDefaultListener = function(err) {
  if (numberOfErrorsReported) {
    console.log('Error %d occured while posting log to ES:', err)
    numberOfErrorsReported--

    if (numberOfErrorsReported === 0) {
      setTimeout(() => {
        numberOfErrorsReported = 3
      }, 10000)
    }
  }
}

ElasticSearchClient.prototype.push = function(typeName = 'api-send', data) {
  if (!numberOfErrorsReported) {
    return Promise.resolve('Error occured while posting log to ES')
  }

  const path = `${ELASTICSEARCH_API_HOST}/logging`
  const index = ELK_INDEX

  const engineerCode = store.state.user.allInfo.code
  const engineerName = store.state.user.allInfo.name

  data.type = typeName
  data.engineer = engineerCode
  data.engineerName = engineerName

  const params = {
    index, data, engineer: data.engineer, auth: 'xxx'
  }

  return axios({
    method: 'POST',
    url: path,
    data: params
  }).then(() => {
    numberOfErrorsReported = 5
  }).catch((error) => {
    errorDefaultListener(error)
  })
}
