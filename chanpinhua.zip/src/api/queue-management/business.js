import requestBase from '@/utils/request'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 业务【修改某个业务的信息】
export function putApiWbBusinessId(id, data) {
  return request({
    url: `/api/wb/business/${id}`,
    method: 'put',
    data
  })
}

// 业务【删除业务】
export function delApiWbBusinessId(id) {
  return request({
    url: `/api/wb/business/${id}`,
    method: 'delete'
  })
}

// 业务【新建业务】
export function postApiWbBusiness(data) {
  return request({
    url: `/api/wb/business`,
    method: 'post',
    data
  })
}

// 业务【获取所有业务】
export function getApiWbBusiness() {
  return request({
    url: `/api/wb/business`,
    method: 'get'
  })
}

// 业务【获取某个业务详情】
export function getApiWbBusinessId(id) {
  return request({
    url: `/api/wb/business/${id}`,
    method: 'get'
  })
}

// 业务【通过业务名称搜索业务】
export function getApiWbBusinessSearch(name) {
  return request({
    url: `/api/wb/business/search`,
    method: 'get',
    params: { name }
  })
}
