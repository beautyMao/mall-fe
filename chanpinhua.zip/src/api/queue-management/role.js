import requestBase from '@/utils/request'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 角色【获取角色列表】
export function getApiWbRole() {
  return request({
    url: '/api/wb/role',
    method: 'get'
  })
}

// 角色【删除角色】
export function delApiWbRoleId(id) {
  return request({
    url: `/api/wb/role/${id}`,
    method: 'delete'
  })
}

// 角色【修改角色】
export function putApiWbRoleId(id, data) {
  return request({
    url: `/api/wb/role/${id}`,
    method: 'put',
    data
  })
}

// 角色【新建角色】
export function postApiWbRole(data) {
  return request({
    url: `/api/wb/role`,
    method: 'post',
    data
  })
}

// 角色【获取角色详情】
export function getApiWbRoleId(id) {
  return request({
    url: `/api/wb/role/${id}`,
    method: 'get'
  })
}

// 角色【通过角色名称搜索角色】
export function getApiWbRoleSearch(name) {
  return request({
    url: `/api/wb/role/search`,
    method: 'get',
    params: { name }
  })
}
