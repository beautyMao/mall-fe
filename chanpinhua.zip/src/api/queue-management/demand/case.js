import requestBase from '@/utils/request'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 精确查询获取列表数据
export function getApiWbCaseSearch(params) {
  return requestBase({
    url: `/api/wb/case/search`,
    method: 'get',
    params
  })
}

// 获取 case 详情数据
export function getApiWbCaseSearchCaseId(case_id) {
  return request({
    url: `/api/wb/case/search/${case_id}`,
    method: 'get'
  })
}

// 问题分类-【列表展示】
export function getApiWbClassifiedProblem() {
  return request({
    url: `/api/wb/classifiedProblem`,
    method: 'get'
  })
}
