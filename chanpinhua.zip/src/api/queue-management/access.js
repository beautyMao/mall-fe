import requestBase from '@/utils/request'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 通路【获取通路列表】
export function getApiWbAccess() {
  return request({
    url: `/api/wb/access`,
    method: 'get'
  })
}

// 通路【获取不同类型下通路列表】
export function getApiWbAccessAccessesByTypeType(type) {
  return request({
    url: `/api/wb/access/accessesByType/${type}`,
    method: 'get'
  })
}

// 通路【删除通路】
export function delApiWbAccessId(id) {
  return request({
    url: `/api/wb/access/${id}`,
    method: 'delete'
  })
}

// 通路【修改某个通路的信息】
export function putApiWbAccessId(id, data) {
  return request({
    url: `/api/wb/access/${id}`,
    method: 'put',
    data
  })
}

// 通路【新建通路】
export function postApiWbAccess(data) {
  return request({
    url: `/api/wb/access`,
    method: 'post',
    data
  })
}

// 通路【获取某个通路详情】
export function getApiWbAccessId(id) {
  return request({
    url: `/api/wb/access/${id}`,
    method: 'get'
  })
}

// 通路【通过通路名称或通路标识搜索通路】
export function getApiWbAccessSearch(name) {
  return request({
    url: `/api/wb/access/search`,
    method: 'get',
    params: { name }
  })
}

// 通路【通过通路名称或通路标识搜索通路】
export function getAuthUrl(id) {
  return request({
    url: `/api/wb/access/${id}/wechat_auth_url`,
    method: 'get'
  })
}

