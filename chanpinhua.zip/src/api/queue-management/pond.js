import requestBase from '@/utils/request'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 队列【获取所有队列列表】
export function getApiWbQueue(page) {
  return request({
    url: '/api/wb/queue',
    method: 'get',
    params: { page }
  })
}

// 队列【删除队列】
export function delApiWbQueueId(id) {
  return request({
    url: `/api/wb/queue/${id}`,
    method: 'delete'
  })
}

// 队列【修改某个队列的信息】
export function putApiWbQueueId(id, data) {
  return request({
    url: `/api/wb/queue/${id}`,
    method: 'put',
    data
  })
}

// 队列【创建大队列】
export function postApiWbQueue(data) {
  return request({
    url: `/api/wb/queue`,
    method: 'post',
    data
  })
}

// 队列【获取某个大队列详情】
export function getApiWbQueueId(id) {
  return request({
    url: `/api/wb/queue/${id}`,
    method: 'get'
  })
}

// 队列【通过队列编号或名称搜索大队列】
export function getApiWbQueueSearch(name) {
  return request({
    url: `/api/wb/queue/search`,
    method: 'get',
    params: { name }
  })
}

// 队列【获取业务下大队列列表】
export function apiWbBusinessIdQueues(id) {
  return request({
    url: `/api/wb/business/${id}/queues`,
    method: 'get'
  })
}

// 队列【批量编辑队列】
export function putApiWbQueueBatchUpdate(data) {
  return request({
    url: `/api/wb/queue/batchUpdate`,
    method: 'put',
    data
  })
}

// 队列【批量编辑队列】
export function postApiWbQueueAccessBusinessQueues(data) {
  return request({
    url: `/api/wb/queue/accessBusinessQueues`,
    method: 'post',
    data
  })
}
