import requestBase from '@/utils/request'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 账号【获取客服账号列表】
export function getApiWbEngineer() {
  return request({
    url: '/api/wb/engineer',
    method: 'get'
  })
}

// 账号【编辑账号】
export function putApiWbEngineerId(id, data) {
  return request({
    url: `/api/wb/engineer/${id}`,
    method: 'put',
    data
  })
}

// 账号【获取客服账号详情】
export function getApiWbEngineerId(id) {
  return request({
    url: `/api/wb/engineer/${id}`,
    method: 'get'
  })
}

// 账号【搜索客服】
export function getApiWbEngineerSearch(name) {
  return request({
    url: `/api/wb/engineer/search`,
    method: 'get',
    params: { name }
  })
}

// 账号【获取客服的队列详情】
export function getApiWbEngineerCodeQueues(code) {
  return request({
    url: `/api/wb/engineer/${code}/queues`,
    method: 'get'
  })
}

// 账号【获取队列下客服列表】
export function getApiWbQueueIdEngineers(id) {
  return request({
    url: `/api/wb/queue/${id}/engineers`,
    method: 'get'
  })
}

