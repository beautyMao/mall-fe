import request from '@/utils/request'

// 账号【获取工程师账号列表】
export function getApiWbEngineerLocale() {
  return request({
    url: '/api/wb/engineerLocale',
    method: 'get'
  })
}

// 账号【搜索工程师账号列表】
export function getApiWbEngineerSearch(code) {
  return request({
    url: '/api/wb/engineerLocale/search',
    method: 'get',
    params: { code }
  })
}

// 账号【搜索工程师详情】
export function getApiWbEngineerSearchInfo(code) {
  return request({
    url: '/api/wb/engineerLocale/searchEngineer',
    method: 'get',
    params: { code }
  })
}

// 账号现场权限【新增/编辑】
export function postApiWbEngineerLocale(data) {
  return request({
    url: '/api/wb/engineerLocale',
    method: 'post',
    data
  })
}
