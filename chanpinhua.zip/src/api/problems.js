import { createResourceRequest } from '@/utils/request-rest'
import request from '@/utils/request'

/**
 * 问题分类api
 * @type {Promise<any>|{post, (*, *=): *, get, (*): *, update, (*, *=): *, list, (): *, delete, (*): *}}
 */
export const problemRestApi = createResourceRequest('/api/wb/classifiedProblem')

export function putMoveNodeApi(id, data) {
  return request({
    url: `/api/wb/classifiedProblem/move/${id}`,
    method: 'put',
    data: data
  })
}

export function putAddNodeApi(data) {
  return request({
    url: `/api/wb/classifiedProblem`,
    method: 'put',
    data: data
  })
}
