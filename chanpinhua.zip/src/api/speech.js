import requestBase from '@/utils/request'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 获取客服全部话术
export function getApiWbEngineerSpeech() {
  return request({
    url: '/api/wb/engineerTalk',
    method: 'get'
  })
}

// 获取客服全部子话术
export function getApiWbEngineerPersonalSpeech(param) {
  return request({
    url: `/api/wb/engineerChildrenTalks`,
    method: 'get',
    params: param
  })
}

// 新建客服话术
export function postApiWbEngineerSpeech(data) {
  return request({
    url: '/api/wb/engineerTalk',
    method: 'post',
    data
  })
}

// 批量删除话术
export function deleteApiWbEngineerBatchDelete(data) {
  return request({
    url: '/api/wb/engineerTalks/batchDestroy',
    method: 'delete',
    data
  })
}

// 单次删除话术
export function delApiWbEngineerSpeech(id) {
  return request({
    url: `/api/wb/engineerTalk/${id}`,
    method: 'delete'
  })
}

// 编辑客服话术
export function putApiWbEngineerSpeech(id, data) {
  return request({
    url: `/api/wb/engineerTalk/${id}`,
    method: 'put',
    data
  })
}
