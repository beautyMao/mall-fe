import requestBase from '@/utils/request'
import { createResourceRequest } from '@/utils/request-rest'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 全局配置-超时会话-【列表】
export function getConfigTimeoutSpeech(params) {
  return request({
    url: `/api/wb/configTimeoutSpeech`,
    method: 'get',
    params
  })
}

// 全局配置-空框会话-【列表】
export function getConfigSilentSpeech(params) {
  return request({
    url: `/api/wb/configSilentSpeech`,
    method: 'get',
    params
  })
}

// 全局配置-系统会话-【列表】
export function getConfigSystemSpeech(params) {
  return request({
    url: '/api/wb/configSystemSpeech',
    method: 'get',
    params
  })
}

export const configTimeoutSpeechRestApi = createResourceRequest('/api/wb/configTimeoutSpeech')
export const configSilentSpeechRestApi = createResourceRequest('/api/wb/configSilentSpeech')
export const configSystemSpeechRestApi = createResourceRequest('/api/wb/configSystemSpeech')

// 现场队列【获取通路业务下队列列表】
export function searchApiWbQueuesByBusiness(data) {
  return request({
    url: `/api/wb/queue/accessBusinessQueues`,
    method: 'post',
    data
  })
}
