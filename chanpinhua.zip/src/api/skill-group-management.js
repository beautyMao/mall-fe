import requestBase from '@/utils/request'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 队列【获取所有队列列表】
export function getApiWbQueue(page) {
  return request({
    url: '/api/wb/queue',
    method: 'get',
    params: { page }
  })
}

// 队列【删除队列】
export function delApiWbQueueId(id) {
  return request({
    url: `/api/wb/queue/${id}`,
    method: 'delete'
  })
}

// 队列【修改某个队列的信息】
export function putApiWbQueueId(id, data) {
  return request({
    url: `/api/wb/queue/${id}`,
    method: 'put',
    data
  })
}

// 队列【创建大队列】
export function postApiWbQueue(data) {
  return request({
    url: `/api/wb/queue`,
    method: 'post',
    data
  })
}

// 队列【获取某个大队列详情】
export function getApiWbQueueId(id) {
  return request({
    url: `/api/wb/queue/${id}`,
    method: 'get'
  })
}

// 业务【新建业务】
export function postApiWbBusiness(data) {
  return request({
    url: `/api/wb/business`,
    method: 'post',
    data
  })
}

// 通路【获取所有通路】
export function getAllAccess() {
  return request({
    url: `/api/wb/access`,
    method: 'get'
  })
}

// 队列【通过队列编号或名称搜索大队列】
export function getApiWbQueueSearch(name) {
  return request({
    url: `/api/wb/queue/search`,
    method: 'get',
    params: { name }
  })
}

// 队列【获取业务下大队列列表】
export function apiWbBusinessIdQueues(id) {
  return request({
    url: `/api/wb/business/${id}/queues`,
    method: 'get'
  })
}

// 队列【批量编辑队列】
export function putApiWbQueueBatchUpdate(data) {
  return request({
    url: `/api/wb/queue/batchUpdate`,
    method: 'put',
    data
  })
}

// 队列【批量编辑队列】
export function postApiWbQueueAccessBusinessQueues(data) {
  return request({
    url: `/api/wb/queue/accessBusinessQueues`,
    method: 'post',
    data
  })
}

// 队列【获取技能组下绑定的客服】
export function postApiSkillEngineers(params) {
  return request({
    url: `/api/wb/getSkillEngineers`,
    method: 'get',
    params
  })
}

// 队列【获取技能组下绑定的客服】
export function delApiWbQueueEngineerId(params) {
  return request({
    url: `/api/wb/queue/deleteEngineer`,
    method: 'delete',
    params
  })
}

// 业务【获取业务列表】
export function searchApiWbStructureBusiness() {
  return request({
    url: `/api/wb/structureBusiness?search=true`,
    method: 'get'
  })
}

// 客服【获取通过业务查询客服】
export function searchApiWbEngineersByBusiness(params) {
  return request({
    url: `/api/wb/business/engineers`,
    method: 'get',
    params
  })
}

// 队列【队列下添加客服】
export function postApiWbQueuesAddEngineers(data) {
  return request({
    url: `/api/wb/queue/addEngineers`,
    method: 'post',
    data
  })
}

// 账号-信息-搜索
export function getAccountSearch(data) {
  return request({
    url: `/api/cube/engineer/account/search`,
    method: 'post',
    data
  })
}

// 获取业务列表-组织结构
export function getStructureBusiness(params) {
  return request({
    url: `/api/wb/structureBusiness`,
    method: 'get',
    params
  })
}
