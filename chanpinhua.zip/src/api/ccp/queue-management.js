import request from '@/utils/request'

// 大队列 个人队列
export function getQueueInfo(accessId, businessId) {
  return request({
    url: `/api/ccmc/queue/info?access=${accessId}&business=${businessId}`,
    method: 'get'
  })
}

// 大队列 组队列
export function getInfo(accessId, businessId) {
  return request({
    url: `/api/ccmc/queue/person?access=${accessId}&business=${businessId}`,
    method: 'get'
  })
}

// 个人队列
export function EngineerInfo(accessId, businessId) {
  return request({
    url: `/api/ccmc/Queues/Engineer/List?access=${accessId}&business=${businessId}`,
    method: 'get'
  })
}

// 可接起case量
export function getCaseInfo(accessId, businessId) {
  return request({
    url: `/api/ccmc/receiveCase/canList?accessId=${accessId}&businessId=${businessId}`,
    method: 'get'
  })
}

// 下载表单
export function getDownloadFrom(accessId, businessId) {
  return request({
    url: `/api/ccmc/queue/exportExcel?accessId=${accessId}&businessId=${businessId}`,
    method: 'get'
  })
}
// 获取现场下工程师状态
export function getEngionFrom(accessId, businessId) {
  return request({
    url: `/api/ccmc/search/status/engineer?business=${businessId}&access=${accessId}&pluck=true`,
    method: 'get'
  })
}

