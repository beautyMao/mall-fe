import request from '@/utils/request'
// import { getQueryString } from '@/utils/index'
// const businessID = getQueryString('businessID')
// const accessID = getQueryString('accessID')
// 获取用户情感分类的数量
function getEmotionnums(businessID, accessID, date) {
  return request({
    url: `/api/ccmc/cs?businessId=${businessID}&accessId=${accessID}&date=${date}`,
    method: 'get'
  })
}
// 选择某个情感查看列表
function getEmotionList(businessID, accessID, type, date) {
  return request({
    url: `/api/ccmc/cs/chat/feed?businessId=${businessID}&accessId=${accessID}&sat=${type}&date=${date}`,
    method: 'get'
  })
}
// 情感分类
function getEmotionClassify(businessID, accessID, cate) {
  return request({
    url: `/api/ccmc/cs/breakdown/category?businessId=${businessID}&accessId=${accessID}&cate=${cate}`,
    method: 'get'
  })
}
// 根据select选择的值及来源显示，具体的愤怒值等
function getEmotionDetail(businessID, accessID, cate, source, code, date) {
  return request({
    url: `/api/ccmc/cs/breakdown?businessId=${businessID}&accessId=${accessID}&cate=${cate}&${source}=${code}&date=${date}`,
    method: 'get'
  })
}
// 根据select选的值获取愤怒的数据
function getEmotionnotatallList(businessID, accessID, cate, source, groups, date) {
  return request({
    url: `/api/ccmc/cs/breakdown/chat_feed?businessId=${businessID}&accessId=${accessID}&cate=${cate}&${source}=${groups}&sat=not_at_all&date=${date}`,
    method: 'get'
  })
}

// 获取聊天记录
function getAskList(businessID, accessID, id) {
  return request({
    url: `/api/ccmc/cs/chat/message?businessId=${businessID}&accessId=${accessID}&chat=${id}`,
    method: 'get'
  })
}

export default {
  getEmotionnums,
  getEmotionList,
  getEmotionClassify,
  getEmotionDetail,
  getEmotionnotatallList,
  getAskList
}
