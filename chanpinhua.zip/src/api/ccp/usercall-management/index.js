/*
* @Author: wuna
* @Date:   2018-10-25 15:43:01
* @Last Modified by:   wuna
* @Last Modified time: 2018-12-12 15:26:21
*/
import request from '@/utils/request'

// 来电量详情（包括累计来电量、时段来电量、预测来电量）
const userCallDetail = (data) => {
  // mode: endTime / nowTime
  data.sort = data.sort === '正' ? 0 : 1
  return request({
    url: `/api/ccmc/AbandonRate/Detail?access=${data.access}&business=${data.business}&sort=${data.sort}&mode=${data.mode}&date=${data.time ? data.time : ''}`,
    method: 'get'
  })
}

// 时段来电用户面板详情
const fetchUserLable = (data) => request({
  url: `/api/ccmc/AbandonRate/Label?access=${data.access}&business=${data.business}&interval=${data.interval}&type=${data.type}`,
  method: 'get'
})

// 累计来电用户面板详情
const fetchTotalUserLable = (data) => request({
  url: `/api/ccmc/AbandonRate/Label/Today?access=${data.access}&business=${data.business}`
})

// 预测校准list(按时段)
const fetchPredictiveCaliListByTime = (data) => request({
  url: `/api/ccmc/intoNum/guess/interval?access=${data.access}&business=${data.business}&sort=1&mode=nowTime&id=${data.id}`,
  method: 'get'
})

// 预测校准list（按天）
const fetchPredictiveCaliList = (data) => request({
  url: `/api/ccmc/intoNum/guess/day?access=${data.access}&business=${data.business}&sort=1`,
  method: 'get'
})

// 预测时段编辑
const fetchEditPredictiveCall = (data) => request({
  url: `/api/ccmc/intoNum/calibrator/interval`,
  method: 'post',
  data: data
})

// 预测时段 按天编辑
const fetchEditPredictiveCallDay = (data) => request({
  url: `/api/ccmc/intoNum/calibrator/day`,
  method: 'post',
  data: data
})

// 下载表单
const fetchdownForm = (data) => request({
  url: `/api/ccmc/AbandonRate/exportExcel?access=${data.access}&business=${data.business}&sort=1&mode=nowTime&date=${data.time ? data.time : ''}`,
  method: 'get'
})

export { userCallDetail, fetchUserLable, fetchTotalUserLable, fetchPredictiveCaliListByTime, fetchPredictiveCaliList, fetchEditPredictiveCall, fetchEditPredictiveCallDay, fetchdownForm }
