import request from '@/utils/request'
// 问题分类
export function threshold(businessId, accessId) {
  return request({
    url: `/api/ccmc/Threshold/QueueNumber?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
export function thresholdRobot(businessId, accessId) {
  return request({
    url: `/api/ccmc/Threshold/Robot?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
export function thresholdAbandon(businessId, accessId) {
  return request({
    url: `/api/ccmc/Threshold/Abandon?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
export function thresholdStatusTime(businessId, accessId) {
  return request({
    url: `/api/ccmc/Threshold/StatusTime?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
export function thresholdProblem(businessId, accessId) {
  return request({
    url: `/api/ccmc/Threshold/Problem?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
export function thresholdPickup(businessId, accessId) {
  return request({
    url: `/api/ccmc/Threshold/Pickup?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
export function UpdatethresholdPickup(data) {
  return request({ url: `/api/ccmc/Threshold/Pickup`, method: 'put', data }
  )
}
export function UpdatethresholdProblem(data) {
  return request({ url: `/api/ccmc/Threshold/Problem`, method: 'put', data }
  )
}
export function Updatethreshold(data) {
  return request({ url: `/api/ccmc/Threshold/QueueNumber`, method: 'put', data }
  )
}
export function UpdatethresholdAbandon(data) {
  return request({ url: `/api/ccmc/Threshold/Abandon`, method: 'put', data }
  )
}
export function UpdatethresholdRobot(data) {
  return request({ url: `/api/ccmc/Threshold/Robot`, method: 'put', data }
  )
}
export function UpdatethresholdStatusTime(data) {
  return request({ url: `/api/ccmc/Threshold/StatusTime`, method: 'put', data }
  )
}

