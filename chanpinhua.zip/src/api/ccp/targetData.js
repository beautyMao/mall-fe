import request from '@/utils/request'

// 问题分类
export function targetToday(businessId, accessId) {
  return request({
    url: `/api/ccmc/abandonTarget/targetToday?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
export function targetWeek(businessId, accessId) {
  return request({
    url: `/api/ccmc/abandonTarget/targetWeek?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
export function Updatetarget(data) {
  return request({ url: `/api/ccmc/abandonTarget/targetDate`, method: 'post', data }
  )
}
