import request from '@/utils/request'
import NProgress from 'nprogress'
import { Message } from 'element-ui'

export function shuffleRoute(to, from, next) {
  if (to.fullPath === '/devccp-management/actioncontrol/:id') { // 现场看板
    getEngineerLocales().then(res => {
      if (!res.data.length) {
        Message({
          showClose: true,
          message: '该账号未配置通路业务信息，无权限查看',
          type: 'warning'
        })
        NProgress.done()
      } else {
        if (from.fullPath === '/devccp-management/actioncontrol/' + res.data[0].value + res.data[0].children[0].value) {
          next(false)
        } else {
          next({
            path: '/devccp-management/actioncontrol/' + res.data[0].value + res.data[0].children[0].value,
            query: {
              businessID: res.data[0].value,
              business: res.data[0].label,
              accessID: res.data[0].children[0].value,
              access: res.data[0].children[0].label
            }
          })
        }
        // 结束顶部进度条
        NProgress.done()
      }
    })
  } else {
    next()
  }
}

export function targetDateRoute(to, from, next) {
  if (to.fullPath === '/devccp-management/targetDate/:id') {
    getEngineerLocales().then(res => {
      if (!res.data.length) {
        Message({
          showClose: true,
          message: '该账号未配置通路业务信息，无权限查看',
          type: 'warning'
        })
        NProgress.done()
      } else {
        if (from.fullPath === '/devccp-management/targetDate/' + res.data[0].value + res.data[0].children[0].value) {
          next(false)
        } else {
          next({
            path: '/devccp-management/targetDate/' + res.data[0].value + res.data[0].children[0].value,
            query: {
              businessID: res.data[0].value,
              business: res.data[0].label,
              accessID: res.data[0].children[0].value,
              access: res.data[0].children[0].label
            }
          })
        }
        NProgress.done()
      }
    })
  } else {
    next()
  }
}
export function ThresholdRoute(to, from, next) {
  if (to.fullPath === '/devccp-management/Threshold-settings/:id') {
    getEngineerLocales().then(res => {
      if (!res.data.length) {
        Message({
          showClose: true,
          message: '该账号未配置通路业务信息，无权限查看',
          type: 'warning'
        })
        NProgress.done()
      } else {
        if (from.fullPath === '/devccp-management/Threshold-settings/' + res.data[0].value + res.data[0].children[0].value) {
          next(false)
        } else {
          next({
            path: '/devccp-management/Threshold-settings/' + res.data[0].value + res.data[0].children[0].value,
            query: {
              businessID: res.data[0].value,
              business: res.data[0].label,
              accessID: res.data[0].children[0].value,
              access: res.data[0].children[0].label
            }
          })
        }
        NProgress.done()
      }
    })
  } else {
    next()
  }
}
// 缺勤配置页面路由重新跳转带业务id、通路id等
export function BusinessDeploy(to, from, next) {
  if (to.fullPath === '/business-configuration/business-deploy') {
    getEngineerLocales().then(res => {
      if (!res.data.length) {
        Message({
          showClose: true,
          message: '该账号未配置通路业务信息，无权限查看',
          type: 'warning'
        })
        NProgress.done()
      } else {
        if (from.fullPath === '/business-configuration/business-deploy') {
          next(false)
        } else {
          next({
            path: '/business-configuration/business-deploy',
            query: {
              businessID: res.data[0].value,
              business: res.data[0].label,
              accessID: res.data[0].children[0].value,
              access: res.data[0].children[0].label
            }
          })
        }
        // 结束顶部进度条
        NProgress.done()
      }
    })
  } else {
    next()
  }
}
// 预测校准页面路由重新跳转带业务id、通路id等
export function forecastCallDay(to, from, next) {
  if (to.fullPath === '/devccp-management/forecastCallDay') {
    getEngineerLocales().then(res => {
      if (!res.data.length) {
        Message({
          showClose: true,
          message: '该账号未配置通路业务信息，无权限查看',
          type: 'warning'
        })
        NProgress.done()
      } else {
        next({
          path: '/devccp-management/forecastCallDay',
          query: {
            businessID: res.data[0].value,
            business: res.data[0].label,
            accessID: res.data[0].children[0].value,
            access: res.data[0].children[0].label
          }
        })
        // 结束顶部进度条
        NProgress.done()
      }
    })
  } else {
    next()
  }
}
export function getEngineerLocales() {
  return request({
    url: `/api/ccmc/Engineer/Locales`,
    method: 'get'
  })
}

