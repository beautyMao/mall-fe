import request from '@/utils/request'

// 问题分类
export function getCaseClass(businessId, accessId) {
  return request({
    url: `/api/ccmc/robotManual/newCaseLabels?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 天气预警
export function getweatherWarn(businessId, accessId) {
  return request({
    url: `/api/ccmc/weather/warning?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
