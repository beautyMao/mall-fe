import request from '@/utils/request'

// 机器人转人工数据 机器人进入量 转人工量 机器人转人工率
export function getEnterInfo(accessId, businessId) {
  return request({
    url: `/api/ccmc/robotManual/accessCountByHour?accessId=${accessId}&businessId=${businessId}`,
    method: 'get'
  })
}

// 人工 饼图详情
export function getEnterInfo1(accessId, businessId) {
  return request({
    url: `/api/ccmc/robotManual/manualLabels?accessId=${accessId}&businessId=${businessId}`,
    method: 'get'
  })
}
// 机器人 饼图详情
export function getEnterInfo2(accessId, businessId) {
  return request({
    url: `/api/ccmc/robotManual/robotLabels?accessId=${accessId}&businessId=${businessId}`,
    method: 'get'
  })
}

// 历史数据
export function history(accessId, businessId) {
  return request({
    url: `/api/ccmc/robotManual/accessHistory?accessId=${accessId}&businessId=${businessId}`,
    method: 'get'
  })
}
