import request from '@/utils/request'
// 获取业务现场
export function EngineerLocales() {
  return request({
    url: `/api/ccmc/Engineer/Locales`,
    method: 'get'
  })
}

// 获取业务现场
export function getStatusCount(businessId, accessId) {
  return request({
    url: `/api/ccmc/engineer/status_count?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 当前现场平均排队时长
export function getLineupTime(businessId, accessId) {
  return request({
    url: `/api/ccmc/AbandonRate/Now/LineupTime?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 当前现场愤怒值
export function getNotAtAll(businessId, accessId) {
  return request({
    url: `/api/ccmc/cs/NotAtAll?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 当前现场排队量
export function getLineupNum(businessId, accessId) {
  return request({
    url: `/api/ccmc/AbandonRate/Now/LineupNum?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}

// 当前现场放弃率
export function getGaveupRate(businessId, accessId) {
  return request({
    url: `/api/ccmc/AbandonRate/Now/GaveupRate?businessId=${businessId}&accessId=${accessId}&mode=nowTime&sort=1`,
    method: 'get'
  })
}
// 当前现场放弃率
export function getPickupRate(businessId, accessId) {
  return request({
    url: `/api/ccmc/AbandonRate/Now/PickupRate?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 点评满意
export function getSatisfactionDegree(businessId, accessId) {
  return request({
    url: `/api/ccmc/engineer/comment/satisfaction_degree?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 问题分类
export function getNewCaseLabels(businessId, pro) {
  // return request({
  //   url: `/api/ccmc/robotManual/newCaseLabels?businessId=${businessId}&accessId=${accessId}`,
  //   method: 'get'
  // })
  let url = ''
  if (pro) {
    url += `&pro=${pro}`
  }
  return request({
    url: `/api/cube/ccp/case/labels?businessId=${businessId}${url}`,
    method: 'get'
  })
}

// 机器人转人工
export function getRobotManual(businessId, accessId) {
  return request({
    url: `/api/ccmc/robotManual/robotReport?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}

// 所有现场当前会话总数
export function getCount(businessId, accessId) {
  return request({
    url: `/api/ccmc/conversation/count?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}

// 本现场业务服务量
export function getLocalesCount(business, access) {
  return request({
    url: `/api/ccmc/conversation/locale_count?business_name=${business}&access_name=${access}`,
    method: 'get'
  })
}
// 本现场AHT
export function getAhtCount(businessId, accessId) {
  return request({
    url: `/api/ccmc/engineer/aht?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 本现场排队量
export function getQueuesCount(businessId, accessId) {
  return request({
    url: `/api/ccmc/Queues/Count?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 当前放弃率实时监控详情
export function getNowDetail(businessId, accessId) {
  return request({
    url: `/api/ccmc/AbandonRate/Now/Detail?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 满意度概况
export function getFeedDetail(businessId, accessId) {
  return request({
    url: `/api/ccmc/cs?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}

// 时段服务明细
export function getIntervalData(businessId, accessId) {
  return request({
    url: `/api/ccmc/intoNum/guess/interval?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 当前放弃率
export function getIntervalNowData(businessId, accessId) {
  return request({
    url: `/api/ccmc/AbandonRate/Now/Detail?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 地域来电分析
export function getPhoneCallData(businessId, accessId, cate = 'pro') {
  return request({
    url: `/api/ccmc/phone_call/breakdown?businessId=${businessId}&accessId=${accessId}&cate=${cate}`,
    method: 'get'
  })
}
// 机器人进入量及人工转化率
export function getBreakdown(businessId, accessId) {
  return request({
    url: `/api/ccmc/phone_call/breakdown?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 工程师管理面板
export function getOnlineEngineer(businessId, accessId) {
  return request({
    url: `/api/ccmc/engineer/online?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 队列员工状态
export function QueuesDate(businessId, accessId) {
  return request({
    url: `/api/ccmc/Queues/Count?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
export function AbandonRate(businessId, accessId) {
  return request({
    url: `/api/ccmc/AbandonRate/Dash?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 业务【获取所有业务】
export function getApiWbBusiness() {
  return request({
    url: `/api/wb/structureBusiness?search=1`,
    method: 'get'
  })
}
// 天气预警
export function getweatherWarn(businessId, accessId) {
  return request({
    url: `/api/ccmc/weather/warning?businessId=${businessId}&accessId=${accessId}`,
    method: 'get'
  })
}
// 服务量趋势
export function getBusinessesTrend(businessId, isExcel) {
  let downloadExcel = ''
  if (isExcel) {
    downloadExcel += `&isExcel=${isExcel}`
  }
  return request({
    url: `/api/cube/ccp/businessesTrend/getBusinessesTrend?businessId=${businessId}${downloadExcel}`,
    method: 'get'
  })
}
// 获取业务
export function getBusinessesList() {
  return request({
    url: `/api/cube/ccp/getBusinessesList`,
    method: 'get'
  })
}
// 看板配置
export function setConfigDashboard(para) {
  return request({
    url: `/api/wb/configDashboard/business`,
    method: 'post',
    data: para
  })
}
// 获取看板配置
export function getConfigDashboard(businesId) {
  return request({
    url: `/api/wb/configDashboard/business/${businesId}`,
    method: 'get'
  })
}
// 工程师状态信息统计
export function getEngineerStatus(businesId) {
  return request({
    url: `/api/cube/ccp/engineers/getEngineerStatus?businessId=${businesId}`,
    method: 'get'
  })
}
// 问题分类
export function getLabels(businesId, pro) {
  let pro_name = ''
  if (pro) {
    pro_name += `&pro=${pro}`
  }
  return request({
    url: `/api/cube/ccp/case/labels?businessId=${businesId}${pro_name}`,
    method: 'get'
  })
}
// SAAS - saas数据看板问题分类数据列表
export function getApiCubeCcpCaseLabelsList(params) {
  return request({
    url: `/api/cube/ccp/case/labelsList`,
    method: 'get',
    params
  })
}
// 机器人进入量及转人工率
export function getRobotReport(businesId) {
  return request({
    url: `api/cube/ccp/robotManual/robotReport?businessId=${businesId}`,
    method: 'get'
  })
}
// 机器人及人工每小时访问量
export function getAccessCountByHour(businesId) {
  return request({
    url: `/api/cube/ccp/robotManual/accessCountByHour?businessId=${businesId}`,
    method: 'get'
  })
}
// 获取机器人及人工访问历史记录
export function getAccessHistory(businesId) {
  return request({
    url: `/api/cube/ccp/robotManual/accessHistory?businessId=${businesId}`,
    method: 'get'
  })
}
// 地域来电分析
export function getWeatherBreakdown(businesId, pro) {
  let pro_name = ''
  if (pro) {
    pro_name += `&pro=${pro}`
  }
  return request({
    url: `/api/cube/ccp/weather/breakdown?businessId=${businesId}${pro_name}`,
    method: 'get'
  })
}
// 地区来电量趋势
export function getCallsbyhours(businesId, pro) {
  let pro_name = ''
  if (pro) {
    pro_name += `&pro=${pro}`
  }
  return request({
    url: `/api/cube/ccp/weather/callsbyhours?businessId=${businesId}${pro_name}`,
    method: 'get'
  })
}
// 全国天气监控
export function getWarning(businesId) {
  return request({
    url: `/api/cube/ccp/weather/warning?businessId=${businesId}`,
    method: 'get'
  })
}
// 客服明细
export function getCustomerDetails(params) {
  return request({
    url: `/api/cube/ccp/customerDetails/getCustomerDetails`,
    method: 'get',
    params
  })
}
// 首页服务数据
export function getServiceData(businesId) {
  return request({
    url: `/api/cube/ccp/index/getServiceData?businessId=${businesId}`,
    method: 'get'
  })
}
// 首页重要业务数据
export function getMainBusinessData(businesId) {
  return request({
    url: `/api/cube/ccp/index/getMainBusinessData?businessId=${businesId}`,
    method: 'get'
  })
}
// 首页重要业务数据
export function getEmotionData(businesId) {
  return request({
    url: `/api/cube/ccp/emotion/get?businessId=${businesId}`,
    method: 'get'
  })
}
// 客服明细
export function getQueueDetails(params) {
  return request({
    url: `/api/cube/ccp/queueDetails/getQueueDetails`,
    method: 'get',
    params
  })
}

// SAAS - saas数据看板情感数据列表
export function getApiCubeCcpEmotionGetEmotionsList(params) {
  return request({
    url: '/api/cube/ccp/emotion/getEmotionsList',
    method: 'get',
    params
  })
}

// SAAS - saas数据看板情感趋势
export function getApiCubeCcpEmotionGetEmotionsByHours(params) {
  return request({
    url: '/api/cube/ccp/emotion/getEmotionsByHours',
    method: 'get',
    params
  })
}

// SAAS - saas数据看板用户情感占比
export function getApiCubeCcpEmotionGet(params) {
  return request({
    url: '/api/cube/ccp/emotion/get',
    method: 'get',
    params
  })
}

// WB_QUEUE_MANAGE - 【查询会话列表】
export function getApiCubeCcpSessionSearch(params) {
  return request({
    url: '/api/cube/ccp/session/search',
    method: 'get',
    params
  })
}

// WB_QUEUE_MANAGE - saas数据看板会话详情
export function getApiCubeCcpSessionInfo(params) {
  return request({
    url: '/api/cube/ccp/session/info',
    method: 'get',
    params
  })
}

// WB_QUEUE_MANAGE - saas数据看板会话记录下载
export function getApiCubeCcpSessionExcel(params) {
  return request({
    url: '/api/cube/ccp/session/excel',
    method: 'get',
    params
  })
}
