import request from '@/utils/request'
// 队列选择
export function queueItems(businessID, accessID) {
  return request({
    url: `/api/ccmc/search/queue?business=${businessID}&access=${accessID}`,
    method: 'get'
  })
}
// 小组信息
export function groupItems(businessID, accessID) {
  return request({
    url: `/api/ccmc/search/group?business=${businessID}&access=${accessID}`,
    method: 'get'
  })
}
// 工作状态
export function workStatus(businessID, accessID) {
  return request({
    url: `/api/ccmc/search/work/status?business=${businessID}&access=${accessID}`,
    method: 'get'
  })
}
// 个性化查询
export function customeSearch(params) {
  return request({
    url: `/api/ccmc/search/status/engineer`,
    method: 'get',
    params
  })
}
// 个性化查询-排队时长
export function queueDurationSearch(params) {
  return request({
    url: `/api/ccmc/search/queue/user`,
    method: 'get',
    params
  })
}
// 个性化查询-饼图
export function getCaseChart(params) {
  return request({
    url: `/api/ccmc/trouble/breakdown`,
    method: 'get',
    params
  })
}
// 现场队列【获取通路业务下队列列表】
export function getQueuesFromAccess(data) {
  return request({
    url: `/api/wb/queue/accessBusinessQueues`,
    method: 'post',
    data
  })
}
// 获取当前现场排队数
export function getCurrentSceneQueueNums(accessID, bussinessID) {
  return request({
    url: `/api/ccmc/engineer/pickup/getLineupByLocale?access=${accessID}&business=${bussinessID}`,
    method: 'get'
  })
}
// 获取当前现场工程师列表
export function getCurrentSceneEngineerNums(accessID, bussinessID, keyword) {
  return request({
    url: `/api/ccmc/engineer/pickup/getEngineerInfoList?access=${accessID}&business=${bussinessID}&keyword=${keyword}`,
    method: 'get'
  })
}
// 添加pickup请求
export function addPickUp(data) {
  return request({
    url: `/api/ccmc/engineer/pickup/addEngineerPickupLineInfo`,
    method: 'post',
    data
  })
}
// 获取通路下的队列列表
export function getCurrentSceneQueueList(data) {
  return request({
    url: `/api/wb/queue/accessBusinessQueues`,
    method: 'post',
    data
  })
}
// // 获取借出反馈
// export function getLendFeedback(data) {
//   return request({
//     url: `/api/ccmc/engineer/transfer/applyIn`,
//     method: 'get',
//     data
//   })
// }
// 获取人力收回申请
export function getEngineerRecallMsg(accessID, bussinessID) {
  return request({
    url: `/api/ccmc/engineer/transfer/applyRecall?access=${accessID}&business=${bussinessID}`,
    method: 'get'
  })
}
// 同意人力收回申请
export function agreeBackApplication(data) {
  return request({
    url: `/api/ccmc/engineer/transfer/agreeRecall`,
    method: 'post',
    data
  })
}
// 拒绝申请
export function refuseBackApplication(data) {
  return request({
    url: `/api/ccmc/engineer/transfer/refuse`,
    method: 'post',
    data
  })
}
// 获取收回人力回复
export function getReclaimReply(accessId, businessId) {
  return request({
    url: `/api/ccmc/engineer/transfer/repliedRecall?access=${accessId}&business=${businessId}`,
    method: 'get'
  })
}
// 获取借出反馈
export function getBorrowFeedBack(accessId, businessId) {
  return request({
    url: `/api/ccmc/engineer/transfer/applyIn?access=${accessId}&business=${businessId}`,
    method: 'get'
  })
}
// 确认接收
export function confirmReceive(data) {
  return request({
    url: `/api/ccmc/engineer/transfer/agreeIn`,
    method: 'post',
    data
  })
}
// 当前现场人力缺口
export function currentScenePersonStatus(params) {
  return request({
    url: `/api/ccmc/personnel/control/getLocaleEvaluate`,
    method: 'get',
    params
  })
}
// 天气预警分布
export function getWeatherDistribute(params) {
  return request({
    url: `/api/ccmc/weather/warning`,
    method: 'get',
    params
  })
}
// 来电拆分
export function getProvinceCallPercent(params) {
  return request({
    url: `/api/ccmc/phone_call/breakdown`,
    method: 'get',
    params
  })
}
// 来电故障拆分
export function getProvinceCallCasePercent(params) {
  return request({
    url: `/api/ccmc/phone_call/trouble/breakdown`,
    method: 'get',
    params
  })
}
