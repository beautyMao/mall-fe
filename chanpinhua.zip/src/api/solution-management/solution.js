import request from '@/utils/request'

// 超期提醒
export function documentReminder(params) {
  return request({
    url: `/api/wb/documentReminder`,
    method: 'post',
    data: params
  })
}

// 判断客服是否处于pickup状态
export function getPickupStatus(code) {
  return request({
    url: `/api/ccmc/isPickup?engineer_code=${code}`,
    method: 'get'
  })
}
