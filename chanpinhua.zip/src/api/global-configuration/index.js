import { createResourceRequest } from '@/utils/request-rest'
import request from '@/utils/request'

/**
 * 全局配置 点评api
 * @type {Promise<any>|{post, (*, *=): *, get, (*): *, update, (*, *=): *, list, (): *, delete, (*): *}}
 */
export const reviewConfRestApi = createResourceRequest('/api/wb/configComment')

export const reviewConfStatusRestApi = createResourceRequest('/api/wb/configCommentStatus')

export function getReviewConfAccessListApi(id) {
  return request({
    url: `/api/wb/configCommentAccessList?accessType=${id}`,
    method: 'get'
  })
}

export function deleteReviewConfAccessListApi(data) {
  return request({
    url: `/api/wb/configCommentBantchDelete`,
    method: 'delete',
    data
  })
}
