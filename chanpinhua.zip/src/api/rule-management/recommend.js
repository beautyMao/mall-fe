import request from '@/utils/request'

//  全局配置-全局开关-【获取】
export function getSwitch(data = 'matchingLabelRule') {
  return request({
    url: `/api/wb/configGlobalSwitch/switch?key_name=${data}`,
    method: 'get'
  })
}
//  全局配置-全局开关-【修改】
export function getSwitchChange(data) {
  return request({
    url: `/api/wb/configGlobalSwitch/switch`,
    method: 'put',
    data
  })
}

// 全局配置-客户标签与客服标签匹配规则-【移动】
export function getMove(id, data) {
  return request({
    url: `/api/wb/matchingLabelRule/move/${id}`,
    method: 'put',
    data
  })
}

//  客户标签-【列表展示】
export function getMatchingLabelRule() {
  return request({
    url: '/api/wb/matchingLabelRule',
    method: 'get'
  })
}

//  批量创建
export function getBatchMatchingLabelRule(data) {
  return request({
    url: '/api/wb/batchMatchingLabelRule',
    method: 'post',
    data
  })
}

// 批量修改
export function getBatchChange(data) {
  return request({
    url: '/api/wb/batchMatchingLabelRule',
    method: 'put',
    data
  })
}
// 批量删除
export function getBatchDelete(data) {
  return request({
    url: '/api/wb/batchMatchingLabelRule',
    method: 'delete',
    data
  })
}

//  客户list
export function getCustomerLabel() {
  return request({
    url: '/api/wb/customerLabel',
    method: 'get'
  })
}
// 客服list
export function getServicerLabel() {
  return request({
    url: '/api/wb/servicerLabel',
    method: 'get'
  })
}

