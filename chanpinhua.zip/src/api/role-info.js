import request from '@/utils/request'

//  角色列表
export function getRoleList(data) {
  return request({
    url: `/api/cube/engineer/role/lists?${data}`,
    method: 'get'
  })
}

//  角色删除
export function getRoleDelete(data) {
  return request({
    url: `/api/cube/engineer/role/delete`,
    method: 'post',
    data
  })
}

//  角色编辑
export function getRoleEdit(data) {
  return request({
    url: `/api/cube/engineer/role/edit`,
    method: 'post',
    data
  })
}

//  权限列表
export function getLimitsList() {
  return request({
    url: `/api/cube/engineer/permission/lists`,
    method: 'get'
  })
}

//  角色新增
export function getCreateRole(data) {
  return request({
    url: `/api/cube/engineer/role/create`,
    method: 'post',
    data
  })
}

//  角色详情
export function getRoleDetail(id) {
  return request({
    url: `/api/cube/engineer/role/info?id=${id}`,
    method: 'get'
  })
}
