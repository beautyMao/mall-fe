import request from '@/utils/request'

// 全局配置-企业信息-【修改】
export function getConfigCompanyInfo(data) {
  return request({
    url: `/api/wb/configCompanyInfo/1`,
    method: 'put',
    data
  })
}
// 全局配置-企业信息-【单条记录】
export function getConfigCompanyInfo1(data) {
  return request({
    url: `/api/wb/configCompanyInfo/1`,
    method: 'get'
  })
}
// 公共维护 保存
export function postNoticeMaintain(data) {
  return request({
    url: `/api/wb/maintenance`,
    method: 'post',
    data
  })
}
// 公共维护 获取
export function getNoticeMaintain() {
  return request({
    url: `/api/csc/maintenance`,
    method: 'get'
  })
}
// 常见问题-【修改】
export function postCommonProblem(data) {
  return request({
    url: `/api/wb/commonProblem`,
    method: 'post',
    data
  })
}
// 常见问题-【获取】
export function getCommonProblem() {
  return request({
    url: `/api/csc/commonProblem`,
    method: 'get'
  })
}
//  轮播图-【获取】
export function getBanner() {
  return request({
    url: `/api/csc/banner`,
    method: 'get'
  })
}
// 轮播图-【更改】
export function putChangeBanner(id, data) {
  return request({
    url: `/api/wb/banner/${id}`,
    method: 'put',
    data
  })
}
// 轮播图-【删除】
export function getDelBanner(id) {
  return request({
    url: `/api/wb/banner/${id}`,
    method: 'delete'
  })
}
// 轮播图-【添加】
export function postAddBanner(data) {
  return request({
    url: `/api/wb/banner`,
    method: 'post',
    data
  })
}
