import requestBase from '@/utils/request'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 业务【获取业务列表-组织结构】
export function getApiWbStructureBusiness(params) {
  return request({
    url: '/api/wb/structureBusiness',
    method: 'get',
    params
  })
}

// 业务【新建业务-组织结构】
export function postApiWbStructureBusiness(data) {
  return request({
    url: '/api/wb/structureBusiness',
    method: 'post',
    data
  })
}

// 业务【编辑业务-组织结构】
export function putApiWbStructureBusiness(id, data) {
  return request({
    url: `/api/wb/structureBusiness/${id}`,
    method: 'put',
    data
  })
}

// 业务【删除业务-组织结构】
export function delApiWbStructureBusiness(id) {
  return request({
    url: `/api/wb/structureBusiness/${id}`,
    method: 'delete'
  })
}

// 账号【获取客服列表】
export function getApiWbEngineerList(params) {
  return request({
    url: `/api/wb/engineerList`,
    method: 'get',
    params
  })
}

// 获取角色列表
export function getApiCubeEngineerRoleLists(params) {
  return request({
    url: `/api/cube/engineer/role/lists`,
    method: 'get',
    params
  })
}

// 账号【客服列表导出】
export function postApiWbEngineerExport(data) {
  return request({
    url: `/api/wb/engineerExport`,
    method: 'post',
    data
  })
}

// 角色-信息-删除
export function postApiCubeEngineerAccountDelete(data) {
  return request({
    url: `/api/cube/engineer/account/delete`,
    method: 'post',
    data
  })
}
