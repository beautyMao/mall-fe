import requestBase from '@/utils/request'
import { CUBE } from '@/configuration'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

// 上传图片
export const upLoadImg = CUBE.api.oss

// 客服状态切换
export function engineerStatus(engineer_code, prev_stat, current_stat) {
  return request({
    url: '/api/wb/engineer/workUpdate',
    method: 'get',
    params: {
      engineer_code,
      prev_stat,
      current_stat,
      type: 1
    }
  })
}

// 顶部--客服状态获取
export function getEngStatus() {
  return request({
    url: `/api/wb/engineer/currentStatus`,
    method: 'get'
  })
}

// 客服累计状态时间获取
export function getEngStatusTime() {
  return request({
    url: `/api/wb/engineer/todayWorkTime`,
    method: 'get'
  })
}

// 获取七牛上传token
export function getQiniuUpToken() {
  return request({
    url: '/api/wb/qiniu/token',
    method: 'post'
  })
}

// 网络延迟获取
export function getNetStatusPing() {
  return request({
    url: '/api/wb/netstatus/ping',
    method: 'get',
    vuexLoading: false
  })
}

// 获取客服权限
export function getLoginPermission() {
  // return Promise.resolve({
  //   data
  // })
  return request({
    url: '/api/cube/engineer/account/permissions',
    method: 'get'
  })
}

// 获取版本号
export function getVersion() {
  return request({
    url: `/api/csc/hasnewversion`,
    method: 'get'
  })
}

// 获取历史版本信息
export function getVersionHistory() {
  return request({
    url: `/api/csc/versions`,
    method: 'get'
  })
}
