import requestBase from '@/utils/request'
import { createResourceRequest } from '@/utils/request-rest'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}
// 知识库分类
export const configClassifiedKnowledgeRestApi = createResourceRequest('/api/wb/classifiedKnowledge')
export const configKnowledgeRestApi = createResourceRequest('/api/wb/knowledgeBase')

// 知识库分类【添加分类】
export function searchApiWbClassifiedKnowledge(params) {
  return request({
    url: `/api/wb/classifiedKnowledge`,
    method: 'get',
    params
  })
}

// 知识库分类【获取问题下文章列表】
export function searchApiWbClassifiedKnowledgeById(id, params) {
  return request({
    url: `/api/wb/classifiedKnowledge/${id}`,
    method: 'get',
    params
  })
}

// 知识库分类【获取问题下文章列表】
export function getApiWbClassifiedKnowledge(id) {
  return request({
    url: `/api/wb/classifiedKnowledge/${id}`,
    method: 'get'
  })
}

// 知识库【添加文章】
export function postApiWbKnowledgeBase(params) {
  return request({
    url: `/api/wb/knowledgeBase`,
    method: 'post',
    params
  })
}

// 知识库【文章移动】
export function postApiMoveArticle(params) {
  return request({
    url: `/api/wb/moveArticle`,
    method: 'post',
    params
  })
}

// 知识库分类【批量删除问题分类】
export function commitDeleteBatchClassifiedKnowledge(params) {
  return request({
    url: `/api/wb/batchClassifiedKnowledge`,
    method: 'delete',
    params
  })
}

// 知识库分类【批量删除文章】
export function commitDeletBatchKnowledgeArticle(params) {
  return request({
    url: `/api/wb/batchKnowledgeArticle`,
    method: 'delete',
    params
  })
}

// 知识库【文章移动】
export function commitRemoveBatchKnowledgeArticle(params) {
  return request({
    url: `/api/wb/moveArticle`,
    method: 'post',
    params
  })
}

