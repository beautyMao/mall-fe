import { createResourceRequest } from '@/utils/request-rest'
import request from '@/utils/request'

/**
 * CRM 用户相关API
 * @type {Promise<any>|{post, (*, *=): *, get, (*): *, update, (*, *=): *, list, (): *, delete, (*): *}}
 */
export const customerRestApi = createResourceRequest('/api/crm/customer')

/**
 * 导入用户，excel
 * @return {Promise<any>}
 * @param file
 */
export function customerImport(file) {
  const data = new FormData()
  data.append('excel', file, file.name)
  return request({
    url: `/api/crm/import`,
    method: 'post',
    data: data,
    timeout: 3 * 60 * 1000
  })
}

export function customerExport(query) {
  return request({
    url: `/api/crm/export`,
    method: 'post',
    responseType: 'blob',
    data: query
  })
}

/**
 * 获取错误报告下载链接
 * @param key
 * @return {string}
 */
export function getErrorReportLink(key) {
  return request({
    url: `/api/crm/error_report?key=${key}`,
    method: 'get'
  })
}
