import requestBase from '@/utils/request'
import { createResourceRequest } from '@/utils/request-rest'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}
// 质检规则【列表展示】
export const configQualityTestingRulesRestApi = createResourceRequest('/api/wb/qualityTestingRules')
export const configKnowledgeRestApi = createResourceRequest('/api/wb/knowledgeBase')

// 质检规则【列表展示】
export function getQualityTestingRules(params) {
  return request({
    url: `api/wb/qualityTestingRules`,
    method: 'get',
    params
  })
}

// 质检规则【是否启用】
export function getTriggerIsUse(id) {
  return request({
    url: `/api/wb/qualityTestingRules/triggerIsUse/${id}`,
    method: 'get'
  })
}

// 知识库分类【获取问题下文章列表】
export function getApiWbClassifiedKnowledge(id) {
  return request({
    url: `/api/wb/classifiedKnowledge/${id}`,
    method: 'get'
  })
}

// 知识库【添加文章】
export function postApiWbKnowledgeBase(params) {
  return request({
    url: `/api/wb/knowledgeBase`,
    method: 'post',
    params
  })
}

// 知识库【文章移动】
export function postApiMoveArticle(params) {
  return request({
    url: `/api/wb/moveArticle`,
    method: 'post',
    params
  })
}

// 知识库分类【批量删除问题分类】
export function commitDeleteBatchClassifiedKnowledge(params) {
  return request({
    url: `/api/wb/batchClassifiedKnowledge`,
    method: 'delete',
    params
  })
}

// 知识库分类【批量删除文章】
export function commitDeletBatchKnowledgeArticle(params) {
  return request({
    url: `/api/wb/batchKnowledgeArticle`,
    method: 'delete',
    params
  })
}

// 知识库【文章移动】
export function commitRemoveBatchKnowledgeArticle(params) {
  return request({
    url: `/api/wb/moveArticle`,
    method: 'post',
    params
  })
}

