import request from '@/utils/request'

// 账号-信息-搜索open
export function getAccountSearch1(data) {
  return request({
    url: `/api/open/cube/engineer/password/search`,
    method: 'post',
    data
  })
}

// 获取业务通路
export function getBusinessInfo() {
  return request({
    url: `api/wb/access`,
    method: 'get'
  })
}

//  获取点评列表 is_excel 字段为是否导出字段
export function getServiceJudgeInfo(data) {
  return request({
    url: `api/wb/comment/search?${data}`,
    method: 'get'
  })
}
// 详情
export function getDetailInfo(id) {
  return request({
    url: `api/wb/comment/search/${id}`,
    method: 'get'
  })
}

