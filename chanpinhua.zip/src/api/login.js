import request from '@/utils/request'

export function login(engineer_code, password, captcha) {
  if (process.env.VUE_APP_ENV_CONFIG === 'dev') captcha = 'C1U3B3E4'
  return request({
    url: '/api/login',
    method: 'post',
    data: {
      engineer_code,
      password,
      captcha
    }
  })
}

/**
 * 客服登出
 * @param phone_sys_sessid 如果有电话的话（可选）
 * @return {Promise<any>}
 */
export function engineerLogout(phone_sys_sessid) {
  const params = {}
  if (phone_sys_sessid) {
    params.phone_sys_sessid = phone_sys_sessid
  }
  return request({
    url: `/api/wb/engineer/reset`,
    method: 'get',
    params
  })
}

// 获取工程师信息，当前状态和im 签名等
export function getInfo() {
  return request({
    url: `/api/wb/engineer/info`,
    method: 'get'
  })
}
