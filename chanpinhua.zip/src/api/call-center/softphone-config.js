const BJ = {
  api: 'https://cube.lenovo.com.cn/cti/',
  name: '北京',
  routers: {
    agent: '7631030',
    conferenceTransfer: '7631010',
    transfer: '7631008',
    satisfy: '7631040'
  },
  prefix: {
    '南京': '07'
  }
}

const NJ = {
  api: 'https://cubectinj.lenovo.com.cn/',
  name: '南京',
  routers: {
    agent: '7631130',
    conferenceTransfer: '7631110',
    transfer: '7631110',
    satisfy: '7631140'
  },
  prefix: {
    '北京': '87'
  }
}

/**
 * 两地各自部署了独立的sip server
 *
 * @param location
 * @return {{prefix: {}, name: string, api: string, routers: {agent: string, transfer: string, satisfy: string, conferenceTransfer: string}}}
 */
export const getConfig = function(location) {
  if (location === '南京') {
    return NJ
  }
  return BJ
}
