import Vue from 'vue'
import get from 'lodash.get'
import { wsHeartBeat } from '@/api/call-center/softphone'
import { MessageType, ErrorCode } from '@call/voice/enum'
import Message from '@/utils/message-intercept'
import { isProd } from '@/utils'
import { getConfig } from '@/api/call-center/softphone-config'

// const protocol = window.location.protocol === 'http:' ? 'ws://' : 'wss://'
const protocol = 'wss://'
const LOG_NAME = '[softphone ws log]'
const eventHub = new Vue()

let baseUrl
let wsUrl

/**
 * @type WebSocket
 */
let websocket
let wsPromise
let timer
let closeFlag = false
const heartBeatLoop = 30 * 1000
const config = {
  sessionId: null,
  loginCode: null,
  place: null,
  api: null
}

/**
 * 关于【事件缓冲池】：
 * 事件间隔时间太短，sip 事件顺序偶尔会导致系统不稳定
 * 所以这里将信赖事件里的referenceId，在前端做事件缓冲池，通过referenceId 重新整理顺序
 * 500ms的缓冲基本上足够抹平这些乱序了
 * @type {Array}
 */
const eventPool = []

/**
 * 接口中的所有请求都是异步操作的。当发送请求，可以获取状态和响应码
 * 但是该状态和响应码只是表明服务端已经开始处理请求，
 * 但是服务端后的状态将会以cometd/websocket 的方式将event传给前端。
 *
 * 初始化软电话的websokect
 * 1、接收来电推送
 * 2、每执行一个动作接口，相应的会收到动作执行后的反馈
 * 3、保持心跳
 * 4、每次连接只能保持一分钟，之后需要重新连接
 * @param sessionId
 * @param loginCode
 * @param place
 * @param location
 * @return Promise<Vue>
 */
function init({ sessionId, loginCode, place, location }) {
  if (!sessionId || !place) {
    return Promise.reject('软电话条session 错误，不能初始化')
  }

  config.sessionId = sessionId
  config.loginCode = loginCode
  config.place = place
  config.api = getConfig(location).api
  baseUrl = config.api.split('//')[1]
  wsUrl = `${protocol}${baseUrl}websocket/softphone/`

  wsPromise = reConnect()
  return wsPromise
}

function reConnect() {
  websocket = new WebSocket(wsUrl + config.sessionId)
  timer && clearInterval(timer)

  websocket.onerror = (error) => {
    console.log(LOG_NAME, error)
    eventHub.$emit('error', error)
  }
  // 每隔1min 会自动断开一次
  websocket.onclose = () => {
    if (!closeFlag) {
      reConnect()
    }
  }

  websocket.onmessage = (event) => {
    if (event.data === 'heartCheck') {
      return
    }

    console.log(LOG_NAME, event.data)
    const msg = JSON.parse(event.data)

    // 事件已读
    if (msg.referenceId) {
      retrunAckMsg(msg.referenceId)
    }

    // 由event pool 去emit
    addPool(msg)
  }

  return new Promise(resolve => {
    websocket.onopen = () => {
      timer = setInterval(() => {
        sendHeartBeat(config.loginCode, config.place)
      }, heartBeatLoop)
      sendHeartBeat(config.loginCode, config.place)

      resolve(eventHub)
    }
  })
}

// 添加到事件池里，emit 将在这里延迟500ms 之后发出
function addPool(event) {
  eventPool.push(event)
  if (eventPool.length) {
    eventPool.sort((a, b) => {
      return a.referenceId - b.referenceId
    })
  }

  setTimeout(() => {
    if (eventPool.length) {
      const msg = eventPool.shift()
      const type = get(msg, 'data.messageType') ? get(msg, 'data.messageType') : get(msg, 'messageType')
      if (type) {
        eventHub.$emit(type, msg, type)
        logMessage(type, msg)
      }
    }
  }, 500)
}

function destroy() {
  if (websocket) {
    closeFlag = true
    websocket.close()
  }
  timer && clearInterval(timer)

  // 为工具提供入口
  return eventHub
}

function sendHeartBeat(loginCode, place) {
  if (websocket && websocket.readyState === WebSocket.OPEN) {
    wsHeartBeat(loginCode, place).catch(error => {
      console.log(LOG_NAME, 'heartCheck error', error)
    })
    websocket.send('heartCheck')
  } else {
    console.log(LOG_NAME, 'websocket is not ready for heart check.')
  }
}

// 回复ack信息
function retrunAckMsg(referenceId) {
  if (websocket) {
    if (websocket.readyState === 1) {
      websocket.send(JSON.stringify({
        EventName: 'EventAck',
        referenceId
      }))
    }
  }
}

// 开发和测试环境，记录话机状态变更历史
function logMessage(type, msg) {
  if (type === MessageType.ErrorMessage) {
    Message({
      message: 'Error: ' + (ErrorCode[msg.errorCode] || msg.errorMessage),
      type: 'softphone'
    })
  } else {
    Message({
      message: [
        '<b>messageName</b>=' + get(msg, 'data.messageName', ''),
        '<b>displayName</b>=' + get(msg, 'data.devices[0].userState.displayName', ''),
        '<b>otherDn</b>=' + get(msg, 'data.otherDn', ''),
        '<b>connId</b>=' + get(msg, 'data.call.connId', ''),
        '<b>transferConnId</b>=' + get(msg, 'data.call.transferConnId', ''),
        '<b>VirualQueue</b>=' + get(msg, 'data.call.userData.VirualQueue', ''),
        '<b>callType</b>=' + get(msg, 'data.call.callType', '')
      ].join('; '),
      type: 'softphone',
      dangerouslyUseHTMLString: true,
      hide: isProd
    })
  }
}

/**
 * 添加消息监听
 * @param type
 * @param func
 */
function addEventListener(type, func) {
  eventHub.$on(type, func)
}

/**
 * 移除消息监听
 * @param type
 * @param func
 */
function removeEventListener(type, func) {
  eventHub.$off(type, func)
}

export default {
  init, addEventListener, removeEventListener, destroy, addPool
}
