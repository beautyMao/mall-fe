import request from '@/utils/request'

const defaultConfig = { showLoading: true }

// 获取签名
export function getSign(identifier) {
  return request({
    url: `/api/csc/ucenter/userSig?identifier=${identifier}`,
    method: 'get'
  })
}

// 获取会话列表
export function getCaseList(engineerCode) {
  return request({
    url: `/api/csc/caseList?engineer_code=${engineerCode}`,
    method: 'get'
  })
}

// 获取历史聊天内容
export function getHistory(caseid, cube_uid) {
  return request({
    url: `/api/csc/session/messages/${caseid}`,
    method: 'get',
    params: {
      cube_uid,
      pageSize: 1000
    }
  })
}

// 获取会话详情
export function getCaseInfo(sessionid) {
  return request({
    url: `api/csc/caseInfoByid?id=${sessionid}`,
    method: 'get'
  })
}

// 获取一个用户所有的case list
export function getAllSessions(cube_uid) {
  return request({
    url: `/api/csc/session/sessionList?cube_uid=${cube_uid}`,
    method: 'get'
  })
}

// 获取一个用户的sessionlist
export function getSessionsList(cube_uid, page, per_page) {
  return request({
    url: `/api/csc/session/sessionList?cube_uid=${cube_uid}&page=${page}&per_page=${per_page}`,
    method: 'get'
  })
}

/**
 * 结束会话
 * @param id
 * @param isAuto
 */
export function endConversation(id, isAuto = '') {
  return request({
    url: '/api/csc/session/close',
    method: 'get',
    params: {
      id,
      close_type: isAuto
    },
    defaultConfig
  })
}

/**
 * 创建服务记录
 * @param session_id
 * @param case_id
 * @param classified_problem_id 问题分类 （分类id 以、号分隔 如1、2、3）
 * @param problem_description
 * @param fileMeta
 * @param files
 * @return {Promise<any>}
 */
export function createCase({ session_id, case_id, classified_problem_id, problem_description, fileMeta, files }) {
  const data = new FormData()
  case_id && data.append('case_id', case_id)
  data.append('session_id', session_id)
  data.append('classified_problem_id', classified_problem_id)
  data.append('problem_description', problem_description)
  fileMeta.forEach((item, index) => {
    data.append(`file[${index}][file_name]`, item.file_name)
    data.append(`file[${index}][file_url]`, item.file_url)
  })
  files.forEach((item, index) => {
    data.append(`files[${index}]`, item)
  })

  return request({
    url: '/api/wb/case/create',
    method: 'post',
    data
    // data: { case_id, classified_problem_id, problem_description, file: fileMeta, files }
  })
}

/**
 * 查询用户的服务记录
 * @return {Promise<any>}
 * @param code_customer
 * @param query
 */
export function getUserCases(code_customer, query) {
  const params = {
    code_customer,
    size: 50
  }
  if (query) {
    params.query = query
  }
  return request({
    url: '/api/wb/case/search',
    method: 'get',
    params
  })
}

/**
 * 获取case 记录 详情
 * @param case_id
 * @return {Promise<any>}
 */
export function getUserCaseInfo(case_id) {
  return request({
    url: `/api/wb/case/search/${case_id}`,
    method: 'get'
  })
}

/**
 * 接触记录条件查询
 * @param cube_uid
 * @param client_type
 * @param page_size
 * @return {Promise<any>}
 */
export function getIRList(cube_uid, client_type = 'webchat', page_size = 200) {
  return request({
    url: `/api/wb/IR/GetIRListByQC`,
    method: 'post',
    data: {
      cube_uid, client_type, page_size
    }
  })
}

/**
 * 获取用户信息
 * @param cube_uid
 * @param customer_uid
 * @return {Promise<any>}
 */
export function getUserInfo({ cube_uid, customer_uid }) {
  return request({
    url: '/api/wb/user/info',
    method: 'get',
    params: {
      cube_uid,
      customer_uid
    }
  })
}

/**
 * 查询用户列表
 * @return {Promise<any>}
 * @param params
 */
export function queryUserList(params) {
  return request({
    url: '/api/wb/user/select',
    method: 'get',
    params
  })
}

/**
 * 绑定用户
 * @param cube_uid
 * @param customer_uid
 * @return {Promise<any>}
 */
export function bindUserInfo(cube_uid, customer_uid) {
  return request({
    url: '/api/wb/user/bind',
    method: 'post',
    data: { cube_uid, customer_uid }
  })
}

/**
 * 用户注册
 * 仅限于对接lenovo 体系使用
 * @example
 * {
 "CubeUID":"12313",
    "CustomerName": "戎青松",
    "Sex": "1",
    "Mobile": "15901180405",
    "CompanyName": "",
    "Status": "1",
    "RegisteredLenovoID": 1,
    "UpdateBy": "A06886",
    "SourceFlag": "15",
    "IsMassage": 0
}
 * @param data
 * @return {Promise<any>}
 */
export function userRegistration(data) {
  return request({
    url: '/api/wb/user/register',
    method: 'post',
    data
  })
}

/**
 * 更新用户
 * @param data
 * @return {Promise<any>}
 */
export function userUpdateInfo(data) {
  return request({
    url: '/api/wb/user/update',
    method: 'post',
    data
  })
}

// 获取客服服务量和排队量
export function getEngineerQueueNum(engineerCode) {
  return request({
    url: `/api/csc/queue/userNumber?engineer_code=${engineerCode}`,
    method: 'get',
    vuexLoading: false
  })
}

// 获取业务列表
export function businessList(queue_type = 1) {
  return request({
    url: `/api/wb/business`,
    method: 'get',
    params: {
      queue_type
    }
  })
}

// 获取业务下队列列表
export function businessQueue(id, type = 1) {
  return request({
    url: `/api/wb/business/${id}/queues`,
    method: 'get',
    params: {
      type
    }
  })
}

// 获取业务下队列列表
export function telBusinessQueue(id) {
  return request({
    url: `/api/wb/phone/business/${id}/queues`,
    method: 'get'
  })
}

// 转接-查询个人队列队列
export function transPersonQueue(engineerCode, query) {
  return request({
    url: `/api/wb/searchTransferEngineer?name=${query}&code=${engineerCode}`,
    method: 'get'
  })
}

// 转接-搜索队列
export function transSearchBigQueue(name, sourceType = 1) {
  return request({
    url: `/api/wb/transferQueue/search`,
    method: 'get',
    params: {
      name,
      sourceType
    }
  })
}

// 转接-获取队列下的客服列表
export function transferEngneersList(code, engineer_code) {
  return request({
    url: `/api/wb/queue/onlineEengineer?skill=${code}&engineer_code=${engineer_code}`,
    method: 'get'
  })
}

// 转接-个人队列转接
export function personTransfer(session_id, queue_code, engineer_code) {
  const params = {
    session_id,
    queue_code,
    engineer_code
  }
  return request({
    url: `/api/csc/queue/transferPersonal`,
    method: 'post',
    data: params,
    defaultConfig
  })
}

// 转接-队列转接
export function queueTransfer(session_id, queue_code, engineer_code) {
  const params = {
    session_id,
    queue_code,
    engineer_code
  }
  return request({
    url: `/api/csc/queue/transferBigQueue`,
    method: 'post',
    data: params,
    defaultConfig
  })
}

/**
 * 智能推荐
 * @param question
 * @param sessionId
 * @return {Promise<any>}
 */
export function getAnswerRecommend(question, sessionId) {
  return request({
    url: '/api/wb/robot/answerRecommend',
    method: 'get',
    params: {
      terminal: 'web',
      platform: 'engineer',
      question, sessionId
    }
  })
}

// 推送消息--发送短信
export function sendMsg(paras) {
  return request({
    url: `/api/wb/notification/SMS`,
    method: 'post',
    data: paras
  })
}

// 推送消息--长链接转短链接
export function transferShortURL(url, type = 'baidu') {
  return request({
    url: '/api/wb/shortLink',
    method: 'get',
    params: { url, type }
  })
}

// 推送消息--发送邮件
export function sendEmail(paras) {
  return request({
    url: `/api/wb/notification/email`,
    method: 'post',
    data: paras
  })
}

// 创建IR
export function createIR(data) {
  return request({
    url: `/api/wb/IR/CreateIR`,
    method: 'post',
    data
  })
}

// 获取客服话术列表
export function enginneerTalkList() {
  return request({
    url: `/api/wb/engineerTalk`,
    method: 'get'
  })
}

// 获取客服个人或者子集话术列表
export function engineerPartList(id, page, pagesize) {
  return request({
    url: `/api/wb/engineerTalks?id=${id}&page=${page}&pagesize=${pagesize}`,
    method: 'get'
  })
}

// 后台配置-文本会话超时配置【根据队列code获取超时会话记录】
export function getTimeoutReplay(queueCode) {
  return request({
    url: `/api/wb/getTimeoutAndSilentSpeech/${queueCode}`,
    method: 'get'
  })
}

export function getEngineerDetails(engineerCode) {
  return request({
    url: `/api/wb/engineer/${engineerCode}`
  })
}

/**
 * 给用户打标签
 * @param cube_uid
 * @param customer_uid
 * @param customer_label_id 所组成的数组 ｛ "cube_uid":"Orz5d099d93953af_n1I1zOPamVU", "customer_uid":"ohP4Z6Dtj9J8cqdX10_6Pst8FeyA", "customer_label_id":[1,2] ｝
 * @return {Promise<any>}
 */
export function giveCustomerLabel(cube_uid, customer_uid = '', customer_label_id) {
  return request({
    url: '/api/wb/giveCustomerLabel',
    method: 'put',
    data: {
      cube_uid, customer_uid, customer_label_id
    }
  })
}

/**
 * 获取用户标签
 * @param cube_uid
 */
export function getCustomerLabel(cube_uid) {
  return request({
    url: '/api/wb/getCustomerLabel',
    method: 'get',
    params: { cube_uid }
  })
}

// "engineer_code": "X01228",
// "cube_uid": "Orz5d130a07af8b7_IVP9BtUQTBH",
// "session_id": "4r0jo3BZ-BL",
// "customer_id": "10091749773",
// "queue_id": "1",
// "access_id": "9"
/**
 * 给用户发送邀评
 * todo 是否可以简化参数？
 * @return {Promise<any>}
 */
export function inviteComment(session) {
  return request({
    url: '/api/wb/inviteComment',
    method: 'post',
    data: {
      'engineer_code': session.engineer_code,
      'cube_uid': session.cube_uid,
      'session_id': session.id,
      'access_id': session.access_id
    }
  })
}

/**
 * 检查当前会话是否发起过邀评
 * @param sessionId
 * @return {Promise<any>}
 */
export function checkInviteComment(sessionId) {
  return request({
    url: `/api/wb/inviteComment/${sessionId}`,
    method: 'get'
  })
}

/**
 * 知识库查询
 * @param name
 * @param page
 * @param size
 * @return {Promise<any>}
 */
export function knowledgeBaseSearch(name, page = 1, size = 10) {
  return request({
    url: '/api/wb/searchArticleContent',
    method: 'get',
    params: { name, page, size }
  })
}
