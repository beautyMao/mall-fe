import requestBase from '@/utils/request'
// import { getFirstAskOrderList } from '@/api/solution-management/solution'
import { getToken } from '@/utils/auth'

const request = config => {
  config.timeout = 10 * 1000
  return requestBase(config)
}

/**
 * 获取当前客服的分机号
 * @returns {Promise}
 */
export function getPhoneEngineerDnno() {
  return request({
    url: 'api/wb/phone/engineer/DnNo',
    method: 'get'
  })
}

/**
 * 获取目标客服的号码、location 和在线状态
 * @param engineerCode
 * @return {Promise<any>}
 */
export function getTargetPhoneEngineerDnno(engineerCode) {
  return request({
    url: `/api/wb/phone/engineer/${engineerCode}/dnInfo`,
    method: 'get'
  })
}

/**
 * 天气预报
 * @export
 * @param {*} data
 * @returns {Promise}
 */
export function getApiWbWeatherForecast(data) {
  return request({
    url: `/api/wb/weather/forecast`,
    method: 'get',
    params: data
  })
}

/**
 * 服务量
 * @export
 * @param engineer_code
 * @returns {Promise}
 */
export function getApiCscServiceDetails(engineer_code) {
  return request({
    url: `/api/wb/phone/serviceDetails`,
    method: 'get',
    params: {
      engineer_code
    }
  })
}

/**
 * 记录 HOLD 量
 * @export
 * @param {*} data
 * @returns
 */
export function getApiCscPhoneHoldOperation(data) {
  return request({
    url: `/api/wb/phone/holdOperation`,
    method: 'post',
    data
  })
}

/**
 * 获取电话归属地的特殊提醒
 * @export
 * @param {*} params
 * @returns
 */
export function getApiWbPhoneSpecialReminder(params) {
  return request({
    url: `/api/wb/phone/specialReminder`,
    method: 'get',
    params
  })
}

/**
 * 获取分机号的归属地
 * @export
 * @returns
 * @param dnNo
 */
export function getApiWbPhoneDninfoDnNo(dnNo) {
  return request({
    url: `/api/wb/phone/dninfo/${dnNo}`,
    method: 'get'
  })
}

/**
 * 获取分机号的归属地
 * @export
 * @returns
 * @param phone
 */
export function getApiWbPhonePhoneLocation(phone) {
  return request({
    url: `/api/wb/phone/phoneLocation`,
    method: 'get',
    params: {
      phone
    }
  })
}

/**
 * 发起转接队列
 * @return {Promise}
 * @param data
 */
export function postApiWbPhoneTransfer(data) {
  return request({
    url: `/api/wb/phone/transfer`,
    method: 'post',
    data
  })
}

/**
 * 获取客服电话的服务列表
 * @export
 * @param {*} engineer_code
 * @returns
 */
export function geApiWbPhoneEngineerServiceLog(engineer_code) {
  return request({
    url: `/api/wb/phone/engineerServiceLog`,
    method: 'get',
    params: {
      engineer_code
    }
  })
}

// 登录成功后初始化客服的工作台
export function getApiWbPhoneInitializeEngineer() {
  return request({
    url: `/api/wb/engineer/initialize`,
    method: 'get'
  })
}

// 客服登出
export function phoneEngineerLogout(phone_sys_sessid) {
  const params = {}
  if (phone_sys_sessid) {
    params.phone_sys_sessid = phone_sys_sessid
  }
  return request({
    url: `/api/wb/engineer/reset`,
    method: 'get',
    params
  })
}

/**
 * 同步的
 * 客服登出，用于浏览器关闭
 * @param phone_sys_sessid
 */
export function syncEngineerLogout(phone_sys_sessid) {
  const url = [
    '/api/wb/engineer/reset',
    phone_sys_sessid ? `?phone_sys_sessid=${phone_sys_sessid}` : ''
  ].join('')
  const client = new XMLHttpRequest()
  client.open('GET', url, false)
  // config.headers['Authorization'] = `Bearer ${getToken()}`
  client.setRequestHeader('Content-Type', 'text/plain;charset=UTF-8')
  client.setRequestHeader('Authorization', `Bearer ${getToken()}`)
  client.send()
}

// 通过code或者电话获取客服基本信息
export function getPhoneEngineerInfo(params) {
  return request({
    url: `/api/wb/phone/searchEngineerInfo`,
    method: 'get',
    params
  })
}

/**
 * 开始一通会话
 * 振铃事件后调用，用于更新会话状态或是会话数据不漏操作
 * @example
 * {
    "calling_phone":"15210148765",
    "called_phone":"4001312321"
    "skill":"Q101",
    "conn_id":"xxxxx",
    "engineer_code":'A05246',
    "hit":"true"
}
 */
export function startPhoneConversion({ calling_phone, called_phone, skill, conn_id, engineer_code }) {
  return request({
    url: `/api/wb/phone/start/conversation`,
    method: 'post',
    data: {
      calling_phone, called_phone, skill, conn_id, engineer_code,
      hit: true
    }
  })
}

/**
 * 电话台客服外呼
 * @param calling_phone
 * @param called_phone
 * @param conn_id
 * @param engineer_code
 * @param business
 */
export function startCalloutConversion({ calling_phone, called_phone, conn_id, engineer_code, skill }) {
  return request({
    url: `/api/wb/phone/callout`,
    method: 'post',
    data: {
      calling_phone, called_phone, conn_id, engineer_code, skill
    }
  })
}

/**
 * 关闭一通电话
 * @param sessionId
 * @param type 关闭会话接口 type 会话类型： 呼入结束：callin 或 呼出结束：callout
 * @param is_transfer_satisfaction 是否转接满意度 true 或者 false 默认为false
 */
export function closePhoneConversion(sessionId, type, is_transfer_satisfaction = false) {
  return request({
    url: `/api/wb/phone/closePhoneSession`,
    method: 'post',
    data: {
      type,
      is_transfer_satisfaction,
      session_id: sessionId
    }
  })
}

/**
 * 电话通路退出排队通知
 * 调用场景：转接用户，在队列里等待，未接起前，用户挂断。
 * @param conn_id
 */
export function phoneQuitNotify(conn_id) {
  return request({
    url: '/api/phone/quit/notify',
    method: 'post',
    data: {
      conn_id
    }
  })
}

// 搜索转接的客服
export function searchPhoneEngineer(name, engineer_code) {
  return request({
    url: `api/wb/phone/skill/searchEngineer`,
    method: 'get',
    params: {
      name, engineer_code
    }
  })
}

// 转接-查询电话个人下的客服
export function getApiWbPhoneSkillSearchEngineer(name, code, transferSteps) {
  return request({
    url: `/api/wb/phone/skill/searchEngineer?name=${name}&engineer_code=${code}&transferSteps=${transferSteps}`,
    method: 'get'
  })
}

// 转接-电话客服列表接口
// todo skill: "The skill may only contain letters and numbers."
export function getApiWbPhoneSkillEngineerList(code, engineer_code, transferSteps) {
  return request({
    url: `/api/wb/phone/skill/engineerList?skill=${code}&engineer_code=${engineer_code}&transferSteps=${transferSteps}`,
    method: 'get'
  })
}

/**
 * 客服状态切换 type = 2 控制客服在魔方系统里的电话状态
 * @param engineer_code
 * @param prev_stat
 * @param current_stat
 */
export function engineerStateUpdate(engineer_code, prev_stat, current_stat) {
  return request({
    url: `/api/wb/engineer/workUpdate`,
    method: 'get',
    params: {
      engineer_code,
      prev_stat,
      current_stat,
      type: 2
    }
  })
}

/**
 * 客服重连话机
 * 对魔方系统无副作用的重连接口，用于当前ws session 失效的情况
 */
export function engineerReconnect() {
  return request({
    url: '/api/wb/phone/engineer/reconnect',
    method: 'get'
  })
}

/**
 * 在多次登录、不同浏览器下重复登录所导致的session 失效
 * 检查当前软电话条的SessionId是否有效
 * 魔方系统会存储最后一次有效session
 * @example
 *   {
        "statusCode": 200,
        "message": {
          "info": "Success"
        },
        "data": {
          "valid": true// true为有效, false为无效
        }
    }
 */
export function engineerSessionCheck() {
  return request({
    url: '/api/wb/phone/engineer/genesysid/check',
    method: 'get'
  })
}

/**
 * PHONE_CHAT - 【记录转接微信code码】
 * @export
 * @param {*} lenovo_id
 * @param {*} session_id
 * @param {*} phone
 * @returns
 */
export function postApiWbPhoneRecordTransferCode(lenovo_id, session_id, phone) {
  return request({
    url: '/api/wb/phone/recordTransferCode',
    method: 'post',
    data: lenovo_id ? {
      session_id,
      phone,
      lenovo_id
    } : {
      session_id,
      phone
    }
  })
}
