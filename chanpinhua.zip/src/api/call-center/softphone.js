import axios from 'axios'
import loadingIntercept from '@/utils/axios-interceptor/loading-vuex'
import { getTelToken } from '@/utils/auth'
import { StatusCode } from '@/store/modules/call-center/voice/enum'
import { getConfig } from '@/api/call-center/softphone-config'

let sessionId
let wrapedService
/**
 * {{prefix: {}, name: string, api: string, routers: {agent: string, transfer: string, satisfy: string, conferenceTransfer: string}}}
 */
let config

/**
 * 软电话条请求统一处理
 * @param config
 * @return {Promise}
 */
const request = function(config) {
  const wrapConfig = {
    ...config,
    method: 'post',
    timeout: 5 * 1000,
    // 关闭了vuex api loading 功能
    vuexLoading: false
  }
  return wrapedService(wrapConfig)
}

/**
 * 根据location 初始化请求Service，目前区分北京和南京 sip server
 * @param location
 */
export function initService(location) {
  config = getConfig(location)

  const service = axios.create({
    baseURL: config.api,
    timeout: 5 * 1000,
    headers: {
      'Content-Type': 'application/json',
      'charset': 'utf-8'
    }
  })
  service.interceptors.response.use(response => {
    if (response.data.statusCode !== '0') {
      return Promise.reject(StatusCode[response.data.statusCode] || response.data)
    }
    return response.data
  })
  wrapedService = loadingIntercept(service)
}

/**
 * 初始化session
 * @param place
 * @param loginCode
 * @param password
 * @param isForceLogin
 * @return {Promise}
 */
export function startContactCenterSession(place, loginCode, password = '123', isForceLogin = 0) {
  return request({
    url: '/api/v1/me',
    data: {
      operationName: 'StartContactCenterSession',
      place,
      loginCode,
      password,
      isForceLogin,
      channels: ['voice'],
      queue: ''
    }
  }).then(response => {
    sessionId = response.sessionId
    return sessionId
  })
}

/**
 * 坐席心跳包
 * @param loginCode
 * @param place
 * @return {Promise}
 */
export function wsHeartBeat(loginCode, place) {
  return request({
    url: `/api/v1/me/heart/${place}/${loginCode}`,
    method: 'get'
  })
}

/**
 * 通用动作
 * @param operationName
 * @param data
 * @return {Promise}
 */
function channelOperation(operationName, data = {}) {
  return request({
    url: `/api/v1/me/channel/voice/${getTelToken().id}`,
    data: {
      operationName,
      channel: 'voice',
      ...data
    }
  })
}

function callsOperation(operationName, data = {}) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName,
      ...data
    }
  })
}

/**
 * 签入动作
 * @return {Promise}
 */
export function online() {
  return channelOperation('Online')
}

/**
 * 签出
 * @return {Promise}
 */
export function offline() {
  return channelOperation('Offline')
}

/**
 * 就绪
 * @return {Promise}
 */
export function ready() {
  return channelOperation('Ready')
}

/**
 * 未就绪
 * @return {Promise}
 */
export function notReady() {
  return channelOperation('NotReady')
}

/**
 * 针对魔方开始一通会话时话机状态需要置为not ready
 * 附带随路数据用来区分，不在魔方中同步到CCP
 * @return {Promise}
 */
export function notReadyForConversion() {
  return channelOperation('NotReady', {
    reasonCode: 50
  })
}

/**
 * 小休
 * @return {Promise}
 */
export function auxWork() {
  return channelOperation('AuxWork')
}

/**
 * 案面
 * @return {Promise}
 */
export function afterCallWork() {
  return channelOperation('AfterCallWork')
}

/**
 * 添加随路数据
 * @param connId
 * @param userData
 * @return {Promise}
 */
export function attachUserData(connId, userData) {
  return callsOperation('AttachUserData', { userData, connId })
}

/**
 * 更新随路数据
 * @param connId
 * @param userData
 * @return {Promise}
 */
export function updateUserData(connId, userData) {
  return callsOperation('UpdateUserData', { userData, connId })
}

/**
 * 删除随路数据
 * @param userData
 * @return {Promise}
 * @param connId
 */
export function deleteUserData(connId, { type, key }) {
  return callsOperation('DeleteUserData', { type, key, connId })
}

/**
 * 外拨电话
 * @param phoneNumber
 * @param userData
 * @param extensions
 * @return {Promise}
 */
export function dialCall(phoneNumber, userData = { v_calltype: '3' }, extensions = { customelevel: '1', customelevel1: '2', customelevel2: '3' }) {
  return request({
    url: `/api/v1/me/devices/${getTelToken().id}/calls`,
    data: {
      operationName: 'Dial',
      userData,
      destination: {
        phoneNumber
      },
      extensions
    }
  })
}

/**
 * 接听电话
 * @param connId
 * @return {Promise}
 */
export function answerCall(connId) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'Answer',
      connId
    }
  })
}

/**
 * 挂断电话
 * @param connId
 * @return {Promise}
 */
export function hangup(connId) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'Hangup',
      connId
    }
  })
}

/**
 * 保持电话
 * @param connId
 * @param userData
 * @return {Promise}
 */
export function holdCall(connId, userData) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'Hold',
      connId,
      userData
    }
  })
}

/**
 * 保持取回
 * @param connId
 * @return {Promise}
 */
export function retrieveCall(connId) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'Retrieve',
      connId
    }
  })
}

/**
 * 拒接电话
 * @param connId
 * @param userData
 * @return {Promise}
 */
export function rejectCall(connId, userData) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'Reject',
      connId,
      userData
    }
  })
}

/**
 * 发起单步会议请求
 * @param phoneNumber 电话号码
 * @param connId 会话id
 * @param userData 添加随路数据
 * @return {Promise}
 */
export function singleStepConference(phoneNumber, connId, userData) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'SingleStepConference',
      destination: {
        phoneNumber
      },
      connId,
      userData
    }
  })
}

/**
 * initiateConference 发起开始两步会议请求
 * 该操作会使用当前的call变成hold状态,同时发起一个新的dailing的呼叫。
 * 当完成该操作之后，需要发起CompleteConference完成会议，将目标资源会议到当前的呼叫中。
 * @param phoneNumber
 * @param connId
 * @param userData
 * @return {Promise}
 */
export function initiateConference(phoneNumber, connId, userData) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'InitiateConference',
      destination: {
        phoneNumber
      },
      connId,
      userData
    }
  })
}

/**
 * SingleStepTransfer 发起转接
 * @param connId
 * @param phoneNumber
 * @return {Promise}
 */
export function telTransfer(connId, phoneNumber) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'SingleStepTransfer',
      connId,
      destination: {
        phoneNumber
      }
    }
  })
}

/**
 * InitiateTransfer 发起二步转接
 * @param connId
 * @param phoneNumber
 * @return {Promise}
 */
export function twoTelTransfer(connId, phoneNumber) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'InitiateTransfer',
      connId,
      destination: {
        phoneNumber
      }
    }
  })
}

/**
 * CompleteTransfer 完成转接
 * @param connId
 * @param transferConnId
 * @return {Promise}
 */
export function finishConference(connId, transferConnId) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'CompleteTransfer',
      connId,
      transferConnId
    }
  })
}
/**
 * completeConference 完成会议
 * @param connId
 * @param transferConnId
 * @return {Promise}
 */
export function completeConference(connId, transferConnId) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'CompleteConference',
      connId,
      transferConnId
    }
  })
}

/**
 * 转满意度
 * @export
 * @param {*} connId
 * @param g_sAni
 * @param CALLID
 * @param AgentID
 * @param strCustomerID
 * @param strAgentgroupName
 * @returns {Promise}
 */
export function satisfactionDegree(connId, { g_sAni, CALLID, AgentID, strCustomerID, strAgentgroupName }) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'MuteTransfer',
      connId,
      destination: {
        phoneNumber: config.routers.satisfy
      },
      userData: {
        Function: '999',
        functionPoint: '999',
        CALLID,
        AgentID,
        strCustomerID,
        strAgentgroupName, // @tutu 是这样吧？
        g_sAni: g_sAni || 'undefined'
      }
    }
  })
}

/**
 * 两步转接队列
 * @export
 * @param {*} connId
 * @param strNextAgentgroupName
 * @param {*} phoneNumber
 * @returns {Promise}
 */
export function twoTransferTelQueue(connId, strNextAgentgroupName, phoneNumber = config.routers.conferenceTransfer) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'InitiateTransfer',
      connId,
      destination: {
        phoneNumber
      },
      userData: {
        strNextAgentgroupName,
        lenovo_transferTo: 'group',
        Function: '999',
        functionPoint: ''
      }
    }
  })
}

/**
 * 单步转接队列
 * @export
 * @param {*} connId
 * @param strNextAgentgroupName
 * @param {*} phoneNumber
 * @returns {Promise}
 */
export function transferTelQueue(connId, strNextAgentgroupName, phoneNumber = config.routers.transfer) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'MuteTransfer',
      connId,
      destination: {
        phoneNumber
      },
      userData: {
        strNextAgentgroupName,
        lenovo_transferTo: 'group',
        Function: '998',
        functionPoint: '998',
        transferTelQueue: '998'
      }
    }
  })
}

/**
 * 报工号
 * @export
 * @param {*} connId
 * @param IVRAgentID
 * @param {*} phoneNumber
 * @returns {Promise}
 */
export function reportNumber(connId, IVRAgentID, phoneNumber = config.routers.agent) {
  return request({
    url: `/api/v1/me/calls/${getTelToken().id}`,
    data: {
      operationName: 'InitiateConference',
      connId,
      destination: {
        phoneNumber
      },
      userData: {
        Function: '997',
        functionPoint: '997',
        Function1: '997',
        Conference_Type: '1',
        IVRAgentID
      }
    }
  })
}
// 获取分机信息 api/wb/phone/dninfo/{dnNo}
export function getExtensionDistribute(dnNo) {
  return request({
    url: `/api/wb/phone/dninfo/${dnNo}`,
    method: 'get'
  })
}
