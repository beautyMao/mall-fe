import request from '@/utils/request'

// Account - 账号-信息-密码重置
export function getAccountChangePassword(data) {
  return request({
    url: `/api/cube/engineer/account/reset`,
    method: 'post',
    data
  })
}

// Account - 客服密码-忘记
export function getAccountForgetPassword(data) {
  return request({
    url: `/api/open/cube/engineer/password/forget`,
    method: 'post',
    data
  })
}

export function getPasswordInfo(token) {
  return request({
    url: `/api/open/cube/engineer/password/info?token=${token}`,
    method: 'get'
  })
}

// 账号-信息-搜索open
export function getAccountSearch1(data) {
  return request({
    url: `/api/open/cube/engineer/password/search`,
    method: 'post',
    data
  })
}

// 客服密码-修改
export function getPasswordChange(data) {
  return request({
    url: `/api/open/cube/engineer/password/change `,
    method: 'post',
    data
  })
}

// 账号-信息-搜索
export function getAccountSearch(data) {
  return request({
    url: `/api/cube/engineer/account/search`,
    method: 'post',
    data
  })
}

// 账号-信息-创建
export function getAccountCreate(data) {
  return request({
    url: `/api/cube/engineer/account/create`,
    method: 'post',
    data
  })
}

//  角色-信息-列表
export function getRoleLists() {
  return request({
    url: `/api/cube/engineer/role/lists`,
    method: 'get'
  })
}

// 获取业务
export function getStructureBusiness(boo = 0) {
  return request({
    url: `/api/wb/structureBusiness?search=${boo}`,
    method: 'get'
  })
}
// 获取通路
export function getStructureAccess() {
  return request({
    url: `/api/wb/access`,
    method: 'get'
  })
}

// 账号-信息-创建
export function getBusinessQueues(data) {
  return request({
    url: `/api/wb/queue/accessBusinessQueues`,
    method: 'post',
    data
  })
}

// 客服账号-删除[批量]
export function getAccountDelete(data) {
  return request({
    url: `/api/cube/engineer/account/delete`,
    method: 'post',
    data
  })
}

// 客服账号-详情
export function getAccountInfo(code) {
  return request({
    url: `/api/cube/engineer/account/info?code=${code}`,
    method: 'get'
  })
}
export function getAccountInfo1() {
  return request({
    url: `/api/cube/engineer/account/info`,
    method: 'get'
  })
}

// 客服账号-编辑
export function getAccountEdit(data) {
  return request({
    url: `/api/cube/engineer/account/edit`,
    method: 'post',
    data
  })
}
