import request from '@/utils/request'

// 接触记录精确查询
export function getListInfo(id) {
  return request({
    url: `/api/wb/IR/GetIRInfoByIRID?IRID=${id}&PageIndex=1&PageSize=1`,
    method: 'get'
  })
}

// 接触记录条件查询
export function getListInfo1(data) {
  return request({
    url: `/api/wb/IR/GetIRListByQC`,
    method: 'post',
    data
  })
}

// 接触记录 接触方式
export function getIRContactType() {
  return request({
    url: `/api/wb/IR/GetIRContactType`,
    method: 'get'
  })
}

// 接触记录详情
export function getDetailInfo(id, type) {
  return request({
    url: `/api/wb/IR/GetIRDetailInfoByIRID?IRID=${id}&client_type=${type}`,
    method: 'get'
  })
}

// 工程师
export function getSearchEngineer(id) {
  return request({
    url: `/api/wb/IR/SearchEngineer?code=${id}`,
    method: 'get'
  })
}
