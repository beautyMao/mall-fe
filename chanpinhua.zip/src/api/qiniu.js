import axios from 'axios'
import { getQiniuToken, getToken } from '@/utils/auth'
import { CUBE } from '@/configuration'

// eslint-disable-next-line no-unused-vars
export const QINIU_HOST = CUBE.api.oss
export const QINIU_IMAGEVIEW = '?imageView2/2/w/1920/h/1000/q/80'
export const QINIU_ACTION = CUBE.api.upload

/**
 * 七牛上传图片
 * @param file
 * @param qiNiuToken
 * @param qiNiuHost
 * @link https://developer.qiniu.com/kodo/kb/1326/how-to-upload-photos-to-seven-niuyun-base64-code
 * @link http://kb-static.qiniucdn.com/base64-demo.html
 * @return {Promise<any>}
 */
export function uploadImgByBase64(file, qiNiuToken = getQiniuToken(), qiNiuHost = QINIU_HOST) {
  const date = new Date()
  const rand = (Math.random().toString().substr(3, 20) + Date.now()).toString(36)
  const index = file.name.indexOf('.') // 得到"."在第几位
  const imgType = file.name.substring(index) // 截断"."之前的，得到后缀

  const param = new FormData() // 创建form对象
  param.append('token', qiNiuToken)
  param.append('file', file)
  param.append('key', 'cube/Image/' + date.getFullYear() + (date.getMonth() + 1) + '/' + rand + imgType)

  // 添加请求头
  const config = {
    // headers: { 'Content-Type': 'multipart/form-data' }
    headers: { 'Content-Type': 'application/octet-stream' }
  }

  return new Promise((resolve, reject) => {
    // todo recommend: request method replace axios
    axios({
      method: 'POST',
      url: 'https://up-z1.qiniup.com',
      data: param,
      contentType: config
    }).then(response => {
      resolve({
        response,
        url: qiNiuHost + response.data.key
      })
    }).catch(err => {
      reject(err)
    })
  })
}

/**
 * 上传资源，通过七牛直接上传方式
 * @param blobFile
 * @param qiNiuToken
 * @param qiNiuHost
 * @return {Promise<any>}
 */
export function uploadFile(blobFile, qiNiuToken = getQiniuToken(), qiNiuHost = QINIU_HOST) {
  const date = new Date()
  const rand = (Math.random().toString().substr(3, 20) + Date.now()).toString(36)
  const fileType = blobFile.type.split('/')[1]

  const param = new FormData() // 创建form对象
  param.append('token', qiNiuToken)
  param.append('file', blobFile)
  param.append('key', `cube/Image/${date.getFullYear()}${date.getMonth() + 1}/${rand}.${fileType}`)

  // 添加请求头
  const config = {
    headers: { 'Content-Type': 'multipart/form-data' }
  }

  return new Promise((resolve, reject) => {
    // todo recommend: request method replace axios
    axios({
      method: 'POST',
      url: 'https://up-z1.qiniup.com',
      data: param,
      contentType: config
    }).then(response => {
      resolve({
        response,
        url: qiNiuHost + response.data.key
      })
    }).catch(err => {
      reject(err)
    })
  })
}

// // 只针对存储在七牛上的内容做图片处理： cube.lenovo
// https://developer.qiniu.com/dora/manual/1279/basic-processing-images-imageview2
// this.message.content + '?imageView2/2/w/1000/h/1000/q/75'

/**
 * 使用魔方接口，上传资源
 * @param blobFile
 * @return {Promise<any>}
 */
export function cubeUploadFile(blobFile) {
  const date = new Date()
  const rand = (Math.random().toString().substr(3, 20) + Date.now()).toString(36)
  const fileType = blobFile.type.split('/')[1]

  const param = new FormData() // 创建form对象
  param.append('file', blobFile)
  param.append('key', `cube/Image/${date.getFullYear()}${date.getMonth() + 1}/${rand}.${fileType}`)

  // 添加请求头
  const config = {
    method: 'POST',
    url: `/api/wb/image/up`,
    data: param,
    headers: {
      'Content-Type': 'multipart/form-data',
      'Authorization': `Bearer ${getToken()}`
    }
  }

  // todo qiNiuHost replace ?
  return new Promise((resolve, reject) => {
    // todo recommend: request method replace axios
    axios(config).then(response => {
      resolve({
        url: response.data.data.picUrl
      })
    }).catch(err => {
      reject(err)
    })
  })
}
