## 关于自定义主题

> https://element.eleme.cn/#/zh-CN/component/custom-theme

使用了官方的主题定制工具，可以快速使用`config.json` 来恢复编辑。

###关于`cascader` 组件

由于官方的生成器可能存在版本差异，产生的样式文件未包含`cascader-panel` 的样式。
并且部分样式有误，所以魔方下的样式采用移植的方式修复了`cascader` 样式问题。
移植来源于`element-ui/lib/theme-chalk/index.css`。