# 魔方产品化 工作台

## 快速开始

### host

  10.120.17.56 imccdev.lenovo.com.cn

### 开发

```bash
# 安装依赖
npm install

# 建议不要直接使用 cnpm 安装以来，会有各种诡异的 bug。可以通过如下操作解决 npm 下载速度慢的问题
npm install --registry=https://registry.npm.taobao.org

# 启动服务
npm run dev
```

浏览器访问 http://localhost:9527

### 发布

```bash
# 构建测试环境
npm run build:stage

# 构建生产环境
npm run build:prod
```

### 其它

```bash
# 预览发布环境效果
npm run preview

# 预览发布环境效果 + 静态资源分析
npm run preview -- --report

# 代码格式检查
npm run lint

# 代码格式检查并自动修复
npm run lint -- --fix
```

更多信息请参考 [使用文档](https://panjiachen.github.io/vue-element-admin-site/zh/)

## Saas 配置信息
针对Saas 商户，后端提供了配置获取接口`/api/config.js`，将按照以下顺序加载：
- 优先使用window 下的通过scripts 加载的属性
- 其次使用本地的env 配置信息
- 最后使用default configuration

